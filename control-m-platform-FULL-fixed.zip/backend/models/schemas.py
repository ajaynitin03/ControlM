from pydantic import BaseModel
from typing import List, Optional, Dict, Any


class JobRecord(BaseModel):
    """
    NOTE (CHANGE 4): Criticality is intentionally NOT an input field here.
    Control-M exports do not provide High/Medium/Low — only an optional
    Priority. Criticality is always derived by services/criticality_engine.py
    after the dependency graph is built, never accepted from uploaded data.
    """
    JobId: str
    JobName: str
    AppName: Optional[str] = ""
    SubApplication: Optional[str] = ""
    Platform: Optional[str] = ""
    Schedule: Optional[str] = ""
    Predecessors: Optional[str] = ""
    Successors: Optional[str] = ""
    Priority: Optional[str] = ""
    Runtime: Optional[str] = ""
    Owner: Optional[str] = ""
    Description: Optional[str] = ""
    Status: Optional[str] = ""
    Folder: Optional[str] = ""
    OrderMethod: Optional[str] = ""
    MaxWaitTime: Optional[str] = ""
    Retries: Optional[str] = ""


class UploadResponse(BaseModel):
    success: bool
    message: str
    row_count: int
    columns: List[str]
    preview: List[Dict[str, Any]]
    session_id: str
    execution_history_merged: Optional[bool] = False


class GraphRequest(BaseModel):
    session_id: str
    job_ids: List[str]
    depth: Optional[int] = 3


class CriticalityFactor(BaseModel):
    factor: str
    detail: str
    points: int
    triggered: bool


class GraphNode(BaseModel):
    id: str
    label: str
    criticality: str               # legacy HIGH/MEDIUM/LOW, derived (CHANGE 4)
    criticality_band: Optional[str] = "Low"     # Low/Medium/High/Critical (CHANGE 5)
    criticality_score: Optional[int] = 0
    criticality_factors: Optional[List[CriticalityFactor]] = None
    criticality_reason: Optional[str] = ""
    app_name: str
    platform: str
    schedule: str
    runtime: str
    owner: str
    status: str
    fan_in: int
    fan_out: int
    is_critical_path: bool


class GraphEdge(BaseModel):
    source: str
    target: str


class GraphResponse(BaseModel):
    nodes: List[GraphNode]
    edges: List[GraphEdge]
    has_cycles: bool
    cycle_details: List[List[str]]
    critical_path: List[str]
    session_id: str


class ImpactRequest(BaseModel):
    session_id: str
    job_id: str


class ImpactResponse(BaseModel):
    failed_job: str
    affected_jobs: List[str]
    affected_count: int
