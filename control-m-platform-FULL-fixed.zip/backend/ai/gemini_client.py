"""
Gemini API client — uses google.genai (the new SDK).
Handles rate limiting, retries, token budgeting, and structured JSON output.
Model: gemini-2.0-flash-lite (Gemini 3.1 Lite). Fallback: gemini-2.0-flash.
Spec: 15s timeout, 2 retries, JSON validation mandatory.
"""

from __future__ import annotations
import json, os, re, socket, time, logging, ssl
from typing import Any

# Global SSL bypass to resolve corporate network proxy / certification issues
try:
    ssl._create_default_https_context = ssl._create_unverified_context
except Exception:
    pass

logger = logging.getLogger(__name__)

_CLIENT = None
# Use a single well-known, stable model. No live probe needed at startup.
# The google-genai SDK accepts these model names (as of 2025).
# ── Configure your model here ─────────────────────────────────────
# Set this to whichever Gemini model is live in your project.
# Current recommendation: gemini-2.0-flash-lite (maps to "Gemini 2.0 Flash Lite" / 3.1-lite in Studio)
_MODEL_NAME = "gemini-2.0-flash-lite-001"

# Per-call HTTP timeout (seconds).
_REQUEST_TIMEOUT_SECONDS = 30

# Cache so repeated calls in the same process don't all pay the same
# connectivity probe cost when the network is known to be blocked.
_connectivity_checked = False
_connectivity_ok = True


def _gemini_reachable() -> bool:
    """
    Fast TCP-level reachability probe for Google's Gemini API host.
    Cached per process — resets on server restart.
    """
    global _connectivity_checked, _connectivity_ok
    if _connectivity_checked:
        return _connectivity_ok
    try:
        sock = socket.create_connection(("generativelanguage.googleapis.com", 443), timeout=5)
        sock.close()
        _connectivity_ok = True
        logger.info("[Gemini] Network probe: generativelanguage.googleapis.com is reachable.")
    except Exception as e:
        logger.warning(f"[Gemini] generativelanguage.googleapis.com unreachable: {e}")
        _connectivity_ok = False
    _connectivity_checked = True
    return _connectivity_ok


def reset_connectivity_check():
    """Allow re-probing connectivity (e.g. after a user retries following a network fix)."""
    global _connectivity_checked
    _connectivity_checked = False


def _get_client():
    """Lazily initialize the google.genai client. Does NOT make a live API call."""
    global _CLIENT
    if _CLIENT is not None:
        return _CLIENT
    try:
        import google.genai as genai
        api_key = os.environ.get("GEMINI_API_KEY", "")
        if not api_key:
            raise ValueError("GEMINI_API_KEY environment variable not set")
        _CLIENT = genai.Client(api_key=api_key)
        logger.info(f"[Gemini] Client initialized. Default model: {_MODEL_NAME}")
    except ImportError:
        logger.error("[Gemini] google.genai not installed. Run: pip install google-genai")
        raise
    except Exception as e:
        logger.error(f"[Gemini] Client init failed: {e}")
        raise
    return _CLIENT


class GeminiUnreachableError(RuntimeError):
    """Raised when the network appears to block Gemini entirely."""
    pass


def call_gemini(
    prompt: str,
    expect_json: bool = True,
    retries: int = 2,
    delay: float = 2.0,
) -> Any:
    """
    Call Gemini with retry + JSON extraction.
    Returns parsed dict/list if expect_json=True, else raw string.

    Raises GeminiUnreachableError fast (no retries) if a coarse network
    probe indicates the Gemini host is unreachable.
    """
    if not _gemini_reachable():
        raise GeminiUnreachableError(
            "Cannot reach generativelanguage.googleapis.com. This usually means the "
            "network is blocking or SSL-intercepting Google's API. Check with your "
            "network/security team about allowing this host, or use an approved proxy."
        )

    client = _get_client()
    last_err = None

    # Model fallback order — all valid public models as of mid-2025
    # Try primary first, fall back to full flash variant on repeated failures
    model_candidates = [_MODEL_NAME, "gemini-2.0-flash-001"]

    for attempt in range(retries):
        # Try primary model first, then cycle through fallbacks on repeated failures
        model = model_candidates[min(attempt, len(model_candidates) - 1)]
        try:
            response = client.models.generate_content(
                model=model,
                contents=prompt,
                # Spec mandates 15-second timeout per call
                config={"http_options": {"timeout": 15}},
            )
            text = response.text.strip()

            if not expect_json:
                return text

            return _extract_json(text)

        except Exception as e:
            last_err = e
            logger.warning(f"[Gemini] Attempt {attempt+1} failed (model={model}): {e}")
            if attempt < retries - 1:
                time.sleep(delay * (attempt + 1))

    raise RuntimeError(f"Gemini call failed after {retries} attempts: {last_err}")


def _extract_json(text: str) -> Any:
    """Extract JSON from Gemini response, handling markdown code fences."""
    # Remove ```json ... ``` or ``` ... ```
    cleaned = re.sub(r"```(?:json)?\s*", "", text)
    cleaned = re.sub(r"```\s*$", "", cleaned).strip()

    # Try direct parse
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        pass

    # Try finding first JSON object or array
    for pattern in [r"\{[\s\S]*\}", r"\[[\s\S]*\]"]:
        m = re.search(pattern, cleaned)
        if m:
            try:
                return json.loads(m.group())
            except json.JSONDecodeError:
                pass

    # Last resort: return as text wrapped in dict
    logger.warning("[Gemini] Could not parse JSON from response, returning raw text")
    return {"raw_response": text, "parse_error": True}


def is_available() -> bool:
    """Check if Gemini API key is configured. Does NOT verify network reachability —
    use _gemini_reachable() / the /api/ai/status endpoint for that."""
    return bool(os.environ.get("GEMINI_API_KEY", ""))
