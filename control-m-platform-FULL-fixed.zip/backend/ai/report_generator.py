"""
Report generator — produces Excel and JSON reports from assessment data.
Uses openpyxl for professional Excel output.
"""

from __future__ import annotations
import io, json
from datetime import datetime
from typing import Any

import pandas as pd

try:
    import openpyxl
    from openpyxl.styles import (
        Font, PatternFill, Alignment, Border, Side
    )
    from openpyxl.utils import get_column_letter
    OPENPYXL_OK = True
except ImportError:
    OPENPYXL_OK = False


# ── Color palette ──────────────────────────────────────────────────
COL = {
    "header_bg":  "1E3A5F",   # navy
    "header_fg":  "FFFFFF",
    "alt_row":    "F0F4FA",
    "high_bg":    "FFDEDE",
    "high_fg":    "8B0000",
    "medium_bg":  "FFF3CD",
    "medium_fg":  "7B4B00",
    "low_bg":     "D4EDDA",
    "low_fg":     "155724",
    "critical_bg":"FFB3B3",
    "critical_fg":"660000",
    "section_bg": "E8F0FE",
    "section_fg": "1A237E",
    "border":     "BCC8D8",
}

THIN_BORDER = None  # initialized lazily


def _border():
    global THIN_BORDER
    if THIN_BORDER is None and OPENPYXL_OK:
        s = Side(style="thin", color=COL["border"])
        THIN_BORDER = Border(left=s, right=s, top=s, bottom=s)
    return THIN_BORDER


def _hfont(**kw):
    return Font(bold=True, color=COL["header_fg"], name="Calibri", size=10, **kw)

def _fill(hex_color: str) -> PatternFill:
    return PatternFill("solid", fgColor=hex_color)

def _cell(ws, row, col, value, bold=False, bg=None, fg=None, wrap=False, size=10):
    c = ws.cell(row=row, column=col, value=value)
    c.font = Font(bold=bold, color=fg or "000000", name="Calibri", size=size)
    if bg:
        c.fill = _fill(bg)
    c.alignment = Alignment(vertical="top", wrap_text=wrap, horizontal="left")
    c.border    = _border()
    return c


# ══════════════════════════════════════════════════════════════════
def generate_excel_report(
    bulk_assessments:   list[dict],
    source_analyses:    list[dict],
    modernization_data: list[dict],
    risk_data:          list[dict],
    executive_summary:  dict,
    session_meta:       dict,
) -> bytes:
    """Generate full multi-sheet Excel report. Returns bytes."""
    if not OPENPYXL_OK:
        return _fallback_csv(bulk_assessments)

    wb = openpyxl.Workbook()
    wb.remove(wb.active)   # remove default sheet

    _sheet_cover(wb, executive_summary, session_meta)
    _sheet_bulk_assessment(wb, bulk_assessments)
    _sheet_source_analysis(wb, source_analyses)
    _sheet_modernization(wb, modernization_data)
    _sheet_risk(wb, risk_data)
    _sheet_summary_charts(wb, bulk_assessments, risk_data)

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf.read()


# ── Sheet 1: Cover / Executive Summary ────────────────────────────
def _sheet_cover(wb, summary: dict, meta: dict):
    ws = wb.create_sheet("Executive Summary")
    ws.sheet_view.showGridLines = False

    def big(row, col, val, size=14, bold=True, bg=None, fg="1E3A5F"):
        c = ws.cell(row=row, column=col, value=val)
        c.font = Font(bold=bold, size=size, color=fg, name="Calibri")
        if bg: c.fill = _fill(bg)
        c.alignment = Alignment(wrap_text=True, vertical="top")
        return c

    ws.column_dimensions["A"].width = 6
    ws.column_dimensions["B"].width = 30
    ws.column_dimensions["C"].width = 80

    row = 2
    big(row, 2, "BATCH MODERNIZATION ASSESSMENT", size=18, bg="1E3A5F", fg="FFFFFF")
    ws.cell(row, 2).fill = _fill("1E3A5F")
    ws.cell(row, 3).fill = _fill("1E3A5F")
    ws.merge_cells(f"B{row}:C{row}")
    ws.row_dimensions[row].height = 36
    row += 1

    big(row, 2, f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}", size=10, bold=False, fg="555555")
    big(row, 3, f"File: {meta.get('filename','N/A')} | Jobs: {meta.get('total_jobs',0)}", size=10, bold=False, fg="555555")
    row += 2

    # Headline
    if summary.get("headline"):
        big(row, 2, summary["headline"], size=13, bg="E8F0FE")
        ws.merge_cells(f"B{row}:C{row}")
        ws.row_dimensions[row].height = 28
        row += 1

    # Executive summary text
    if summary.get("executive_summary"):
        ws.cell(row, 2, "SUMMARY").font = Font(bold=True, size=11, color="1E3A5F")
        row += 1
        c = ws.cell(row, 2, summary["executive_summary"])
        c.alignment = Alignment(wrap_text=True, vertical="top")
        c.font      = Font(size=10, name="Calibri")
        ws.merge_cells(f"B{row}:C{row}")
        ws.row_dimensions[row].height = 90
        row += 2

    # Key findings
    if summary.get("key_findings"):
        ws.cell(row, 2, "KEY FINDINGS").font = Font(bold=True, size=11, color="1E3A5F", name="Calibri")
        row += 1
        for f in summary["key_findings"]:
            c = ws.cell(row, 2, f"• {f}")
            c.font = Font(size=10, name="Calibri")
            ws.merge_cells(f"B{row}:C{row}")
            row += 1
        row += 1

    # Strategic recommendations
    if summary.get("strategic_recommendations"):
        ws.cell(row, 2, "STRATEGIC RECOMMENDATIONS").font = Font(bold=True, size=11, color="1E3A5F")
        row += 1
        for rec in summary["strategic_recommendations"]:
            pri = rec.get("priority", "")
            ws.cell(row, 2, f"Priority {pri}: {rec.get('recommendation','')}")
            ws.cell(row, 2).font = Font(bold=True, size=10, color="1E3A5F", name="Calibri")
            row += 1
            ws.cell(row, 3, f"Value: {rec.get('business_value','')} | Timeline: {rec.get('timeline','')}")
            ws.cell(row, 3).font = Font(size=9, color="555555", name="Calibri")
            row += 1
        row += 1

    # Roadmap
    rm = summary.get("modernization_roadmap", {})
    if rm:
        ws.cell(row, 2, "MODERNIZATION ROADMAP").font = Font(bold=True, size=11, color="1E3A5F")
        row += 1
        for phase, desc in rm.items():
            ws.cell(row, 2, phase.upper()).font = Font(bold=True, size=10, color="155724", name="Calibri")
            ws.cell(row, 2).fill = _fill("D4EDDA")
            ws.cell(row, 3, desc).font = Font(size=10, name="Calibri")
            row += 1


# ── Sheet 2: Bulk Assessment ───────────────────────────────────────
def _sheet_bulk_assessment(wb, data: list[dict]):
    ws  = wb.create_sheet("Bulk Assessment")
    hdr = ["Job ID","Job Type","File Operations","DB Operations",
           "Utility Usage","Output Artifacts","Complexity","Mod. Score","Candidate","Reason"]
    widths = [18, 14, 22, 22, 18, 22, 12, 10, 10, 40]
    _write_header(ws, hdr, widths)

    for i, row in enumerate(data, start=2):
        vals = [
            row.get("job_id",""),
            row.get("job_type",""),
            row.get("file_operations",""),
            row.get("db_operations",""),
            row.get("utility_usage",""),
            row.get("output_artifacts",""),
            row.get("migration_complexity",""),
            row.get("modernization_score",""),
            row.get("modernization_candidate",""),
            row.get("brief_reason",""),
        ]
        _write_row(ws, i, vals)
        _color_complexity_row(ws, i, len(hdr), row.get("migration_complexity",""))


# ── Sheet 3: Source Analysis ───────────────────────────────────────
def _sheet_source_analysis(wb, data: list[dict]):
    ws  = wb.create_sheet("Source Analysis")
    hdr = ["Job ID","Tables","Views","Stored Procs","Inner Joins","Left Joins",
           "File Reads","File Writes","FTP","SFTP","MQ","Error Handling","Restart Quality","Hardcoded Creds"]
    widths = [16,26,20,20,10,10,22,22,7,7,7,16,16,14]
    _write_header(ws, hdr, widths)

    for i, row in enumerate(data, start=2):
        joins = row.get("joins", {})
        eh    = row.get("error_handling", {})
        rl    = row.get("restart_logic", {})
        vals  = [
            row.get("job_id",""),
            ", ".join(row.get("tables_used",[])),
            ", ".join(row.get("views_used",[])),
            ", ".join(row.get("stored_procedures",[])),
            joins.get("inner",0),
            joins.get("left",0),
            ", ".join(row.get("file_reads",[])),
            ", ".join(row.get("file_writes",[])),
            "Yes" if row.get("ftp_usage") else "No",
            "Yes" if row.get("sftp_usage") else "No",
            "Yes" if row.get("mq_usage") else "No",
            eh.get("quality",""),
            rl.get("restart_quality",""),
            "⚠ YES" if row.get("hardcoded_credentials") else "No",
        ]
        _write_row(ws, i, vals)
        # Flag hardcoded creds in red
        if row.get("hardcoded_credentials"):
            ws.cell(i, len(hdr)).fill = _fill(COL["critical_bg"])
            ws.cell(i, len(hdr)).font = Font(bold=True, color=COL["critical_fg"])


# ── Sheet 4: Modernization ─────────────────────────────────────────
def _sheet_modernization(wb, data: list[dict]):
    ws  = wb.create_sheet("Modernization Plan")
    hdr = ["Job ID","Current Tech","Current Scheduler","Recommended Tech",
           "Recommended Scheduler","Complexity","Est. Days","Benefits","Migration Steps","Reasoning"]
    widths = [16,14,16,16,18,12,10,30,30,50]
    _write_header(ws, hdr, widths)

    for i, row in enumerate(data, start=2):
        vals = [
            row.get("job_id",""),
            row.get("current_technology",""),
            row.get("current_scheduler",""),
            row.get("recommended_technology",""),
            row.get("recommended_scheduler",""),
            row.get("migration_complexity",""),
            row.get("estimated_effort_days",""),
            "\n".join(f"• {b}" for b in row.get("modernization_benefits",[])),
            "\n".join(f"{j+1}. {s}" for j,s in enumerate(row.get("migration_steps",[]))),
            row.get("reasoning",""),
        ]
        _write_row(ws, i, vals, wrap=True)
        _color_complexity_row(ws, i, len(hdr), row.get("migration_complexity",""))
        ws.row_dimensions[i].height = max(40, len(row.get("migration_steps",[])) * 14)


# ── Sheet 5: Risk Assessment ───────────────────────────────────────
def _sheet_risk(wb, data: list[dict]):
    ws  = wb.create_sheet("Risk Assessment")
    hdr = ["Job ID","Risk Level","Dep. Risk","Data Risk","Op. Risk",
           "Risk Factors","Migration Recommendation","Pre-Migration Actions"]
    widths = [16,12,12,12,12,40,36,36]
    _write_header(ws, hdr, widths)

    for i, row in enumerate(data, start=2):
        factors_text = "\n".join(
            f"• [{f.get('severity','')}] {f.get('factor','')}: {f.get('description','')}"
            for f in row.get("risk_factors", [])
        )
        vals = [
            row.get("job_id",""),
            row.get("risk_level",""),
            row.get("dependency_risk",""),
            row.get("data_risk",""),
            row.get("operational_risk",""),
            factors_text,
            row.get("migration_recommendation",""),
            "\n".join(f"• {a}" for a in row.get("pre_migration_actions",[])),
        ]
        _write_row(ws, i, vals, wrap=True)
        _color_risk_row(ws, i, len(hdr), row.get("risk_level",""))
        ws.row_dimensions[i].height = max(30, len(row.get("risk_factors",[])) * 18)


# ── Sheet 6: Summary stats ─────────────────────────────────────────
def _sheet_summary_charts(wb, bulk: list[dict], risk: list[dict]):
    ws = wb.create_sheet("Summary Statistics")
    ws.sheet_view.showGridLines = False
    ws.column_dimensions["A"].width = 3
    ws.column_dimensions["B"].width = 32
    ws.column_dimensions["C"].width = 18

    def section(row, title):
        c = ws.cell(row, 2, title)
        c.font = Font(bold=True, size=12, color=COL["section_fg"], name="Calibri")
        c.fill = _fill(COL["section_bg"])
        ws.merge_cells(f"B{row}:C{row}")
        ws.row_dimensions[row].height = 22
        return row + 1

    def stat(row, label, value, bg=None):
        lc = ws.cell(row, 2, label)
        vc = ws.cell(row, 3, value)
        lc.font = Font(size=10, name="Calibri")
        vc.font = Font(bold=True, size=10, name="Calibri")
        if bg:
            lc.fill = _fill(bg)
            vc.fill = _fill(bg)
        return row + 1

    r = 2
    r = section(r, "📊 JOB ASSESSMENT OVERVIEW")

    # complexity
    comp = {}
    for b in bulk:
        k = b.get("migration_complexity","Unknown")
        comp[k] = comp.get(k,0) + 1
    r = stat(r, "Total Jobs Assessed", len(bulk))
    r = stat(r, "High Complexity",   comp.get("High",0),   COL["high_bg"])
    r = stat(r, "Medium Complexity", comp.get("Medium",0), COL["medium_bg"])
    r = stat(r, "Low Complexity",    comp.get("Low",0),    COL["low_bg"])

    r += 1
    r = section(r, "🔴 RISK DISTRIBUTION")
    risk_dist = {}
    for rv in risk:
        k = rv.get("risk_level","Unknown")
        risk_dist[k] = risk_dist.get(k,0) + 1
    for lvl, bg in [("Critical",COL["critical_bg"]),("High",COL["high_bg"]),
                     ("Medium",COL["medium_bg"]),("Low",COL["low_bg"])]:
        r = stat(r, f"{lvl} Risk Jobs", risk_dist.get(lvl,0), bg)

    r += 1
    r = section(r, "⚙️ JOB TYPE DISTRIBUTION")
    jtypes = {}
    for b in bulk:
        k = b.get("job_type","Unknown")
        jtypes[k] = jtypes.get(k,0) + 1
    for jt, cnt in sorted(jtypes.items(), key=lambda x:-x[1]):
        r = stat(r, jt, cnt)

    r += 1
    scores = [b.get("modernization_score",0) for b in bulk if isinstance(b.get("modernization_score"),(int,float))]
    if scores:
        r = section(r, "📈 MODERNIZATION SCORES")
        r = stat(r, "Average Score", f"{sum(scores)/len(scores):.1f} / 10")
        r = stat(r, "Max Score", f"{max(scores)} / 10")
        r = stat(r, "Min Score", f"{min(scores)} / 10")
        high_need = sum(1 for s in scores if s >= 7)
        r = stat(r, "High Modernization Need (≥7)", high_need, COL["high_bg"])


# ── Helpers ───────────────────────────────────────────────────────
def _write_header(ws, headers: list[str], widths: list[int]):
    for j, (h, w) in enumerate(zip(headers, widths), start=1):
        c = ws.cell(1, j, h.upper())
        c.font      = _hfont()
        c.fill      = _fill(COL["header_bg"])
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        c.border    = _border()
        ws.column_dimensions[get_column_letter(j)].width = w
    ws.row_dimensions[1].height = 28
    ws.freeze_panes = "A2"


def _write_row(ws, row: int, values: list, wrap: bool = False):
    alt = row % 2 == 0
    for j, v in enumerate(values, start=1):
        c = ws.cell(row, j, v)
        c.font      = Font(size=9, name="Calibri")
        c.alignment = Alignment(vertical="top", wrap_text=wrap, horizontal="left")
        c.border    = _border()
        if alt:
            c.fill = _fill(COL["alt_row"])


def _color_complexity_row(ws, row: int, ncols: int, complexity: str):
    mapping = {"High": (COL["high_bg"], COL["high_fg"]),
               "Medium": (COL["medium_bg"], COL["medium_fg"]),
               "Low": (COL["low_bg"], COL["low_fg"])}
    bg, fg = mapping.get(complexity, (None, None))
    if not bg: return
    for col in range(1, ncols + 1):
        c = ws.cell(row, col)
        if c.value in [complexity]:   # only the complexity cell gets text color
            c.fill = _fill(bg)
            c.font = Font(bold=True, size=9, color=fg, name="Calibri")
        else:
            # subtle tint
            pass


def _color_risk_row(ws, row: int, ncols: int, risk_level: str):
    mapping = {
        "Critical": (COL["critical_bg"], COL["critical_fg"]),
        "High":     (COL["high_bg"],     COL["high_fg"]),
        "Medium":   (COL["medium_bg"],   COL["medium_fg"]),
        "Low":      (COL["low_bg"],      COL["low_fg"]),
    }
    bg, fg = mapping.get(risk_level, (None, None))
    if not bg: return
    # Color only the risk level cell (col 2)
    c = ws.cell(row, 2)
    c.fill = _fill(bg)
    c.font = Font(bold=True, size=9, color=fg, name="Calibri")


def _fallback_csv(data: list[dict]) -> bytes:
    """Fallback if openpyxl not available."""
    if not data:
        return b"No data"
    df = pd.DataFrame(data)
    return df.to_csv(index=False).encode()


def generate_redesigned_excel_report(session: dict) -> bytes:
    """
    Generate the redesigned Batch Assessment Report containing 5 sheets:
    1. Phase 1 Schedule Analysis
    2. High Level Assessment
    3. Detailed AI Analysis
    4. Risk & Modernization
    5. Job Conversion Summary
    """
    if not OPENPYXL_OK:
        return b"Excel report requires openpyxl"

    wb = openpyxl.Workbook()
    wb.remove(wb.active)  # remove default sheet

    # ════════════════════════════════════════════════════════════════
    # SHEET 1 — Phase 1 Schedule Analysis
    # ════════════════════════════════════════════════════════════════
    ws1 = wb.create_sheet("Schedule Analysis")
    hdr1 = [
        "Job ID", "Job Name", "Application", "Platform", "Criticality",
        "Criticality Score", "Criticality Reason", "Critical Path",
        "Fan In", "Fan Out", "Avg Runtime (Secs)"
    ]
    w1 = [18, 25, 18, 12, 12, 10, 35, 12, 10, 10, 15]
    ws1.sheet_view.showGridLines = True
    _write_header(ws1, hdr1, w1)

    jobs = session.get("jobs", [])
    analysis = session.get("phase1_analysis") or {}
    crit_map = analysis.get("criticality_map", {})
    graph = session.get("graph")
    crit_path_jobs = set(analysis.get("critical_path", []))

    for r_idx, job in enumerate(jobs, start=2):
        jid = job.get("JobId", "")
        crit = crit_map.get(jid, {})
        fan_in = len(list(graph.predecessors(jid))) if graph and jid in graph else 0
        fan_out = len(list(graph.successors(jid))) if graph and jid in graph else 0
        on_crit_path = "Yes" if jid in crit_path_jobs else "No"
        
        row_vals = [
            jid,
            job.get("JobName", ""),
            job.get("AppName", "Unknown"),
            job.get("Platform", "Unknown"),
            crit.get("band", "Low"),
            crit.get("score", 0),
            crit.get("reason", "Standard Execution"),
            on_crit_path,
            fan_in,
            fan_out,
            job.get("Runtime", 0)
        ]
        _write_row(ws1, r_idx, row_vals)
        _color_complexity_row(ws1, r_idx, len(hdr1), crit.get("band", "Low"))

    # ════════════════════════════════════════════════════════════════
    # SHEET 2 — High Level Assessment
    # ════════════════════════════════════════════════════════════════
    ws2 = wb.create_sheet("High Level Assessment")
    hdr2 = [
        "Job ID", "Job Name", "Application", "Job Type", "File Operations",
        "DB Operations", "Utilities", "Output Produced", "Risk Indicator",
        "Modernization Recommendation"
    ]
    w2 = [18, 25, 18, 12, 22, 22, 18, 22, 12, 25]
    ws2.sheet_view.showGridLines = True
    _write_header(ws2, hdr2, w2)
    
    high_level_assessments = session.get("high_level_assessments", {})
    for r_idx, job in enumerate(jobs, start=2):
        jid = job.get("JobId", "")
        hl = high_level_assessments.get(jid, {})
        row_vals = [
            jid,
            job.get("JobName", ""),
            job.get("AppName", "Unknown"),
            hl.get("job_type", job.get("Platform", "Unknown")),
            hl.get("file_operations", "None"),
            hl.get("db_operations", "None"),
            hl.get("utilities", "None"),
            hl.get("output_produced", "None"),
            hl.get("risk_indicator", "LOW"),
            hl.get("modernization_recommendation", "Shell -> Python")
        ]
        _write_row(ws2, r_idx, row_vals)
        _color_risk_row(ws2, r_idx, len(hdr2), hl.get("risk_indicator", "LOW"))

    # ════════════════════════════════════════════════════════════════
    # SHEET 3 — Detailed AI Analysis
    # ════════════════════════════════════════════════════════════════
    ws3 = wb.create_sheet("Detailed AI Analysis")
    hdr3 = [
        "Job ID", "Tables", "Views", "Reference Tables", "Functions",
        "Stored Procedures", "Inner Joins", "Outer Joins", "Left Joins",
        "Right Joins", "File Operations", "DB Operations", "Utilities",
        "Error Handling", "Restart Logic", "Retry Logic", "Checkpoint Logic",
        "Failure Recovery", "Detailed Technical Assessment"
    ]
    w3 = [18, 20, 18, 18, 18, 18, 20, 20, 20, 20, 22, 22, 18, 25, 25, 25, 25, 25, 45]
    ws3.sheet_view.showGridLines = True
    _write_header(ws3, hdr3, w3)
    
    detailed_ai_cache = session.get("detailed_ai_cache", {})
    for r_idx, job in enumerate(jobs, start=2):
        jid = job.get("JobId", "")
        da = detailed_ai_cache.get(jid, {})
        joins = da.get("joins", {})
        
        inner_j = ", ".join(joins.get("inner", [])) if isinstance(joins, dict) else ""
        outer_j = ", ".join(joins.get("outer", [])) if isinstance(joins, dict) else ""
        left_j = ", ".join(joins.get("left", [])) if isinstance(joins, dict) else ""
        right_j = ", ".join(joins.get("right", [])) if isinstance(joins, dict) else ""
        
        row_vals = [
            jid,
            ", ".join(da.get("tables", [])) if isinstance(da.get("tables"), list) else da.get("tables", ""),
            ", ".join(da.get("views", [])) if isinstance(da.get("views"), list) else da.get("views", ""),
            ", ".join(da.get("reference_tables", [])) if isinstance(da.get("reference_tables"), list) else da.get("reference_tables", ""),
            ", ".join(da.get("functions", [])) if isinstance(da.get("functions"), list) else da.get("functions", ""),
            ", ".join(da.get("stored_procedures", [])) if isinstance(da.get("stored_procedures"), list) else da.get("stored_procedures", ""),
            inner_j,
            outer_j,
            left_j,
            right_j,
            ", ".join(da.get("file_operations", [])) if isinstance(da.get("file_operations"), list) else da.get("file_operations", ""),
            ", ".join(da.get("db_operations", [])) if isinstance(da.get("db_operations"), list) else da.get("db_operations", ""),
            ", ".join(da.get("utilities", [])) if isinstance(da.get("utilities"), list) else da.get("utilities", ""),
            da.get("error_handling", "None"),
            da.get("restart_logic", "None"),
            da.get("retry_logic", "None"),
            da.get("checkpoint_logic", "None"),
            da.get("failure_recovery", "None"),
            da.get("detailed_technical_assessment", "Heuristic / Pending Detailed AI Analysis")
        ]
        _write_row(ws3, r_idx, row_vals, wrap=True)

    # ════════════════════════════════════════════════════════════════
    # SHEET 4 — Risk & Modernization
    # ════════════════════════════════════════════════════════════════
    ws4 = wb.create_sheet("Risk & Modernization")
    hdr4 = [
        "Job ID", "Risk Level", "Migration Complexity", "Modernization Priority",
        "Technical Debt Score", "Restartability Score", "Recommendations",
        "Detailed Reasoning"
    ]
    w4 = [18, 12, 18, 18, 15, 15, 30, 40]
    ws4.sheet_view.showGridLines = True
    _write_header(ws4, hdr4, w4)
    
    risk_mods_cache = session.get("risk_mods_cache", {})
    for r_idx, job in enumerate(jobs, start=2):
        jid = job.get("JobId", "")
        rm = risk_mods_cache.get(jid, {})
        row_vals = [
            jid,
            rm.get("risk_level", "LOW"),
            rm.get("migration_complexity", "LOW"),
            rm.get("modernization_priority", "LOW"),
            rm.get("technical_debt_score", 5),
            rm.get("restartability_score", 5),
            ", ".join(rm.get("recommendations", [])) if isinstance(rm.get("recommendations"), list) else rm.get("recommendations", ""),
            rm.get("detailed_reasoning", "Heuristic / Pending Risk & Modernization analysis")
        ]
        _write_row(ws4, r_idx, row_vals, wrap=True)
        _color_risk_row(ws4, r_idx, len(hdr4), rm.get("risk_level", "LOW"))

    # ════════════════════════════════════════════════════════════════
    # SHEET 5 — Job Conversion Summary
    # ════════════════════════════════════════════════════════════════
    ws5 = wb.create_sheet("Job Conversion Summary")
    hdr5 = [
        "Job ID", "Target Technology", "Converted Code", "Migration Notes",
        "Dependencies", "Complexity", "Manual Intervention Required"
    ]
    w5 = [18, 18, 45, 30, 20, 12, 15]
    ws5.sheet_view.showGridLines = True
    _write_header(ws5, hdr5, w5)
    
    conversions_cache = session.get("conversions_cache", {})
    for r_idx, job in enumerate(jobs, start=2):
        jid = job.get("JobId", "")
        conv = None
        for key, val in conversions_cache.items():
            if key == jid or key.startswith(jid + "_"):
                conv = val
                break
        if not conv:
            conv = {}
            
        row_vals = [
            jid,
            conv.get("target_technology", "Python"),
            conv.get("converted_code", "Heuristic / Pending Conversion"),
            conv.get("migration_notes", ""),
            ", ".join(conv.get("dependencies", [])) if isinstance(conv.get("dependencies"), list) else conv.get("dependencies", ""),
            conv.get("complexity", "Low"),
            "Yes" if conv.get("manual_intervention_required", False) else "No"
        ]
        _write_row(ws5, r_idx, row_vals, wrap=True)

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf.read()
