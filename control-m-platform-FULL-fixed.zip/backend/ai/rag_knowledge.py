"""
RAG Knowledge Base — static batch modernization knowledge embedded at startup.
Uses sentence-transformers (local, no API cost) for embeddings + FAISS for retrieval.
Falls back to keyword search if sentence-transformers unavailable.
"""

from __future__ import annotations
import json, re
from typing import List, Tuple

# ── Knowledge documents ────────────────────────────────────────────
KNOWLEDGE_DOCS = [
    # ── Modernization patterns ──────────────────────────────────────
    {
        "id": "mod_001",
        "category": "modernization",
        "title": "Shell Script to Python Migration Pattern",
        "content": (
            "Shell scripts should be migrated to Python when they exceed 50 lines, "
            "contain complex logic, or require maintainability. Use subprocess for system calls, "
            "pathlib for file operations, pandas for data processing. "
            "Complexity: LOW for simple file moves, MEDIUM for ETL, HIGH for complex orchestration. "
            "Target: Python with schedule library or Airflow for scheduling."
        ),
    },
    {
        "id": "mod_002",
        "category": "modernization",
        "title": "SQL Batch to PySpark Migration",
        "content": (
            "SQL batch jobs processing >1M rows are candidates for PySpark migration. "
            "Replace cursors with DataFrame operations. Replace stored procedures with PySpark SQL. "
            "Complexity HIGH when: nested cursors, dynamic SQL, complex temp tables. "
            "Migration steps: extract SQL logic, convert joins to DataFrame joins, parallelize. "
            "Target platform: Databricks, EMR, or Synapse Analytics."
        ),
    },
    {
        "id": "mod_003",
        "category": "modernization",
        "title": "Spring Batch Modernization",
        "content": (
            "Spring Batch jobs should be containerized and run on Kubernetes Jobs or Cloud Run. "
            "ItemReader/ItemProcessor/ItemWriter pattern maps well to Python generators. "
            "Use Apache Airflow or Prefect for orchestration replacement. "
            "Database polling steps can be replaced with event-driven triggers. "
            "Complexity: MEDIUM for standard ETL, HIGH for stateful processing."
        ),
    },
    {
        "id": "mod_004",
        "category": "modernization",
        "title": "Perl to Python Migration",
        "content": (
            "Perl scripts can be migrated to Python 1:1. "
            "Replace regex with Python re module. Replace hash with dict. "
            "Replace array with list. Replace print STDOUT with print(). "
            "Common Perl modules: DBI maps to psycopg2/SQLAlchemy, LWP maps to requests. "
            "Complexity: LOW for simple scripts, HIGH for Perl CGI or complex OOP."
        ),
    },
    {
        "id": "mod_005",
        "category": "modernization",
        "title": "Control-M to Airflow Migration",
        "content": (
            "Control-M job dependencies map to Airflow DAG task dependencies. "
            "Each Control-M folder becomes an Airflow DAG. "
            "Predecessors become task dependencies using >>/set_upstream. "
            "Control-M schedule becomes Airflow schedule_interval (cron). "
            "Control-M conditions map to Airflow sensors or XCom values. "
            "Critical path jobs should be mapped to high-priority Airflow tasks."
        ),
    },
    # ── Risk patterns ───────────────────────────────────────────────
    {
        "id": "risk_001",
        "category": "risk",
        "title": "High Fan-in Risk Pattern",
        "content": (
            "Jobs with fan-in > 5 are HIGH risk. They depend on many predecessors. "
            "Single predecessor failure causes this job to fail. "
            "Risk: cascading failure. Recommendation: add error handling, dead-letter queues, "
            "or break into smaller independent jobs. Migration risk: HIGH."
        ),
    },
    {
        "id": "risk_002",
        "category": "risk",
        "title": "High Fan-out Risk Pattern",
        "content": (
            "Jobs with fan-out > 5 are CRITICAL risk bottlenecks. "
            "Their failure blocks all downstream jobs. "
            "Risk: single point of failure in the schedule. "
            "Recommendation: implement checkpointing, restart capability, and alerting. "
            "Migration must preserve exact outputs and file formats."
        ),
    },
    {
        "id": "risk_003",
        "category": "risk",
        "title": "Long Runtime Risk",
        "content": (
            "Jobs with runtime > 60 minutes carry HIGH migration risk. "
            "Risk: timeout in cloud environments, SLA breaches. "
            "Recommendation: partition data, add parallel processing, add checkpointing. "
            "Cloud batch jobs should have max runtime limits configured."
        ),
    },
    {
        "id": "risk_004",
        "category": "risk",
        "title": "No Error Handling Risk",
        "content": (
            "Jobs without explicit error handling are CRITICAL risk. "
            "Silent failures cause data corruption downstream. "
            "Recommendation: add try/catch, exit code checking, and alerting. "
            "In Python: use try/except with specific exception types and logging."
        ),
    },
    {
        "id": "risk_005",
        "category": "risk",
        "title": "FTP Usage Risk",
        "content": (
            "FTP usage is HIGH risk for cloud migration. FTP is insecure and stateful. "
            "Replace with: SFTP, AWS S3 Transfer, Azure Blob Storage, or GCS. "
            "Migration: paramiko for SFTP in Python, boto3 for S3. "
            "Firewall rules and network routes must be reconfigured."
        ),
    },
    {
        "id": "risk_006",
        "category": "risk",
        "title": "Hardcoded Credentials Risk",
        "content": (
            "Hardcoded passwords, API keys, or connection strings are CRITICAL security risk. "
            "Must be migrated to secrets management: AWS Secrets Manager, HashiCorp Vault, "
            "Azure Key Vault. Python: use os.environ or boto3 secrets client. "
            "Remediate before cloud migration."
        ),
    },
    # ── Restartability patterns ─────────────────────────────────────
    {
        "id": "restart_001",
        "category": "restartability",
        "title": "Checkpoint Pattern for Long Running Jobs",
        "content": (
            "Long running batch jobs must implement checkpointing. "
            "Pattern: write progress markers to database or file after each batch. "
            "On restart: read last checkpoint, skip already-processed records. "
            "Python implementation: use SQLite or Redis for checkpoint state. "
            "Spring Batch: built-in JobRepository provides checkpointing."
        ),
    },
    {
        "id": "restart_002",
        "category": "restartability",
        "title": "Idempotency Pattern",
        "content": (
            "Batch jobs must be idempotent — safe to run multiple times with same result. "
            "Use MERGE/UPSERT instead of INSERT. Use unique job run IDs. "
            "Delete-and-reload is NOT idempotent. Use incremental processing with watermarks. "
            "Python: pandas merge with how='outer', database: ON CONFLICT DO UPDATE."
        ),
    },
    {
        "id": "restart_003",
        "category": "restartability",
        "title": "Dead Letter Queue Pattern",
        "content": (
            "Failed records should go to a dead letter queue for reprocessing. "
            "Do not fail entire batch for single record errors. "
            "Pattern: try/except per record, write failures to error table with reason. "
            "Airflow: use on_failure_callback and task retries. "
            "Cloud: AWS SQS DLQ, Azure Service Bus DLQ."
        ),
    },
    # ── Conversion templates ────────────────────────────────────────
    {
        "id": "conv_001",
        "category": "conversion",
        "title": "Shell to Python File Processing Template",
        "content": (
            "Shell: for file in /data/*.csv; do process $file; done "
            "Python equivalent: "
            "from pathlib import Path; import pandas as pd "
            "for file in Path('/data').glob('*.csv'): "
            "    df = pd.read_csv(file); process(df) "
            "Shell variables become Python variables. "
            "Shell if/else becomes Python if/else. "
            "awk/sed operations become pandas string operations."
        ),
    },
    {
        "id": "conv_002",
        "category": "conversion",
        "title": "SQL Cursor to Python Pandas Template",
        "content": (
            "SQL cursor iteration is slow and should be replaced with set-based operations. "
            "CURSOR FOR SELECT -> pd.read_sql() "
            "FETCH NEXT -> DataFrame row operations "
            "UPDATE via cursor -> df.loc[condition, col] = value; to_sql() "
            "INSERT in loop -> df.to_sql(if_exists='append') "
            "Performance: cursor 1000x slower than set-based pandas for large datasets."
        ),
    },
    {
        "id": "conv_003",
        "category": "conversion",
        "title": "Control-M Job to Airflow DAG Template",
        "content": (
            "Control-M Job -> Airflow Task "
            "Control-M Folder -> Airflow DAG "
            "CYCLIC INTERVAL DAYS=1 -> schedule_interval='@daily' "
            "DAYS_AND_WEEKS -> schedule_interval='0 6 * * 1-5' "
            "IN-CONDITION -> Airflow Sensor or XCom "
            "OUT-CONDITION -> XCom push "
            "DO MAIL -> EmailOperator "
            "SHOUT -> SlackOperator or AlertOperator"
        ),
    },
    # ── Bottleneck patterns ─────────────────────────────────────────
    {
        "id": "bottleneck_001",
        "category": "bottleneck",
        "title": "N+1 Query Bottleneck",
        "content": (
            "N+1 query pattern: SELECT inside a loop. "
            "Impact: exponential DB load, slow batch execution. "
            "Fix: replace with JOIN or batch SELECT...WHERE id IN (...). "
            "Python/ORM: use eager loading, select_related(), prefetch_related(). "
            "Example: pandas merge instead of apply with db lookup."
        ),
    },
    {
        "id": "bottleneck_002",
        "category": "bottleneck",
        "title": "Sequential File Processing Bottleneck",
        "content": (
            "Processing large files sequentially is a bottleneck. "
            "Impact: linear time complexity, poor CPU utilization. "
            "Fix: chunk files with pandas chunksize parameter, use multiprocessing.Pool. "
            "Python: concurrent.futures.ProcessPoolExecutor for CPU-bound, "
            "ThreadPoolExecutor for I/O-bound file operations."
        ),
    },
    {
        "id": "bottleneck_003",
        "category": "bottleneck",
        "title": "Missing Index Bottleneck",
        "content": (
            "Full table scans in batch SQL indicate missing indexes. "
            "Symptoms: WHERE clause on non-indexed column, ORDER BY without index. "
            "Fix: CREATE INDEX on join keys and filter columns. "
            "For migration: document all query patterns and create indexes in target DB. "
            "Partitioned tables improve performance for time-series batch data."
        ),
    },
    # ── Architecture best practices ─────────────────────────────────
    {
        "id": "arch_001",
        "category": "architecture",
        "title": "Cloud Batch Architecture Best Practices",
        "content": (
            "Cloud batch architecture: separate compute from storage. "
            "Use object storage (S3/GCS/Blob) for intermediate files. "
            "Use managed database for state and checkpoints. "
            "Container-based execution: Docker + Kubernetes Jobs or Cloud Run Jobs. "
            "Observability: structured logging, metrics, distributed tracing. "
            "Cost: use spot/preemptible instances for batch workloads."
        ),
    },
    {
        "id": "arch_002",
        "category": "architecture",
        "title": "Scheduler Migration Best Practices",
        "content": (
            "Control-M -> Airflow migration best practices: "
            "1. Map all calendars to cron expressions. "
            "2. Map all conditions to sensors. "
            "3. Implement all alerts as callbacks. "
            "4. Use Airflow Variables for global config. "
            "5. Use Airflow Connections for DB connections. "
            "6. Implement retry logic at task level. "
            "7. Use SLAs for critical path monitoring."
        ),
    },
    {
        "id": "mod_006",
        "category": "modernization",
        "title": "Autosys to Airflow Migration",
        "content": (
            "Autosys jobs, boxes, and job definitions (JIL) map to Airflow tasks and DAGs. "
            "An Autosys 'box_job' maps to an Airflow DAG or a Group of tasks. "
            "Job dependencies defined by 'condition' statements map to task dependencies using >> operator. "
            "Schedule templates (run_calendar, start_times) translate to Airflow schedule intervals. "
            "Autosys variables (sendevent, global variables) map to Airflow Variables or XComs."
        ),
    },
    {
        "id": "mod_007",
        "category": "modernization",
        "title": "Cron to Python and Airflow Migration",
        "content": (
            "Unix crontab schedules should be centralized using Airflow. "
            "Each cron line is translated into an Airflow DAG. "
            "Shell command invocations are replaced with specific Airflow Operators (e.g., BashOperator, PythonOperator). "
            "Standardize logging, error alerting (via email or Slack), and retry logic which are usually missing or basic in raw crontabs."
        ),
    },
    {
        "id": "mod_008",
        "category": "modernization",
        "title": "SSIS to dbt and Glue Migration",
        "content": (
            "SQL Server Integration Services (SSIS) packages should be modernized to dbt (data build tool) "
            "and AWS Glue or Azure Data Factory. "
            "Data flow tasks are converted to SQL models in dbt. "
            "Control flow tasks (FTP, email, file system) map to Airflow orchestration. "
            "Migration complexity: HIGH due to nested packages and complex scripts."
        ),
    },
    {
        "id": "mod_009",
        "category": "modernization",
        "title": "Informatica, DataStage, and Talend ETL Modernization",
        "content": (
            "Legacy ETL tools (Informatica PowerCenter, IBM InfoSphere DataStage, Talend) "
            "migrating to cloud should target PySpark, AWS Glue, or Databricks. "
            "Mappings, transformations, and expressions are converted to Spark DataFrame operations. "
            "Workflows/Sequencers map to Airflow DAGs. "
            "Complexity is HIGH due to visual logic that must be translated to code."
        ),
    },
    {
        "id": "mod_010",
        "category": "modernization",
        "title": "SQL Jobs to dbt and Airflow",
        "content": (
            "Database-specific SQL agent jobs (SQL Server Agent, Oracle DBMS_JOB) "
            "are modernized to dbt models scheduled via Airflow. "
            "Decouples transformations from database compute. "
            "Allows version control, testing, and documentation of data models. "
            "Use dbt runs scheduled in Airflow DAGs for reliable data pipelines."
        ),
    },
    {
        "id": "mod_011",
        "category": "modernization",
        "title": "Quartz and Java Batch Migration",
        "content": (
            "Quartz scheduler triggers and Java batch processes are modernized to Spring Boot/Spring Batch "
            "containers triggered via Airflow. "
            "Trigger definitions (SimpleTrigger, CronTrigger) map to Airflow scheduling. "
            "Java batch execution runs as KubernetesPodOperator or ECS/Fargate task."
        ),
    },
]

# ── Embedding / retrieval setup ────────────────────────────────────
_INDEX   = None   # FAISS index or None
_ENCODER = None   # SentenceTransformer or None
_DOCS    = KNOWLEDGE_DOCS  # always available

def _huggingface_reachable(timeout: float = 3.0) -> bool:
    """
    Quick pre-flight check before attempting the (slow, multi-retry)
    sentence-transformers download. Does a real HTTPS request — not just
    a TCP connect — because corporate SSL-inspecting proxies often accept
    the TCP connection fine and only fail at certificate validation
    (the exact CERTIFICATE_VERIFY_FAILED case). A bare TCP check would
    miss that and still trigger the slow doomed-retry path.
    Without this check, every server startup on a blocked/intercepted
    network burns 15-30+ seconds retrying a download that can never
    succeed before falling back anyway.
    """
    import urllib.request
    try:
        urllib.request.urlopen("https://huggingface.co", timeout=timeout)
        return True
    except Exception:
        return False


def _try_build_faiss_index():
    """Attempt to build FAISS index with sentence-transformers. Silent on failure."""
    global _INDEX, _ENCODER

    try:
        from sentence_transformers import SentenceTransformer
        import faiss, numpy as np
    except ImportError as e:
        print(f"[RAG] FAISS unavailable ({e}). Falling back to keyword search.")
        return

    if not _huggingface_reachable():
        print("[RAG] huggingface.co not reachable (blocked/offline network). Falling back to keyword search.")
        return

    try:
        model = SentenceTransformer("all-MiniLM-L6-v2")
        texts = [f"{d['title']} {d['content']}" for d in _DOCS]
        embeddings = model.encode(texts, show_progress_bar=False).astype("float32")
        faiss.normalize_L2(embeddings)

        dim = embeddings.shape[1]
        index = faiss.IndexFlatIP(dim)
        index.add(embeddings)

        _ENCODER = model
        _INDEX   = index
        print("[RAG] FAISS index built successfully with sentence-transformers.")
    except Exception as e:
        print(f"[RAG] FAISS unavailable ({e}). Falling back to keyword search.")

_try_build_faiss_index()


def retrieve(query: str, top_k: int = 4, category: str | None = None) -> List[dict]:
    """
    Retrieve top_k knowledge documents relevant to `query`.
    Uses FAISS if available, otherwise keyword BM25-lite fallback.
    """
    docs = _DOCS if not category else [d for d in _DOCS if d["category"] == category]

    if _INDEX is not None and _ENCODER is not None:
        return _faiss_retrieve(query, top_k, docs)
    return _keyword_retrieve(query, top_k, docs)


def _faiss_retrieve(query: str, top_k: int, docs: list) -> List[dict]:
    import numpy as np
    qvec = _ENCODER.encode([query]).astype("float32")
    import faiss; faiss.normalize_L2(qvec)

    # Search against full index but filter by doc subset
    all_ids = {d["id"]: i for i, d in enumerate(_DOCS)}
    allowed = {d["id"] for d in docs}

    k = min(top_k * 3, len(_DOCS))
    D, I = _INDEX.search(qvec, k)

    results = []
    for idx in I[0]:
        if idx < 0 or idx >= len(_DOCS):
            continue
        doc = _DOCS[idx]
        if doc["id"] in allowed:
            results.append(doc)
        if len(results) >= top_k:
            break
    return results


def _keyword_retrieve(query: str, top_k: int, docs: list) -> List[dict]:
    """Lightweight TF-IDF-style keyword retrieval."""
    tokens = set(re.sub(r"[^\w\s]", " ", query.lower()).split())
    scored = []
    for doc in docs:
        text = f"{doc['title']} {doc['content']}".lower()
        score = sum(1 for t in tokens if t in text)
        scored.append((score, doc))
    scored.sort(key=lambda x: -x[0])
    return [d for score, d in scored[:top_k] if score > 0] or docs[:top_k]


def format_context(docs: List[dict]) -> str:
    """Format retrieved docs as a clean context block for Gemini."""
    if not docs:
        return "No specific knowledge retrieved."
    parts = []
    for d in docs:
        parts.append(f"[{d['category'].upper()}] {d['title']}\n{d['content']}")
    return "\n\n".join(parts)
