"""
Downloadable sample templates (CHANGE 1).

Users may obtain scheduler exports from Control-M, Autosys, cron exports,
or other tools. We provide three downloadable sample CSV templates that
match the exact required column sets from the spec, plus a few extra
realistic example rows so the template is immediately useful as a guide.
"""

from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
import io

router = APIRouter()


CONTROL_M_EXPORT_TEMPLATE = """Job_ID,Job_Name,Application,Job_Type,Predecessor,Successor,Platform,Schedule,Avg_Runtime_Min,Status,Retries,Owner,Priority
J001,EXTRACT_CUSTOMER_DATA,CustomerApp,Shell,,J002,Linux,Daily,12,OK,0,jsmith,5
J002,TRANSFORM_CUSTOMER_DATA,CustomerApp,Python,J001,J003,Linux,Daily,28,OK,1,jsmith,5
J003,LOAD_CUSTOMER_DATA,CustomerApp,SQL,J002,"J004,J005",Linux,Daily,35,OK,2,jsmith,3
J004,GENERATE_CUSTOMER_REPORT,CustomerApp,Shell,J003,,Linux,Daily,8,OK,0,agarcia,5
J005,ARCHIVE_CUSTOMER_DATA,CustomerApp,Shell,J003,,Linux,Daily,5,OK,0,agarcia,5
J006,EXTRACT_FX_RATES,TreasuryApp,Shell,,J007,Windows,Hourly,4,OK,0,mlee,4
J007,LOAD_FX_RATES,TreasuryApp,SQL,J006,,Windows,Hourly,9,OK,0,mlee,4
"""

EXECUTION_HISTORY_TEMPLATE = """Job_ID,Run_Date,Runtime,Status,Restart_Count,Failure_Count,SLA_Breach
J001,2026-06-15,13,OK,0,0,0
J002,2026-06-15,31,OK,0,0,0
J003,2026-06-15,38,OK,1,3,1
J003,2026-06-14,41,FAILED,2,3,1
J003,2026-06-13,33,OK,0,3,0
J004,2026-06-15,9,OK,0,0,0
J005,2026-06-15,5,OK,0,0,0
"""

SOURCE_CODE_INVENTORY_TEMPLATE = """Job_Name,App,Job_Type,Source_File
EXTRACT_CUSTOMER_DATA,CustomerApp,Shell,scripts/extract_customer_data.sh
TRANSFORM_CUSTOMER_DATA,CustomerApp,Python,jobs/transform_customer_data.py
LOAD_CUSTOMER_DATA,CustomerApp,SQL,sql/load_customer_data.sql
GENERATE_CUSTOMER_REPORT,CustomerApp,Shell,scripts/generate_customer_report.sh
ARCHIVE_CUSTOMER_DATA,CustomerApp,Shell,scripts/archive_customer_data.sh
LOAD_FX_RATES,TreasuryApp,SpringBatchXML,batch/load_fx_rates_job.xml
"""

TEMPLATES = {
    "control_m_export": ("control_m_export_template.csv", CONTROL_M_EXPORT_TEMPLATE),
    "execution_history": ("execution_history_template.csv", EXECUTION_HISTORY_TEMPLATE),
    "source_code_inventory": ("source_code_inventory_template.csv", SOURCE_CODE_INVENTORY_TEMPLATE),
}


@router.get("/{kind}")
async def download_template(kind: str):
    """Download a sample CSV template (CHANGE 1)."""
    entry = TEMPLATES.get(kind)
    if not entry:
        raise HTTPException(
            status_code=404,
            detail=f"Unknown template '{kind}'. Valid options: {', '.join(TEMPLATES.keys())}",
        )
    filename, content = entry
    return StreamingResponse(
        io.BytesIO(content.encode("utf-8")),
        media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename={filename}"},
    )


@router.get("/")
async def list_templates():
    """List available templates."""
    return {
        "templates": [
            {"kind": k, "filename": v[0]} for k, v in TEMPLATES.items()
        ]
    }
