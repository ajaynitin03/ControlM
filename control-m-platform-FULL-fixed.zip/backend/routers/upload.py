from fastapi import APIRouter, UploadFile, File, HTTPException, Query
from fastapi.responses import StreamingResponse
from typing import Dict, Optional
import io
import pandas as pd
from services.file_processor import (
    process_csv, process_json, process_xml,
    save_session, get_session
)
from services.upload_validation import validate_or_raise, CsvValidationError
from services.unified_job_model import (
    process_execution_history, aggregate_execution_metrics, merge_job_model,
)
from services.phase1_engine import run_phase1_analysis

router = APIRouter()

# ── Phase-2 in-memory session store ────────────────────────────────
# Keyed by the SAME session_id returned by save_session() below.
# Holds the richer structure (jobs list, dependency graph, filename,
# exec_metrics) that routers/ai_assessment.py and routers/graph.py need,
# on top of the Phase-1 DataFrame-based SESSION_STORE in
# services/file_processor.py.
sessions: Dict[str, dict] = {}


def _read_columns_for_validation(content: bytes, filename: str) -> list:
    """Peek at column headers without fully parsing, for validation (CHANGE 2)."""
    filename_lower = filename.lower()
    try:
        if filename_lower.endswith(".csv"):
            df = pd.read_csv(io.BytesIO(content), dtype=str, nrows=0)
            return list(df.columns)
        elif filename_lower.endswith(".json"):
            import json as _json
            data = _json.loads(content.decode("utf-8"))
            if isinstance(data, list) and data:
                return list(data[0].keys())
            elif isinstance(data, dict):
                for key in ["jobs", "records", "data", "items", "rows"]:
                    if key in data and isinstance(data[key], list) and data[key]:
                        return list(data[key][0].keys())
                return list(data.keys())
            return []
        elif filename_lower.endswith(".xml"):
            # XML structure varies too much to cheaply peek headers;
            # skip pre-validation and rely on post-parse column check.
            return []
    except Exception:
        return []
    return []


def _build_phase1_session(df: pd.DataFrame, exec_metrics: dict, filename: str) -> dict:
    """Run Phase 1 analysis and shape the session dict used across routers."""
    try:
        analysis = run_phase1_analysis(df, exec_metrics)
        graph = analysis["graph"]
    except Exception:
        analysis = None
        graph = None

    return {
        "filename": filename,
        "jobs": df.fillna("").to_dict(orient="records"),
        "graph": graph,
        "exec_metrics": exec_metrics or {},
        "phase1_analysis": analysis,
    }


@router.post("/")
async def upload_file(
    file: UploadFile = File(...),
    execution_history: Optional[UploadFile] = File(None),
):
    """
    Upload Control-M Export (CSV, JSON, or XML) and return normalized data
    preview. Optionally accepts a second `execution_history` file in the
    same request — if provided, it is merged in automatically (CHANGE 3).

    Required columns are validated before processing (CHANGE 2). If
    required columns are missing, the file is rejected with a 422 and a
    structured list of missing columns rather than being silently
    processed with mostly-empty data.
    """
    content = await file.read()
    filename = file.filename.lower()

    # ── CHANGE 2: validate required columns before processing ───────
    columns = _read_columns_for_validation(content, filename)
    if columns:
        try:
            validate_or_raise(columns)
        except CsvValidationError as e:
            raise HTTPException(status_code=422, detail=e.to_dict())

    try:
        if filename.endswith(".csv"):
            df = process_csv(content)
        elif filename.endswith(".json"):
            df = process_json(content)
        elif filename.endswith(".xml"):
            df = process_xml(content)
        else:
            raise HTTPException(status_code=400, detail="Unsupported file type. Use CSV, JSON, or XML.")
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=422, detail=f"File processing failed: {str(e)}")

    if df.empty:
        raise HTTPException(status_code=422, detail="No valid records found in file.")

    # ── CHANGE 3: optional Execution History merge ───────────────────
    exec_metrics = {}
    if execution_history is not None:
        eh_content = await execution_history.read()
        try:
            eh_df = process_execution_history(eh_content, execution_history.filename)
            raw_metrics = aggregate_execution_metrics(eh_df)
            _, exec_metrics = merge_job_model(df, raw_metrics)
        except Exception as e:
            raise HTTPException(
                status_code=422,
                detail=f"Execution History processing failed: {str(e)}",
            )

    session_id = save_session(df)
    sessions[session_id] = _build_phase1_session(df, exec_metrics, file.filename)

    preview = df.head(50).fillna("").to_dict(orient="records")

    response = {
        "success": True,
        "message": f"Processed {len(df)} records successfully",
        "row_count": len(df),
        "columns": list(df.columns),
        "preview": preview,
        "session_id": session_id,
        "total_pages": (len(df) + 49) // 50,
        "execution_history_merged": bool(exec_metrics),
    }
    return response


@router.post("/execution-history/{session_id}")
async def attach_execution_history(session_id: str, file: UploadFile = File(...)):
    """
    Attach (or replace) Execution History for an already-uploaded
    Control-M Export session (CHANGE 3), for cases where the two files
    are uploaded separately rather than in the same request.
    """
    try:
        df = get_session(session_id)
    except KeyError:
        raise HTTPException(status_code=404, detail="Session not found")

    content = await file.read()

    columns = _read_columns_for_validation(content, file.filename.lower())
    if columns:
        try:
            validate_or_raise(columns, file_kind="execution_history")
        except CsvValidationError as e:
            raise HTTPException(status_code=422, detail=e.to_dict())

    try:
        eh_df = process_execution_history(content, file.filename)
        raw_metrics = aggregate_execution_metrics(eh_df)
        _, exec_metrics = merge_job_model(df, raw_metrics)
    except Exception as e:
        raise HTTPException(status_code=422, detail=f"Execution History processing failed: {str(e)}")

    session = sessions.setdefault(session_id, {"filename": "", "jobs": df.fillna("").to_dict(orient="records")})
    session["exec_metrics"] = exec_metrics
    rebuilt = _build_phase1_session(df, exec_metrics, session.get("filename", ""))
    session.update(rebuilt)

    return {
        "success": True,
        "session_id": session_id,
        "execution_history_merged": bool(exec_metrics),
        "matched_jobs": len(exec_metrics),
    }


@router.get("/preview/{session_id}")
async def get_preview(
    session_id: str,
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=10, le=200),
):
    """Get paginated data preview for a session."""
    try:
        df = get_session(session_id)
    except KeyError:
        raise HTTPException(status_code=404, detail="Session not found")

    start = (page - 1) * page_size
    end = start + page_size
    page_df = df.iloc[start:end]

    return {
        "page": page,
        "page_size": page_size,
        "total_rows": len(df),
        "total_pages": (len(df) + page_size - 1) // page_size,
        "data": page_df.fillna("").to_dict(orient="records"),
        "columns": list(df.columns),
    }


@router.get("/jobs/{session_id}")
async def get_job_list(session_id: str):
    """Get list of all jobs for dropdown selection, with derived criticality."""
    try:
        df = get_session(session_id)
    except KeyError:
        raise HTTPException(status_code=404, detail="Session not found")

    session = sessions.get(session_id, {})
    analysis = session.get("phase1_analysis")
    crit_map = analysis.get("criticality_map", {}) if analysis else {}

    jobs = df[["JobId", "JobName", "AppName"]].fillna("").to_dict(orient="records")
    for job in jobs:
        crit = crit_map.get(job["JobId"], {})
        job["Criticality"] = crit.get("legacy_band", "LOW")
        job["CriticalityBand"] = crit.get("band", "Low")
        job["CriticalityScore"] = crit.get("score", 0)
        job["CriticalityFactors"] = crit.get("factors", [])
        job["CriticalityReason"] = crit.get("reason", "")

    return {"jobs": jobs, "count": len(jobs)}


@router.get("/export/{session_id}")
async def export_csv(session_id: str):
    """Export normalized CSV, including derived criticality (CHANGE 5)."""
    try:
        df = get_session(session_id)
    except KeyError:
        raise HTTPException(status_code=404, detail="Session not found")

    session = sessions.get(session_id, {})
    analysis = session.get("phase1_analysis")
    crit_map = analysis.get("criticality_map", {}) if analysis else {}

    export_df = df.copy()
    export_df["Criticality"] = export_df["JobId"].map(
        lambda jid: crit_map.get(jid, {}).get("band", "Low")
    )
    export_df["CriticalityScore"] = export_df["JobId"].map(
        lambda jid: crit_map.get(jid, {}).get("score", 0)
    )
    export_df["CriticalityReason"] = export_df["JobId"].map(
        lambda jid: crit_map.get(jid, {}).get("reason", "")
    )

    output = io.StringIO()
    export_df.to_csv(output, index=False)
    output.seek(0)

    return StreamingResponse(
        io.BytesIO(output.getvalue().encode()),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=normalized_jobs.csv"},
    )
