"""
Criticality Engine — Phase 1 Analysis (CHANGE 4, CHANGE 5, CHANGE 12)

Operational Criticality is derived by our system from graph structure + execution-history signals.
The system does NOT use: Priority, Risk, or Criticality columns from the input.

Scoring (New Operational Criticality Model):

    Critical Path Membership   = +4 if job belongs to critical path
    Fan-Out:
        0-2 downstream jobs = 0
        3-5 downstream jobs = +1
        6-10 downstream jobs = +2
        >10 downstream jobs = +3
    Failures:
        0 = 0
        1-2 = +1
        3-5 = +2
        >5 = +3
    SLA:
        No breach = 0
        Breach = +3
    Runtime:
        <10 min = 0
        10-30 min = +1
        30-60 min = +2
        >60 min = +3
    Retries:
        0 = 0
        1-2 = +1
        3+ = +2
    Dependency Depth:
        <3 = 0
        3-5 = +1
        >5 = +2

Classification:
    0-3 = LOW
    4-6 = MEDIUM
    7-9 = HIGH
    10+ = CRITICAL
"""

from __future__ import annotations
import networkx as nx
import re
from typing import Dict, Any, List, Optional


def score_to_band(score: int) -> str:
    if score >= 10:
        return "Critical"
    if score >= 7:
        return "High"
    if score >= 4:
        return "Medium"
    return "Low"


# Back-compat alias used by older HIGH/MEDIUM/LOW-only call sites.
def band_to_legacy(band: str) -> str:
    return {"Critical": "HIGH", "High": "HIGH", "Medium": "MEDIUM", "Low": "LOW"}.get(band, "LOW")


def parse_runtime_mins(val: Any) -> float:
    if val is None:
        return 0.0
    if isinstance(val, (int, float)):
        return float(val)
    s = str(val).strip().lower()
    if not s or s in ("nan", "none", "-"):
        return 0.0
    
    # Try parsing hh:mm:ss or mm:ss
    if ":" in s:
        parts = s.split(":")
        try:
            if len(parts) == 3:
                h, m, sec = float(parts[0]), float(parts[1]), float(parts[2])
                return h * 60.0 + m + sec / 60.0
            elif len(parts) == 2:
                m, sec = float(parts[0]), float(parts[1])
                return m + sec / 60.0
        except ValueError:
            pass
            
    # Try match numeric + suffix (e.g. "15m", "15 mins", "1.5h")
    match = re.match(r"^([\d.]+)\s*(h|hr|hour|hours|m|min|mins|minute|minutes|s|sec|secs|second|seconds)?$", s)
    if match:
        try:
            num = float(match.group(1))
            unit = match.group(2)
            if not unit:
                return num
            if unit.startswith("h"):
                return num * 60.0
            if unit.startswith("s"):
                return num / 60.0
            return num
        except ValueError:
            pass
        
    try:
        # Extract first float
        match = re.search(r"[\d.]+", s)
        if match:
            return float(match.group(0))
    except ValueError:
        pass
        
    return 0.0


def parse_int(val: Any, default: int = 0) -> int:
    if val is None:
        return default
    if isinstance(val, (int, float)):
        return int(val)
    s = str(val).strip()
    if not s or s.lower() in ("nan", "none", "-"):
        return default
    try:
        match = re.search(r"\d+", s)
        if match:
            return int(match.group(0))
    except ValueError:
        pass
    return default


def compute_job_criticality(
    job_id: str,
    *,
    is_critical_path: bool,
    fan_out: int,
    avg_runtime_min: Optional[float] = None,
    failure_count: int = 0,
    sla_breach_count: int = 0,
    depth: int = 0,
    retries: int = 0,
    runtime_metadata: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Compute the criticality score + band + full factor breakdown for a
    single job, using the exact additive scoring rules from spec.
    """
    factors: List[Dict[str, Any]] = []
    score = 0

    # 1. Critical Path (+4)
    cp_pts = 4 if is_critical_path else 0
    score += cp_pts
    factors.append({
        "factor": "Critical Path",
        "detail": "Job is on the critical execution chain" if is_critical_path else "Job is not on the critical path",
        "points": cp_pts,
        "triggered": is_critical_path,
    })

    # 2. Fan-Out (0-2 = 0, 3-5 = +1, 6-10 = +2, >10 = +3)
    if fan_out <= 2:
        fo_pts = 0
    elif fan_out <= 5:
        fo_pts = 1
    elif fan_out <= 10:
        fo_pts = 2
    else:
        fo_pts = 3
    
    score += fo_pts
    factors.append({
        "factor": "Fan-Out",
        "detail": f"Fan-Out = {fan_out} downstream jobs",
        "points": fo_pts,
        "triggered": fo_pts > 0,
    })

    # 3. Failures (0 = 0, 1-2 = +1, 3-5 = +2, >5 = +3)
    if failure_count == 0:
        fail_pts = 0
    elif failure_count <= 2:
        fail_pts = 1
    elif failure_count <= 5:
        fail_pts = 2
    else:
        fail_pts = 3
    
    score += fail_pts
    factors.append({
        "factor": "Failures",
        "detail": f"Failures = {failure_count}",
        "points": fail_pts,
        "triggered": fail_pts > 0,
    })

    # 4. SLA Breach (No breach = 0, Breach = +3)
    sla_breached = sla_breach_count > 0
    sla_pts = 3 if sla_breached else 0
    score += sla_pts
    factors.append({
        "factor": "SLA Breach",
        "detail": "SLA Breach detected" if sla_breached else "No SLA breach",
        "points": sla_pts,
        "triggered": sla_breached,
    })

    # 5. Runtime (<10 min = 0, 10-30 min = +1, 30-60 min = +2, >60 min = +3)
    runtime_mins = 0.0
    if avg_runtime_min is not None:
        runtime_mins = float(avg_runtime_min)
    else:
        runtime_mins = parse_runtime_mins(runtime_metadata)
        
    if runtime_mins < 10.0:
        rt_pts = 0
    elif runtime_mins <= 30.0:
        rt_pts = 1
    elif runtime_mins <= 60.0:
        rt_pts = 2
    else:
        rt_pts = 3
        
    score += rt_pts
    factors.append({
        "factor": "Runtime",
        "detail": f"Runtime = {runtime_mins:.1f} mins" if avg_runtime_min is not None else f"Runtime = {runtime_metadata}",
        "points": rt_pts,
        "triggered": rt_pts > 0,
    })

    # 6. Retries (0 = 0, 1-2 = +1, 3+ = +2)
    if retries == 0:
        ret_pts = 0
    elif retries <= 2:
        ret_pts = 1
    else:
        ret_pts = 2
        
    score += ret_pts
    factors.append({
        "factor": "Retries",
        "detail": f"Retries = {retries}",
        "points": ret_pts,
        "triggered": ret_pts > 0,
    })

    # 7. Dependency Depth (<3 = 0, 3-5 = +1, >5 = +2)
    if depth < 3:
        dep_pts = 0
    elif depth <= 5:
        dep_pts = 1
    else:
        dep_pts = 2
        
    score += dep_pts
    factors.append({
        "factor": "Dependency Depth",
        "detail": f"Dependency Depth = {depth}",
        "points": dep_pts,
        "triggered": dep_pts > 0,
    })

    band = score_to_band(score)
    
    # Format the explanation exactly as requested
    reason_lines = [f"Operational Criticality: {band.upper()}"]
    reason_lines.append("")
    reason_lines.append("Reason:")
    
    triggered_factors = []
    for f in factors:
        if f["triggered"] and f["points"] > 0:
            name = f["factor"]
            pts = f["points"]
            if name == "Critical Path":
                triggered_factors.append(f"- Critical Path (+{pts})")
            elif name == "Fan-Out":
                triggered_factors.append(f"- Fan-Out = {fan_out} (+{pts})")
            elif name == "Failures":
                triggered_factors.append(f"- Failures = {failure_count} (+{pts})")
            elif name == "SLA Breach":
                triggered_factors.append(f"- SLA Breach (+{pts})")
            elif name == "Runtime":
                rt_str = f"{runtime_mins:.1f} mins" if avg_runtime_min is not None else str(runtime_metadata)
                triggered_factors.append(f"- Runtime = {rt_str} (+{pts})")
            elif name == "Retries":
                triggered_factors.append(f"- Retries = {retries} (+{pts})")
            elif name == "Dependency Depth":
                triggered_factors.append(f"- Dependency Depth = {depth} (+{pts})")
                
    if not triggered_factors:
        reason_lines.append("- None")
    else:
        reason_lines.extend(triggered_factors)
        
    reason = "\n".join(reason_lines)

    return {
        "job_id": job_id,
        "score": score,
        "band": band,
        "legacy_band": band_to_legacy(band),
        "factors": factors,
        "runtime_note": f"Runtime = {runtime_mins:.1f} mins" if avg_runtime_min is not None else f"Runtime = {runtime_metadata}",
        "reason": reason,
    }


def compute_criticality_for_graph(
    G: nx.DiGraph,
    critical_path: List[str],
    fan_metrics: Dict[str, Dict[str, int]],
    exec_metrics: Optional[Dict[str, Dict[str, Any]]] = None,
) -> Dict[str, Dict[str, Any]]:
    """
    Compute criticality for every node in a graph in one pass.
    """
    exec_metrics = exec_metrics or {}
    critical_set = set(critical_path)
    
    # Compute dependency depth for all nodes in the graph
    depth_map = {}
    try:
        topo = list(nx.topological_sort(G))
        for node in topo:
            preds = list(G.predecessors(node))
            if not preds:
                depth_map[node] = 0
            else:
                depth_map[node] = 1 + max(depth_map.get(p, 0) for p in preds)
    except Exception:
        depth_map = {n: 0 for n in G.nodes()}
        
    results: Dict[str, Dict[str, Any]] = {}

    for node_id in G.nodes():
        fan = fan_metrics.get(node_id, {"fan_in": 0, "fan_out": 0})
        em = exec_metrics.get(node_id, {})
        
        node_attrs = G.nodes[node_id] if node_id in G.nodes else {}
        runtime_metadata = node_attrs.get("runtime", "")
        retries_metadata = node_attrs.get("retries", "")
        
        # Calculate retries (max of Control-M metadata retries and history restarts)
        retries = max(parse_int(retries_metadata), parse_int(em.get("restart_count", 0)))
        
        results[node_id] = compute_job_criticality(
            node_id,
            is_critical_path=node_id in critical_set,
            fan_out=fan.get("fan_out", 0),
            avg_runtime_min=em.get("avg_runtime_min"),
            failure_count=em.get("failure_count", 0),
            sla_breach_count=em.get("sla_breach_count", 0),
            depth=depth_map.get(node_id, 0),
            retries=retries,
            runtime_metadata=runtime_metadata,
        )

    return results


def summarize_distribution(criticality_map: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
    """Criticality Distribution + Top Bottlenecks + Critical Jobs (CHANGE 5 / CHANGE 7)."""
    counts = {"Low": 0, "Medium": 0, "High": 0, "Critical": 0}
    for v in criticality_map.values():
        counts[v["band"]] = counts.get(v["band"], 0) + 1

    critical_jobs = sorted(
        (v for v in criticality_map.values() if v["band"] in ("High", "Critical")),
        key=lambda v: v["score"],
        reverse=True,
    )

    return {
        "distribution": counts,
        "total_jobs": len(criticality_map),
        "critical_jobs": critical_jobs[:50],
    }


GLOSSARY: Dict[str, str] = {
    "Critical": (
        "Mission-critical jobs that are on the critical path, have high downstream impact, "
        "frequent failures, or SLA breaches."
    ),
    "High": (
        "Important jobs with significant dependency impact or operational risk."
    ),
    "Medium": (
        "Moderate operational importance with limited impact."
    ),
    "Low": (
        "Jobs with minimal dependency impact and low risk."
    ),
}
