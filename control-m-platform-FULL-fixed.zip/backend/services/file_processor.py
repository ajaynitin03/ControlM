import pandas as pd
import json
import io
import re
import uuid
from typing import Tuple, Dict, Any

try:
    import xmltodict
except ImportError:
    xmltodict = None

# In-memory session store (use Redis in production)
SESSION_STORE: Dict[str, pd.DataFrame] = {}

# NOTE (CHANGE 4): Criticality is NEVER an input column anymore. Control-M
# exports do not provide High/Medium/Low — only an optional Priority field.
# Criticality is always DERIVED downstream by services/criticality_engine.py.
# "Priority" and "Retries" are kept as raw passthrough metadata fields only.
CANONICAL_COLUMNS = [
    "JobId", "JobName", "AppName", "SubApplication", "Platform",
    "Schedule", "Predecessors", "Successors", "Priority", "Runtime", "Owner",
    "Description", "Status", "Folder", "OrderMethod", "MaxWaitTime", "Retries"
]

# Fields that are derived later and must never be sourced from user input,
# even if a column with this name happens to appear in an uploaded file.
DERIVED_ONLY_FIELDS = {"Criticality", "CriticalityScore", "CriticalityBand", "CriticalityFactors", "CriticalityReason"}

COLUMN_ALIASES = {
    "jobid": "JobId",
    "job_id": "JobId",
    "id": "JobId",
    "jobname": "JobName",
    "job_name": "JobName",
    "name": "JobName",
    "appname": "AppName",
    "app_name": "AppName",
    "application": "AppName",
    "app": "AppName",
    "subapplication": "SubApplication",
    "sub_application": "SubApplication",
    "subapp": "SubApplication",
    "platform": "Platform",
    "server": "Platform",
    "host": "Platform",
    "schedule": "Schedule",
    "cron": "Schedule",
    "predecessors": "Predecessors",
    "predecessor": "Predecessors",
    "depends_on": "Predecessors",
    "dependencies": "Predecessors",
    "parent": "Predecessors",
    "successors": "Successors",
    "successor": "Successors",
    "child": "Successors",
    # NOTE: "criticality"/"severity" are intentionally NOT mapped here
    # (CHANGE 4) — any such column is dropped during normalization so it
    # can never leak in as a fake pre-filled criticality value.
    "priority": "Priority",
    "runtime": "Runtime",
    "avg_runtime_min": "Runtime",
    "duration": "Runtime",
    "estimated_runtime": "Runtime",
    "owner": "Owner",
    "user": "Owner",
    "created_by": "Owner",
    "description": "Description",
    "desc": "Description",
    "notes": "Description",
    "status": "Status",
    "state": "Status",
    "folder": "Folder",
    "group": "Folder",
    "ordermethod": "OrderMethod",
    "order_method": "OrderMethod",
    "maxwaittime": "MaxWaitTime",
    "max_wait_time": "MaxWaitTime",
    "timeout": "MaxWaitTime",
    "retries": "Retries",
    "retry_count": "Retries",
}


def normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Normalize column names to canonical schema.

    CHANGE 4: Criticality (and any derived field) is deliberately excluded
    from CANONICAL_COLUMNS / COLUMN_ALIASES, so even if an uploaded file
    contains a "Criticality" or "Risk Indicator" column, it is dropped
    here rather than silently treated as ground truth.
    """
    # Defensively drop any column that maps to a derived-only field name,
    # in case it slips in verbatim (e.g. a file literally has a column
    # named "Criticality" or "Risk Indicator").
    df = df[[c for c in df.columns if c.strip() not in DERIVED_ONLY_FIELDS
             and "risk" not in c.strip().lower().replace(" ", "_")
             and "criticality" not in c.strip().lower()]].copy()

    # Build rename map, track which canonical names have already been assigned
    renamed = {}
    assigned_canonicals = set()

    for col in df.columns:
        normalized = col.strip().lower().replace(" ", "_").replace("-", "_")
        canonical = None

        if normalized in COLUMN_ALIASES:
            canonical = COLUMN_ALIASES[normalized]
        elif col.strip() in CANONICAL_COLUMNS:
            canonical = col.strip()
        else:
            for alias, c in COLUMN_ALIASES.items():
                if alias in normalized:
                    canonical = c
                    break

        if canonical:
            if canonical not in assigned_canonicals:
                renamed[col] = canonical
                assigned_canonicals.add(canonical)
            # else: duplicate mapping — leave original col name, will be dropped later

    df = df.rename(columns=renamed)

    # Drop any leftover non-canonical columns that weren't mapped
    cols_to_keep = [c for c in df.columns if c in CANONICAL_COLUMNS]
    df = df[cols_to_keep].copy()

    # Add missing canonical columns with empty strings
    for col in CANONICAL_COLUMNS:
        if col not in df.columns:
            df[col] = ""

    return df[CANONICAL_COLUMNS]


def normalize_predecessors(val) -> str:
    """Normalize predecessors field: support comma, semicolon, pipe separators."""
    try:
        if pd.isna(val):
            return ""
    except (TypeError, ValueError):
        pass
    val = str(val).strip()
    if val in ["", "nan", "None", "-", "N/A"]:
        return ""
    # Replace semicolons, pipes, spaces with commas
    val = re.sub(r"[;|\s]+", ",", val)
    # Remove duplicates while preserving order
    parts = [p.strip() for p in val.split(",") if p.strip()]
    seen = set()
    unique_parts = []
    for p in parts:
        if p not in seen:
            seen.add(p)
            unique_parts.append(p)
    return ",".join(unique_parts)


def normalize_priority(val) -> str:
    """Pass through raw Priority value as-is (CHANGE 4: no High/Medium/Low mapping).

    Control-M Priority is typically a letter/number (e.g. A-J, or 0-15) and
    must NOT be reinterpreted as a criticality tier. We only strip/clean it.
    """
    try:
        if pd.isna(val):
            return ""
    except (TypeError, ValueError):
        pass
    val = str(val).strip()
    if val in ["", "nan", "None", "-", "N/A"]:
        return ""
    return val


def clean_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    """Full cleaning pipeline."""
    df = normalize_columns(df)

    # Drop rows where JobId is missing
    df["JobId"] = df["JobId"].astype(str).str.strip()
    df = df[df["JobId"].notna() & (df["JobId"] != "") & (df["JobId"] != "nan")]

    # Ensure JobName has fallback
    df["JobName"] = df["JobName"].astype(str).str.strip()
    df.loc[df["JobName"].isin(["", "nan"]), "JobName"] = df["JobId"]

    # Normalize fields (CHANGE 4: Priority is raw passthrough, never a criticality tier)
    df["Predecessors"] = df["Predecessors"].apply(normalize_predecessors)
    df["Successors"] = df["Successors"].apply(normalize_predecessors)
    df["Priority"] = df["Priority"].apply(normalize_priority)

    # Strip whitespace from string columns
    str_cols = ["AppName", "SubApplication", "Platform", "Schedule",
                "Runtime", "Owner", "Description", "Status", "Folder",
                "OrderMethod", "MaxWaitTime", "Retries"]
    for col in str_cols:
        df[col] = df[col].astype(str).str.strip().replace("nan", "")


    # Reset index
    df = df.drop_duplicates(subset=["JobId"]).reset_index(drop=True)
    return df


def process_csv(content: bytes) -> pd.DataFrame:
    """Parse and clean CSV content."""
    try:
        df = pd.read_csv(io.BytesIO(content), dtype=str)
    except Exception:
        df = pd.read_csv(io.BytesIO(content), dtype=str, encoding="latin-1")
    return clean_dataframe(df)


def process_json(content: bytes) -> pd.DataFrame:
    """Parse JSON and convert to DataFrame."""
    data = json.loads(content.decode("utf-8"))
    if isinstance(data, list):
        df = pd.DataFrame(data)
    elif isinstance(data, dict):
        for key in ["jobs", "records", "data", "items", "rows"]:
            if key in data and isinstance(data[key], list):
                df = pd.DataFrame(data[key])
                break
        else:
            df = pd.DataFrame([data])
    else:
        raise ValueError("Unsupported JSON structure")
    return clean_dataframe(df)


def process_xml(content: bytes) -> pd.DataFrame:
    """Parse XML and convert to DataFrame."""
    if xmltodict is None:
        raise ImportError("xmltodict not installed")
    parsed = xmltodict.parse(content.decode("utf-8"))

    records = []

    def find_records(obj, depth=0):
        if isinstance(obj, list):
            for item in obj:
                if isinstance(item, dict):
                    records.append(item)
        elif isinstance(obj, dict):
            for key, val in obj.items():
                if isinstance(val, list) and len(val) > 0 and isinstance(val[0], dict):
                    for item in val:
                        records.append(item)
                    return
                elif isinstance(val, dict) and depth < 3:
                    find_records(val, depth + 1)

    find_records(parsed)

    if not records:
        raise ValueError("No records found in XML")

    df = pd.DataFrame(records)
    # Strip xmltodict @ prefix from attribute names
    df.columns = [c.lstrip("@#") for c in df.columns]
    return clean_dataframe(df)


def save_session(df: pd.DataFrame) -> str:
    """Save DataFrame to session store, return session ID."""
    session_id = str(uuid.uuid4())
    SESSION_STORE[session_id] = df
    return session_id


def get_session(session_id: str) -> pd.DataFrame:
    """Retrieve DataFrame from session store."""
    if session_id not in SESSION_STORE:
        raise KeyError(f"Session {session_id} not found")
    return SESSION_STORE[session_id]
