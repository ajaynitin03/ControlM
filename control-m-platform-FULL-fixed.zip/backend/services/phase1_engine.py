"""
Phase 1 Analysis Engine orchestrator (CHANGE 5, CHANGE 7).

Single entry point that runs the full Phase 1 pipeline on a jobs
DataFrame (+ optional execution metrics), so routers don't have to
re-assemble the same sequence of graph_service / criticality_engine
calls every time:

    1. Build dependency graph
    2. Detect cycles
    3. Find critical path
    4. Compute fan-in / fan-out metrics
    5. Compute dependency depth
    6. Derive criticality per job (score + band + factors + reason)
    7. Apply criticality back onto the graph nodes
    8. Summarize: criticality distribution, top bottlenecks, critical jobs

services/criticality_engine.py owns the scoring math and explanations;
this module just wires it together with the graph.
"""

from __future__ import annotations
import networkx as nx
import pandas as pd
from typing import Dict, Any, Optional, List

from services.graph_service import (
    build_graph, apply_criticality, detect_cycles, find_critical_path,
    compute_fan_metrics,
)
from services.criticality_engine import (
    compute_criticality_for_graph, summarize_distribution, GLOSSARY,
)


def compute_dependency_depth(G: nx.DiGraph) -> Dict[str, int]:
    """Longest path length from any root (no predecessors) to each node."""
    depth: Dict[str, int] = {}
    try:
        topo = list(nx.topological_sort(G))
    except Exception:
        # Cyclic graph — fall back to 0 depth for everything rather than crash.
        return {n: 0 for n in G.nodes()}

    for node in topo:
        preds = list(G.predecessors(node))
        if not preds:
            depth[node] = 0
        else:
            depth[node] = 1 + max(depth.get(p, 0) for p in preds)
    return depth


def identify_bottlenecks(
    G: nx.DiGraph,
    fan_metrics: Dict[str, Dict[str, int]],
    criticality_map: Dict[str, Dict[str, Any]],
    top_n: int = 20,
) -> List[Dict[str, Any]]:
    """
    Bottleneck Jobs (CHANGE 5 / CHANGE 7): jobs whose failure would block
    the largest number of downstream jobs, ranked by fan-out combined with
    criticality score.
    """
    candidates = []
    for node_id, fan in fan_metrics.items():
        crit = criticality_map.get(node_id, {})
        candidates.append({
            "job_id": node_id,
            "label": G.nodes[node_id].get("label", node_id) if node_id in G.nodes else node_id,
            "fan_out": fan.get("fan_out", 0),
            "fan_in": fan.get("fan_in", 0),
            "criticality_score": crit.get("score", 0),
            "criticality_band": crit.get("band", "Low"),
        })

    candidates.sort(key=lambda c: (c["fan_out"], c["criticality_score"]), reverse=True)
    return [c for c in candidates if c["fan_out"] > 0][:top_n]


def run_phase1_analysis(
    df: pd.DataFrame,
    exec_metrics: Optional[Dict[str, Dict[str, Any]]] = None,
) -> Dict[str, Any]:
    """
    Run the full Phase 1 pipeline and return everything needed by the
    routers/UI in one shot.

    exec_metrics: optional output of
        services.unified_job_model.aggregate_execution_metrics(),
    keyed by Job_ID. Pass None / {} if only a Control-M Export was
    uploaded (CHANGE 3 — Execution History is optional).
    """
    G = build_graph(df)

    has_cycles, cycles = detect_cycles(G)
    critical_path = find_critical_path(G)
    fan_metrics = compute_fan_metrics(G)
    depth_map = compute_dependency_depth(G)

    criticality_map = compute_criticality_for_graph(G, critical_path, fan_metrics, exec_metrics)
    apply_criticality(G, criticality_map)

    bottlenecks = identify_bottlenecks(G, fan_metrics, criticality_map)
    distribution = summarize_distribution(criticality_map)

    return {
        "graph": G,
        "has_cycles": has_cycles,
        "cycles": cycles,
        "critical_path": critical_path,
        "fan_metrics": fan_metrics,
        "dependency_depth": depth_map,
        "criticality_map": criticality_map,
        "bottlenecks": bottlenecks,
        "criticality_distribution": distribution["distribution"],
        "critical_jobs": distribution["critical_jobs"],
        "glossary": GLOSSARY,
    }
