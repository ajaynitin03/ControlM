"""
Upload validation (CHANGE 2).

Before any file is processed into the Unified Job Model, we check that it
actually looks like one of our known templates and contains the required
columns. If required columns are missing, we reject the file with a
descriptive error rather than silently producing a mostly-empty dataset.

This module is intentionally permissive about column naming (it reuses the
same alias table as file_processor) but strict about which canonical
fields must be present after aliasing.
"""

from __future__ import annotations
from typing import Dict, List, Tuple
import pandas as pd

from services.file_processor import COLUMN_ALIASES

# ── Required columns per template type (CHANGE 2 + CHANGE 3) ──────
# These mirror the example schemas given in the spec.
REQUIRED_COLUMNS = {
    "control_m_export": ["Job_ID", "Job_Name"],
    "execution_history": ["Job_ID"],
    "source_code_inventory": ["Job_Name"],
}

# Friendly display names used in the "Missing columns" UI list.
DISPLAY_NAME_OVERRIDES = {
    "Job_ID": "Job_ID",
    "Job_Name": "Job_Name",
}


def _normalize_header(col: str) -> str:
    return col.strip().lower().replace(" ", "_").replace("-", "_")


def _resolve_canonical(col: str) -> str:
    """Resolve a raw header to its canonical field name, same logic as file_processor."""
    normalized = _normalize_header(col)
    if normalized in COLUMN_ALIASES:
        return COLUMN_ALIASES[normalized]
    for alias, canonical in COLUMN_ALIASES.items():
        if alias in normalized:
            return canonical
    return col.strip()


# Map "required" spec names (Job_ID, Job_Name) to the canonical names
# used internally (JobId, JobName) so we can check presence regardless
# of which exact header text the uploader typed.
_REQUIRED_TO_CANONICAL = {
    "Job_ID": "JobId",
    "Job_Name": "JobName",
}


def detect_file_kind(columns: List[str]) -> str:
    """
    Best-effort detection of which template a file matches, based on its
    columns. Falls back to 'control_m_export' (the most general / primary
    schema) if nothing else matches clearly.
    """
    canonical_cols = {_resolve_canonical(c) for c in columns}
    lower_cols = {c.strip().lower() for c in columns}

    has_exec_signal = bool(
        {"run_date", "runtime", "restart_count", "failure_count", "sla_breach"} & lower_cols
    )
    has_source_signal = bool(
        {"source_file", "job_type"} & lower_cols
    ) and "predecessor" not in " ".join(lower_cols)

    if has_exec_signal:
        return "execution_history"
    if has_source_signal and "JobId" not in canonical_cols:
        return "source_code_inventory"
    return "control_m_export"


def validate_columns(columns: List[str], file_kind: str = None) -> Tuple[bool, List[str], str]:
    """
    Validate that the required columns (after alias resolution) are present.

    Returns: (is_valid, missing_columns, detected_kind)
    """
    detected_kind = file_kind or detect_file_kind(columns)
    required = REQUIRED_COLUMNS.get(detected_kind, REQUIRED_COLUMNS["control_m_export"])

    canonical_present = {_resolve_canonical(c) for c in columns}

    missing = []
    for req in required:
        canonical_req = _REQUIRED_TO_CANONICAL.get(req, req)
        if canonical_req not in canonical_present:
            missing.append(req)

    return (len(missing) == 0, missing, detected_kind)


class CsvValidationError(Exception):
    """Raised when an uploaded file fails required-column validation (CHANGE 2)."""

    def __init__(self, missing_columns: List[str], detected_kind: str):
        self.missing_columns = missing_columns
        self.detected_kind = detected_kind
        super().__init__(
            "Invalid CSV format. Please use the provided template. "
            f"Missing columns: {', '.join(missing_columns)}"
        )

    def to_dict(self) -> Dict:
        return {
            "error": "Invalid CSV format. Please use the provided template.",
            "detected_kind": self.detected_kind,
            "missing_columns": self.missing_columns,
        }


def validate_or_raise(columns: List[str], file_kind: str = None) -> str:
    """Validate columns; raise CsvValidationError if required columns are missing.

    Returns the detected file kind on success.
    """
    is_valid, missing, detected_kind = validate_columns(columns, file_kind)
    if not is_valid:
        raise CsvValidationError(missing, detected_kind)
    return detected_kind
