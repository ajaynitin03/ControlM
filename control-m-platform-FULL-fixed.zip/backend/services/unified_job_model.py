"""
Unified Job Model (CHANGE 3).

Phase 1 now accepts up to two distinct input sources:

    1. Control-M Export   — dependency / scheduling metadata
    2. Execution History  — runtime / failure / SLA metadata

If only a Control-M Export is uploaded, Phase 1 still works exactly as
before (dependency graph, critical path, fan metrics, cycle detection),
just without execution-derived criticality signals (failure count, SLA
breach, observed avg runtime) — those simply default to 0 / None.

If BOTH are uploaded, they are merged automatically on Job_ID (preferred)
or Job_Name (fallback) into a single Unified Job Model carrying:

    - Dependency Information   (from Control-M Export)
    - Runtime Information      (aggregated from Execution History)
    - Failure Information      (aggregated from Execution History)
    - SLA Information          (aggregated from Execution History)

This module does NOT compute criticality itself — it only prepares the
merged per-job metrics. services/criticality_engine.py consumes the
output (`exec_metrics`) to score each job once the dependency graph
(and therefore critical path / fan-out) is available.
"""

from __future__ import annotations
import pandas as pd
from typing import Dict, Any, Optional, Tuple


# ── Execution History canonical schema (per spec) ─────────────────
EXEC_HISTORY_COLUMNS = [
    "Job_ID", "Run_Date", "Runtime", "Status",
    "Restart_Count", "Failure_Count", "SLA_Breach",
]

EXEC_HISTORY_ALIASES = {
    "job_id": "Job_ID",
    "jobid": "Job_ID",
    "id": "Job_ID",
    "run_date": "Run_Date",
    "date": "Run_Date",
    "runtime": "Runtime",
    "duration": "Runtime",
    "runtime_min": "Runtime",
    "status": "Status",
    "restart_count": "Restart_Count",
    "restarts": "Restart_Count",
    "failure_count": "Failure_Count",
    "failures": "Failure_Count",
    "sla_breach": "SLA_Breach",
    "sla_breached": "SLA_Breach",
    "breached_sla": "SLA_Breach",
}


def _normalize_exec_columns(df: pd.DataFrame) -> pd.DataFrame:
    renamed = {}
    for col in df.columns:
        key = col.strip().lower().replace(" ", "_").replace("-", "_")
        if key in EXEC_HISTORY_ALIASES:
            renamed[col] = EXEC_HISTORY_ALIASES[key]
        elif col.strip() in EXEC_HISTORY_COLUMNS:
            renamed[col] = col.strip()
    df = df.rename(columns=renamed)
    for col in EXEC_HISTORY_COLUMNS:
        if col not in df.columns:
            df[col] = "" if col not in ("Restart_Count", "Failure_Count") else 0
    return df[EXEC_HISTORY_COLUMNS]


def _to_bool_breach(val) -> bool:
    s = str(val).strip().lower()
    return s in ("true", "1", "yes", "y", "breach", "breached")


def _to_numeric(val, default=0.0) -> float:
    try:
        if pd.isna(val):
            return default
        return float(val)
    except (TypeError, ValueError):
        return default


def process_execution_history(content: bytes, filename: str = "") -> pd.DataFrame:
    """Parse a raw Execution History CSV/JSON into a normalized DataFrame."""
    import io
    import json as _json

    if filename.lower().endswith(".json"):
        data = _json.loads(content.decode("utf-8"))
        records = data if isinstance(data, list) else data.get("records", data.get("data", [data]))
        df = pd.DataFrame(records)
    else:
        try:
            df = pd.read_csv(io.BytesIO(content), dtype=str)
        except Exception:
            df = pd.read_csv(io.BytesIO(content), dtype=str, encoding="latin-1")

    df = _normalize_exec_columns(df)
    df["Job_ID"] = df["Job_ID"].astype(str).str.strip()
    df = df[df["Job_ID"].notna() & (df["Job_ID"] != "") & (df["Job_ID"] != "nan")]
    return df.reset_index(drop=True)


def aggregate_execution_metrics(exec_df: pd.DataFrame) -> Dict[str, Dict[str, Any]]:
    """
    Aggregate Execution History rows (one per run) into one summary record
    per Job_ID — this is the "Runtime / Failure / SLA Information" portion
    of the Unified Job Model.

    NOTE: Failure_Count / Restart_Count / SLA_Breach in a Control-M-style
    execution log are typically a per-run snapshot value (e.g. "this run's
    cumulative failure count so far"), not a per-row delta. Summing them
    across every run row would over-count. We instead use the maximum
    observed value across runs for the count-style fields, and fall back
    to counting rows whose Status indicates failure if no explicit count
    is present at all.
    """
    if exec_df is None or exec_df.empty:
        return {}

    metrics: Dict[str, Dict[str, Any]] = {}
    for job_id, group in exec_df.groupby("Job_ID"):
        runtimes = group["Runtime"].apply(lambda v: _to_numeric(v, default=None))
        runtimes = runtimes.dropna()
        failure_counts = group["Failure_Count"].apply(lambda v: _to_numeric(v, 0))
        restart_counts = group["Restart_Count"].apply(lambda v: _to_numeric(v, 0))
        sla_breaches = group["SLA_Breach"].apply(_to_bool_breach)

        status_failures = group["Status"].astype(str).str.lower().str.contains(
            "fail|error|abend", regex=True
        ).sum()

        max_failure_count = int(failure_counts.max()) if len(failure_counts) else 0
        failure_total = max_failure_count if max_failure_count > 0 else int(status_failures)

        metrics[str(job_id)] = {
            "run_count": int(len(group)),
            "avg_runtime_min": float(runtimes.mean()) if len(runtimes) else None,
            "max_runtime_min": float(runtimes.max()) if len(runtimes) else None,
            "failure_count": failure_total,
            "restart_count": int(restart_counts.max()) if len(restart_counts) else 0,
            "sla_breach_count": int(sla_breaches.sum()),
            "last_run_date": str(group["Run_Date"].iloc[-1]) if "Run_Date" in group else "",
        }

    return metrics


def merge_job_model(
    control_m_df: pd.DataFrame,
    exec_metrics: Optional[Dict[str, Dict[str, Any]]] = None,
) -> Tuple[pd.DataFrame, Dict[str, Dict[str, Any]]]:
    """
    Build the Unified Job Model.

    control_m_df: cleaned Control-M Export dataframe (canonical columns,
                  from services.file_processor.clean_dataframe).
    exec_metrics: output of aggregate_execution_metrics(), keyed by Job_ID.
                  If a job_id from Control-M doesn't appear here, it simply
                  gets zeroed-out execution signals (no error — Execution
                  History is optional, per CHANGE 3).

    Merge key: Job_ID (primary). If a Control-M row's JobId has no match in
    exec_metrics, we also attempt a fallback match on JobName, since some
    Execution History exports key on job name instead of ID.

    Returns: (control_m_df unchanged, exec_metrics_by_job_id) — the
    dependency dataframe is NOT mutated with new columns here; callers
    that need a flat merged row should call get_merged_row() below. This
    keeps the dependency graph builder decoupled from execution metrics
    (matches CHANGE 6 / CHANGE 7 expectations that graph building works
    standalone).
    """
    exec_metrics = exec_metrics or {}

    if not exec_metrics:
        return control_m_df, {}

    # Build a JobName -> Job_ID lookup for fallback matching.
    name_to_id = {
        str(row["JobName"]).strip(): str(row["JobId"]).strip()
        for _, row in control_m_df.iterrows()
    }

    merged_metrics: Dict[str, Dict[str, Any]] = {}
    control_m_ids = set(control_m_df["JobId"].astype(str).str.strip())

    for key, metric in exec_metrics.items():
        key = str(key).strip()
        if key in control_m_ids:
            merged_metrics[key] = metric
        elif key in name_to_id:
            merged_metrics[name_to_id[key]] = metric
        else:
            # Execution history references a job not present in the
            # Control-M export — keep it under its own key so it's not
            # silently dropped; graph/criticality code simply won't find
            # a matching node for it.
            merged_metrics[key] = metric

    return control_m_df, merged_metrics


def get_merged_row(job_row: Dict[str, Any], exec_metrics: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
    """Flatten a single Control-M job row + its execution metrics into one dict (for export/inspection)."""
    job_id = str(job_row.get("JobId", "")).strip()
    em = exec_metrics.get(job_id, {})
    return {
        **job_row,
        "RunCount": em.get("run_count", 0),
        "AvgRuntimeMin": em.get("avg_runtime_min"),
        "MaxRuntimeMin": em.get("max_runtime_min"),
        "FailureCount": em.get("failure_count", 0),
        "RestartCount": em.get("restart_count", 0),
        "SlaBreachCount": em.get("sla_breach_count", 0),
        "LastRunDate": em.get("last_run_date", ""),
    }
