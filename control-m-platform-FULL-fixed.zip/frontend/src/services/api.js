import axios from 'axios'

const api = axios.create({
  baseURL: '/api',
  timeout: 60000,   // 60s — AI calls can take time
})

const BASE = '/api'

// ════════════════════════════════════════════════════════════════
// PHASE-1 — Upload & Analysis
// ════════════════════════════════════════════════════════════════

export const uploadFile = (file, onProgress, executionHistoryFile = null) => {
  const formData = new FormData()
  formData.append('file', file)
  if (executionHistoryFile) {
    formData.append('execution_history', executionHistoryFile)
  }
  return api.post('/upload/', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
    onUploadProgress: onProgress,
  })
}

export const attachExecutionHistory = (sessionId, file, onProgress) => {
  const formData = new FormData()
  formData.append('file', file)
  return api.post(`/upload/execution-history/${sessionId}`, formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
    onUploadProgress: onProgress,
  })
}

export const getPreview = (sessionId, page = 1, pageSize = 50) =>
  api.get(`/upload/preview/${sessionId}`, { params: { page, page_size: pageSize } })

export const getJobs = (sessionId) =>
  api.get(`/upload/jobs/${sessionId}`)

export const buildGraph = (sessionId, jobIds, depth = 3) =>
  api.post('/graph/build', { session_id: sessionId, job_ids: jobIds, depth })

export const getFullGraph = (sessionId) =>
  api.get(`/graph/full/${sessionId}`)

export const getImpactAnalysis = (sessionId, jobId) =>
  api.post('/analysis/impact', { session_id: sessionId, job_id: jobId })

export const getCriticalPath = (sessionId) =>
  api.get(`/analysis/critical-path/${sessionId}`)

export const getFanMetrics = (sessionId) =>
  api.get(`/analysis/fan-metrics/${sessionId}`)

export const getCycles = (sessionId) =>
  api.get(`/analysis/cycles/${sessionId}`)

export const getSummary = (sessionId) =>
  api.get(`/analysis/summary/${sessionId}`)

export const getCriticalityDistribution = (sessionId) =>
  api.get(`/analysis/criticality-distribution/${sessionId}`)

export const getJobCriticalityDetail = (sessionId, jobId) =>
  api.get(`/analysis/criticality/${sessionId}/${jobId}`)

export const exportCsv = (sessionId) =>
  `${BASE}/upload/export/${sessionId}`

// ════════════════════════════════════════════════════════════════
// Templates (CHANGE 1) — downloadable sample CSVs
// ════════════════════════════════════════════════════════════════

export const TEMPLATE_KINDS = {
  CONTROL_M_EXPORT: 'control_m_export',
  EXECUTION_HISTORY: 'execution_history',
  SOURCE_CODE_INVENTORY: 'source_code_inventory',
}

export const downloadTemplateUrl = (kind) =>
  `${BASE}/templates/${kind}`

export const downloadTemplate = (kind) =>
  api.get(`/templates/${kind}`, { responseType: 'blob' })

// ════════════════════════════════════════════════════════════════
// PHASE-2 — AI Assessment (Gemini + RAG)
// ════════════════════════════════════════════════════════════════

export const ai = {
  /** Check setup status. Returns gemini availability, inventory, and source info */
  status: (sessionId) =>
    api.get(`/ai/status/${sessionId}`),

  /** Upload inventory CSV */
  uploadInventory: (sessionId, file) => {
    const formData = new FormData()
    formData.append('file', file)
    return api.post(`/ai/upload-inventory/${sessionId}`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    })
  },

  /** Upload source code files (supports multiple file uploads) */
  uploadSourceFiles: (sessionId, files) => {
    const formData = new FormData()
    for (let i = 0; i < files.length; i++) {
      formData.append('files', files[i])
    }
    return api.post(`/ai/upload-source/${sessionId}`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    })
  },

  /** Clear uploads */
  clearInputs: (sessionId) =>
    api.post(`/ai/clear-inputs/${sessionId}`),

  /** Start assessment (RAG indexing + High level rules assessment) */
  startAssessment: (sessionId) =>
    api.post(`/ai/start-assessment/${sessionId}`),

  /** Get High Level Assessment results */
  getHighLevel: (sessionId) =>
    api.get(`/ai/high-level/${sessionId}`),

  /** Run detailed AI RAG analysis for a job */
  detailedAnalysis: (sessionId, jobId) =>
    api.post(`/ai/detailed-analysis/${sessionId}/${jobId}`),

  /** Run Risk & Modernization analysis for a job */
  riskModernization: (sessionId, jobId) =>
    api.post(`/ai/risk-modernization/${sessionId}/${jobId}`),

  /** Convert job code to target technology */
  convertJob: (sessionId, jobId, targetTechnology) =>
    api.post(`/ai/convert-job/${sessionId}/${jobId}`, null, {
      params: { target_technology: targetTechnology },
    }),

  /** Generate aggregate executive summary */
  executiveSummary: (sessionId) =>
    api.post(`/ai/executive-summary/${sessionId}`),

  /** Final Excel Report download URL */
  finalReportUrl: (sessionId) =>
    `${BASE}/ai/final-report/${sessionId}`,
}
