import { useState, useCallback, useRef, useEffect } from 'react'
import { useApp } from '../../hooks/useAppState'
import { getFullGraph } from '../../services/api'
import { initCytoscape, exportPNG, exportSVG, relayout } from '../../utils/cytoscapeBuilder'
import toast from 'react-hot-toast'
import FileCard from './FileCard'
import {
  LayoutList, GitBranch, Download, Loader2, PackageCheck,
  GitMerge, ZoomIn, ZoomOut, Maximize2, RotateCcw, X,
} from 'lucide-react'

/* ─── Jaccard similarity on two sets ─── */
function jaccard(setA, setB) {
  if (!setA.size && !setB.size) return 1
  const intersection = new Set([...setA].filter(x => setB.has(x)))
  const union = new Set([...setA, ...setB])
  return intersection.size / union.size
}

/* ─── Build a compound Cytoscape element list from multiple graphData objects ─── */
function buildUnifiedElements(files, isMerged) {
  if (isMerged) {
    // Deduplicate nodes/edges by ID across all files — keep original data intact
    const nodeMap = new Map()
    const edgeMap = new Map()
    files.forEach(f => {
      const gd = f.graphData
      if (!gd) return
      gd.nodes.forEach(n => { if (!nodeMap.has(n.data.id)) nodeMap.set(n.data.id, n) })
      gd.edges.forEach(e => { if (!edgeMap.has(e.data.id)) edgeMap.set(e.data.id, e) })
    })
    return [...nodeMap.values(), ...edgeMap.values()]
  }

  // Compound layout: one parent node per file, children = that file's jobs
  const elements = []
  files.forEach((f, fi) => {
    const gd = f.graphData
    if (!gd) return
    const parentId = `__file_${fi}__`
    const hue = (fi * 53 + 210) % 360
    const color = `hsl(${hue}, 65%, 50%)`

    // Parent compound node — stylesheet reads data(label) for node:parent
    elements.push({
      data: {
        id: parentId,
        label: f.fileName,
      },
    })

    // Child nodes — stylesheet reads data(displayLabel) for childless nodes
    gd.nodes.forEach(n => {
      const scopedId = `${parentId}_${n.data.id}`
      elements.push({
        data: {
          ...n.data,
          id: scopedId,
          originalId: n.data.id,
          // displayLabel is what node:childless stylesheet renders
          displayLabel: n.data.displayLabel || n.data.label || n.data.id,
          parent: n.data.parent ? `${parentId}_${n.data.parent}` : parentId,
          fileIndex: fi,
        },
        classes: (n.classes || ''),
        position: n.position,
      })
    })

    // Edges — remap source/target to scoped IDs
    gd.edges.forEach(e => {
      const scopedSrc = `${parentId}_${e.data.source}`
      const scopedTgt = `${parentId}_${e.data.target}`
      elements.push({
        data: {
          ...e.data,
          id: `${parentId}_${e.data.id}`,
          source: scopedSrc,
          target: scopedTgt,
          fileIndex: fi,
        },
        classes: (e.classes || ''),
      })
    })
  })
  return elements
}

/* ─── Unified Diagram Panel ─── */
function UnifiedDiagramPanel({ files, isMerged, onClose }) {
  const containerRef = useRef(null)
  const cyRef = useRef(null)
  const [layoutDir, setLayoutDir] = useState('TB')

  const totalNodes = files.reduce((s, f) => s + (f.graphData?.node_count || 0), 0)
  const totalEdges = files.reduce((s, f) => s + (f.graphData?.edge_count || 0), 0)

  useEffect(() => {
    if (!containerRef.current) return
    if (cyRef.current) { cyRef.current.destroy(); cyRef.current = null }

    const elements = buildUnifiedElements(files, isMerged)
    cyRef.current = initCytoscape(containerRef.current, elements, () => {})

    return () => {
      if (cyRef.current) { cyRef.current.destroy(); cyRef.current = null }
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    if (cyRef.current) relayout(cyRef.current, layoutDir)
  }, [layoutDir])

  return (
    <div style={{
      position: 'fixed', inset: 0, zIndex: 9999,
      background: 'rgba(0,0,0,0.72)', backdropFilter: 'blur(4px)',
      display: 'flex', flexDirection: 'column',
    }}>
      {/* Modal shell */}
      <div style={{
        margin: '24px auto', width: 'calc(100% - 48px)', maxWidth: 1400,
        flex: 1, minHeight: 0,
        display: 'flex', flexDirection: 'column',
        background: '#0f1117', borderRadius: 18,
        border: '1px solid #2d3748', overflow: 'hidden',
        boxShadow: '0 32px 80px rgba(0,0,0,0.6)',
      }}>
        {/* Header bar */}
        <div style={{
          background: '#151a27', borderBottom: '1px solid #1e2a3a',
          padding: '14px 20px', display: 'flex', alignItems: 'center', gap: 12, flexShrink: 0,
        }}>
          <GitMerge size={17} color={isMerged ? '#34d399' : '#60a5fa'} />
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 14, fontWeight: 700, color: '#f1f5f9' }}>
              {isMerged ? 'Unified Merged Diagram' : 'Combined Multi-File Diagram'}
            </div>
            <div style={{ fontSize: 11, color: '#64748b', marginTop: 1 }}>
              {isMerged
                ? `${files.length} similar files merged · ${totalNodes} nodes · ${totalEdges} edges`
                : `${files.length} files grouped in chronological order · ${totalNodes} total nodes`}
            </div>
          </div>

          {/* Similarity badge */}
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: 6,
            padding: '4px 12px', borderRadius: 99,
            background: isMerged ? 'rgba(52,211,153,0.12)' : 'rgba(96,165,250,0.12)',
            border: `1px solid ${isMerged ? '#065f46' : '#1e3a5f'}`,
            fontSize: 11, fontWeight: 700,
            color: isMerged ? '#34d399' : '#60a5fa',
          }}>
            {isMerged ? '✓ Files are similar — merged' : '⊞ Files differ — grouped by file'}
          </div>

          {/* Layout toggle */}
          <div style={{ display: 'flex', gap: 2, background: 'rgba(255,255,255,0.05)', borderRadius: 8, padding: 4 }}>
            {['TB', 'LR'].map(dir => (
              <button key={dir} onClick={() => setLayoutDir(dir)} style={{
                padding: '5px 10px', background: layoutDir === dir ? 'rgba(255,255,255,0.12)' : 'transparent',
                border: 'none', borderRadius: 5, cursor: 'pointer',
                color: layoutDir === dir ? '#e2e8f0' : '#64748b',
                fontSize: 11, fontWeight: 700, transition: 'all 0.1s',
              }}>
                {dir}
              </button>
            ))}
          </div>

          {/* Zoom controls */}
          <div style={{ display: 'flex', gap: 4, background: 'rgba(255,255,255,0.05)', borderRadius: 8, padding: 4 }}>
            {[
              { title: 'Zoom in',    icon: ZoomIn,    fn: () => cyRef.current?.zoom(cyRef.current.zoom() * 1.3) },
              { title: 'Zoom out',   icon: ZoomOut,   fn: () => cyRef.current?.zoom(cyRef.current.zoom() * 0.77) },
              { title: 'Fit view',   icon: Maximize2, fn: () => cyRef.current?.fit(undefined, 40) },
              { title: 'Reset view', icon: RotateCcw, fn: () => cyRef.current?.fit(undefined, 40) },
            ].map(({ title, icon: Icon, fn }) => (
              <button key={title} onClick={fn} title={title} style={{
                padding: '6px 8px', background: 'transparent', border: 'none',
                borderRadius: 6, cursor: 'pointer', color: '#94a3b8',
                display: 'flex', alignItems: 'center',
                transition: 'color 0.1s, background 0.1s',
              }}
                onMouseEnter={e => e.currentTarget.style.color = '#e2e8f0'}
                onMouseLeave={e => e.currentTarget.style.color = '#94a3b8'}
              >
                <Icon size={14} />
              </button>
            ))}
          </div>

          {/* Export PNG */}
          <button
            onClick={() => {
              if (!cyRef.current) return
              const blob = exportPNG(cyRef.current)
              const a = document.createElement('a')
              a.href = URL.createObjectURL(blob)
              a.download = 'unified-diagram.png'
              a.click()
              setTimeout(() => URL.revokeObjectURL(a.href), 3000)
              toast.success('PNG exported')
            }}
            style={{
              display: 'flex', alignItems: 'center', gap: 5,
              padding: '6px 12px', borderRadius: 7,
              background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)',
              color: '#94a3b8', fontSize: 11, fontWeight: 600, cursor: 'pointer',
            }}
          >
            <Download size={12} /> Export PNG
          </button>

          {/* Close */}
          <button onClick={onClose} style={{
            padding: 7, background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)',
            borderRadius: 7, cursor: 'pointer', color: '#94a3b8', display: 'flex',
          }}>
            <X size={15} />
          </button>
        </div>

        {/* File legend */}
        {!isMerged && (
          <div style={{
            display: 'flex', gap: 10, padding: '8px 20px', flexWrap: 'wrap',
            background: '#0d1120', borderBottom: '1px solid #1e2a3a', flexShrink: 0,
          }}>
            {files.map((f, fi) => {
              const hue = (fi * 53 + 210) % 360
              const color = `hsl(${hue}, 65%, 50%)`
              return (
                <div key={f.sessionId} style={{
                  display: 'flex', alignItems: 'center', gap: 6,
                  padding: '3px 10px', borderRadius: 6,
                  background: 'rgba(255,255,255,0.04)',
                  border: `1px solid ${color}44`,
                }}>
                  <div style={{ width: 8, height: 8, borderRadius: 2, background: color }} />
                  <span style={{ fontSize: 11, color: '#94a3b8', fontFamily: 'monospace' }}>{f.fileName}</span>
                  <span style={{ fontSize: 10, color: '#475569' }}>
                    {f.graphData?.node_count ?? 0} nodes
                  </span>
                </div>
              )
            })}
          </div>
        )}

        {/* Graph canvas */}
        <div style={{ flex: 1, position: 'relative', minHeight: 0 }}>
          <div ref={containerRef} style={{ width: '100%', height: '100%', background: '#1a1d27' }} />

          {/* Stats bar */}
          <div style={{
            position: 'absolute', bottom: 12, left: 12, zIndex: 10,
            display: 'flex', gap: 10, alignItems: 'center',
            padding: '5px 12px', background: 'rgba(0,0,0,0.65)',
            borderRadius: 8, backdropFilter: 'blur(6px)',
          }}>
            {[
              [`${files.length}`, 'files'],
              [`${totalNodes}`, 'nodes'],
              [`${totalEdges}`, 'edges'],
            ].map(([val, label], i, arr) => (
              <span key={label} style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                <span style={{ fontFamily: 'monospace', color: '#e2e8f0', fontWeight: 700, fontSize: 12 }}>{val}</span>
                <span style={{ fontSize: 11, color: '#64748b' }}>{label}</span>
                {i < arr.length - 1 && <span style={{ color: '#334155', marginLeft: 4 }}>·</span>}
              </span>
            ))}
          </div>

          {/* Hint */}
          <div style={{
            position: 'absolute', bottom: 12, right: 12, zIndex: 10,
            fontSize: 10, color: '#334155',
            padding: '3px 8px', background: 'rgba(0,0,0,0.4)', borderRadius: 5,
          }}>
            Scroll to zoom · Drag to pan
          </div>
        </div>
      </div>
    </div>
  )
}

/* ─── Main MultiFileView ─── */
export default function MultiFileView() {
  const { state, dispatch } = useApp()
  const { uploadedFiles, selectedFileIds } = state
  const [generatingAll, setGeneratingAll] = useState(false)
  const [checkingSimularity, setCheckingSimilarity] = useState(false)
  const [unifiedPanel, setUnifiedPanel] = useState(null) // { files, isMerged }

  // ── useRef map — never goes stale inside callbacks ──────────────
  const cyRefsMap = useRef({})

  const selectedFiles = uploadedFiles.filter(f => selectedFileIds.includes(f.sessionId))

  const registerCyRef = useCallback((sessionId, refObject) => {
    cyRefsMap.current[sessionId] = refObject
  }, [])

  const unregisterCyRef = useCallback((sessionId) => {
    delete cyRefsMap.current[sessionId]
  }, [])

  // ── Generate all diagrams sequentially ─────────────────────────
  const handleGenerateAll = useCallback(async () => {
    if (selectedFiles.length === 0) { toast.error('No files selected'); return }
    setGeneratingAll(true)
    let count = 0
    for (const f of selectedFiles) {
      if (f.graphData) { count++; continue }
      const toastId = `graph-${f.sessionId}`
      try {
        toast.loading(`Building graph for "${f.fileName}"…`, { id: toastId })
        const res = await getFullGraph(f.sessionId)
        dispatch({ type: 'UPDATE_FILE_GRAPH', sessionId: f.sessionId, payload: res.data })
        toast.success(`"${f.fileName}" graphed`, { id: toastId })
        count++
      } catch {
        toast.error(`Failed: ${f.fileName}`, { id: toastId })
      }
    }
    setGeneratingAll(false)
    if (count > 0) toast.success(`${count} diagram${count !== 1 ? 's' : ''} ready`)
  }, [selectedFiles, dispatch])

  // ── Export all graphs ─────────────────────────────────────────
  const handleExportAll = useCallback(async () => {
    const entries = Object.entries(cyRefsMap.current)
    if (entries.length === 0) {
      toast.error('Generate diagrams first — no active graphs found')
      return
    }
    const toastId = 'export-all'
    toast.loading('Exporting graphs…', { id: toastId })
    let exported = 0

    for (const [sid, refObj] of entries) {
      const cy = refObj?.current
      if (!cy) continue
      const file = uploadedFiles.find(f => f.sessionId === sid)
      const base = (file?.fileName.replace(/\.[^.]+$/, '') || sid)
      try {
        const blob = exportPNG(cy)
        triggerDownload(URL.createObjectURL(blob), `${base}-graph.png`)
        exported++
      } catch (e) {
        console.error('PNG export failed:', e)
      }
      await sleep(200)
      try {
        const svgStr = await exportSVG(cy)
        if (svgStr) {
          const blob = new Blob([svgStr], { type: 'image/svg+xml;charset=utf-8' })
          triggerDownload(URL.createObjectURL(blob), `${base}-graph.svg`)
        }
      } catch (e) {
        console.error('SVG export failed:', e)
      }
      await sleep(200)
    }

    if (exported > 0) {
      toast.success(`Exported ${exported} graph${exported !== 1 ? 's' : ''} (PNG + SVG)`, { id: toastId })
    } else {
      toast.error('Nothing to export — open the Diagram tab in each card first', { id: toastId })
    }
  }, [uploadedFiles])

  // ── Check Similarity ────────────────────────────────────────────
  const handleCheckSimilarity = useCallback(async () => {
    if (selectedFiles.length < 2) {
      toast.error('Select at least 2 files to compare similarity')
      return
    }
    setCheckingSimilarity(true)

    // Step 1: auto-generate any missing graphs
    const needsGraph = selectedFiles.filter(f => !f.graphData)
    if (needsGraph.length > 0) {
      toast.loading(`Generating ${needsGraph.length} missing diagram${needsGraph.length > 1 ? 's' : ''}…`, { id: 'sim-gen' })
      for (const f of needsGraph) {
        try {
          const res = await getFullGraph(f.sessionId)
          dispatch({ type: 'UPDATE_FILE_GRAPH', sessionId: f.sessionId, payload: res.data })
        } catch {
          toast.error(`Could not generate graph for "${f.fileName}"`)
        }
      }
      toast.dismiss('sim-gen')
    }

    // Step 2: read updated graphData from store (re-read via state after dispatch)
    // We need to read from the store after state updates — use a slight async gap
    await sleep(100)

    setCheckingSimilarity(false)
    // Signal to run the actual comparison now that state has settled
    setUnifiedPanel('pending')
  }, [selectedFiles, dispatch])

  // Step 3: run similarity logic once panel is 'pending' and selectedFiles have updated graphData
  useEffect(() => {
    if (unifiedPanel !== 'pending') return

    const filesWithGraph = selectedFiles.filter(f => f.graphData)
    if (filesWithGraph.length < 2) {
      toast.error('Need at least 2 files with graph data to compare')
      setUnifiedPanel(null)
      return
    }

    // Compute Jaccard pairwise
    const jobIdSets = filesWithGraph.map(f => {
      const ids = (f.graphData.nodes || []).map(n => n.data?.originalId || n.data?.id || '')
      return new Set(ids)
    })

    let minSim = 1
    for (let i = 0; i < jobIdSets.length; i++) {
      for (let j = i + 1; j < jobIdSets.length; j++) {
        const sim = jaccard(jobIdSets[i], jobIdSets[j])
        if (sim < minSim) minSim = sim
      }
    }

    const isMerged = minSim >= 0.7
    toast.success(
      isMerged
        ? `Files are ${Math.round(minSim * 100)}% similar — merging into one diagram`
        : `Files are different (${Math.round(minSim * 100)}% similarity) — showing grouped diagram`
    )
    setUnifiedPanel({ files: filesWithGraph, isMerged })
  }, [unifiedPanel, selectedFiles])

  const allGraphed = selectedFiles.length > 0 && selectedFiles.every(f => f.graphData)

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden', background: '#f8f9fc' }}>

      {/* Top bar */}
      <div style={{
        background: '#ffffff', borderBottom: '1px solid #e4e8f0',
        padding: '12px 24px', display: 'flex', alignItems: 'center', gap: 10, flexShrink: 0,
      }}>
        <LayoutList size={17} color="#2563eb" />
        <div style={{ flex: 1 }}>
          <span style={{ fontSize: 14, fontWeight: 700, color: '#111827' }}>Diagrams &amp; Data</span>
          <span style={{ fontSize: 12, color: '#9ca3af', marginLeft: 10 }}>
            {selectedFiles.length} of {uploadedFiles.length} files selected
          </span>
        </div>

        <div style={{ display: 'flex', gap: 8 }}>
          {/* Check Similarity button */}
          {selectedFiles.length >= 2 && (
            <button
              onClick={handleCheckSimilarity}
              disabled={checkingSimularity}
              style={{
                display: 'flex', alignItems: 'center', gap: 6,
                padding: '7px 14px', borderRadius: 8, cursor: checkingSimularity ? 'not-allowed' : 'pointer',
                border: '1px solid #a5b4fc',
                background: 'linear-gradient(135deg, #ede9fe 0%, #dbeafe 100%)',
                fontSize: 12, fontWeight: 700,
                color: '#4f46e5',
                opacity: checkingSimularity ? 0.55 : 1,
                transition: 'opacity 0.15s, box-shadow 0.15s',
                boxShadow: '0 1px 4px rgba(79,70,229,0.15)',
              }}
              onMouseEnter={e => { if (!checkingSimularity) e.currentTarget.style.boxShadow = '0 2px 10px rgba(79,70,229,0.28)' }}
              onMouseLeave={e => e.currentTarget.style.boxShadow = '0 1px 4px rgba(79,70,229,0.15)'}
            >
              {checkingSimularity
                ? <><Loader2 size={13} style={{ animation: 'spin 1s linear infinite' }} /> Checking…</>
                : <><GitMerge size={13} /> Check Job Similarity</>}
            </button>
          )}

          {/* Generate All */}
          <button
            onClick={handleGenerateAll}
            disabled={generatingAll || selectedFiles.length === 0}
            style={{
              display: 'flex', alignItems: 'center', gap: 6,
              padding: '7px 14px', borderRadius: 8, cursor: 'pointer',
              border: `1px solid ${allGraphed ? '#bbf7d0' : '#bfdbfe'}`,
              background: allGraphed ? '#f0fdf4' : '#eff4ff',
              fontSize: 12, fontWeight: 600,
              color: allGraphed ? '#16a34a' : '#1d4ed8',
              opacity: (generatingAll || selectedFiles.length === 0) ? 0.45 : 1,
              transition: 'opacity 0.15s',
            }}
          >
            {generatingAll
              ? <><Loader2 size={13} style={{ animation: 'spin 1s linear infinite' }} /> Generating…</>
              : allGraphed
                ? <><PackageCheck size={13} /> All Graphed</>
                : <><GitBranch size={13} /> Generate All Diagrams</>}
          </button>

          {/* Export All */}
          <button
            onClick={handleExportAll}
            style={{
              display: 'flex', alignItems: 'center', gap: 6,
              padding: '7px 14px', borderRadius: 8, cursor: 'pointer',
              border: '1px solid #e4e8f0', background: '#ffffff',
              fontSize: 12, fontWeight: 600, color: '#374151',
            }}
          >
            <Download size={13} /> Export All Graphs
          </button>
        </div>
      </div>

      {/* Content */}
      <div style={{ flex: 1, overflowY: 'auto', padding: 24 }}>
        {uploadedFiles.length === 0 ? (
          <EmptyState label="No files uploaded" sub="Upload CSV, JSON, or XML files using the Upload page." />
        ) : selectedFiles.length === 0 ? (
          <EmptyState label="No files selected" sub="Select files on the Upload page to view them here." />
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 32 }}>
            {selectedFiles.map((fileEntry, idx) => (
              <FileCard
                key={fileEntry.sessionId}
                fileEntry={fileEntry}
                index={idx}
                onRegisterCyRef={registerCyRef}
                onUnregisterCyRef={unregisterCyRef}
              />
            ))}
          </div>
        )}
      </div>

      {/* Unified Diagram Modal */}
      {unifiedPanel && unifiedPanel !== 'pending' && (
        <UnifiedDiagramPanel
          files={unifiedPanel.files}
          isMerged={unifiedPanel.isMerged}
          onClose={() => setUnifiedPanel(null)}
        />
      )}
    </div>
  )
}

function EmptyState({ label, sub }) {
  return (
    <div style={{
      display: 'flex', flexDirection: 'column', alignItems: 'center',
      justifyContent: 'center', padding: '80px 24px',
      background: '#ffffff', borderRadius: 16, border: '1px solid #e4e8f0',
    }}>
      <LayoutList size={36} color="#d1d5db" style={{ marginBottom: 12 }} />
      <div style={{ fontSize: 15, fontWeight: 600, color: '#374151', marginBottom: 4 }}>{label}</div>
      <div style={{ fontSize: 13, color: '#9ca3af' }}>{sub}</div>
    </div>
  )
}

function triggerDownload(url, filename) {
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
  setTimeout(() => URL.revokeObjectURL(url), 3000)
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)) }
