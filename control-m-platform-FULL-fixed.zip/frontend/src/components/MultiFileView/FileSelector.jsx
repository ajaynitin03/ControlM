// FileSelector is now embedded in UploadPage — this file is kept for compatibility
export default function FileSelector() { return null }
