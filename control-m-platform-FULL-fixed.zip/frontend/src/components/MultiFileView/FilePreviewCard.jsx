import { useEffect, useRef, useState, useCallback } from 'react'
import { ChevronLeft, ChevronRight, Loader2, ZoomIn, ZoomOut, Maximize2, RotateCcw, Target, AlertTriangle } from 'lucide-react'
import toast from 'react-hot-toast'
import { getPreview, getFullGraph } from '../../services/api'
import { useApp } from '../../hooks/useAppState'
import {
  initCytoscape, resetHighlight, highlightCriticalPath,
  exportPNG, relayout
} from '../../utils/cytoscapeBuilder'

const CRIT_BADGE = {
  HIGH:   <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-red-100 text-red-700 border border-red-200">HIGH</span>,
  MEDIUM: <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-orange-100 text-orange-700 border border-orange-200">MED</span>,
  LOW:    <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-green-100 text-green-700 border border-green-200">LOW</span>,
}

/* ── Data preview sub-component ─────────────────────────────────── */
function PreviewTable({ sessionId, uploadData }) {
  const [page, setPage]             = useState(1)
  const [data, setData]             = useState(uploadData?.preview || [])
  const [totalPages, setTotalPages] = useState(uploadData?.total_pages || 1)
  const [loading, setLoading]       = useState(false)
  const columns                     = uploadData?.columns || []

  useEffect(() => {
    if (!sessionId || page === 1) {
      setData(uploadData?.preview || [])
      setTotalPages(uploadData?.total_pages || 1)
      return
    }
    setLoading(true)
    getPreview(sessionId, page)
      .then((res) => {
        setData(res.data.data)
        setTotalPages(res.data.total_pages)
      })
      .finally(() => setLoading(false))
  }, [sessionId, page, uploadData])

  const renderCell = (col, val) => {
    if (col === 'Criticality') return CRIT_BADGE[val] || <span className="text-xs text-gray-500">{val || 'LOW'}</span>
    if (col === 'Predecessors' && val) {
      const preds = val.split(',').filter(Boolean)
      return (
        <div className="flex flex-wrap gap-1">
          {preds.map((p) => (
            <span key={p} className="px-1.5 py-0.5 bg-blue-50 border border-blue-200 rounded text-xs font-mono text-blue-700">
              {p}
            </span>
          ))}
        </div>
      )
    }
    return <span className="text-gray-700 text-xs">{val || '—'}</span>
  }

  return (
    <div className="flex flex-col min-h-0">
      {/* Pagination header */}
      <div className="flex items-center justify-between mb-2 px-1">
        <p className="text-xs text-gray-500">
          {uploadData?.row_count} rows · {columns.length} columns
        </p>
        <div className="flex items-center gap-1.5">
          <span className="text-xs text-gray-400">Page {page} / {totalPages}</span>
          <button
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            disabled={page === 1 || loading}
            className="p-1 rounded border border-gray-200 hover:bg-gray-50 disabled:opacity-40 transition-colors"
          >
            <ChevronLeft size={12} className="text-gray-600" />
          </button>
          <button
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            disabled={page === totalPages || loading}
            className="p-1 rounded border border-gray-200 hover:bg-gray-50 disabled:opacity-40 transition-colors"
          >
            <ChevronRight size={12} className="text-gray-600" />
          </button>
        </div>
      </div>

      {/* Table */}
      <div className="overflow-auto rounded-lg border border-gray-200" style={{ maxHeight: 280 }}>
        <table className="w-full text-left text-xs border-collapse">
          <thead className="sticky top-0 z-10 bg-gray-50">
            <tr>
              <th className="px-3 py-2 text-gray-500 font-semibold uppercase tracking-wider border-b border-gray-200">#</th>
              {columns.map((col) => (
                <th key={col} className="px-3 py-2 text-gray-500 font-semibold uppercase tracking-wider whitespace-nowrap border-b border-gray-200">
                  {col}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan={columns.length + 1} className="text-center py-6 text-gray-400">Loading…</td>
              </tr>
            ) : data.map((row, idx) => (
              <tr key={idx} className="border-b border-gray-100 hover:bg-gray-50 transition-colors">
                <td className="px-3 py-1.5 text-gray-400 font-mono">{(page - 1) * 50 + idx + 1}</td>
                {columns.map((col) => (
                  <td key={col} className="px-3 py-1.5 max-w-[180px]">{renderCell(col, row[col])}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

/* ── Graph sub-component ────────────────────────────────────────── */
function GraphView({ fileEntry, onGraphDataUpdate }) {
  const containerRef  = useRef(null)
  const cyRef         = useRef(null)
  const [loadingGraph, setLoadingGraph] = useState(false)
  const [layoutDir, setLayoutDir]       = useState('TB')
  const graphData = fileEntry.graphData

  // Build graph on demand
  const buildGraph = useCallback(async () => {
    if (!fileEntry.sessionId) return
    setLoadingGraph(true)
    try {
      const res = await getFullGraph(fileEntry.sessionId)
      onGraphDataUpdate(fileEntry.sessionId, res.data)
    } catch (err) {
      toast.error(`Graph failed for "${fileEntry.fileName}": ${err.response?.data?.detail || err.message}`)
    } finally {
      setLoadingGraph(false)
    }
  }, [fileEntry.sessionId, fileEntry.fileName, onGraphDataUpdate])

  // Init cytoscape when graphData arrives
  useEffect(() => {
    if (!containerRef.current || !graphData) return
    if (cyRef.current) { cyRef.current.destroy(); cyRef.current = null }
    const elements = [...graphData.nodes, ...graphData.edges]
    cyRef.current = initCytoscape(containerRef.current, elements, () => {})
    return () => { if (cyRef.current) { cyRef.current.destroy(); cyRef.current = null } }
  }, [graphData])

  useEffect(() => {
    if (cyRef.current) relayout(cyRef.current, layoutDir)
  }, [layoutDir])

  if (!graphData && !loadingGraph) {
    return (
      <div
        className="flex flex-col items-center justify-center gap-3 rounded-lg border"
        style={{ height: 320, background: '#f9fafb', border: '1px solid #e5e7eb' }}
      >
        <p className="text-sm text-gray-500">Dependency diagram not yet generated</p>
        <button
          onClick={buildGraph}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white text-sm font-semibold rounded-lg transition-colors"
        >
          Generate Full Diagram
        </button>
      </div>
    )
  }

  if (loadingGraph) {
    return (
      <div
        className="flex items-center justify-center gap-3 rounded-lg border"
        style={{ height: 320, background: '#f9fafb', border: '1px solid #e5e7eb' }}
      >
        <Loader2 size={20} className="animate-spin text-blue-500" />
        <span className="text-sm text-gray-500">Building graph…</span>
      </div>
    )
  }

  return (
    <div className="relative rounded-lg border overflow-hidden" style={{ height: 400, border: '1px solid #e5e7eb', background: '#0f1117' }}>
      {/* Toolbar */}
      <div className="absolute top-2 left-2 z-10 flex items-center gap-1">
        <div className="flex items-center gap-px bg-white/10 border border-white/10 rounded-lg p-1 backdrop-blur-sm">
          <button onClick={() => cyRef.current?.zoom(cyRef.current.zoom() * 1.3)} className="p-1.5 text-gray-300 hover:text-white hover:bg-white/10 rounded transition-colors" title="Zoom in">
            <ZoomIn size={13} />
          </button>
          <button onClick={() => cyRef.current?.zoom(cyRef.current.zoom() * 0.77)} className="p-1.5 text-gray-300 hover:text-white hover:bg-white/10 rounded transition-colors" title="Zoom out">
            <ZoomOut size={13} />
          </button>
          <button onClick={() => cyRef.current?.fit(undefined, 40)} className="p-1.5 text-gray-300 hover:text-white hover:bg-white/10 rounded transition-colors" title="Fit">
            <Maximize2 size={13} />
          </button>
          <button onClick={() => { if (cyRef.current) resetHighlight(cyRef.current) }} className="p-1.5 text-gray-300 hover:text-white hover:bg-white/10 rounded transition-colors" title="Reset">
            <RotateCcw size={13} />
          </button>
        </div>

        {/* Layout toggle */}
        <div className="flex items-center gap-px bg-white/10 border border-white/10 rounded-lg p-1 backdrop-blur-sm">
          {['TB', 'LR'].map((dir) => (
            <button
              key={dir}
              onClick={() => setLayoutDir(dir)}
              className={`px-2 py-1 text-xs rounded transition-colors ${layoutDir === dir ? 'bg-blue-600/60 text-blue-200' : 'text-gray-400 hover:text-gray-200'}`}
            >
              {dir}
            </button>
          ))}
        </div>

        {/* Critical path */}
        {graphData?.critical_path?.length > 0 && (
          <button
            onClick={() => {
              if (cyRef.current) {
                highlightCriticalPath(cyRef.current, graphData.critical_path)
                toast.success(`Critical path: ${graphData.critical_path.length} jobs`)
              }
            }}
            className="flex items-center gap-1.5 px-2.5 py-1.5 bg-white/10 border border-white/10 backdrop-blur-sm rounded-lg text-xs text-amber-300 hover:bg-white/20 transition-colors"
          >
            <Target size={12} />Critical Path
          </button>
        )}
      </div>

      {/* Cycle warning */}
      {graphData?.has_cycles && (
        <div className="absolute top-2 right-2 z-10">
          <div className="flex items-center gap-1.5 px-2.5 py-1.5 bg-red-950/80 border border-red-600/40 rounded-lg backdrop-blur-sm">
            <AlertTriangle size={12} className="text-red-400" />
            <span className="text-xs text-red-300">
              {graphData.cycle_details.length} cycle{graphData.cycle_details.length > 1 ? 's' : ''} detected
            </span>
          </div>
        </div>
      )}

      {/* Stats bar */}
      <div className="absolute bottom-2 left-2 z-10">
        <div className="flex items-center gap-2.5 px-2.5 py-1 bg-black/50 border border-white/10 rounded-lg backdrop-blur-sm text-xs text-gray-400">
          <span><span className="font-mono text-gray-200">{graphData?.node_count}</span> nodes</span>
          <span className="text-gray-600">·</span>
          <span><span className="font-mono text-gray-200">{graphData?.edge_count}</span> edges</span>
        </div>
      </div>

      <div ref={containerRef} style={{ width: '100%', height: '100%' }} />
    </div>
  )
}

/* ── Main file card ──────────────────────────────────────────────── */
export default function FilePreviewCard({ fileEntry, index }) {
  const { dispatch } = useApp()
  const [collapsed, setCollapsed] = useState(false)

  const handleGraphDataUpdate = useCallback((sessionId, graphData) => {
    dispatch({ type: 'UPDATE_FILE_GRAPH', sessionId, payload: graphData })
  }, [dispatch])

  return (
    <div
      style={{
        background: '#ffffff',
        border: '1px solid #e2e8f0',
        borderRadius: 16,
        overflow: 'hidden',
      }}
    >
      {/* Card header */}
      <div
        style={{ background: '#f8fafc', borderBottom: '1px solid #e2e8f0' }}
        className="flex items-center justify-between px-5 py-3"
      >
        <div className="flex items-center gap-3">
          <div
            className="w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold text-white flex-shrink-0"
            style={{ background: `hsl(${(index * 47 + 210) % 360}, 65%, 50%)` }}
          >
            {index + 1}
          </div>
          <div>
            <p className="text-sm font-semibold text-gray-800 font-mono">{fileEntry.fileName}</p>
            <p className="text-xs text-gray-500">
              {fileEntry.uploadData?.row_count ?? '?'} jobs · session <span className="font-mono">{fileEntry.sessionId?.slice(0, 8)}…</span>
            </p>
          </div>
        </div>

        <button
          onClick={() => setCollapsed((c) => !c)}
          className="px-3 py-1 rounded-lg border border-gray-200 text-xs text-gray-500 hover:bg-gray-100 transition-colors"
        >
          {collapsed ? 'Expand' : 'Collapse'}
        </button>
      </div>

      {/* Card body */}
      {!collapsed && (
        <div className="p-5 space-y-6">
          {/* Preview section */}
          <div>
            <h4 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3">
              Data Preview
            </h4>
            <PreviewTable sessionId={fileEntry.sessionId} uploadData={fileEntry.uploadData} />
          </div>

          {/* Separator */}
          <div style={{ borderTop: '1px solid #e2e8f0' }} />

          {/* Graph section */}
          <div>
            <h4 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3">
              Dependency Diagram
            </h4>
            <GraphView fileEntry={fileEntry} onGraphDataUpdate={handleGraphDataUpdate} />
          </div>
        </div>
      )}
    </div>
  )
}
