import { useState, useEffect, useRef, useCallback } from 'react'
import {
  ChevronLeft, ChevronRight, ChevronDown, ChevronUp,
  GitBranch, ZoomIn, ZoomOut, Maximize2, RotateCcw, Target,
  Download, Image as ImageIcon, FileCode, AlertTriangle, Loader2,
  AlignCenter, AlignLeft,
} from 'lucide-react'
import toast from 'react-hot-toast'
import { getPreview, getFullGraph, buildGraph, getJobs } from '../../services/api'
import { useApp } from '../../hooks/useAppState'
import {
  initCytoscape, resetHighlight, highlightCriticalPath,
  exportPNG, exportSVG, relayout,
} from '../../utils/cytoscapeBuilder'



/* ── Criticality badge ───────────────────────────────────────────── */
function CritBadge({ val }) {
  const s = {
    HIGH:   { background: '#fef2f2', color: '#dc2626', border: '1px solid #fecaca' },
    MEDIUM: { background: '#fffbeb', color: '#d97706', border: '1px solid #fde68a' },
    LOW:    { background: '#f0fdf4', color: '#16a34a', border: '1px solid #bbf7d0' },
  }[val] || { background: '#f0fdf4', color: '#16a34a', border: '1px solid #bbf7d0' }
  return (
    <span style={{ ...s, padding: '2px 7px', borderRadius: 5, fontSize: 10, fontWeight: 700 }}>
      {val || 'LOW'}
    </span>
  )
}

/* ─────────────────────────────────────────────────────────────────
   JOB PICKER (per-file)
   Lets user select specific jobs → builds a filtered graph for that file.
───────────────────────────────────────────────────────────────────*/
function JobPicker({ sessionId, fileName, onGraphBuilt }) {
  const [allJobs, setAllJobs]         = useState([])
  const [loading, setLoading]         = useState(true)
  const [building, setBuilding]       = useState(false)
  const [search, setSearch]           = useState('')
  const [filterCrit, setFilterCrit]   = useState('ALL')
  const [selectedIds, setSelectedIds] = useState([])

  useEffect(() => {
    setLoading(true)
    getJobs(sessionId)
      .then(r => setAllJobs(r.data.jobs || []))
      .catch(() => toast.error('Failed to load jobs'))
      .finally(() => setLoading(false))
  }, [sessionId])

  const filtered = allJobs.filter(j => {
    const q = search.toLowerCase()
    const matchSearch = !q || j.JobId.toLowerCase().includes(q) || j.JobName.toLowerCase().includes(q) || (j.AppName || '').toLowerCase().includes(q)
    const matchCrit = filterCrit === 'ALL' || j.Criticality === filterCrit
    return matchSearch && matchCrit
  })

  const toggle = id => setSelectedIds(prev =>
    prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
  )
  const selectAll = () => setSelectedIds(filtered.map(j => j.JobId))
  const clearAll  = () => setSelectedIds([])

  const critCounts = allJobs.reduce((acc, j) => {
    acc[j.Criticality] = (acc[j.Criticality] || 0) + 1; return acc
  }, {})

  const handleBuild = async () => {
    setBuilding(true)
    try {
      const res = selectedIds.length > 0
        ? await buildGraph(sessionId, selectedIds, 10)
        : await getFullGraph(sessionId)
      onGraphBuilt(res.data)
      toast.success(`Graph built — ${res.data.node_count} nodes, ${res.data.edge_count} edges`)
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Graph build failed')
    } finally {
      setBuilding(false)
    }
  }

  if (loading) return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '24px 0', color: '#9ca3af' }}>
      <Loader2 size={16} style={{ animation: 'spin 1s linear infinite' }} /> Loading jobs…
    </div>
  )

  return (
    <div>
      {/* Toolbar */}
      <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 12, flexWrap: 'wrap' }}>
        <input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Search job ID, name, app…"
          style={{
            flex: 1, minWidth: 160, padding: '6px 12px', borderRadius: 8,
            border: '1px solid #e4e8f0', fontSize: 12, color: '#374151',
            outline: 'none', background: '#ffffff',
          }}
        />
        {/* Criticality filter pills */}
        {['ALL', 'HIGH', 'MEDIUM', 'LOW'].map(c => {
          const colors = {
            ALL:    ['#e4e8f0', '#374151', '#f8f9fc'],
            HIGH:   ['#fecaca', '#dc2626', '#fef2f2'],
            MEDIUM: ['#fde68a', '#d97706', '#fffbeb'],
            LOW:    ['#bbf7d0', '#16a34a', '#f0fdf4'],
          }[c]
          const active = filterCrit === c
          return (
            <button key={c} onClick={() => setFilterCrit(c)} style={{
              padding: '4px 10px', borderRadius: 6, fontSize: 11, fontWeight: 600, cursor: 'pointer',
              border: `1px solid ${colors[0]}`,
              background: active ? colors[2] : '#ffffff',
              color: active ? colors[1] : '#9ca3af',
            }}>
              {c}{c !== 'ALL' ? ` (${critCounts[c] || 0})` : ''}
            </button>
          )
        })}
        <button onClick={selectAll} style={{ padding: '4px 10px', borderRadius: 6, border: '1px solid #e4e8f0', background: '#fff', fontSize: 11, fontWeight: 600, color: '#374151', cursor: 'pointer' }}>
          All
        </button>
        <button onClick={clearAll} style={{ padding: '4px 10px', borderRadius: 6, border: '1px solid #e4e8f0', background: '#fff', fontSize: 11, fontWeight: 600, color: '#374151', cursor: 'pointer' }}>
          None
        </button>
      </div>

      {/* Job list */}
      <div style={{ maxHeight: 280, overflowY: 'auto', border: '1px solid #e4e8f0', borderRadius: 10 }}>
        {filtered.length === 0 ? (
          <div style={{ padding: 24, textAlign: 'center', color: '#9ca3af', fontSize: 13 }}>No jobs match</div>
        ) : filtered.map((job, i) => {
          const sel = selectedIds.includes(job.JobId)
          return (
            <div key={job.JobId} onClick={() => toggle(job.JobId)} style={{
              display: 'flex', alignItems: 'center', gap: 10, padding: '8px 12px',
              cursor: 'pointer', borderBottom: i < filtered.length - 1 ? '1px solid #f1f3f7' : 'none',
              background: sel ? '#eff4ff' : '#ffffff', transition: 'background 0.1s',
            }}
              onMouseEnter={e => { if (!sel) e.currentTarget.style.background = '#f8f9fc' }}
              onMouseLeave={e => { if (!sel) e.currentTarget.style.background = '#ffffff' }}
            >
              {/* Checkbox */}
              <div style={{
                width: 16, height: 16, borderRadius: 4, flexShrink: 0,
                border: sel ? '2px solid #2563eb' : '2px solid #d1d5db',
                background: sel ? '#2563eb' : '#ffffff',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                {sel && <span style={{ color: '#fff', fontSize: 9, fontWeight: 700, lineHeight: 1 }}>✓</span>}
              </div>
              <CritBadge val={job.Criticality} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 12, fontWeight: 600, color: '#374151', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  {job.JobName}
                </div>
                <div style={{ fontSize: 10, fontFamily: 'monospace', color: '#9ca3af' }}>
                  {job.JobId}{job.AppName ? ` · ${job.AppName}` : ''}
                </div>
              </div>
            </div>
          )
        })}
      </div>

      {/* Build button */}
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        marginTop: 12, padding: '10px 14px', background: '#f8f9fc',
        border: '1px solid #e4e8f0', borderRadius: 10,
      }}>
        <span style={{ fontSize: 12, color: '#6b7280' }}>
          {selectedIds.length === 0
            ? 'No jobs selected — will build full diagram'
            : `${selectedIds.length} job${selectedIds.length !== 1 ? 's' : ''} selected (+ dependencies)`}
        </span>
        <button
          onClick={handleBuild}
          disabled={building}
          style={{
            display: 'flex', alignItems: 'center', gap: 6,
            padding: '7px 16px', borderRadius: 8, border: 'none',
            background: building ? '#93c5fd' : '#2563eb', color: '#ffffff',
            fontSize: 12, fontWeight: 700, cursor: building ? 'not-allowed' : 'pointer',
          }}
        >
          {building
            ? <><Loader2 size={13} style={{ animation: 'spin 1s linear infinite' }} /> Building…</>
            : <><GitBranch size={13} /> Build Diagram</>}
        </button>
      </div>
    </div>
  )
}

/* ─────────────────────────────────────────────────────────────────
   PREVIEW TABLE
───────────────────────────────────────────────────────────────────*/
function PreviewTable({ sessionId, uploadData }) {
  const [page, setPage]               = useState(1)
  const [data, setData]               = useState(uploadData?.preview || [])
  const [totalPages, setTotalPages]   = useState(uploadData?.total_pages || 1)
  const [loading, setLoading]         = useState(false)
  const [expandedRow, setExpandedRow] = useState(null)
  const columns = uploadData?.columns || []

  useEffect(() => {
    if (page === 1) { setData(uploadData?.preview || []); setTotalPages(uploadData?.total_pages || 1); return }
    setLoading(true)
    getPreview(sessionId, page)
      .then(r => { setData(r.data.data); setTotalPages(r.data.total_pages) })
      .finally(() => setLoading(false))
  }, [sessionId, page])

  const renderCell = (col, val) => {
    if (col === 'Criticality') return <CritBadge val={val} />
    if (col === 'Predecessors' && val) {
      return (
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 3 }}>
          {val.split(',').filter(Boolean).map(p => (
            <span key={p} style={{ padding: '2px 6px', background: '#eff4ff', border: '1px solid #bfdbfe', borderRadius: 4, fontSize: 10, fontFamily: 'monospace', color: '#1d4ed8' }}>{p}</span>
          ))}
        </div>
      )
    }
    return <span style={{ fontSize: 12, color: '#374151' }}>{val || <span style={{ color: '#d1d5db' }}>—</span>}</span>
  }

  return (
    <div>
      {/* Controls row */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10, gap: 12, flexWrap: 'wrap' }}>
        <div style={{ fontSize: 12, color: '#6b7280' }}>
          <strong style={{ color: '#374151' }}>{uploadData?.row_count}</strong> jobs &nbsp;·&nbsp;
          <strong style={{ color: '#374151' }}>{columns.length}</strong> columns
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ fontSize: 12, color: '#9ca3af' }}>Page {page}/{totalPages}</span>
          {[['‹', -1], ['›', 1]].map(([label, dir]) => (
            <button key={label} onClick={() => setPage(p => p + dir)}
              disabled={(dir === -1 && page === 1) || (dir === 1 && page === totalPages) || loading}
              style={{ padding: '4px 8px', border: '1px solid #e4e8f0', borderRadius: 6, background: '#fff', cursor: 'pointer', fontSize: 13, fontWeight: 700, color: '#6b7280', opacity: ((dir === -1 && page === 1) || (dir === 1 && page === totalPages)) ? 0.35 : 1 }}>
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div style={{ overflowX: 'auto', overflowY: 'auto', maxHeight: 380, borderRadius: 10, border: '1px solid #e4e8f0' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
          <thead style={{ position: 'sticky', top: 0, background: '#f8f9fc', zIndex: 1 }}>
            <tr style={{ borderBottom: '1px solid #e4e8f0' }}>
              <th style={thStyle}>#</th>
              {columns.map(c => <th key={c} style={thStyle}>{c}</th>)}
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={columns.length + 1} style={{ textAlign: 'center', padding: 24, color: '#9ca3af' }}>Loading…</td></tr>
            ) : data.map((row, idx) => (
              <>
                <tr key={idx}
                  style={{ borderBottom: '1px solid #f1f3f7', background: expandedRow === idx ? '#fafbff' : '#ffffff', cursor: 'pointer', transition: 'background 0.1s' }}
                  onClick={() => setExpandedRow(expandedRow === idx ? null : idx)}
                  onMouseEnter={e => { if (expandedRow !== idx) e.currentTarget.style.background = '#f8f9fc' }}
                  onMouseLeave={e => { if (expandedRow !== idx) e.currentTarget.style.background = '#ffffff' }}
                >
                  <td style={{ ...tdStyle, color: '#9ca3af', fontFamily: 'monospace', fontSize: 11 }}>{(page - 1) * 50 + idx + 1}</td>
                  {columns.map(col => <td key={col} style={{ ...tdStyle, maxWidth: 200 }}>{renderCell(col, row[col])}</td>)}
                </tr>
                {expandedRow === idx && (
                  <tr key={`exp-${idx}`}>
                    <td colSpan={columns.length + 1} style={{ padding: '0 12px 14px 44px', background: '#fafbff', borderBottom: '2px solid #e4e8f0' }}>
                      <JobDetailPanel row={row} columns={columns} />
                    </td>
                  </tr>
                )}
              </>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

function JobDetailPanel({ row, columns }) {
  const fields = columns.map(c => ({ label: c, value: row[c] })).filter(f => f.value)

  return (
    <div style={{ background: '#ffffff', border: '1px solid #e4e8f0', borderRadius: 10, padding: 16, marginTop: 8 }}>
      <div style={{ ...labelStyle, marginBottom: 10 }}>Job Details</div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(180px, 1fr))', gap: '6px 16px' }}>
        {fields.map(f => (
          <div key={f.label}>
            <div style={{ fontSize: 10, fontWeight: 600, color: '#9ca3af', textTransform: 'uppercase', letterSpacing: '0.05em' }}>{f.label}</div>
            <div style={{ fontSize: 12, color: '#374151', marginTop: 1, wordBreak: 'break-word' }}>{f.value}</div>
          </div>
        ))}
      </div>
    </div>
  )
}

/* ─────────────────────────────────────────────────────────────────
   GRAPH PANEL (per file) — renders cytoscape, handles exports
───────────────────────────────────────────────────────────────────*/
function GraphPanel({ fileEntry, onRegisterCyRef, onUnregisterCyRef }) {
  const { dispatch } = useApp()
  const containerRef  = useRef(null)
  const cyRef         = useRef(null)   // holds the live cytoscape instance
  const [loadingGraph, setLoadingGraph] = useState(false)
  const [layoutDir, setLayoutDir]       = useState('TB')
  const [section, setSection]           = useState('diagram') // 'picker' | 'diagram'
  const graphData = fileEntry.graphData

  // Register this file's cyRef with the parent on mount
  useEffect(() => {
    onRegisterCyRef(fileEntry.sessionId, cyRef)
    return () => onUnregisterCyRef(fileEntry.sessionId)
  }, [fileEntry.sessionId, onRegisterCyRef, onUnregisterCyRef])

  // Build cytoscape whenever graphData changes
  useEffect(() => {
    if (!containerRef.current || !graphData) return
    if (cyRef.current) { cyRef.current.destroy(); cyRef.current = null }
    const elements = [...graphData.nodes, ...graphData.edges]
    cyRef.current = initCytoscape(containerRef.current, elements, () => {})
    return () => { if (cyRef.current) { cyRef.current.destroy(); cyRef.current = null } }
  }, [graphData])

  useEffect(() => {
    if (cyRef.current && graphData) relayout(cyRef.current, layoutDir)
  }, [layoutDir])

  // Called by JobPicker after a custom graph is built
  const handleGraphBuilt = useCallback((gd) => {
    dispatch({ type: 'UPDATE_FILE_GRAPH', sessionId: fileEntry.sessionId, payload: gd })
    setSection('diagram')
  }, [dispatch, fileEntry.sessionId])

  // PNG export
  const handleExportPNG = useCallback(() => {
    if (!cyRef.current) return
    const blob = exportPNG(cyRef.current)
    triggerDownload(URL.createObjectURL(blob), `${fileEntry.fileName.replace(/\.[^.]+$/, '')}-graph.png`)
    toast.success('PNG exported')
  }, [fileEntry.fileName])

  // SVG export — async because exportSVG uses canvas
  const handleExportSVG = useCallback(async () => {
    if (!cyRef.current) { toast.error('No diagram open'); return }
    const toastId = 'svg-export'
    toast.loading('Preparing SVG…', { id: toastId })
    try {
      const svgStr = await exportSVG(cyRef.current)
      const blob = new Blob([svgStr], { type: 'image/svg+xml;charset=utf-8' })
      triggerDownload(URL.createObjectURL(blob), `${fileEntry.fileName.replace(/\.[^.]+$/, '')}-graph.svg`)
      toast.success('SVG exported', { id: toastId })
    } catch (err) {
      toast.error('SVG export failed: ' + err.message, { id: toastId })
    }
  }, [fileEntry.fileName])

  return (
    <div>
      {/* Sub-nav: Select Jobs | Diagram */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }}>
        <div style={{ display: 'flex', background: '#f1f4f9', borderRadius: 8, padding: 3, gap: 2 }}>
          {[['picker', 'Select Jobs'], ['diagram', 'Diagram']].map(([id, label]) => (
            <button key={id} onClick={() => setSection(id)} style={{
              padding: '5px 14px', borderRadius: 6, border: 'none', fontSize: 12, fontWeight: 600,
              cursor: 'pointer', transition: 'all 0.1s',
              background: section === id ? '#ffffff' : 'transparent',
              color: section === id ? '#1d4ed8' : '#9ca3af',
              boxShadow: section === id ? '0 1px 3px rgba(0,0,0,0.08)' : 'none',
            }}>
              {label}
            </button>
          ))}
        </div>
        {section === 'picker' && (
          <span style={{ fontSize: 11, color: '#9ca3af' }}>
            Select specific jobs to graph, or leave empty for the full diagram
          </span>
        )}
      </div>

      {/* Job Picker */}
      {section === 'picker' && (
        <JobPicker
          sessionId={fileEntry.sessionId}
          fileName={fileEntry.fileName}
          onGraphBuilt={handleGraphBuilt}
        />
      )}

      {/* Diagram view */}
      {section === 'diagram' && (
        <>
          {!graphData && !loadingGraph ? (
            /* No graph yet — prompt user */
            <div style={{
              height: 220, display: 'flex', flexDirection: 'column',
              alignItems: 'center', justifyContent: 'center', gap: 14,
              background: '#f8f9fc', borderRadius: 12, border: '1px dashed #d1d5db',
            }}>
              <GitBranch size={30} color="#d1d5db" />
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: '#374151', marginBottom: 4 }}>No diagram yet</div>
                <div style={{ fontSize: 12, color: '#9ca3af' }}>
                  Use <strong>Select Jobs</strong> to pick specific jobs, or generate the full diagram below.
                </div>
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                <button onClick={() => setSection('picker')} style={btnSecondary}>
                  <GitBranch size={13} /> Select Jobs
                </button>
                <button onClick={async () => {
                  setLoadingGraph(true)
                  try {
                    const res = await getFullGraph(fileEntry.sessionId)
                    dispatch({ type: 'UPDATE_FILE_GRAPH', sessionId: fileEntry.sessionId, payload: res.data })
                  } catch { toast.error('Graph build failed') }
                  finally { setLoadingGraph(false) }
                }} style={btnPrimary}>
                  <GitBranch size={13} /> Generate Full Diagram
                </button>
              </div>
            </div>
          ) : loadingGraph ? (
            <div style={{ height: 220, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10, background: '#f8f9fc', borderRadius: 12, border: '1px solid #e4e8f0' }}>
              <Loader2 size={20} color="#2563eb" style={{ animation: 'spin 1s linear infinite' }} />
              <span style={{ fontSize: 13, color: '#6b7280' }}>Building dependency graph…</span>
            </div>
          ) : (
            <>
              {/* Diagram toolbar */}
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 8, flexWrap: 'wrap' }}>
                {/* Zoom / pan controls */}
                <ToolGroup>
                  <TBtn title="Zoom in"      onClick={() => cyRef.current?.zoom(cyRef.current.zoom() * 1.3)}><ZoomIn  size={13} /></TBtn>
                  <TBtn title="Zoom out"     onClick={() => cyRef.current?.zoom(cyRef.current.zoom() * 0.77)}><ZoomOut size={13} /></TBtn>
                  <TBtn title="Fit to view"  onClick={() => cyRef.current?.fit(undefined, 40)}><Maximize2 size={13} /></TBtn>
                  <TBtn title="Reset highlights" onClick={() => cyRef.current && resetHighlight(cyRef.current)}><RotateCcw size={13} /></TBtn>
                </ToolGroup>

                {/* Layout direction */}
                <ToolGroup>
                  {['TB', 'LR'].map(d => (
                    <button key={d} onClick={() => setLayoutDir(d)} style={{
                      padding: '4px 10px', border: 'none', borderRadius: 5, cursor: 'pointer', fontSize: 11, fontWeight: 600,
                      background: layoutDir === d ? '#eff4ff' : 'transparent',
                      color: layoutDir === d ? '#2563eb' : '#9ca3af',
                      display: 'flex', alignItems: 'center', gap: 4,
                    }}>
                      {d === 'TB' ? <AlignCenter size={11} /> : <AlignLeft size={11} />} {d}
                    </button>
                  ))}
                </ToolGroup>

                {/* Critical path */}
                {graphData?.critical_path?.length > 0 && (
                  <button onClick={() => {
                    if (cyRef.current) {
                      highlightCriticalPath(cyRef.current, graphData.critical_path)
                      toast.success(`Critical path: ${graphData.critical_path.length} jobs`)
                    }
                  }} style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '5px 11px', background: '#fffbeb', border: '1px solid #fde68a', borderRadius: 8, fontSize: 11, fontWeight: 600, color: '#b45309', cursor: 'pointer' }}>
                    <Target size={12} /> Critical Path
                  </button>
                )}

                {/* Re-select jobs */}
                <button onClick={() => setSection('picker')} style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '5px 11px', background: '#f8f9fc', border: '1px solid #e4e8f0', borderRadius: 8, fontSize: 11, fontWeight: 600, color: '#374151', cursor: 'pointer', marginLeft: 2 }}>
                  <GitBranch size={12} /> Change Selection
                </button>

                {/* Export */}
                <ToolGroup style={{ marginLeft: 'auto' }}>
                  <TBtn title="Export PNG" onClick={handleExportPNG}><ImageIcon size={12} /><span style={{ fontSize: 11 }}>PNG</span></TBtn>
                  <TBtn title="Export SVG" onClick={handleExportSVG}><FileCode size={12} /><span style={{ fontSize: 11 }}>SVG</span></TBtn>
                </ToolGroup>
              </div>

              {/* Graph canvas */}
              <div style={{ position: 'relative', borderRadius: 12, overflow: 'hidden', border: '1px solid #2d3748', height: 520 }}>
                {/* Cycle warning */}
                {graphData?.has_cycles && (
                  <div style={{
                    position: 'absolute', top: 10, left: '50%', transform: 'translateX(-50%)',
                    zIndex: 10, display: 'flex', alignItems: 'center', gap: 6,
                    padding: '6px 14px', background: 'rgba(127,29,29,0.95)',
                    border: '1px solid #991b1b', borderRadius: 8,
                  }}>
                    <AlertTriangle size={13} color="#fca5a5" />
                    <span style={{ fontSize: 11, color: '#fca5a5', fontWeight: 600 }}>
                      {graphData.cycle_details?.length} cycle{graphData.cycle_details?.length !== 1 ? 's' : ''} detected
                    </span>
                  </div>
                )}

                {/* Stats bar */}
                <div style={{
                  position: 'absolute', bottom: 10, left: 10, zIndex: 10,
                  display: 'flex', gap: 10, alignItems: 'center',
                  padding: '5px 10px', background: 'rgba(0,0,0,0.55)',
                  borderRadius: 7, backdropFilter: 'blur(6px)',
                }}>
                  {[
                    [`${graphData.node_count}`, 'nodes'],
                    [`${graphData.edge_count}`, 'edges'],
                    ...(graphData.critical_path?.length ? [[`${graphData.critical_path.length}`, 'in critical path']] : []),
                  ].map(([val, label], i, arr) => (
                    <>
                      <span key={label} style={{ fontSize: 11, color: '#94a3b8' }}>
                        <span style={{ fontFamily: 'monospace', color: '#e2e8f0', fontWeight: 700 }}>{val}</span> {label}
                      </span>
                      {i < arr.length - 1 && <span style={{ color: '#475569', fontSize: 10 }}>·</span>}
                    </>
                  ))}
                </div>

                {/* Hint */}
                <div style={{
                  position: 'absolute', bottom: 10, right: 10, zIndex: 10,
                  fontSize: 10, color: '#64748b',
                  padding: '3px 8px', background: 'rgba(0,0,0,0.4)', borderRadius: 5,
                }}>
                  Scroll to zoom · Drag to pan
                </div>

                <div ref={containerRef} style={{ width: '100%', height: '100%', background: '#1a1d27' }} />
              </div>
            </>
          )}
        </>
      )}
    </div>
  )
}

/* ─────────────────────────────────────────────────────────────────
   MAIN FILE CARD
───────────────────────────────────────────────────────────────────*/
export default function FileCard({ fileEntry, index, onRegisterCyRef, onUnregisterCyRef }) {
  const [activeTab, setActiveTab] = useState('preview') // 'preview' | 'graph'
  const [collapsed, setCollapsed] = useState(false)

  const hue   = (index * 53 + 210) % 360
  const color = `hsl(${hue}, 65%, 42%)`
  const ext   = fileEntry.fileName.split('.').pop().toLowerCase()

  return (
    <div style={{ background: '#ffffff', border: '1px solid #e4e8f0', borderRadius: 16, overflow: 'hidden', boxShadow: '0 2px 8px rgba(0,0,0,0.05)' }}>
      {/* Card header */}
      <div style={{ background: '#f8f9fc', borderBottom: collapsed ? 'none' : '1px solid #e4e8f0', padding: '14px 20px', display: 'flex', alignItems: 'center', gap: 14 }}>
        <div style={{ width: 34, height: 34, borderRadius: 9, background: color, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontSize: 13, fontWeight: 700, flexShrink: 0 }}>
          {index + 1}
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 14, fontWeight: 700, color: '#111827', fontFamily: 'monospace', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
            {fileEntry.fileName}
          </div>
          <div style={{ fontSize: 11, color: '#9ca3af', marginTop: 2, display: 'flex', gap: 10 }}>
            <span>{fileEntry.uploadData?.row_count ?? '?'} jobs</span>
            <span style={{ textTransform: 'uppercase', fontWeight: 600 }}>{ext}</span>
            {fileEntry.graphData && (
              <span style={{ color: '#16a34a', fontWeight: 600 }}>
                ✓ {fileEntry.graphData.node_count} nodes graphed
              </span>
            )}
          </div>
        </div>

        {/* Tab switcher */}
        <div style={{ display: 'flex', background: '#ffffff', border: '1px solid #e4e8f0', borderRadius: 8, padding: 3, gap: 2 }}>
          {[['preview', 'Data Preview'], ['graph', 'Dependency Diagram']].map(([id, label]) => (
            <button key={id} onClick={() => setActiveTab(id)} style={{
              padding: '5px 14px', borderRadius: 6, border: 'none', fontSize: 12, fontWeight: 600,
              cursor: 'pointer', transition: 'all 0.1s',
              background: activeTab === id ? '#eff4ff' : 'transparent',
              color: activeTab === id ? '#1d4ed8' : '#9ca3af',
              boxShadow: activeTab === id ? '0 1px 3px rgba(37,99,235,0.12)' : 'none',
            }}>
              {label}
            </button>
          ))}
        </div>

        {/* Collapse toggle */}
        <button onClick={() => setCollapsed(c => !c)}
          style={{ padding: 7, border: '1px solid #e4e8f0', borderRadius: 8, background: '#ffffff', cursor: 'pointer', display: 'flex' }}>
          {collapsed ? <ChevronDown size={14} color="#6b7280" /> : <ChevronUp size={14} color="#6b7280" />}
        </button>
      </div>

      {!collapsed && (
        <div style={{ padding: 20 }}>
          {activeTab === 'preview' && <PreviewTable sessionId={fileEntry.sessionId} uploadData={fileEntry.uploadData} />}
          {activeTab === 'graph'   && <GraphPanel fileEntry={fileEntry} onRegisterCyRef={onRegisterCyRef} onUnregisterCyRef={onUnregisterCyRef} />}
        </div>
      )}
    </div>
  )
}

/* ─────────────────────────────────────────────────────────────────
   Small shared style helpers
───────────────────────────────────────────────────────────────────*/
const thStyle = { padding: '9px 12px', textAlign: 'left', fontSize: 10, fontWeight: 700, color: '#9ca3af', letterSpacing: '0.06em', textTransform: 'uppercase', whiteSpace: 'nowrap' }
const tdStyle = { padding: '9px 12px' }
const labelStyle = { fontSize: 11, fontWeight: 700, color: '#9ca3af', letterSpacing: '0.07em', textTransform: 'uppercase' }

const btnPrimary = {
  display: 'inline-flex', alignItems: 'center', gap: 6,
  padding: '8px 16px', borderRadius: 8, border: 'none',
  background: '#2563eb', color: '#ffffff', fontSize: 12, fontWeight: 700, cursor: 'pointer',
}
const btnSecondary = {
  display: 'inline-flex', alignItems: 'center', gap: 6,
  padding: '8px 16px', borderRadius: 8, border: '1px solid #e4e8f0',
  background: '#ffffff', color: '#374151', fontSize: 12, fontWeight: 600, cursor: 'pointer',
}

function ToolGroup({ children, style = {} }) {
  return (
    <div style={{ display: 'flex', gap: 2, background: '#ffffff', border: '1px solid #e4e8f0', borderRadius: 8, padding: 3, ...style }}>
      {children}
    </div>
  )
}
function TBtn({ children, title, onClick }) {
  return (
    <button onClick={onClick} title={title} style={{
      display: 'flex', alignItems: 'center', gap: 3, padding: '5px 7px', borderRadius: 5,
      border: 'none', background: 'transparent', cursor: 'pointer', color: '#6b7280',
      transition: 'background 0.1s',
    }}
      onMouseEnter={e => e.currentTarget.style.background = '#f1f4f9'}
      onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
    >
      {children}
    </button>
  )
}

function triggerDownload(url, filename) {
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
  setTimeout(() => URL.revokeObjectURL(url), 3000)
}
