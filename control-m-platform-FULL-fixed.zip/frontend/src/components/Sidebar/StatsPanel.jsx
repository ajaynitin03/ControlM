// Stats moved into Overview panel on right side
export default function StatsPanel() { return null }
