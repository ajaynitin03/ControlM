// Kept for legacy compatibility — actual upload UI is now in the Upload tab (UploadPage)
export default function FileUpload() { return null }
