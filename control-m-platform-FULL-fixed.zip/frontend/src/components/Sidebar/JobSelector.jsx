import { useEffect, useState, useCallback } from 'react'
import Select from 'react-select'
import { Loader2, Network, Layers } from 'lucide-react'
import toast from 'react-hot-toast'
import { getJobs, buildGraph, getFullGraph } from '../../services/api'
import { useApp } from '../../hooks/useAppState'

export default function JobSelector() {
  const { state, dispatch } = useApp()
  const { sessionId, selectedJobs } = state
  const [options, setOptions] = useState([])
  const [loadingJobs, setLoadingJobs] = useState(false)
  const [buildingGraph, setBuildingGraph] = useState(false)
  const [depth, setDepth] = useState(3)

  useEffect(() => {
    if (!sessionId) return
    setLoadingJobs(true)
    getJobs(sessionId)
      .then((res) => {
        const opts = res.data.jobs.map((j) => ({
          value: j.JobId,
          label: `${j.JobId} — ${j.JobName}`,
          criticality: j.Criticality,
          app: j.AppName,
        }))
        setOptions(opts)
      })
      .catch(() => toast.error('Failed to load job list'))
      .finally(() => setLoadingJobs(false))
  }, [sessionId])

  const handleBuild = useCallback(async () => {
    if (!sessionId) return
    setBuildingGraph(true)
    try {
      const res = selectedJobs.length > 0
        ? await buildGraph(sessionId, selectedJobs, depth)
        : await getFullGraph(sessionId)
      dispatch({ type: 'SET_GRAPH_DATA', payload: res.data })
      dispatch({ type: 'SET_ACTIVE_TAB', payload: 'graph' })
      if (res.data.has_cycles) {
        toast.error(`⚠ Cycle detected in ${res.data.cycle_details.length} dependency loop(s)`, { duration: 5000 })
      } else {
        toast.success(`Graph built: ${res.data.node_count} nodes, ${res.data.edge_count} edges`)
      }
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Graph build failed')
    } finally {
      setBuildingGraph(false)
    }
  }, [sessionId, selectedJobs, depth, dispatch])

  const formatOptionLabel = ({ label, criticality }) => (
    <div className="flex items-center gap-2">
      <span className={`w-2 h-2 rounded-full flex-shrink-0 ${
        criticality === 'HIGH' ? 'bg-red-400' :
        criticality === 'MEDIUM' ? 'bg-orange-400' : 'bg-green-400'
      }`} />
      <span className="text-sm truncate">{label}</span>
    </div>
  )

  if (!sessionId) {
    return (
      <div className="p-4">
        <p className="label mb-2">Job Selection</p>
        <p className="text-xs text-slate-500">Upload a file first to select jobs.</p>
      </div>
    )
  }

  return (
    <div className="p-4 flex flex-col gap-3">
      <p className="label">Job Selection</p>

      {loadingJobs ? (
        <div className="flex items-center gap-2 text-slate-400 text-sm">
          <Loader2 size={14} className="animate-spin" />
          Loading jobs…
        </div>
      ) : (
        <Select
          isMulti
          options={options}
          value={options.filter((o) => selectedJobs.includes(o.value))}
          onChange={(vals) => dispatch({ type: 'SET_SELECTED_JOBS', payload: vals.map((v) => v.value) })}
          formatOptionLabel={formatOptionLabel}
          placeholder="All jobs (or search/select specific)"
          classNamePrefix="rs"
          menuPlacement="auto"
          maxMenuHeight={200}
          isClearable
        />
      )}

      <div>
        <label className="label block mb-1.5">Dependency Depth</label>
        <div className="flex items-center gap-3">
          <input
            type="range"
            min={1}
            max={10}
            value={depth}
            onChange={(e) => setDepth(+e.target.value)}
            className="flex-1 accent-brand-500"
          />
          <span className="text-sm font-mono text-slate-300 w-4 text-center">{depth}</span>
        </div>
      </div>

      <div className="flex gap-2">
        <button
          onClick={handleBuild}
          disabled={buildingGraph || !sessionId}
          className="btn-primary flex-1 flex items-center justify-center gap-2"
        >
          {buildingGraph
            ? <><Loader2 size={14} className="animate-spin" />Building…</>
            : <><Network size={14} />Build Graph</>
          }
        </button>

        <button
          onClick={() => {
            dispatch({ type: 'SET_SELECTED_JOBS', payload: [] })
            handleBuild()
          }}
          disabled={buildingGraph || !sessionId}
          title="Show all jobs"
          className="btn-ghost px-2.5"
        >
          <Layers size={16} />
        </button>
      </div>

      {selectedJobs.length > 0 && (
        <p className="text-xs text-slate-500">
          {selectedJobs.length} job{selectedJobs.length > 1 ? 's' : ''} selected — graph will show all upstream/downstream dependencies.
        </p>
      )}
    </div>
  )
}
