import { useEffect, useState } from 'react'
import { ChevronLeft, ChevronRight, Download } from 'lucide-react'
import { getPreview } from '../../services/api'
import { useApp } from '../../hooks/useAppState'

const CRIT_BADGE = {
  HIGH:   <span className="badge-high">HIGH</span>,
  MEDIUM: <span className="badge-medium">MED</span>,
  LOW:    <span className="badge-low">LOW</span>,
}

export default function DataPreview() {
  const { state } = useApp()
  const { sessionId, uploadData } = state
  const [page, setPage] = useState(1)
  const [data, setData] = useState(uploadData?.preview || [])
  const [totalPages, setTotalPages] = useState(uploadData?.total_pages || 1)
  const [loading, setLoading] = useState(false)
  const [columns] = useState(uploadData?.columns || [])

  useEffect(() => {
    if (!sessionId || page === 1) {
      setData(uploadData?.preview || [])
      setTotalPages(uploadData?.total_pages || 1)
      return
    }
    setLoading(true)
    getPreview(sessionId, page)
      .then((res) => {
        setData(res.data.data)
        setTotalPages(res.data.total_pages)
      })
      .finally(() => setLoading(false))
  }, [sessionId, page, uploadData])

  if (!uploadData) {
    return (
      <div className="flex-1 flex items-center justify-center text-slate-500">
        <p>Upload a file to preview data</p>
      </div>
    )
  }

  const renderCell = (col, val) => {
    if (col === 'Criticality') return CRIT_BADGE[val] || <span className="badge-low">{val || 'LOW'}</span>
    if (col === 'Predecessors' && val) {
      const preds = val.split(',').filter(Boolean)
      return (
        <div className="flex flex-wrap gap-1">
          {preds.map((p) => (
            <span key={p} className="px-1.5 py-0.5 bg-brand-950/40 border border-brand-800/30 rounded text-xs font-mono text-brand-300">
              {p}
            </span>
          ))}
        </div>
      )
    }
    return <span className="text-slate-300 text-xs">{val || '—'}</span>
  }

  return (
    <div className="flex-1 flex flex-col min-h-0 p-4">
      {/* Header */}
      <div className="flex items-center justify-between mb-3">
        <div>
          <h2 className="text-sm font-semibold text-slate-100">Data Preview</h2>
          <p className="text-xs text-slate-500">
            {uploadData.row_count} total rows · {columns.length} columns
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-500">
            Page {page} of {totalPages}
          </span>
          <button
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            disabled={page === 1 || loading}
            className="btn-ghost p-1.5"
          >
            <ChevronLeft size={15} />
          </button>
          <button
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            disabled={page === totalPages || loading}
            className="btn-ghost p-1.5"
          >
            <ChevronRight size={15} />
          </button>
        </div>
      </div>

      {/* Table */}
      <div className="flex-1 min-h-0 overflow-auto rounded-xl border border-surface-border">
        <table className="w-full text-left text-xs border-collapse">
          <thead className="sticky top-0 z-10">
            <tr className="bg-surface-card border-b border-surface-border">
              <th className="px-3 py-2.5 text-slate-400 font-semibold text-xs uppercase tracking-wider">#</th>
              {columns.map((col) => (
                <th
                  key={col}
                  className="px-3 py-2.5 text-slate-400 font-semibold text-xs uppercase tracking-wider whitespace-nowrap"
                >
                  {col}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan={columns.length + 1} className="text-center py-8 text-slate-500">
                  Loading…
                </td>
              </tr>
            ) : data.map((row, idx) => (
              <tr
                key={idx}
                className="border-b border-surface-border/50 hover:bg-surface-hover transition-colors"
              >
                <td className="px-3 py-2 text-slate-600 font-mono">
                  {(page - 1) * 50 + idx + 1}
                </td>
                {columns.map((col) => (
                  <td key={col} className="px-3 py-2 max-w-[200px]">
                    {renderCell(col, row[col])}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
