import { createContext, useContext, useReducer } from 'react'

const AppContext = createContext(null)

const initialState = {
  // ── Multi-file ──────────────────────────────────────────────────
  uploadedFiles:    [],  // [{ sessionId, fileName, uploadData, graphData, summary, isSelected }]
  selectedFileIds:  [],  // sessionIds chosen for preview/diagrams

  // ── Legacy single-file (picker / graph / analysis tabs) ─────────
  sessionId:        null,
  uploadData:       null,
  graphData:        null,
  summary:          null,
  selectedJobs:     [],
  selectedNode:     null,
  activeTab:        'upload',
  impactData:       null,
  criticalPathData: null,
  fanMetrics:       null,
  loading:          {},
  errors:           {},
}

function reducer(state, action) {
  switch (action.type) {
    case 'ADD_UPLOADED_FILE': {
      const exists = state.uploadedFiles.some(f => f.sessionId === action.payload.sessionId)
      if (exists) {
        return {
          ...state,
          uploadedFiles: state.uploadedFiles.map(f =>
            f.sessionId === action.payload.sessionId ? { ...f, ...action.payload } : f
          ),
        }
      }
      return { ...state, uploadedFiles: [...state.uploadedFiles, action.payload] }
    }
    case 'UPDATE_FILE_GRAPH':
      return {
        ...state,
        uploadedFiles: state.uploadedFiles.map(f =>
          f.sessionId === action.sessionId ? { ...f, graphData: action.payload } : f
        ),
      }
    case 'UPDATE_FILE_SUMMARY':
      return {
        ...state,
        uploadedFiles: state.uploadedFiles.map(f =>
          f.sessionId === action.sessionId ? { ...f, summary: action.payload } : f
        ),
      }
    case 'TOGGLE_FILE_SELECTED': {
      const sid = action.payload
      const next = state.selectedFileIds.includes(sid)
        ? state.selectedFileIds.filter(id => id !== sid)
        : [...state.selectedFileIds, sid]
      return { ...state, selectedFileIds: next }
    }
    case 'SET_SELECTED_FILE_IDS':
      return { ...state, selectedFileIds: action.payload }
    case 'REMOVE_UPLOADED_FILE': {
      const remaining = state.uploadedFiles.filter(f => f.sessionId !== action.payload)
      return {
        ...state,
        uploadedFiles: remaining,
        selectedFileIds: state.selectedFileIds.filter(id => id !== action.payload),
        // Reset legacy if it was the active session
        sessionId:  state.sessionId === action.payload ? (remaining[0]?.sessionId ?? null) : state.sessionId,
        uploadData: state.sessionId === action.payload ? (remaining[0]?.uploadData ?? null) : state.uploadData,
      }
    }
    case 'SET_SESSION':         return { ...state, sessionId: action.payload }
    case 'SET_UPLOAD_DATA':     return { ...state, uploadData: action.payload }
    case 'SET_GRAPH_DATA':      return { ...state, graphData: action.payload }
    case 'SET_SUMMARY':         return { ...state, summary: action.payload }
    case 'SET_SELECTED_JOBS':   return { ...state, selectedJobs: action.payload }
    case 'SET_SELECTED_NODE':   return { ...state, selectedNode: action.payload }
    case 'SET_ACTIVE_TAB':      return { ...state, activeTab: action.payload }
    case 'SET_IMPACT_DATA':     return { ...state, impactData: action.payload }
    case 'SET_CRITICAL_PATH':   return { ...state, criticalPathData: action.payload }
    case 'SET_FAN_METRICS':     return { ...state, fanMetrics: action.payload }
    case 'SET_LOADING':         return { ...state, loading: { ...state.loading, [action.key]: action.payload } }
    case 'SET_ERROR':           return { ...state, errors: { ...state.errors, [action.key]: action.payload } }
    case 'RESET':               return initialState
    default:                    return state
  }
}

export function AppProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, initialState)
  return (
    <AppContext.Provider value={{ state, dispatch }}>
      {children}
    </AppContext.Provider>
  )
}

export function useApp() {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error('useApp must be used within AppProvider')
  return ctx
}
