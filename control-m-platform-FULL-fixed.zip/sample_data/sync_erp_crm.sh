#!/bin/bash

echo "Syncing ERP data to CRM..."

sqlplus crm_user/pass@CRMDB <<EOF
INSERT INTO crm_transactions
SELECT * FROM erp_staging;

COMMIT;
EOF

if [ $? -ne 0 ]; then
  echo "CRM sync failed"
  exit 1
fi

echo "ERP to CRM sync completed"