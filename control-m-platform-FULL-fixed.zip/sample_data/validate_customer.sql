SELECT COUNT(*) 
FROM customers
WHERE customer_id IS NULL;