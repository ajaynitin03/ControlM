#!/bin/bash

echo "Starting ERP Data Extraction..."

# Simulate data extraction from ERP system
scp erp.admin@erp-server:/data/erp_transactions.dat /data/staging/

if [ $? -ne 0 ]; then
  echo "File transfer failed"
  exit 1
fi

echo "ERP data extracted successfully"