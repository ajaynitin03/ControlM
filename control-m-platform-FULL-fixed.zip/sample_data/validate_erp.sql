-- Validate ERP Data Integrity

SELECT COUNT(*) AS invalid_records
FROM erp_staging
WHERE transaction_id IS NULL
   OR amount <= 0;

-- Check duplicates
SELECT transaction_id, COUNT(*)
FROM erp_staging
GROUP BY transaction_id
HAVING COUNT(*) > 1;