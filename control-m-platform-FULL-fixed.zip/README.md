# Control-M Job Dependency Visualizer

**A production-grade web application for visualizing, analyzing, and understanding Control-M job schedules and their dependencies.**

---

## Overview

Control-M Job Dependency Visualizer ingests job schedule files (CSV, JSON, or XML), normalizes them to a canonical schema, and renders interactive directed acyclic graphs (DAGs) with risk highlighting, critical path analysis, cycle detection, and impact analysis.

Built for operations teams, data engineers, and system administrators who need to understand complex batch job pipelines at a glance.

---

## Features

| Feature | Description |
|---|---|
| **Multi-format Upload** | Accept CSV, JSON, XML — auto-converted to normalized CSV |
| **Data Preview** | Paginated table view (50 rows/page) with formatted columns |
| **DAG Visualization** | Interactive Cytoscape.js graph with dagre layout |
| **Risk Highlighting** | HIGH (red/glow), MEDIUM (orange), LOW (green) node styles |
| **Node Details** | Click any node for a detailed job properties panel |
| **Critical Path** | Highlight the longest dependency chain |
| **Cycle Detection** | Detect and display invalid dependency loops |
| **Fan-in / Fan-out** | Per-job incoming/outgoing dependency counts |
| **Impact Analysis** | Simulate job failure → highlight all affected downstream jobs |
| **Export** | Download graph as PNG or SVG |
| **CSV Export** | Download normalized CSV from any input format |

---

## Architecture

```
control-m-viz/
├── backend/                    # FastAPI Python backend
│   ├── main.py                 # App entry point, CORS, router registration
│   ├── requirements.txt
│   ├── models/
│   │   └── schemas.py          # Pydantic request/response models
│   ├── routers/
│   │   ├── upload.py           # /api/upload  - file ingestion & preview
│   │   ├── graph.py            # /api/graph   - DAG construction
│   │   └── analysis.py        # /api/analysis - critical path, fan, cycles
│   └── services/
│       ├── file_processor.py   # CSV/JSON/XML normalization pipeline
│       └── graph_service.py    # NetworkX graph logic
│
├── frontend/                   # React + Vite + Tailwind CSS
│   ├── index.html
│   ├── vite.config.js
│   ├── tailwind.config.js
│   └── src/
│       ├── App.jsx             # Root component with tab routing
│       ├── main.jsx
│       ├── index.css
│       ├── hooks/
│       │   └── useAppState.jsx # Global state with useReducer + Context
│       ├── services/
│       │   └── api.js          # Axios API client
│       ├── utils/
│       │   └── cytoscapeBuilder.js  # Cytoscape init, styles, export
│       └── components/
│           ├── Sidebar/        # Nav, upload, job selector, stats
│           ├── DataPreview/    # Paginated table
│           ├── GraphPanel/     # Main Cytoscape visualization
│           ├── JobDetails/     # Click-to-inspect node panel
│           └── Analysis/       # Critical path, fan metrics, cycles
│
└── sample_data/
    ├── sample_jobs.csv
    ├── sample_jobs.json
    └── sample_jobs.xml
```

---

## Tech Stack

| Layer | Technology |
|---|---|
| Frontend | React 18, Vite, Tailwind CSS |
| Graph | Cytoscape.js + cytoscape-dagre |
| HTTP Client | Axios |
| UI | Custom Tailwind components (dark enterprise theme) |
| Backend | FastAPI (Python 3.10+) |
| Data | pandas, NetworkX |
| Parsing | xmltodict |
| State | React Context + useReducer |

---

## Setup

### Prerequisites
- Python 3.10+
- Node.js 18+

### Backend

```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

The API will be available at `http://localhost:8000`  
Swagger docs at `http://localhost:8000/docs`

### Frontend

```bash
cd frontend
npm install
npm run dev
```

The app will be available at `http://localhost:5173`

The Vite dev server proxies `/api` → `http://localhost:8000` automatically.

### Production Build

```bash
# Frontend
cd frontend && npm run build
# Serve dist/ with nginx or any static server

# Backend
uvicorn main:app --host 0.0.0.0 --port 8000 --workers 4
```

---

## API Endpoints

### Upload

| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/upload/` | Upload CSV/JSON/XML, returns preview + session |
| GET | `/api/upload/preview/{session_id}` | Paginated data (page, page_size) |
| GET | `/api/upload/jobs/{session_id}` | All jobs for dropdown |
| GET | `/api/upload/export/{session_id}` | Download normalized CSV |

### Graph

| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/graph/build` | Build graph for selected jobs (+ upstream/downstream) |
| GET | `/api/graph/full/{session_id}` | Build graph for all jobs |

**POST /api/graph/build body:**
```json
{
  "session_id": "uuid",
  "job_ids": ["JOB001", "JOB002"],
  "depth": 3
}
```

### Analysis

| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/analysis/impact` | Impact analysis for a given job |
| GET | `/api/analysis/critical-path/{session_id}` | Longest dependency chain |
| GET | `/api/analysis/fan-metrics/{session_id}` | Fan-in/fan-out per job |
| GET | `/api/analysis/cycles/{session_id}` | Cycle detection |
| GET | `/api/analysis/summary/{session_id}` | Overview stats |

---

## CSV Schema

| Column | Type | Required | Description |
|---|---|---|---|
| JobId | string | ✓ | Unique job identifier |
| JobName | string | ✓ | Human-readable job name |
| AppName | string | | Application group name |
| SubApplication | string | | Sub-application category |
| Platform | string | | Server/platform name |
| Schedule | string | | Cron expression or schedule name |
| Predecessors | string | | Comma-separated predecessor JobIds |
| Criticality | enum | | HIGH / MEDIUM / LOW |
| Runtime | string | | Estimated duration (e.g. "45m") |
| Owner | string | | Job owner/team |
| Description | string | | Job description |
| Status | string | | Active / Inactive / etc. |
| Folder | string | | Control-M folder name |
| OrderMethod | string | | Ordering method |
| MaxWaitTime | string | | Maximum wait time in minutes |

### Column Aliases

The backend auto-maps common column name variants:

| Input | Canonical |
|---|---|
| `job_id`, `id` | `JobId` |
| `job_name`, `name` | `JobName` |
| `app_name`, `application` | `AppName` |
| `depends_on`, `parent` | `Predecessors` |
| `priority`, `severity` | `Criticality` |
| `duration` | `Runtime` |

---

## Graph Visualization

### Node Colors
- 🔴 **RED** — HIGH criticality (larger node, red glow)
- 🟠 **ORANGE** — MEDIUM criticality (medium node, orange glow)
- 🟢 **GREEN** — LOW criticality (standard node)
- 🔵 **BLUE** — Selected node or selected job
- 🟡 **AMBER** — Critical path nodes/edges

### Interactions
- **Click node** — Show details panel with job properties
- **Click background** — Deselect / clear highlights
- **Scroll** — Zoom in/out
- **Drag** — Pan the graph
- **Zoom controls** — Toolbar top-left
- **Fit** — Auto-fit graph in view

---

## Screenshots

> *(Add screenshots here after deployment)*

| View | Description |
|---|---|
| `screenshot_upload.png` | File upload drag-and-drop interface |
| `screenshot_preview.png` | Paginated data preview table |
| `screenshot_graph.png` | Full dependency graph with risk highlighting |
| `screenshot_details.png` | Node detail panel with fan metrics |
| `screenshot_analysis.png` | Critical path and fan-in/fan-out analysis |

---

## Environment Variables

| Variable | Default | Description |
|---|---|---|
| `VITE_API_BASE` | `/api` | Backend base URL (set for production) |

For production, set `VITE_API_BASE=https://your-api.domain.com/api` in `.env.production`.

---

## Production Considerations

- **Session storage** — Replace in-memory `SESSION_STORE` dict with Redis for multi-worker deployments
- **File size** — Add `MAX_FILE_SIZE` validation for large uploads
- **Auth** — Integrate JWT/OAuth2 via FastAPI security utilities
- **Rate limiting** — Add `slowapi` or nginx rate limiting
- **CORS** — Restrict `allow_origins` to your frontend domain

---

## License

MIT — see LICENSE for details.
