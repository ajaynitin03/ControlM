from pydantic import BaseModel
from typing import List, Optional, Dict, Any


class JobRecord(BaseModel):
    JobId: str
    JobName: str
    AppName: Optional[str] = ""
    SubApplication: Optional[str] = ""
    Platform: Optional[str] = ""
    Schedule: Optional[str] = ""
    Predecessors: Optional[str] = ""
    Criticality: Optional[str] = "LOW"
    Runtime: Optional[str] = ""
    Owner: Optional[str] = ""
    Description: Optional[str] = ""
    Status: Optional[str] = ""
    Folder: Optional[str] = ""
    OrderMethod: Optional[str] = ""
    MaxWaitTime: Optional[str] = ""


class UploadResponse(BaseModel):
    success: bool
    message: str
    row_count: int
    columns: List[str]
    preview: List[Dict[str, Any]]
    session_id: str


class GraphRequest(BaseModel):
    session_id: str
    job_ids: List[str]
    depth: Optional[int] = 3


class GraphNode(BaseModel):
    id: str
    label: str
    criticality: str
    app_name: str
    platform: str
    schedule: str
    runtime: str
    owner: str
    status: str
    fan_in: int
    fan_out: int
    is_critical_path: bool


class GraphEdge(BaseModel):
    source: str
    target: str


class GraphResponse(BaseModel):
    nodes: List[GraphNode]
    edges: List[GraphEdge]
    has_cycles: bool
    cycle_details: List[List[str]]
    critical_path: List[str]
    session_id: str


class ImpactRequest(BaseModel):
    session_id: str
    job_id: str


class ImpactResponse(BaseModel):
    failed_job: str
    affected_jobs: List[str]
    affected_count: int
