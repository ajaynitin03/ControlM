import networkx as nx
import pandas as pd
from typing import List, Dict, Tuple, Any, Set


def build_graph(df: pd.DataFrame) -> nx.DiGraph:
    """Build a directed graph from the jobs DataFrame."""
    G = nx.DiGraph()

    for _, row in df.iterrows():
        G.add_node(
            row["JobId"],
            label=row["JobName"],
            job_id=row["JobId"],
            criticality=row["Criticality"],
            app_name=row["AppName"],
            sub_application=row.get("SubApplication", ""),
            platform=row["Platform"],
            schedule=row["Schedule"],
            runtime=row["Runtime"],
            owner=row["Owner"],
            description=row["Description"],
            status=row["Status"],
            folder=row["Folder"],
        )

    all_job_ids = set(df["JobId"].tolist())
    for _, row in df.iterrows():
        preds_raw = row.get("Predecessors", "")
        if not preds_raw or str(preds_raw).strip() == "":
            continue
        predecessors = [p.strip() for p in str(preds_raw).split(",") if p.strip()]
        for pred in predecessors:
            if pred in all_job_ids:
                G.add_edge(pred, row["JobId"])
            else:
                if not G.has_node(pred):
                    G.add_node(pred, label=pred, job_id=pred, criticality="LOW",
                               app_name="External", sub_application="",
                               platform="", schedule="", runtime="",
                               owner="", description="External dependency",
                               status="", folder="")
                G.add_edge(pred, row["JobId"])

    return G


def detect_cycles(G: nx.DiGraph) -> Tuple[bool, List[List[str]]]:
    try:
        cycles = list(nx.simple_cycles(G))
        return len(cycles) > 0, cycles[:10]
    except Exception:
        return False, []


def find_critical_path(G: nx.DiGraph) -> List[str]:
    if len(G.nodes) == 0:
        return []
    try:
        dag = nx.DiGraph([(u, v) for u, v in G.edges()
                          if not nx.has_path(G, v, u) or u == v])
    except Exception:
        dag = G

    if dag.number_of_nodes() == 0:
        return []

    try:
        topo = list(nx.topological_sort(dag))
        dist = {node: 0 for node in topo}
        prev = {node: None for node in topo}

        for node in topo:
            for successor in dag.successors(node):
                if dist[node] + 1 > dist[successor]:
                    dist[successor] = dist[node] + 1
                    prev[successor] = node

        if not dist:
            return []

        end_node = max(dist, key=dist.get)
        path = []
        current = end_node
        while current is not None:
            path.append(current)
            current = prev[current]
        return list(reversed(path))
    except Exception:
        return []


def get_subgraph_for_jobs(G: nx.DiGraph, job_ids: List[str], depth: int = 3) -> nx.DiGraph:
    nodes_to_include: Set[str] = set()
    for job_id in job_ids:
        if job_id not in G:
            continue
        nodes_to_include.add(job_id)
        try:
            nodes_to_include.update(nx.ancestors(G, job_id))
        except Exception:
            pass
        try:
            nodes_to_include.update(nx.descendants(G, job_id))
        except Exception:
            pass

    if not nodes_to_include:
        return G

    return G.subgraph(nodes_to_include).copy()


def compute_fan_metrics(G: nx.DiGraph) -> Dict[str, Dict[str, int]]:
    return {
        node: {"fan_in": G.in_degree(node), "fan_out": G.out_degree(node)}
        for node in G.nodes()
    }


def get_impact_analysis(G: nx.DiGraph, job_id: str) -> List[str]:
    if job_id not in G:
        return []
    try:
        return list(nx.descendants(G, job_id))
    except Exception:
        return []


def graph_to_cytoscape(
    G: nx.DiGraph,
    critical_path: List[str],
    fan_metrics: Dict[str, Dict[str, int]],
    selected_jobs: List[str],
) -> Tuple[List[Dict], List[Dict]]:
    """Convert NetworkX graph to Cytoscape.js compound-node format."""
    critical_set = set(critical_path)
    selected_set = set(selected_jobs)

    # Collect unique AppName groups
    app_groups = {}
    for node_id, data in G.nodes(data=True):
        app = data.get("app_name", "").strip()
        if app and app != "External":
            if app not in app_groups:
                app_groups[app] = app  # group id = app name

    # Build compound parent nodes (one per AppName)
    group_nodes = []
    for app_name in app_groups:
        group_nodes.append({
            "data": {
                "id": f"__group__{app_name}",
                "label": app_name,
                "type": "group",
            }
        })

    # Build child (job) nodes
    nodes = []
    for node_id, data in G.nodes(data=True):
        fan = fan_metrics.get(node_id, {"fan_in": 0, "fan_out": 0})
        app = data.get("app_name", "").strip()
        parent_id = f"__group__{app}" if app and app != "External" else None

        # Build two-line display label: "JOB_NAME\n(JOB_ID)"
        job_name = data.get("label", node_id)
        display_label = f"{job_name}\n({node_id})"

        node_data: Dict[str, Any] = {
            "id": node_id,
            "label": job_name,
            "displayLabel": display_label,
            "job_id": node_id,
            "criticality": data.get("criticality", "LOW"),
            "app_name": app,
            "platform": data.get("platform", ""),
            "schedule": data.get("schedule", ""),
            "runtime": data.get("runtime", ""),
            "owner": data.get("owner", ""),
            "description": data.get("description", ""),
            "status": data.get("status", ""),
            "folder": data.get("folder", ""),
            "fan_in": fan["fan_in"],
            "fan_out": fan["fan_out"],
            "is_critical_path": node_id in critical_set,
            "is_selected": node_id in selected_set,
        }
        if parent_id:
            node_data["parent"] = parent_id

        nodes.append({"data": node_data})

    # Build edges
    edges = []
    for source, target in G.edges():
        edges.append({
            "data": {
                "id": f"{source}__{target}",
                "source": source,
                "target": target,
                "is_critical_path": source in critical_set and target in critical_set,
            }
        })

    return group_nodes + nodes, edges
