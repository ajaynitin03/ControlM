from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from routers import upload, graph, analysis

app = FastAPI(
    title="Control-M Job Scheduler Visualizer",
    description="Production-grade API for visualizing and analyzing Control-M job dependencies",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(upload.router, prefix="/api/upload", tags=["Upload"])
app.include_router(graph.router, prefix="/api/graph", tags=["Graph"])
app.include_router(analysis.router, prefix="/api/analysis", tags=["Analysis"])


@app.get("/api/health")
def health():
    return {"status": "ok", "version": "1.0.0"}
