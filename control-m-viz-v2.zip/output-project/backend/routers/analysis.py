import networkx as nx
from fastapi import APIRouter, HTTPException
from models.schemas import ImpactRequest
from services.file_processor import get_session
from services.graph_service import (
    build_graph, find_critical_path, get_impact_analysis,
    compute_fan_metrics, detect_cycles
)

router = APIRouter()


@router.post("/impact")
async def impact_analysis(request: ImpactRequest):
    """Analyze impact if a specific job fails."""
    try:
        df = get_session(request.session_id)
    except KeyError:
        raise HTTPException(status_code=404, detail="Session not found")

    G = build_graph(df)
    affected = get_impact_analysis(G, request.job_id)

    # Enrich with job names
    job_map = dict(zip(df["JobId"], df["JobName"]))
    affected_enriched = [
        {"job_id": j, "job_name": job_map.get(j, j)} for j in affected
    ]

    return {
        "failed_job": request.job_id,
        "failed_job_name": job_map.get(request.job_id, request.job_id),
        "affected_jobs": affected_enriched,
        "affected_count": len(affected),
    }


@router.get("/critical-path/{session_id}")
async def get_critical_path(session_id: str):
    """Get the critical path (longest dependency chain)."""
    try:
        df = get_session(session_id)
    except KeyError:
        raise HTTPException(status_code=404, detail="Session not found")

    G = build_graph(df)
    path = find_critical_path(G)
    job_map = dict(zip(df["JobId"], df["JobName"]))
    crit_map = dict(zip(df["JobId"], df["Criticality"]))

    return {
        "critical_path": [
            {
                "job_id": j,
                "job_name": job_map.get(j, j),
                "criticality": crit_map.get(j, "LOW"),
            }
            for j in path
        ],
        "path_length": len(path),
    }


@router.get("/fan-metrics/{session_id}")
async def get_fan_metrics(session_id: str):
    """Get fan-in / fan-out metrics for all jobs."""
    try:
        df = get_session(session_id)
    except KeyError:
        raise HTTPException(status_code=404, detail="Session not found")

    G = build_graph(df)
    fan = compute_fan_metrics(G)
    job_map = dict(zip(df["JobId"], df["JobName"]))
    crit_map = dict(zip(df["JobId"], df["Criticality"]))

    metrics = [
        {
            "job_id": job_id,
            "job_name": job_map.get(job_id, job_id),
            "criticality": crit_map.get(job_id, "LOW"),
            "fan_in": vals["fan_in"],
            "fan_out": vals["fan_out"],
            "total_connections": vals["fan_in"] + vals["fan_out"],
        }
        for job_id, vals in fan.items()
    ]
    # Sort by total connections descending
    metrics.sort(key=lambda x: x["total_connections"], reverse=True)

    return {"metrics": metrics, "count": len(metrics)}


@router.get("/cycles/{session_id}")
async def get_cycles(session_id: str):
    """Detect and return all cycles."""
    try:
        df = get_session(session_id)
    except KeyError:
        raise HTTPException(status_code=404, detail="Session not found")

    G = build_graph(df)
    has_cycles, cycles = detect_cycles(G)
    job_map = dict(zip(df["JobId"], df["JobName"]))

    enriched_cycles = [
        [{"job_id": j, "job_name": job_map.get(j, j)} for j in cycle]
        for cycle in cycles
    ]

    return {
        "has_cycles": has_cycles,
        "cycle_count": len(cycles),
        "cycles": enriched_cycles,
    }


@router.get("/summary/{session_id}")
async def get_summary(session_id: str):
    """Get overall graph statistics summary."""
    try:
        df = get_session(session_id)
    except KeyError:
        raise HTTPException(status_code=404, detail="Session not found")

    G = build_graph(df)
    has_cycles, cycles = detect_cycles(G)
    critical_path = find_critical_path(G)

    # Criticality counts
    crit_counts = df["Criticality"].value_counts().to_dict()

    # Root nodes (no predecessors)
    root_nodes = [n for n in G.nodes() if G.in_degree(n) == 0]
    # Leaf nodes (no successors)
    leaf_nodes = [n for n in G.nodes() if G.out_degree(n) == 0]

    return {
        "total_jobs": len(df),
        "total_edges": G.number_of_edges(),
        "high_criticality": crit_counts.get("HIGH", 0),
        "medium_criticality": crit_counts.get("MEDIUM", 0),
        "low_criticality": crit_counts.get("LOW", 0),
        "has_cycles": has_cycles,
        "cycle_count": len(cycles),
        "critical_path_length": len(critical_path),
        "root_jobs": len(root_nodes),
        "leaf_jobs": len(leaf_nodes),
        "isolated_jobs": len(list(nx_isolated(G))),
    }


def nx_isolated(G):
    """Helper to find isolated nodes."""
    return [n for n in G.nodes() if G.degree(n) == 0]
