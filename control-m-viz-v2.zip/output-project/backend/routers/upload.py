from fastapi import APIRouter, UploadFile, File, HTTPException, Query
from fastapi.responses import StreamingResponse
import io
import pandas as pd
from services.file_processor import (
    process_csv, process_json, process_xml,
    save_session, get_session
)

router = APIRouter()


@router.post("/")
async def upload_file(file: UploadFile = File(...)):
    """Upload CSV, JSON, or XML file and return normalized data preview."""
    content = await file.read()
    filename = file.filename.lower()

    try:
        if filename.endswith(".csv"):
            df = process_csv(content)
        elif filename.endswith(".json"):
            df = process_json(content)
        elif filename.endswith(".xml"):
            df = process_xml(content)
        else:
            raise HTTPException(status_code=400, detail="Unsupported file type. Use CSV, JSON, or XML.")
    except Exception as e:
        raise HTTPException(status_code=422, detail=f"File processing failed: {str(e)}")

    if df.empty:
        raise HTTPException(status_code=422, detail="No valid records found in file.")

    session_id = save_session(df)

    preview = df.head(50).fillna("").to_dict(orient="records")

    return {
        "success": True,
        "message": f"Processed {len(df)} records successfully",
        "row_count": len(df),
        "columns": list(df.columns),
        "preview": preview,
        "session_id": session_id,
        "total_pages": (len(df) + 49) // 50,
    }


@router.get("/preview/{session_id}")
async def get_preview(
    session_id: str,
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=10, le=200),
):
    """Get paginated data preview for a session."""
    try:
        df = get_session(session_id)
    except KeyError:
        raise HTTPException(status_code=404, detail="Session not found")

    start = (page - 1) * page_size
    end = start + page_size
    page_df = df.iloc[start:end]

    return {
        "page": page,
        "page_size": page_size,
        "total_rows": len(df),
        "total_pages": (len(df) + page_size - 1) // page_size,
        "data": page_df.fillna("").to_dict(orient="records"),
        "columns": list(df.columns),
    }


@router.get("/jobs/{session_id}")
async def get_job_list(session_id: str):
    """Get list of all jobs for dropdown selection."""
    try:
        df = get_session(session_id)
    except KeyError:
        raise HTTPException(status_code=404, detail="Session not found")

    jobs = df[["JobId", "JobName", "AppName", "Criticality"]].fillna("").to_dict(orient="records")
    return {"jobs": jobs, "count": len(jobs)}


@router.get("/export/{session_id}")
async def export_csv(session_id: str):
    """Export normalized CSV."""
    try:
        df = get_session(session_id)
    except KeyError:
        raise HTTPException(status_code=404, detail="Session not found")

    output = io.StringIO()
    df.to_csv(output, index=False)
    output.seek(0)

    return StreamingResponse(
        io.BytesIO(output.getvalue().encode()),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=normalized_jobs.csv"},
    )
