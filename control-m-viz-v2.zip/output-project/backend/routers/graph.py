from fastapi import APIRouter, HTTPException
from models.schemas import GraphRequest
from services.file_processor import get_session
from services.graph_service import (
    build_graph, detect_cycles, find_critical_path,
    get_subgraph_for_jobs, compute_fan_metrics, graph_to_cytoscape
)

router = APIRouter()


@router.post("/build")
async def build_dependency_graph(request: GraphRequest):
    """Build dependency graph for selected jobs."""
    try:
        df = get_session(request.session_id)
    except KeyError:
        raise HTTPException(status_code=404, detail="Session not found")

    # Build full graph
    full_graph = build_graph(df)

    # Cycle detection on full graph
    has_cycles, cycle_details = detect_cycles(full_graph)

    # Get subgraph for selected jobs
    if request.job_ids:
        subgraph = get_subgraph_for_jobs(full_graph, request.job_ids, request.depth)
    else:
        subgraph = full_graph

    # Critical path
    critical_path = find_critical_path(subgraph)

    # Fan metrics
    fan_metrics = compute_fan_metrics(subgraph)

    # Convert to Cytoscape format
    nodes, edges = graph_to_cytoscape(subgraph, critical_path, fan_metrics, request.job_ids)

    return {
        "nodes": nodes,
        "edges": edges,
        "has_cycles": has_cycles,
        "cycle_details": cycle_details,
        "critical_path": critical_path,
        "node_count": len(nodes),
        "edge_count": len(edges),
        "session_id": request.session_id,
    }


@router.get("/full/{session_id}")
async def get_full_graph(session_id: str):
    """Build graph for all jobs in session."""
    try:
        df = get_session(session_id)
    except KeyError:
        raise HTTPException(status_code=404, detail="Session not found")

    full_graph = build_graph(df)
    has_cycles, cycle_details = detect_cycles(full_graph)
    critical_path = find_critical_path(full_graph)
    fan_metrics = compute_fan_metrics(full_graph)
    nodes, edges = graph_to_cytoscape(full_graph, critical_path, fan_metrics, [])

    return {
        "nodes": nodes,
        "edges": edges,
        "has_cycles": has_cycles,
        "cycle_details": cycle_details,
        "critical_path": critical_path,
        "node_count": len(nodes),
        "edge_count": len(edges),
        "session_id": session_id,
    }
