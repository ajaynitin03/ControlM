import axios from 'axios'

const api = axios.create({
  baseURL: '/api',
  timeout: 30000,
})

export const uploadFile = (file, onProgress) => {
  const formData = new FormData()
  formData.append('file', file)
  return api.post('/upload/', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
    onUploadProgress: onProgress,
  })
}

export const getPreview = (sessionId, page = 1, pageSize = 50) =>
  api.get(`/upload/preview/${sessionId}`, { params: { page, page_size: pageSize } })

export const getJobs = (sessionId) =>
  api.get(`/upload/jobs/${sessionId}`)

export const buildGraph = (sessionId, jobIds, depth = 3) =>
  api.post('/graph/build', { session_id: sessionId, job_ids: jobIds, depth })

export const getFullGraph = (sessionId) =>
  api.get(`/graph/full/${sessionId}`)

export const getImpactAnalysis = (sessionId, jobId) =>
  api.post('/analysis/impact', { session_id: sessionId, job_id: jobId })

export const getCriticalPath = (sessionId) =>
  api.get(`/analysis/critical-path/${sessionId}`)

export const getFanMetrics = (sessionId) =>
  api.get(`/analysis/fan-metrics/${sessionId}`)

export const getCycles = (sessionId) =>
  api.get(`/analysis/cycles/${sessionId}`)

export const getSummary = (sessionId) =>
  api.get(`/analysis/summary/${sessionId}`)

export const exportCsv = (sessionId) =>
  `${api.defaults.baseURL}/upload/export/${sessionId}`
