import { Toaster } from 'react-hot-toast'
import { AppProvider, useApp } from './hooks/useAppState'
import Sidebar       from './components/Sidebar'
import UploadPage    from './components/UploadPage'
import MultiFileView from './components/MultiFileView'
import AnalysisPanel from './components/Analysis'
import './index.css'

// Spin keyframe injected globally for Loader2
const style = document.createElement('style')
style.textContent = `
  @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
`
document.head.appendChild(style)

function MainContent() {
  const { state } = useApp()
  const { activeTab } = state

  return (
    <div style={{ display: 'flex', height: '100vh', width: '100vw', overflow: 'hidden', background: '#f8f9fc' }}>
      <Sidebar />

      {/* Main panel */}
      <main style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0, overflow: 'hidden' }}>
        {/* Top bar */}
        <header style={{
          height: 48, flexShrink: 0, background: '#ffffff',
          borderBottom: '1px solid #e4e8f0',
          display: 'flex', alignItems: 'center', padding: '0 24px',
          justifyContent: 'space-between',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <span style={{ fontSize: 12, color: '#9ca3af' }}>Control-M Visualizer</span>
            <span style={{ color: '#d1d5db' }}>›</span>
            <span style={{ fontSize: 12, fontWeight: 600, color: '#374151', textTransform: 'capitalize' }}>
              {activeTab === 'multiview' ? 'Diagrams & Data' : activeTab === 'upload' ? 'Upload Files' : activeTab === 'analysis' ? 'Analysis' : activeTab}
            </span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <div style={{ width: 7, height: 7, borderRadius: '50%', background: '#16a34a', boxShadow: '0 0 6px rgba(22,163,74,0.6)' }} />
            <span style={{ fontSize: 11, color: '#9ca3af' }}>API connected</span>
          </div>
        </header>

        {/* Page content */}
        <div style={{ flex: 1, display: 'flex', minHeight: 0, overflow: 'hidden' }}>
          {activeTab === 'upload'    && <UploadPage />}
          {activeTab === 'multiview' && <MultiFileView />}
          {activeTab === 'analysis'  && <AnalysisPanel />}

          {/* Picker & graph tabs redirect gracefully */}
          {(activeTab === 'picker' || activeTab === 'preview' || activeTab === 'graph') && (
            <LegacyTabRedirect />
          )}
        </div>
      </main>

      <Toaster
        position="bottom-right"
        toastOptions={{
          style: {
            background: '#ffffff',
            border: '1px solid #e4e8f0',
            color: '#374151',
            fontSize: '13px',
            boxShadow: '0 4px 12px rgba(0,0,0,0.10)',
          },
          success: { iconTheme: { primary: '#16a34a', secondary: '#ffffff' } },
          error:   { iconTheme: { primary: '#dc2626', secondary: '#ffffff' } },
        }}
      />
    </div>
  )
}

function LegacyTabRedirect() {
  const { dispatch } = useApp()
  return (
    <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#f8f9fc' }}>
      <div style={{ textAlign: 'center' }}>
        <div style={{ fontSize: 14, color: '#6b7280', marginBottom: 12 }}>
          This view has been moved to <strong>Diagrams &amp; Data</strong>
        </div>
        <button
          onClick={() => dispatch({ type: 'SET_ACTIVE_TAB', payload: 'multiview' })}
          style={{
            padding: '8px 20px', background: '#2563eb', color: '#fff', border: 'none',
            borderRadius: 8, fontSize: 13, fontWeight: 600, cursor: 'pointer',
          }}
        >
          Go to Diagrams &amp; Data →
        </button>
      </div>
    </div>
  )
}

export default function App() {
  return (
    <AppProvider>
      <MainContent />
    </AppProvider>
  )
}
