import { useState, useEffect, useRef, useCallback } from 'react'
import {
  ChevronLeft, ChevronRight, ChevronDown, ChevronUp,
  GitBranch, ZoomIn, ZoomOut, Maximize2, RotateCcw, Target,
  Download, Image, FileCode, AlertTriangle, Loader2,
  Wand2, ArrowLeftRight, AlignCenter, AlignLeft, Info
} from 'lucide-react'
import toast from 'react-hot-toast'
import { getPreview, getFullGraph } from '../../services/api'
import { useApp } from '../../hooks/useAppState'
import {
  initCytoscape, resetHighlight, highlightCriticalPath,
  exportPNG, exportSVG, relayout
} from '../../utils/cytoscapeBuilder'

/* ── Conversion targets ─────────────────────────────────────────── */
const CONVERSION_TARGETS = ['Python', 'Spring Batch', 'Shell Script', 'Java', 'PySpark', 'Airflow DAG', 'Ansible']

const CRIT_BADGE_STYLE = {
  HIGH:   { background: '#fef2f2', color: '#dc2626', border: '1px solid #fecaca' },
  MEDIUM: { background: '#fffbeb', color: '#d97706', border: '1px solid #fde68a' },
  LOW:    { background: '#f0fdf4', color: '#16a34a', border: '1px solid #bbf7d0' },
}

function CritBadge({ val }) {
  const style = CRIT_BADGE_STYLE[val] || CRIT_BADGE_STYLE.LOW
  return (
    <span style={{
      ...style, padding: '2px 7px', borderRadius: 5,
      fontSize: 10, fontWeight: 700, letterSpacing: '0.03em',
    }}>{val || 'LOW'}</span>
  )
}

/* ── Preview table ───────────────────────────────────────────────── */
function PreviewTable({ sessionId, uploadData }) {
  const [page, setPage]             = useState(1)
  const [data, setData]             = useState(uploadData?.preview || [])
  const [totalPages, setTotalPages] = useState(uploadData?.total_pages || 1)
  const [loading, setLoading]       = useState(false)
  const [expandedRow, setExpandedRow] = useState(null)
  const [convTarget, setConvTarget]   = useState('Python')
  const columns = uploadData?.columns || []

  useEffect(() => {
    if (!sessionId || page === 1) {
      setData(uploadData?.preview || [])
      setTotalPages(uploadData?.total_pages || 1)
      return
    }
    setLoading(true)
    getPreview(sessionId, page)
      .then(res => { setData(res.data.data); setTotalPages(res.data.total_pages) })
      .finally(() => setLoading(false))
  }, [sessionId, page])

  const renderCell = (col, val) => {
    if (col === 'Criticality') return <CritBadge val={val} />
    if (col === 'Predecessors' && val) {
      const preds = val.split(',').filter(Boolean)
      return (
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 3 }}>
          {preds.map(p => (
            <span key={p} style={{
              padding: '2px 6px', background: '#eff4ff', border: '1px solid #bfdbfe',
              borderRadius: 4, fontSize: 10, fontFamily: 'monospace', color: '#1d4ed8',
            }}>{p}</span>
          ))}
        </div>
      )
    }
    return <span style={{ fontSize: 12, color: '#374151' }}>{val || <span style={{ color: '#c0c6d4' }}>—</span>}</span>
  }

  return (
    <div>
      {/* Table controls */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
        <div style={{ fontSize: 12, color: '#6b7280' }}>
          <strong style={{ color: '#374151' }}>{uploadData?.row_count}</strong> jobs &nbsp;·&nbsp;
          <strong style={{ color: '#374151' }}>{columns.length}</strong> columns
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          {/* Conversion target selector */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <span style={{ fontSize: 11, color: '#9ca3af' }}>Convert to:</span>
            <select
              value={convTarget}
              onChange={e => setConvTarget(e.target.value)}
              style={{
                fontSize: 11, padding: '3px 8px', borderRadius: 6,
                border: '1px solid #e4e8f0', background: '#ffffff', color: '#374151',
                cursor: 'pointer',
              }}
            >
              {CONVERSION_TARGETS.map(t => <option key={t}>{t}</option>)}
            </select>
          </div>
          {/* Pagination */}
          <span style={{ fontSize: 12, color: '#9ca3af' }}>Page {page}/{totalPages}</span>
          <button onClick={() => setPage(p => Math.max(1, p-1))} disabled={page===1||loading}
            style={{ padding: '4px 7px', border: '1px solid #e4e8f0', borderRadius: 6, background: '#fff', cursor: 'pointer', opacity: page===1?0.4:1 }}>
            <ChevronLeft size={12} color="#6b7280" />
          </button>
          <button onClick={() => setPage(p => Math.min(totalPages, p+1))} disabled={page===totalPages||loading}
            style={{ padding: '4px 7px', border: '1px solid #e4e8f0', borderRadius: 6, background: '#fff', cursor: 'pointer', opacity: page===totalPages?0.4:1 }}>
            <ChevronRight size={12} color="#6b7280" />
          </button>
        </div>
      </div>

      {/* Table */}
      <div style={{ overflowX: 'auto', overflowY: 'auto', maxHeight: 360, borderRadius: 10, border: '1px solid #e4e8f0' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
          <thead style={{ position: 'sticky', top: 0, zIndex: 1, background: '#f8f9fc' }}>
            <tr style={{ borderBottom: '1px solid #e4e8f0' }}>
              <th style={{ padding: '9px 12px', textAlign: 'left', fontSize: 10, fontWeight: 700, color: '#9ca3af', letterSpacing: '0.06em', textTransform: 'uppercase', whiteSpace: 'nowrap' }}>#</th>
              {columns.map(col => (
                <th key={col} style={{ padding: '9px 12px', textAlign: 'left', fontSize: 10, fontWeight: 700, color: '#9ca3af', letterSpacing: '0.06em', textTransform: 'uppercase', whiteSpace: 'nowrap' }}>
                  {col}
                </th>
              ))}
              <th style={{ padding: '9px 12px', textAlign: 'left', fontSize: 10, fontWeight: 700, color: '#9ca3af', letterSpacing: '0.06em', textTransform: 'uppercase', whiteSpace: 'nowrap' }}>
                Actions
              </th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={columns.length + 2} style={{ textAlign: 'center', padding: 24, color: '#9ca3af' }}>Loading…</td></tr>
            ) : data.map((row, idx) => (
              <>
                <tr key={idx}
                  style={{ borderBottom: '1px solid #f1f3f7', background: expandedRow === idx ? '#fafbff' : '#ffffff', transition: 'background 0.1s', cursor: 'pointer' }}
                  onClick={() => setExpandedRow(expandedRow === idx ? null : idx)}
                >
                  <td style={{ padding: '9px 12px', color: '#9ca3af', fontFamily: 'monospace', fontSize: 11 }}>
                    {(page-1)*50+idx+1}
                  </td>
                  {columns.map(col => (
                    <td key={col} style={{ padding: '9px 12px', maxWidth: 200 }}>{renderCell(col, row[col])}</td>
                  ))}
                  <td style={{ padding: '9px 12px' }}>
                    <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                      {/* LLM convert button — DISABLED, no functionality */}
                      <button
                        disabled
                        title={`LLM convert to ${convTarget} — coming soon`}
                        style={{
                          display: 'flex', alignItems: 'center', gap: 5,
                          padding: '4px 9px', borderRadius: 6, fontSize: 11, fontWeight: 600,
                          color: '#7c3aed', background: '#f5f3ff', border: '1px solid #ddd6fe',
                          cursor: 'not-allowed', opacity: 0.55,
                          whiteSpace: 'nowrap',
                        }}
                      >
                        <Wand2 size={11} /> LLM to {convTarget}
                      </button>

                      {/* Job conversion button — DISABLED */}
                      <button
                        disabled
                        title="Job conversion — coming soon"
                        style={{
                          display: 'flex', alignItems: 'center', gap: 5,
                          padding: '4px 9px', borderRadius: 6, fontSize: 11, fontWeight: 600,
                          color: '#0891b2', background: '#ecfeff', border: '1px solid #a5f3fc',
                          cursor: 'not-allowed', opacity: 0.55,
                          whiteSpace: 'nowrap',
                        }}
                      >
                        <ArrowLeftRight size={11} /> Convert Job
                      </button>

                      <button
                        onClick={e => { e.stopPropagation(); setExpandedRow(expandedRow === idx ? null : idx) }}
                        style={{ padding: '4px 6px', border: '1px solid #e4e8f0', borderRadius: 6, background: '#fff', cursor: 'pointer' }}
                        title="View details"
                      >
                        <Info size={11} color="#6b7280" />
                      </button>
                    </div>
                  </td>
                </tr>
                {/* Expanded row — detailed job analysis */}
                {expandedRow === idx && (
                  <tr key={`exp-${idx}`} style={{ background: '#fafbff' }}>
                    <td colSpan={columns.length + 2} style={{ padding: '0 12px 14px 44px', borderBottom: '1px solid #e4e8f0' }}>
                      <JobDetailExpanded row={row} columns={columns} convTarget={convTarget} />
                    </td>
                  </tr>
                )}
              </>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

/* ── Expanded job detail row ─────────────────────────────────────── */
function JobDetailExpanded({ row, columns, convTarget }) {
  const fields = columns.map(c => ({ label: c, value: row[c] })).filter(f => f.value)
  const jobType = row['Platform'] || row['Job Type'] || row['Type'] || 'Shell'
  const jobName = row['Job Name'] || row['JobName'] || row['job_name'] || 'Unknown Job'

  return (
    <div style={{
      background: '#ffffff', border: '1px solid #e4e8f0', borderRadius: 10,
      padding: 16, marginTop: 8,
    }}>
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 20, flexWrap: 'wrap' }}>
        {/* Field grid */}
        <div style={{ flex: 1, minWidth: 280 }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: '#9ca3af', letterSpacing: '0.07em', textTransform: 'uppercase', marginBottom: 10 }}>
            Job Details
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '6px 16px' }}>
            {fields.map(f => (
              <div key={f.label}>
                <div style={{ fontSize: 10, fontWeight: 600, color: '#9ca3af', textTransform: 'uppercase', letterSpacing: '0.05em' }}>{f.label}</div>
                <div style={{ fontSize: 12, color: '#374151', marginTop: 1, wordBreak: 'break-word' }}>{f.value}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Conversion panel */}
        <div style={{
          width: 260, background: '#fafbff', border: '1px solid #e4e8f0', borderRadius: 10, padding: 14, flexShrink: 0,
        }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: '#9ca3af', letterSpacing: '0.07em', textTransform: 'uppercase', marginBottom: 10 }}>
            Job Conversion
          </div>
          <div style={{ fontSize: 12, color: '#374151', marginBottom: 12 }}>
            <span style={{ fontWeight: 600 }}>{jobType}</span>
            <span style={{ color: '#9ca3af', margin: '0 6px' }}>→</span>
            <span style={{ fontWeight: 600, color: '#2563eb' }}>{convTarget}</span>
          </div>
          <div style={{ fontSize: 11, color: '#6b7280', marginBottom: 12, lineHeight: 1.5 }}>
            Convert <strong>{jobName}</strong> from {jobType} to {convTarget}.
            This will rewrite the job logic while preserving all dependencies and scheduling.
          </div>
          <div style={{ display: 'flex', gap: 6 }}>
            <button disabled style={{
              flex: 1, padding: '7px 12px', borderRadius: 7, fontSize: 11, fontWeight: 700,
              background: '#7c3aed', color: '#fff', border: 'none', cursor: 'not-allowed', opacity: 0.45,
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 5,
            }}>
              <Wand2 size={12} /> LLM Convert
            </button>
            <button disabled style={{
              flex: 1, padding: '7px 12px', borderRadius: 7, fontSize: 11, fontWeight: 700,
              background: '#0891b2', color: '#fff', border: 'none', cursor: 'not-allowed', opacity: 0.45,
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 5,
            }}>
              <ArrowLeftRight size={12} /> Quick Convert
            </button>
          </div>
          <div style={{ marginTop: 8, fontSize: 10, color: '#c0c6d4', textAlign: 'center' }}>
            Feature coming soon
          </div>
        </div>
      </div>
    </div>
  )
}

/* ── Graph panel per file ───────────────────────────────────────── */
function GraphPanel({ fileEntry, onRegisterCyRef }) {
  const { dispatch } = useApp()
  const containerRef  = useRef(null)
  const cyRef         = useRef(null)
  const [loading, setLoading]     = useState(false)
  const [layoutDir, setLayoutDir] = useState('TB')
  const [showLegend, setShowLegend] = useState(false)
  const graphData = fileEntry.graphData

  // Register ref upward for export
  useEffect(() => {
    onRegisterCyRef(fileEntry.sessionId, cyRef)
  }, [fileEntry.sessionId, onRegisterCyRef])

  // Build cytoscape when graphData arrives
  useEffect(() => {
    if (!containerRef.current || !graphData) return
    if (cyRef.current) { cyRef.current.destroy(); cyRef.current = null }
    const elements = [...graphData.nodes, ...graphData.edges]
    cyRef.current = initCytoscape(containerRef.current, elements, () => {})
    return () => { if (cyRef.current) { cyRef.current.destroy(); cyRef.current = null } }
  }, [graphData])

  useEffect(() => {
    if (cyRef.current && graphData) relayout(cyRef.current, layoutDir)
  }, [layoutDir])

  const buildGraph = useCallback(async () => {
    setLoading(true)
    try {
      const res = await getFullGraph(fileEntry.sessionId)
      dispatch({ type: 'UPDATE_FILE_GRAPH', sessionId: fileEntry.sessionId, payload: res.data })
    } catch (err) {
      toast.error(`Graph failed: ${err.response?.data?.detail || err.message}`)
    } finally {
      setLoading(false)
    }
  }, [fileEntry.sessionId, dispatch])

  const handleExportPNG = useCallback(() => {
    if (!cyRef.current) return
    const blob = exportPNG(cyRef.current)
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `${fileEntry.fileName.replace(/\.[^.]+$/, '')}-graph.png`
    a.click()
    URL.revokeObjectURL(url)
    toast.success('PNG exported')
  }, [fileEntry.fileName])

  const handleExportSVG = useCallback(() => {
    if (!cyRef.current) return
    try {
      const svgStr = exportSVG(cyRef.current)
      if (!svgStr) { toast.error('SVG export unavailable'); return }
      const blob = new Blob([svgStr], { type: 'image/svg+xml;charset=utf-8' })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `${fileEntry.fileName.replace(/\.[^.]+$/, '')}-graph.svg`
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      setTimeout(() => URL.revokeObjectURL(url), 2000)
      toast.success('SVG exported')
    } catch (err) {
      toast.error('SVG export failed: ' + err.message)
    }
  }, [fileEntry.fileName])

  if (!graphData && !loading) {
    return (
      <div style={{
        height: 200, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
        gap: 12, background: '#f8f9fc', borderRadius: 10, border: '1px solid #e4e8f0',
      }}>
        <GitBranch size={28} color="#d1d5db" />
        <div style={{ fontSize: 13, color: '#9ca3af' }}>Dependency diagram not generated</div>
        <button onClick={buildGraph} style={{
          display: 'flex', alignItems: 'center', gap: 6, padding: '8px 18px',
          background: '#2563eb', color: '#fff', border: 'none', borderRadius: 8,
          fontSize: 13, fontWeight: 600, cursor: 'pointer',
        }}>
          <GitBranch size={14} /> Generate Diagram
        </button>
      </div>
    )
  }

  if (loading) {
    return (
      <div style={{
        height: 200, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10,
        background: '#f8f9fc', borderRadius: 10, border: '1px solid #e4e8f0',
      }}>
        <Loader2 size={20} color="#2563eb" style={{ animation: 'spin 1s linear infinite' }} />
        <span style={{ fontSize: 13, color: '#6b7280' }}>Building dependency graph…</span>
      </div>
    )
  }

  return (
    <div style={{ position: 'relative' }}>
      {/* Toolbar */}
      <div style={{
        display: 'flex', alignItems: 'center', gap: 6, marginBottom: 8, flexWrap: 'wrap',
      }}>
        {/* Zoom controls */}
        <div style={{ display: 'flex', gap: 2, background: '#ffffff', border: '1px solid #e4e8f0', borderRadius: 8, padding: 3 }}>
          {[
            { icon: ZoomIn,    title: 'Zoom in',    action: () => cyRef.current?.zoom(cyRef.current.zoom() * 1.3) },
            { icon: ZoomOut,   title: 'Zoom out',   action: () => cyRef.current?.zoom(cyRef.current.zoom() * 0.77) },
            { icon: Maximize2, title: 'Fit to view', action: () => cyRef.current?.fit(undefined, 40) },
            { icon: RotateCcw, title: 'Reset highlights', action: () => cyRef.current && resetHighlight(cyRef.current) },
          ].map(({ icon: Icon, title, action }) => (
            <button key={title} onClick={action} title={title} style={{
              padding: '5px 7px', borderRadius: 5, border: 'none', background: 'transparent',
              cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
              transition: 'background 0.1s',
            }}
              onMouseEnter={e => e.currentTarget.style.background = '#f1f4f9'}
              onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
            >
              <Icon size={13} color="#6b7280" />
            </button>
          ))}
        </div>

        {/* Layout */}
        <div style={{ display: 'flex', gap: 2, background: '#ffffff', border: '1px solid #e4e8f0', borderRadius: 8, padding: 3 }}>
          {['TB', 'LR'].map(dir => (
            <button key={dir} onClick={() => setLayoutDir(dir)} style={{
              padding: '4px 10px', borderRadius: 5, border: 'none', fontSize: 11, fontWeight: 600,
              background: layoutDir === dir ? '#eff4ff' : 'transparent',
              color: layoutDir === dir ? '#2563eb' : '#9ca3af', cursor: 'pointer',
            }}>
              {dir === 'TB' ? <><AlignCenter size={11} style={{ display: 'inline', verticalAlign: 'middle', marginRight: 3 }} />TB</> : <><AlignLeft size={11} style={{ display: 'inline', verticalAlign: 'middle', marginRight: 3 }} />LR</>}
            </button>
          ))}
        </div>

        {/* Critical path */}
        {graphData?.critical_path?.length > 0 && (
          <button
            onClick={() => {
              if (cyRef.current) {
                highlightCriticalPath(cyRef.current, graphData.critical_path)
                toast.success(`Critical path: ${graphData.critical_path.length} jobs`)
              }
            }}
            style={{
              display: 'flex', alignItems: 'center', gap: 5, padding: '5px 11px',
              background: '#fffbeb', border: '1px solid #fde68a', borderRadius: 8,
              fontSize: 11, fontWeight: 600, color: '#b45309', cursor: 'pointer',
            }}
          >
            <Target size={12} /> Critical Path
          </button>
        )}

        {/* Export */}
        <div style={{ display: 'flex', gap: 2, background: '#ffffff', border: '1px solid #e4e8f0', borderRadius: 8, padding: 3, marginLeft: 'auto' }}>
          <button onClick={handleExportPNG} title="Export PNG" style={{
            display: 'flex', alignItems: 'center', gap: 4, padding: '4px 9px', borderRadius: 5,
            border: 'none', background: 'transparent', fontSize: 11, fontWeight: 600, color: '#6b7280', cursor: 'pointer',
          }}
            onMouseEnter={e => e.currentTarget.style.background = '#f1f4f9'}
            onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
          >
            <Image size={12} /> PNG
          </button>
          <button onClick={handleExportSVG} title="Export SVG" style={{
            display: 'flex', alignItems: 'center', gap: 4, padding: '4px 9px', borderRadius: 5,
            border: 'none', background: 'transparent', fontSize: 11, fontWeight: 600, color: '#6b7280', cursor: 'pointer',
          }}
            onMouseEnter={e => e.currentTarget.style.background = '#f1f4f9'}
            onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
          >
            <FileCode size={12} /> SVG
          </button>
        </div>
      </div>

      {/* Graph canvas — scrollable + proper height */}
      <div style={{
        position: 'relative', borderRadius: 10, overflow: 'hidden',
        border: '1px solid #2d3748',
        height: 500,
      }}>
        {/* Cycle warning */}
        {graphData?.has_cycles && (
          <div style={{
            position: 'absolute', top: 10, left: '50%', transform: 'translateX(-50%)',
            zIndex: 10, display: 'flex', alignItems: 'center', gap: 7,
            padding: '6px 14px', background: 'rgba(127,29,29,0.95)', border: '1px solid #991b1b',
            borderRadius: 8, boxShadow: '0 2px 8px rgba(0,0,0,0.4)',
          }}>
            <AlertTriangle size={13} color="#fca5a5" />
            <span style={{ fontSize: 11, color: '#fca5a5', fontWeight: 600 }}>
              {graphData.cycle_details?.length} cycle{graphData.cycle_details?.length > 1 ? 's' : ''} detected
            </span>
          </div>
        )}

        {/* Stats */}
        <div style={{
          position: 'absolute', bottom: 10, left: 10, zIndex: 10,
          display: 'flex', alignItems: 'center', gap: 10,
          padding: '5px 10px', background: 'rgba(0,0,0,0.55)',
          borderRadius: 7, backdropFilter: 'blur(6px)',
        }}>
          <span style={{ fontSize: 11, color: '#94a3b8' }}>
            <span style={{ fontFamily: 'monospace', color: '#e2e8f0', fontWeight: 700 }}>{graphData.node_count}</span> nodes
          </span>
          <span style={{ color: '#475569', fontSize: 11 }}>·</span>
          <span style={{ fontSize: 11, color: '#94a3b8' }}>
            <span style={{ fontFamily: 'monospace', color: '#e2e8f0', fontWeight: 700 }}>{graphData.edge_count}</span> edges
          </span>
          {graphData.critical_path?.length > 0 && (
            <>
              <span style={{ color: '#475569', fontSize: 11 }}>·</span>
              <span style={{ fontSize: 11, color: '#fbbf24', fontWeight: 600 }}>
                ⚡ {graphData.critical_path.length} in path
              </span>
            </>
          )}
        </div>

        {/* Scroll hint */}
        <div style={{
          position: 'absolute', bottom: 10, right: 10, zIndex: 10,
          fontSize: 10, color: '#64748b',
          padding: '4px 8px', background: 'rgba(0,0,0,0.4)', borderRadius: 5,
        }}>
          Scroll to zoom · Drag to pan
        </div>

        <div ref={containerRef} style={{ width: '100%', height: '100%', background: '#1a1d27' }} />
      </div>
    </div>
  )
}

/* ── Main card component ─────────────────────────────────────────── */
export default function FileCard({ fileEntry, index, onRegisterCyRef }) {
  const [section, setSection] = useState('preview') // 'preview' | 'graph'
  const [collapsed, setCollapsed] = useState(false)

  const ext  = fileEntry.fileName.split('.').pop().toLowerCase()
  const hue  = (index * 53 + 210) % 360
  const color = `hsl(${hue}, 65%, 45%)`

  return (
    <div style={{
      background: '#ffffff', border: '1px solid #e4e8f0',
      borderRadius: 16, overflow: 'hidden',
      boxShadow: '0 2px 8px rgba(0,0,0,0.05)',
    }}>
      {/* Card header */}
      <div style={{
        background: '#f8f9fc', borderBottom: '1px solid #e4e8f0',
        padding: '14px 20px', display: 'flex', alignItems: 'center', gap: 14,
      }}>
        {/* Index badge */}
        <div style={{
          width: 34, height: 34, borderRadius: 9, background: color,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: '#fff', fontSize: 13, fontWeight: 700, flexShrink: 0,
        }}>
          {index + 1}
        </div>

        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 14, fontWeight: 700, color: '#111827', fontFamily: 'monospace', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
            {fileEntry.fileName}
          </div>
          <div style={{ fontSize: 11, color: '#9ca3af', marginTop: 2, display: 'flex', gap: 10 }}>
            <span>{fileEntry.uploadData?.row_count ?? '?'} jobs</span>
            <span style={{ textTransform: 'uppercase', fontWeight: 600 }}>{ext}</span>
            <span style={{ fontFamily: 'monospace', color: '#c0c6d4' }}>{fileEntry.sessionId?.slice(0, 8)}…</span>
          </div>
        </div>

        {/* Graph status badge */}
        {fileEntry.graphData && (
          <span style={{
            padding: '3px 10px', background: '#f0fdf4', border: '1px solid #bbf7d0',
            borderRadius: 99, fontSize: 11, color: '#16a34a', fontWeight: 600,
          }}>✓ Graphed</span>
        )}

        {/* Section tabs */}
        <div style={{ display: 'flex', gap: 2, background: '#f1f4f9', borderRadius: 8, padding: 3 }}>
          {[['preview', 'Data Preview'], ['graph', 'Dependency Diagram']].map(([id, label]) => (
            <button key={id} onClick={() => setSection(id)} style={{
              padding: '5px 12px', borderRadius: 6, border: 'none', fontSize: 12, fontWeight: 600,
              cursor: 'pointer', transition: 'all 0.1s',
              background: section === id ? '#ffffff' : 'transparent',
              color: section === id ? '#1d4ed8' : '#9ca3af',
              boxShadow: section === id ? '0 1px 3px rgba(0,0,0,0.08)' : 'none',
            }}>
              {label}
            </button>
          ))}
        </div>

        {/* Collapse toggle */}
        <button
          onClick={() => setCollapsed(c => !c)}
          style={{ padding: 6, border: '1px solid #e4e8f0', borderRadius: 7, background: '#fff', cursor: 'pointer' }}
          title={collapsed ? 'Expand' : 'Collapse'}
        >
          {collapsed ? <ChevronDown size={14} color="#6b7280" /> : <ChevronUp size={14} color="#6b7280" />}
        </button>
      </div>

      {/* Card body */}
      {!collapsed && (
        <div style={{ padding: 20 }}>
          {section === 'preview' && (
            <PreviewTable sessionId={fileEntry.sessionId} uploadData={fileEntry.uploadData} />
          )}
          {section === 'graph' && (
            <GraphPanel fileEntry={fileEntry} onRegisterCyRef={onRegisterCyRef} />
          )}
        </div>
      )}
    </div>
  )
}
