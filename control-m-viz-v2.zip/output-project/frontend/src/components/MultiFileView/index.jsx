import { useState, useCallback } from 'react'
import { useApp } from '../../hooks/useAppState'
import { getFullGraph } from '../../services/api'
import { exportPNG, exportSVG } from '../../utils/cytoscapeBuilder'
import toast from 'react-hot-toast'
import FileCard from './FileCard'
import { LayoutList, GitBranch, Download, Loader2, PackageCheck } from 'lucide-react'

export default function MultiFileView() {
  const { state, dispatch } = useApp()
  const { uploadedFiles, selectedFileIds } = state
  const [generatingAll, setGeneratingAll] = useState(false)
  const [cyRefs, setCyRefs] = useState({}) // sessionId -> cyRef

  const selectedFiles = uploadedFiles.filter(f => selectedFileIds.includes(f.sessionId))

  const registerCyRef = useCallback((sessionId, cyRef) => {
    setCyRefs(prev => ({ ...prev, [sessionId]: cyRef }))
  }, [])

  // Generate all diagrams one by one
  const handleGenerateAll = useCallback(async () => {
    if (selectedFiles.length === 0) { toast.error('No files selected'); return }
    setGeneratingAll(true)
    let count = 0
    for (const f of selectedFiles) {
      if (f.graphData) { count++; continue }
      try {
        toast.loading(`Building graph for "${f.fileName}"…`, { id: `graph-${f.sessionId}` })
        const res = await getFullGraph(f.sessionId)
        dispatch({ type: 'UPDATE_FILE_GRAPH', sessionId: f.sessionId, payload: res.data })
        toast.success(`"${f.fileName}" graphed`, { id: `graph-${f.sessionId}` })
        count++
      } catch (err) {
        toast.error(`Failed: ${f.fileName}`, { id: `graph-${f.sessionId}` })
      }
    }
    setGeneratingAll(false)
    if (count > 0) toast.success(`All ${count} diagrams ready`)
  }, [selectedFiles, dispatch])

  // Export all graphs + analysis as ZIP-like bundle
  const handleExportAll = useCallback(async () => {
    if (Object.keys(cyRefs).length === 0) { toast.error('Generate diagrams first'); return }
    let exported = 0
    for (const [sid, cyRef] of Object.entries(cyRefs)) {
      if (!cyRef?.current) continue
      const file = uploadedFiles.find(f => f.sessionId === sid)
      const baseName = file?.fileName.replace(/\.[^.]+$/, '') || sid
      // PNG
      try {
        const pngBlob = exportPNG(cyRef.current)
        const pngUrl = URL.createObjectURL(pngBlob)
        const a = document.createElement('a')
        a.href = pngUrl; a.download = `${baseName}-graph.png`; a.click()
        URL.revokeObjectURL(pngUrl)
        exported++
      } catch {}
      await new Promise(r => setTimeout(r, 120))
      // SVG
      try {
        const svgStr = exportSVG(cyRef.current)
        if (svgStr) {
          const svgBlob = new Blob([svgStr], { type: 'image/svg+xml' })
          const svgUrl = URL.createObjectURL(svgBlob)
          const a = document.createElement('a')
          a.href = svgUrl; a.download = `${baseName}-graph.svg`; a.click()
          URL.revokeObjectURL(svgUrl)
        }
      } catch {}
      await new Promise(r => setTimeout(r, 120))
    }
    if (exported > 0) toast.success(`Exported ${exported} graph${exported !== 1 ? 's' : ''}`)
    else toast.error('No graphs ready to export — generate diagrams first')
  }, [cyRefs, uploadedFiles])

  const allGraphed = selectedFiles.length > 0 && selectedFiles.every(f => f.graphData)

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden', background: '#f8f9fc' }}>
      {/* ── Top bar ───────────────────────────────────── */}
      <div style={{
        background: '#ffffff', borderBottom: '1px solid #e4e8f0',
        padding: '12px 24px', display: 'flex', alignItems: 'center', gap: 12, flexShrink: 0,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, flex: 1 }}>
          <LayoutList size={17} color="#2563eb" />
          <div>
            <span style={{ fontSize: 14, fontWeight: 700, color: '#111827' }}>Diagrams & Data</span>
            <span style={{ fontSize: 12, color: '#9ca3af', marginLeft: 10 }}>
              {selectedFiles.length} of {uploadedFiles.length} files selected
            </span>
          </div>
        </div>

        <div style={{ display: 'flex', gap: 8 }}>
          {/* Generate all */}
          <button
            onClick={handleGenerateAll}
            disabled={generatingAll || selectedFiles.length === 0}
            style={{
              display: 'flex', alignItems: 'center', gap: 6,
              padding: '7px 14px', borderRadius: 8, cursor: 'pointer',
              border: '1px solid #bfdbfe', background: allGraphed ? '#f0fdf4' : '#eff4ff',
              fontSize: 12, fontWeight: 600,
              color: allGraphed ? '#16a34a' : '#1d4ed8',
              opacity: (generatingAll || selectedFiles.length === 0) ? 0.5 : 1,
            }}
          >
            {generatingAll
              ? <><Loader2 size={13} style={{ animation: 'spin 1s linear infinite' }} /> Generating…</>
              : allGraphed
                ? <><PackageCheck size={13} /> All Graphed</>
                : <><GitBranch size={13} /> Generate All Diagrams</>
            }
          </button>

          {/* Export all */}
          <button
            onClick={handleExportAll}
            style={{
              display: 'flex', alignItems: 'center', gap: 6,
              padding: '7px 14px', borderRadius: 8, cursor: 'pointer',
              border: '1px solid #e4e8f0', background: '#ffffff',
              fontSize: 12, fontWeight: 600, color: '#374151',
            }}
          >
            <Download size={13} /> Export All Graphs
          </button>
        </div>
      </div>

      {/* ── Content ───────────────────────────────────── */}
      <div style={{ flex: 1, overflowY: 'auto', padding: 24 }}>
        {uploadedFiles.length === 0 ? (
          <EmptyState label="No files uploaded" sub="Upload CSV, JSON, or XML files first." />
        ) : selectedFiles.length === 0 ? (
          <EmptyState label="No files selected" sub="Check files on the Upload page to view them here." />
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 32 }}>
            {selectedFiles.map((fileEntry, idx) => (
              <FileCard
                key={fileEntry.sessionId}
                fileEntry={fileEntry}
                index={idx}
                onRegisterCyRef={registerCyRef}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

function EmptyState({ label, sub }) {
  return (
    <div style={{
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
      padding: '80px 24px', background: '#ffffff', borderRadius: 16, border: '1px solid #e4e8f0',
    }}>
      <LayoutList size={36} color="#d1d5db" style={{ marginBottom: 12 }} />
      <div style={{ fontSize: 15, fontWeight: 600, color: '#374151', marginBottom: 4 }}>{label}</div>
      <div style={{ fontSize: 13, color: '#9ca3af' }}>{sub}</div>
    </div>
  )
}
