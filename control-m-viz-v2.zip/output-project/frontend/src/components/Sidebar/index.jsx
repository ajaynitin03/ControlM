import { Network, Upload, Layers, Table2, BarChart2, LayoutList, ChevronRight } from 'lucide-react'
import { useApp } from '../../hooks/useAppState'

const NAV_ITEMS = [
  { id: 'upload',    icon: Upload,     label: 'Upload Files',    desc: 'Import job schedules' },
  { id: 'picker',    icon: Layers,     label: 'Select Jobs',     desc: 'Choose jobs to graph' },
  { id: 'multiview', icon: LayoutList, label: 'Diagrams & Data', desc: 'Preview & dependencies' },
  { id: 'analysis',  icon: BarChart2,  label: 'Analysis',        desc: 'Critical path & metrics' },
]

export default function Sidebar() {
  const { state, dispatch } = useApp()
  const { activeTab, sessionId, graphData, uploadedFiles } = state

  const setTab = id => dispatch({ type: 'SET_ACTIVE_TAB', payload: id })

  const isEnabled = id => {
    if (id === 'upload') return true
    if (id === 'multiview') return uploadedFiles.length > 0
    if (id === 'analysis') return uploadedFiles.length > 0
    if (!sessionId) return false
    return true
  }

  return (
    <aside
      style={{
        width: 240,
        minWidth: 240,
        background: '#ffffff',
        borderRight: '1px solid #e4e8f0',
        display: 'flex',
        flexDirection: 'column',
        height: '100vh',
        flexShrink: 0,
      }}
    >
      {/* Logo */}
      <div style={{ padding: '20px 20px 16px', borderBottom: '1px solid #e4e8f0' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{
            width: 36, height: 36, borderRadius: 10,
            background: 'linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: '0 2px 6px rgba(37,99,235,0.30)',
            flexShrink: 0,
          }}>
            <Network size={18} color="#fff" />
          </div>
          <div>
            <div style={{ fontSize: 13, fontWeight: 700, color: '#111827', letterSpacing: '-0.02em' }}>
              Control-M Viz
            </div>
            <div style={{ fontSize: 11, color: '#9ca3af', marginTop: 1 }}>
              Job Dependency Analyzer
            </div>
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav style={{ padding: '12px 12px 0', flex: 1 }}>
        <div style={{ fontSize: 10, fontWeight: 600, color: '#9ca3af', letterSpacing: '0.08em', textTransform: 'uppercase', padding: '0 8px 8px' }}>
          Navigation
        </div>
        {NAV_ITEMS.map(({ id, icon: Icon, label, desc }) => {
          const enabled = isEnabled(id)
          const active  = activeTab === id

          return (
            <button
              key={id}
              onClick={() => enabled && setTab(id)}
              disabled={!enabled}
              style={{
                width: '100%',
                display: 'flex',
                alignItems: 'center',
                gap: 10,
                padding: '9px 10px',
                borderRadius: 8,
                marginBottom: 2,
                cursor: enabled ? 'pointer' : 'not-allowed',
                background: active ? '#eff4ff' : 'transparent',
                border: 'none',
                textAlign: 'left',
                transition: 'background 0.12s',
                opacity: enabled ? 1 : 0.38,
                borderRight: active ? '3px solid #2563eb' : '3px solid transparent',
              }}
              onMouseEnter={e => { if (!active && enabled) e.currentTarget.style.background = '#f8f9fc' }}
              onMouseLeave={e => { if (!active) e.currentTarget.style.background = 'transparent' }}
            >
              <div style={{
                width: 30, height: 30, borderRadius: 7,
                background: active ? '#dbeafe' : '#f1f4f9',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                flexShrink: 0,
              }}>
                <Icon size={14} color={active ? '#2563eb' : '#6b7280'} />
              </div>
              <div style={{ minWidth: 0 }}>
                <div style={{ fontSize: 13, fontWeight: active ? 600 : 500, color: active ? '#1d4ed8' : '#374151' }}>
                  {label}
                </div>
                <div style={{ fontSize: 11, color: '#9ca3af', marginTop: 1 }}>{desc}</div>
              </div>
              {active && <ChevronRight size={13} color="#2563eb" style={{ marginLeft: 'auto', flexShrink: 0 }} />}
            </button>
          )
        })}
      </nav>

      {/* File count pill */}
      {uploadedFiles.length > 0 && (
        <div style={{ padding: '12px 20px', borderTop: '1px solid #e4e8f0' }}>
          <div style={{
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            padding: '8px 12px', background: '#f8f9fc', borderRadius: 8, border: '1px solid #e4e8f0',
          }}>
            <span style={{ fontSize: 12, color: '#6b7280' }}>Files loaded</span>
            <span style={{
              fontSize: 12, fontWeight: 700, color: '#2563eb',
              background: '#dbeafe', padding: '1px 8px', borderRadius: 99,
            }}>
              {uploadedFiles.length}
            </span>
          </div>
        </div>
      )}

      {/* Footer */}
      <div style={{ padding: '10px 20px 16px', borderTop: '1px solid #f1f3f7' }}>
        <div style={{ fontSize: 11, color: '#c0c6d4' }}>v2.0.0 · Control-M Visualizer</div>
      </div>
    </aside>
  )
}
