import cytoscape from 'cytoscape'
import dagre from 'cytoscape-dagre'

cytoscape.use(dagre)

const CRITICALITY_STYLE = {
  HIGH:   { bg: '#3d1010', border: '#ef4444', text: '#fca5a5', shadow: 'rgba(239,68,68,0.5)'  },
  MEDIUM: { bg: '#3d2a05', border: '#f97316', text: '#fdba74', shadow: 'rgba(249,115,22,0.4)' },
  LOW:    { bg: '#0a2a14', border: '#22c55e', text: '#86efac', shadow: 'rgba(34,197,94,0.3)'  },
}

const GROUP_COLORS = [
  { bg: 'rgba(59,130,246,0.07)',  border: '#1e40af', label: '#93c5fd' },
  { bg: 'rgba(168,85,247,0.07)',  border: '#6b21a8', label: '#d8b4fe' },
  { bg: 'rgba(20,184,166,0.07)',  border: '#0f766e', label: '#5eead4' },
  { bg: 'rgba(245,158,11,0.07)',  border: '#92400e', label: '#fcd34d' },
  { bg: 'rgba(236,72,153,0.07)',  border: '#9d174d', label: '#f9a8d4' },
  { bg: 'rgba(99,102,241,0.07)',  border: '#3730a3', label: '#a5b4fc' },
  { bg: 'rgba(34,197,94,0.07)',   border: '#14532d', label: '#86efac' },
]

let groupColorMap = {}
let groupColorIdx = 0
function getGroupColor(id) {
  if (!groupColorMap[id]) {
    groupColorMap[id] = GROUP_COLORS[groupColorIdx % GROUP_COLORS.length]
    groupColorIdx++
  }
  return groupColorMap[id]
}

export function initCytoscape(container, elements, onNodeClick) {
  groupColorMap = {}
  groupColorIdx = 0

  const groupIds = [...new Set(
    elements.filter(e => e.data?.parent).map(e => e.data.parent)
  )]
  groupIds.forEach(g => getGroupColor(g))

  const cy = cytoscape({
    container,
    elements,
    style: buildStyle(),
    layout: {
      name: 'dagre',
      rankDir: 'TB',
      nodeSep: 44,
      rankSep: 88,
      padding: 60,
      animate: true,
      animationDuration: 380,
    },
    userZoomingEnabled: true,
    userPanningEnabled: true,
    minZoom: 0.05,
    maxZoom: 6,
    wheelSensitivity: 0.18,
    boxSelectionEnabled: false,
  })

  cy.on('tap', 'node', evt => {
    const node = evt.target
    if (node.isParent()) return
    highlightConnected(cy, node.id())
    onNodeClick?.(node.data())
  })

  cy.on('tap', evt => {
    if (evt.target === cy) {
      resetHighlight(cy)
      onNodeClick?.(null)
    }
  })

  cy.on('mouseover', 'node:childless', evt => evt.target.addClass('hovered'))
  cy.on('mouseout',  'node:childless', evt => evt.target.removeClass('hovered'))

  return cy
}

export function highlightConnected(cy, nodeId) {
  resetHighlight(cy)
  const escaped = CSS.escape(nodeId)
  const node = cy.$(`#${escaped}`)
  if (node.empty()) return
  const hood = node.closedNeighborhood()
  cy.elements().addClass('dimmed')
  hood.removeClass('dimmed')
  hood.forEach(el => {
    const p = el.parent()
    if (p.length) p.removeClass('dimmed')
  })
  node.addClass('selected-node')
}

export function resetHighlight(cy) {
  cy.elements().removeClass('dimmed selected-node impact-node critical-path-node hovered')
  cy.edges().removeClass('critical-path-edge impact-edge dimmed')
}

export function highlightImpact(cy, affectedIds) {
  resetHighlight(cy)
  cy.elements().addClass('dimmed')
  affectedIds.forEach(id => {
    const el = cy.$(`#${CSS.escape(id)}`)
    el.removeClass('dimmed').addClass('impact-node')
    const p = el.parent()
    if (p.length) p.removeClass('dimmed')
  })
  cy.edges().forEach(e => {
    if (affectedIds.includes(e.source().id()) && affectedIds.includes(e.target().id())) {
      e.removeClass('dimmed').addClass('impact-edge')
    }
  })
}

export function highlightCriticalPath(cy, pathIds) {
  resetHighlight(cy)
  cy.elements().addClass('dimmed')
  const s = new Set(pathIds)
  cy.nodes(':childless').forEach(n => {
    if (s.has(n.id())) {
      n.removeClass('dimmed').addClass('critical-path-node')
      const p = n.parent()
      if (p.length) p.removeClass('dimmed')
    }
  })
  cy.edges().forEach(e => {
    if (s.has(e.source().id()) && s.has(e.target().id())) {
      e.removeClass('dimmed').addClass('critical-path-edge')
    }
  })
}

export function relayout(cy, direction = 'TB') {
  cy.layout({
    name: 'dagre',
    rankDir: direction,
    nodeSep: 44,
    rankSep: 88,
    padding: 60,
    animate: true,
    animationDuration: 380,
  }).run()
}

export function exportPNG(cy) {
  return cy.png({ output: 'blob', bg: '#1a1d27', full: true, scale: 2 })
}

export function exportSVG(cy) {
  // Cytoscape svg() returns string; wrap in proper SVG document
  try {
    const raw = cy.svg({ full: true, bg: '#1a1d27' })
    // Ensure it's a proper SVG string
    if (typeof raw === 'string') return raw
    // Some builds return an object
    return String(raw)
  } catch {
    // Fallback: export as PNG blob and convert (should not happen)
    return null
  }
}

function buildStyle() {
  return [
    {
      selector: 'node:parent',
      style: {
        label: 'data(label)',
        'text-valign': 'top',
        'text-halign': 'center',
        'font-size': 11,
        'font-weight': 700,
        'font-family': 'Inter, sans-serif',
        'letter-spacing': 1,
        color: '#94a3b8',
        'background-color': 'rgba(20,24,36,0.7)',
        'background-opacity': 1,
        'border-width': 1.5,
        'border-color': '#2d3a52',
        'border-style': 'dashed',
        padding: '28px',
        shape: 'roundrectangle',
        'text-margin-y': -4,
      },
    },
    {
      selector: 'node:childless',
      style: {
        label: 'data(displayLabel)',
        'text-valign': 'center',
        'text-halign': 'center',
        'text-wrap': 'wrap',
        'text-max-width': 130,
        'font-size': 10,
        'font-family': 'Inter, sans-serif',
        color: '#e2e8f0',
        'background-color': '#1d2744',
        'border-width': 1.5,
        'border-color': '#3b4f7a',
        width: 144,
        height: 50,
        shape: 'roundrectangle',
        'transition-property': 'opacity, border-color, background-color, border-width',
        'transition-duration': '0.16s',
      },
    },
    {
      selector: 'node:childless[criticality = "HIGH"]',
      style: {
        'background-color': CRITICALITY_STYLE.HIGH.bg,
        'border-color':     CRITICALITY_STYLE.HIGH.border,
        'border-width': 2,
        color:              CRITICALITY_STYLE.HIGH.text,
        'shadow-blur': 18,
        'shadow-color':     CRITICALITY_STYLE.HIGH.shadow,
        'shadow-opacity': 0.9,
        'shadow-offset-x': 0,
        'shadow-offset-y': 0,
      },
    },
    {
      selector: 'node:childless[criticality = "MEDIUM"]',
      style: {
        'background-color': CRITICALITY_STYLE.MEDIUM.bg,
        'border-color':     CRITICALITY_STYLE.MEDIUM.border,
        'border-width': 2,
        color:              CRITICALITY_STYLE.MEDIUM.text,
        'shadow-blur': 14,
        'shadow-color':     CRITICALITY_STYLE.MEDIUM.shadow,
        'shadow-opacity': 0.8,
        'shadow-offset-x': 0,
        'shadow-offset-y': 0,
      },
    },
    {
      selector: 'node:childless[criticality = "LOW"]',
      style: {
        'background-color': CRITICALITY_STYLE.LOW.bg,
        'border-color':     CRITICALITY_STYLE.LOW.border,
        'border-width': 1.5,
        color:              CRITICALITY_STYLE.LOW.text,
      },
    },
    {
      selector: 'node:childless[is_selected = true]',
      style: {
        'border-width': 3,
        'border-color': '#6366f1',
        'shadow-blur': 22,
        'shadow-color': 'rgba(99,102,241,0.7)',
        'shadow-opacity': 1,
        'shadow-offset-x': 0,
        'shadow-offset-y': 0,
      },
    },
    {
      selector: 'edge',
      style: {
        width: 1.5,
        'line-color': '#2d3f5c',
        'target-arrow-color': '#2d3f5c',
        'target-arrow-shape': 'triangle',
        'curve-style': 'bezier',
        'arrow-scale': 1.1,
        opacity: 0.85,
      },
    },
    {
      selector: 'edge[is_critical_path = true], .critical-path-edge',
      style: {
        'line-color': '#f59e0b',
        'target-arrow-color': '#f59e0b',
        width: 2.5,
        opacity: 1,
      },
    },
    {
      selector: '.impact-edge',
      style: {
        'line-color': '#ef4444',
        'target-arrow-color': '#ef4444',
        width: 2,
        opacity: 1,
      },
    },
    {
      selector: '.dimmed',
      style: { opacity: 0.1 },
    },
    {
      selector: '.hovered',
      style: { 'border-color': '#818cf8', 'border-width': 2 },
    },
    {
      selector: '.selected-node',
      style: {
        'border-color': '#6366f1',
        'border-width': 3,
        'shadow-blur': 24,
        'shadow-color': 'rgba(99,102,241,0.8)',
        'shadow-opacity': 1,
        'shadow-offset-x': 0,
        'shadow-offset-y': 0,
        opacity: 1,
      },
    },
    {
      selector: '.impact-node',
      style: {
        'border-color': '#ef4444',
        'border-width': 2.5,
        'background-color': '#3d0a0a',
        color: '#fca5a5',
        'shadow-blur': 18,
        'shadow-color': 'rgba(239,68,68,0.7)',
        'shadow-opacity': 1,
        'shadow-offset-x': 0,
        'shadow-offset-y': 0,
        opacity: 1,
      },
    },
    {
      selector: '.critical-path-node',
      style: {
        'border-color': '#f59e0b',
        'border-width': 2.5,
        'background-color': '#2d1800',
        color: '#fcd34d',
        'shadow-blur': 18,
        'shadow-color': 'rgba(245,158,11,0.7)',
        'shadow-opacity': 1,
        'shadow-offset-x': 0,
        'shadow-offset-y': 0,
        opacity: 1,
      },
    },
  ]
}
