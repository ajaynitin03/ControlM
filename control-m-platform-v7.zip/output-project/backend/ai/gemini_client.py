"""
Gemini API client.
Handles initialization, retries, rate limiting, and structured JSON extraction.
"""
from __future__ import annotations
import json
import logging
import os
import re
import time
from typing import Any

logger = logging.getLogger(__name__)

_MODEL = None


def _get_model():
    global _MODEL
    if _MODEL is not None:
        return _MODEL
    try:
        import google.generativeai as genai
        api_key = os.environ.get("GEMINI_API_KEY", "").strip()
        if not api_key:
            raise ValueError("GEMINI_API_KEY environment variable not set")
        genai.configure(api_key=api_key)
        _MODEL = genai.GenerativeModel(
            model_name="gemini-1.5-flash",
            generation_config={
                "temperature":      0.1,
                "top_p":            0.95,
                "max_output_tokens": 4096,
            },
        )
        logger.info("Gemini model initialized: gemini-1.5-flash")
    except Exception as e:
        logger.error(f"Gemini init failed: {e}")
        raise
    return _MODEL


def is_available() -> bool:
    return bool(os.environ.get("GEMINI_API_KEY", "").strip())


def call_gemini(
    prompt: str,
    expect_json: bool = True,
    retries: int = 3,
    delay: float = 2.0,
) -> Any:
    """
    Call Gemini with retry logic and JSON extraction.
    Returns parsed dict/list when expect_json=True, else raw string.
    Raises RuntimeError after all retries exhausted.
    """
    model     = _get_model()
    last_err  = None

    for attempt in range(retries):
        try:
            response = model.generate_content(prompt)
            text     = response.text.strip()
            if not expect_json:
                return text
            return _extract_json(text)
        except Exception as e:
            last_err = e
            logger.warning(f"Gemini attempt {attempt + 1}/{retries} failed: {e}")
            if attempt < retries - 1:
                time.sleep(delay * (attempt + 1))

    raise RuntimeError(
        f"Gemini call failed after {retries} attempts. Last error: {last_err}"
    )


def _extract_json(text: str) -> Any:
    """
    Robustly extract JSON from Gemini response.
    Handles markdown fences, leading/trailing noise.
    """
    # Strip markdown code fences
    cleaned = re.sub(r"```(?:json)?\s*", "", text)
    cleaned = re.sub(r"```\s*$", "", cleaned, flags=re.MULTILINE).strip()

    # Attempt 1: direct parse of cleaned text
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        pass

    # Attempt 2: find first JSON object
    m = re.search(r"\{[\s\S]*\}", cleaned)
    if m:
        try:
            return json.loads(m.group())
        except json.JSONDecodeError:
            pass

    # Attempt 3: find first JSON array
    m = re.search(r"\[[\s\S]*\]", cleaned)
    if m:
        try:
            return json.loads(m.group())
        except json.JSONDecodeError:
            pass

    # Attempt 4: fix common escaping issues and retry
    fixed = cleaned.replace("\n", "\\n").replace("\t", "\\t")
    try:
        return json.loads(fixed)
    except json.JSONDecodeError:
        pass

    logger.warning("Could not parse JSON from Gemini response. Returning raw text.")
    return {"raw_response": text, "parse_error": True}


def validate_json_response(result: Any, required_keys: list) -> bool:
    """Check that a Gemini response dict contains all required keys."""
    if not isinstance(result, dict):
        return False
    if result.get("parse_error"):
        return False
    for key in required_keys:
        if key not in result:
            return False
    return True
