"""
Phase-2 Assessment Engine.
Orchestrates RAG retrieval + Gemini calls for all AI features.
Every function has a heuristic fallback that runs when Gemini is unavailable.
"""
from __future__ import annotations
import logging
import re
from typing import Any

from ai.rag_knowledge import retrieve, format_context
from ai.gemini_client import call_gemini, is_available, validate_json_response
from ai import prompts

logger = logging.getLogger(__name__)

BULK_CHUNK_SIZE = 20   # jobs per Gemini call — keeps prompts within token budget


# ═══════════════════════════════════════════════════════════════════
# FEATURE 1 — BULK JOB ASSESSMENT
# ═══════════════════════════════════════════════════════════════════

def bulk_assess_jobs(jobs: list) -> list:
    """Assess all jobs in chunks. Returns list of assessment dicts."""
    results = []
    chunks  = [jobs[i:i + BULK_CHUNK_SIZE] for i in range(0, len(jobs), BULK_CHUNK_SIZE)]

    for idx, chunk in enumerate(chunks):
        logger.info(f"[BulkAssess] chunk {idx + 1}/{len(chunks)} — {len(chunk)} jobs")
        rag_docs = retrieve("batch job modernization complexity migration assessment", top_k=3)
        ctx      = format_context(rag_docs)

        if is_available():
            prompt = prompts.bulk_assessment_prompt(chunk, ctx)
            raw    = call_gemini(prompt, expect_json=True)
            if isinstance(raw, list) and len(raw) > 0:
                results.extend(raw)
                continue
            if isinstance(raw, dict) and not raw.get("parse_error"):
                results.append(raw)
                continue
        # fallback for this chunk
        results.extend([_heuristic_bulk(j) for j in chunk])

    return results


def _heuristic_bulk(job: dict) -> dict:
    platform = (job.get("Platform") or "").lower()
    crit     = job.get("Criticality", "Low")
    score    = int(job.get("CriticalityScore", 0))

    jtype = "Unknown"
    if any(k in platform for k in ["java", "spring"]):  jtype = "Java/SpringBatch"
    elif "python" in platform:                           jtype = "Python"
    elif any(k in platform for k in ["sql", "db"]):     jtype = "SQL"
    elif "perl" in platform:                             jtype = "Perl"
    elif any(k in platform for k in ["shell", "sh", "bash"]): jtype = "Shell"

    complexity = "Medium"
    if crit in ("Critical", "High"):  complexity = "High"
    elif crit == "Low":               complexity = "Low"

    mod_score = min(10, max(1, score + 2))

    return {
        "job_id":                 job.get("JobId", ""),
        "job_type":               jtype,
        "file_operations":        "Unknown",
        "db_operations":          "Unknown",
        "utility_usage":          "Unknown",
        "output_artifacts":       "Unknown",
        "migration_complexity":   complexity,
        "modernization_score":    mod_score,
        "modernization_candidate": "Maybe",
        "brief_reason":           "Heuristic — provide GEMINI_API_KEY for AI analysis",
    }


# ═══════════════════════════════════════════════════════════════════
# FEATURE 2 — SOURCE CODE ANALYSIS
# ═══════════════════════════════════════════════════════════════════

def analyze_source_code(job_meta: dict, source_code: str) -> dict:
    rag_docs = retrieve(
        "source code analysis tables joins file operations error handling restart logic",
        top_k=4,
    )
    ctx = format_context(rag_docs)

    if is_available():
        prompt = prompts.source_code_analysis_prompt(job_meta, source_code, ctx)
        result = call_gemini(prompt, expect_json=True)
        required = ["job_id", "tables_used", "joins", "error_handling", "restart_logic"]
        if validate_json_response(result, required):
            return result

    return _heuristic_source(job_meta, source_code)


def _heuristic_source(job_meta: dict, code: str) -> dict:
    tables = list(set(re.findall(
        r"(?:FROM|JOIN|INTO|UPDATE|TABLE)\s+([a-zA-Z_]\w*)", code, re.I
    )))
    joins = {
        "inner": len(re.findall(r"\bINNER\s+JOIN\b",  code, re.I)),
        "left":  len(re.findall(r"\bLEFT\s+JOIN\b",   code, re.I)),
        "right": len(re.findall(r"\bRIGHT\s+JOIN\b",  code, re.I)),
        "outer": len(re.findall(r"\bOUTER\s+JOIN\b",  code, re.I)),
        "cross": len(re.findall(r"\bCROSS\s+JOIN\b",  code, re.I)),
    }
    has_try   = bool(re.search(r"try\s*[\{:]|catch|except|raise|BEGIN\s+EXCEPTION", code, re.I))
    has_ftp   = bool(re.search(r"\bftp\b",  code, re.I))
    has_sftp  = bool(re.search(r"\bsftp\b", code, re.I))
    has_mq    = bool(re.search(r"\b(mq|queue|jms|amqp|kafka)\b", code, re.I))
    has_cred  = bool(re.search(r"password\s*=\s*['\"][^'\"]{3,}", code, re.I))
    has_retry = bool(re.search(r"\b(retry|retries|attempt|backoff)\b", code, re.I))
    has_ckpt  = bool(re.search(r"\b(checkpoint|resume|restart_from)\b", code, re.I))

    file_ops = []
    if re.search(r"\bread\b|open\(|fopen|cat\s", code, re.I):   file_ops.append("Read")
    if re.search(r"\bwrite\b|fwrite|echo\s.*>",   code, re.I):  file_ops.append("Write")
    if has_ftp:   file_ops.append("FTP")
    if has_sftp:  file_ops.append("SFTP")
    if re.search(r"\barchive\b|gzip|tar\b",       code, re.I):  file_ops.append("Archive")
    if re.search(r"\brm\b|delete|unlink",         code, re.I):  file_ops.append("Delete")
    if re.search(r"\bmv\b|move\b|shutil\.move",   code, re.I):  file_ops.append("Move")

    db_ops = []
    for op in ["SELECT", "INSERT", "UPDATE", "DELETE", "MERGE"]:
        if re.search(r"\b" + op + r"\b", code, re.I):
            db_ops.append(op)

    return {
        "job_id":           job_meta.get("JobId", ""),
        "tables_used":      tables[:20],
        "reference_tables": [],
        "views_used":       list(set(re.findall(r"VIEW\s+([a-zA-Z_]\w*)", code, re.I))),
        "stored_procedures": list(set(re.findall(r"EXEC(?:UTE)?\s+([a-zA-Z_]\w*)", code, re.I))),
        "functions":        [],
        "joins":            joins,
        "file_reads":       list(set(re.findall(r"open\(['\"]([^'\"]+)['\"]", code, re.I))),
        "file_writes":      [],
        "file_operations":  file_ops,
        "db_operations":    db_ops,
        "ftp_usage":        has_ftp,
        "sftp_usage":       has_sftp,
        "api_calls":        [],
        "mq_usage":         has_mq,
        "utilities":        [],
        "data_transformations": [],
        "error_handling": {
            "has_try_catch":  has_try,
            "has_exit_codes": bool(re.search(r"exit\s*\(?\d", code, re.I)),
            "has_logging":    bool(re.search(r"\b(log|echo|print|logger)\b", code, re.I)),
            "quality":        "Minimal" if has_try else "None",
        },
        "restart_logic": {
            "has_checkpoints":  has_ckpt,
            "has_retry":        has_retry,
            "is_idempotent":    False,
            "restart_quality":  "Minimal" if (has_ckpt or has_retry) else "None",
        },
        "hardcoded_credentials": has_cred,
        "tech_debt_notes": [
            "Heuristic analysis — provide GEMINI_API_KEY for deep AI analysis"
        ],
    }


# ═══════════════════════════════════════════════════════════════════
# FEATURE 3 — BOTTLENECK ANALYSIS
# ═══════════════════════════════════════════════════════════════════

def analyze_bottlenecks(job_meta: dict, source_code: str) -> dict:
    rag_docs = retrieve(
        "performance bottleneck batch job query optimization",
        top_k=3,
        category="bottleneck",
    )
    ctx = format_context(rag_docs)

    if is_available():
        prompt = prompts.bottleneck_analysis_prompt(job_meta, source_code, ctx)
        result = call_gemini(prompt, expect_json=True)
        if validate_json_response(result, ["job_id", "bottlenecks"]):
            return result

    return _heuristic_bottleneck(job_meta, source_code)


def _heuristic_bottleneck(job_meta: dict, code: str) -> dict:
    bottlenecks = []

    if re.search(r"SELECT.*WHERE.*IN\s*\(.*SELECT", code, re.I | re.S):
        bottlenecks.append({
            "type":           "N+1 Query",
            "location":       "SQL subquery section",
            "description":    "Correlated subquery or N+1 query pattern detected",
            "impact":         "High",
            "recommendation": "Replace with JOIN or batch SELECT...WHERE id IN (...)",
        })

    if re.search(r"(for|while)\s+.*:[\s\S]{0,300}(SELECT|execute|cursor)", code, re.I):
        bottlenecks.append({
            "type":           "N+1 Query",
            "location":       "Loop body",
            "description":    "Database query inside a loop detected",
            "impact":         "High",
            "recommendation": "Move query outside loop and batch-fetch records",
        })

    if re.search(r"\bftp\b|\bsftp\b", code, re.I):
        bottlenecks.append({
            "type":           "Sequential File Processing",
            "location":       "FTP/SFTP section",
            "description":    "Sequential file transfer — no parallelism",
            "impact":         "Medium",
            "recommendation": "Use parallel transfers or cloud object storage (S3/GCS)",
        })

    if re.search(r"cursor\s*\.\s*fetch|FETCH\s+NEXT", code, re.I):
        bottlenecks.append({
            "type":           "Full Table Scan",
            "location":       "Cursor iteration",
            "description":    "Row-by-row cursor processing is significantly slower than set-based operations",
            "impact":         "High",
            "recommendation": "Replace cursor with set-based SQL or Pandas DataFrame operations",
        })

    overall = "Low"
    if any(b["impact"] == "Critical" for b in bottlenecks): overall = "Critical"
    elif any(b["impact"] == "High" for b in bottlenecks):   overall = "High"
    elif any(b["impact"] == "Medium" for b in bottlenecks): overall = "Medium"

    top = bottlenecks[0]["recommendation"] if bottlenecks else "No obvious bottlenecks detected"

    return {
        "job_id":                    job_meta.get("JobId", ""),
        "bottlenecks":               bottlenecks,
        "overall_performance_risk":  overall,
        "top_recommendation":        top,
    }


# ═══════════════════════════════════════════════════════════════════
# FEATURE 4 — RISK ASSESSMENT
# ═══════════════════════════════════════════════════════════════════

def assess_risk(
    job_meta: dict,
    source_code: str,
    fan_in: int,
    fan_out: int,
) -> dict:
    platform = job_meta.get("Platform", "")
    query    = f"risk assessment migration {platform} fan-in fan-out critical"
    rag_docs = retrieve(query, top_k=4, category="risk")
    ctx      = format_context(rag_docs)

    if is_available():
        prompt = prompts.risk_assessment_prompt(job_meta, source_code, fan_in, fan_out, ctx)
        result = call_gemini(prompt, expect_json=True)
        if validate_json_response(result, ["job_id", "risk_level", "risk_factors"]):
            return result

    return _heuristic_risk(job_meta, source_code, fan_in, fan_out)


def _heuristic_risk(job_meta: dict, code: str, fan_in: int, fan_out: int) -> dict:
    factors = []
    score   = 0

    if fan_out > 5:
        factors.append({
            "factor": f"High Fan-Out ({fan_out} downstream jobs)",
            "severity": "Critical",
            "description": f"Failure blocks {fan_out} downstream jobs",
            "migration_impact": "Exact outputs/formats must be preserved",
        })
        score += 3

    elif fan_out >= 3:
        factors.append({
            "factor": f"Moderate Fan-Out ({fan_out} downstream)",
            "severity": "High",
            "description": f"Impacts {fan_out} downstream jobs on failure",
            "migration_impact": "Downstream jobs must be tested after migration",
        })
        score += 2

    if fan_in > 5:
        factors.append({
            "factor": f"High Fan-In ({fan_in} predecessors)",
            "severity": "High",
            "description": f"Depends on {fan_in} predecessor jobs",
            "migration_impact": "All predecessors must be migrated or mocked first",
        })
        score += 2

    crit = job_meta.get("Criticality", "Low")
    crit_score = int(job_meta.get("CriticalityScore", 0))
    if crit in ("Critical", "High") or crit_score >= 7:
        factors.append({
            "factor": f"High Operational Criticality ({crit}, score={crit_score})",
            "severity": "High",
            "description": job_meta.get("CriticalityReason", "High criticality job"),
            "migration_impact": "Requires parallel run and thorough regression testing",
        })
        score += 2

    if code and re.search(r"password\s*=\s*['\"][^'\"]{3,}", code, re.I):
        factors.append({
            "factor": "Hardcoded Credentials",
            "severity": "Critical",
            "description": "Credentials embedded directly in source code",
            "migration_impact": "Must migrate to secrets manager before cloud deployment",
        })
        score += 3

    if code and re.search(r"\bftp\b", code, re.I):
        factors.append({
            "factor": "FTP Usage",
            "severity": "High",
            "description": "Unencrypted FTP transfers are a security and compatibility risk",
            "migration_impact": "Must replace with SFTP or cloud object storage",
        })
        score += 1

    if not factors:
        factors.append({
            "factor": "Standard Migration",
            "severity": "Low",
            "description": "No major risk factors identified",
            "migration_impact": "Standard migration approach applicable",
        })

    level_map = [(6, "Critical"), (4, "High"), (2, "Medium"), (0, "Low")]
    level = "Low"
    for threshold, lbl in level_map:
        if score >= threshold:
            level = lbl
            break

    return {
        "job_id":                  job_meta.get("JobId", ""),
        "risk_level":              level,
        "risk_factors":            factors,
        "dependency_risk":         "High" if (fan_in > 3 or fan_out > 3) else "Low",
        "data_risk":               "Medium",
        "operational_risk":        "High" if crit in ("Critical", "High") else "Medium",
        "migration_recommendation": "Perform parallel run before cutover; document all interfaces",
        "pre_migration_actions": [
            "Document all input/output file formats",
            "Map all database dependencies",
            "Create rollback plan",
            "Set up monitoring and alerting",
        ],
    }


# ═══════════════════════════════════════════════════════════════════
# FEATURE 5 — MODERNIZATION ASSESSMENT
# ═══════════════════════════════════════════════════════════════════

def assess_modernization(job_meta: dict, source_code: str) -> dict:
    platform = job_meta.get("Platform", "")
    rag_docs = retrieve(
        f"modernization {platform} migration target technology recommended",
        top_k=4,
    )
    ctx = format_context(rag_docs)

    if is_available():
        prompt = prompts.modernization_assessment_prompt(job_meta, source_code, ctx)
        result = call_gemini(prompt, expect_json=True)
        if validate_json_response(result, ["job_id", "recommended_technology", "migration_complexity"]):
            return result

    return _heuristic_modernization(job_meta)


def _heuristic_modernization(job_meta: dict) -> dict:
    platform = (job_meta.get("Platform") or "").lower()
    crit     = job_meta.get("Criticality", "Low")

    # (current_tech, rec_tech, rec_scheduler, complexity, days, tools)
    tech_map = {
        "shell":   ("Shell",       "Python",      "Airflow", "Medium",  5,  ["subprocess", "pathlib", "schedule"]),
        "bash":    ("Shell",       "Python",      "Airflow", "Medium",  5,  ["subprocess", "pathlib", "schedule"]),
        "python":  ("Python",      "Python",      "Airflow", "Low",     2,  ["Pandas", "SQLAlchemy"]),
        "perl":    ("Perl",        "Python",      "Airflow", "Medium",  7,  ["re", "os", "subprocess"]),
        "sql":     ("SQL",         "PySpark",     "Airflow", "High",    10, ["PySpark", "SQLAlchemy"]),
        "java":    ("Java",        "SpringBatch", "Airflow", "High",    15, ["Spring Batch", "JPA"]),
        "spring":  ("SpringBatch", "SpringBatch", "Airflow", "Medium",  5,  ["Spring Batch 5", "Spring Cloud"]),
        "cobol":   ("COBOL",       "Python",      "Airflow", "High",    20, ["Pandas", "SQLAlchemy"]),
    }

    current_tech = "Unknown"
    rec_tech     = "Python"
    rec_sched    = "Airflow"
    complexity   = "Medium"
    days         = 5
    tools: list  = []

    for key, vals in tech_map.items():
        if key in platform:
            current_tech, rec_tech, rec_sched, complexity, days, tools = vals
            break

    if crit in ("Critical", "High") and complexity == "Low":
        complexity = "Medium"
        days       = days * 2

    return {
        "job_id":                  job_meta.get("JobId", ""),
        "current_technology":      current_tech,
        "current_scheduler":       "Control-M",
        "recommended_technology":  rec_tech,
        "recommended_scheduler":   rec_sched,
        "suggested_tools":         tools,
        "migration_complexity":    complexity,
        "estimated_effort_days":   days,
        "modernization_benefits":  [
            "Cloud-native execution",
            "Improved observability and monitoring",
            "Reduced Control-M licensing cost",
            "Better developer experience",
        ],
        "migration_steps": [
            "Analyze and document source code",
            "Convert job logic to target technology",
            "Set up target runtime environment",
            "Parallel run testing",
            "Cutover and decommission original",
        ],
        "dependencies_to_address": [],
        "reasoning": (
            f"Heuristic assessment based on platform={platform}, criticality={crit}. "
            "Set GEMINI_API_KEY for AI-powered detailed reasoning."
        ),
    }


# ═══════════════════════════════════════════════════════════════════
# FEATURE 6 — JOB CONVERSION
# ═══════════════════════════════════════════════════════════════════

def convert_job(job_meta: dict, source_code: str, target_technology: str) -> dict:
    platform = job_meta.get("Platform", "")
    query    = f"conversion {platform} to {target_technology} template"
    rag_docs = retrieve(query, top_k=4, category="conversion")
    ctx      = format_context(rag_docs)

    if not is_available():
        return {
            "job_id":                job_meta.get("JobId", ""),
            "source_technology":     platform or "Unknown",
            "target_technology":     target_technology,
            "converted_code":        (
                f"# Gemini API key required for code conversion\n"
                f"# Set GEMINI_API_KEY environment variable\n"
                f"# Target: {target_technology}\n"
                f"# Source job: {job_meta.get('JobName', '')}"
            ),
            "migration_explanation": "AI-powered conversion requires GEMINI_API_KEY",
            "risks":                 ["Manual conversion required without AI"],
            "validation_checklist":  [
                "Review all logic manually",
                "Test with sample inputs",
                "Validate all outputs match",
                "Test error handling paths",
            ],
            "estimated_effort_hours": 8,
            "manual_review_needed":   True,
            "manual_review_reasons":  ["No Gemini API key configured"],
        }

    prompt = prompts.job_conversion_prompt(job_meta, source_code, target_technology, ctx)
    result = call_gemini(prompt, expect_json=True)
    if not validate_json_response(result, ["job_id", "converted_code"]):
        result["converted_code"] = result.get("raw_response", "# Conversion failed — check logs")
    return result


# ═══════════════════════════════════════════════════════════════════
# EXECUTIVE SUMMARY
# ═══════════════════════════════════════════════════════════════════

def generate_executive_summary(assessments: list, jobs_df_stats: dict) -> dict:
    rag_docs = retrieve(
        "batch modernization strategy executive cloud migration recommendation",
        top_k=4,
    )
    ctx = format_context(rag_docs)

    complexity_counts: dict = {}
    risk_counts:       dict = {}
    for a in assessments:
        c = a.get("migration_complexity", "Medium")
        r = a.get("risk_level",           "Medium")
        complexity_counts[c] = complexity_counts.get(c, 0) + 1
        risk_counts[r]       = risk_counts.get(r,       0) + 1

    scores = [
        a.get("modernization_score", 5)
        for a in assessments
        if isinstance(a.get("modernization_score"), (int, float))
    ]

    stats = {
        **jobs_df_stats,
        "high_complexity":   complexity_counts.get("High",     0),
        "medium_complexity": complexity_counts.get("Medium",   0),
        "low_complexity":    complexity_counts.get("Low",      0),
        "critical_risk":     risk_counts.get("Critical",       0),
        "high_risk":         risk_counts.get("High",           0),
        "avg_mod_score":     sum(scores) / len(scores) if scores else 5.0,
    }

    if is_available():
        prompt = prompts.executive_summary_prompt(stats, ctx)
        result = call_gemini(prompt, expect_json=True)
        if validate_json_response(result, ["headline", "executive_summary", "key_findings"]):
            return result

    total = stats.get("total_jobs", 0)
    high  = stats.get("high_count",  0)
    crit  = stats.get("critical_count", 0)
    return {
        "headline": (
            f"Batch Modernization Assessment: {total} Jobs Analyzed — "
            f"{crit + high} Require Priority Attention"
        ),
        "executive_summary": (
            f"This assessment covers {total} batch jobs across your Control-M environment. "
            f"{crit} jobs are critical and {high} are high criticality. "
            f"{stats.get('high_complexity', 0)} jobs have high migration complexity. "
            "Set GEMINI_API_KEY for AI-generated executive insights."
        ),
        "key_findings": [
            f"{total} total batch jobs assessed",
            f"{crit} CRITICAL and {high} HIGH criticality jobs require immediate attention",
            f"{stats.get('high_complexity', 0)} HIGH complexity migrations identified",
            f"{risk_counts.get('Critical', 0)} CRITICAL risk jobs need pre-migration remediation",
            "Control-M to Airflow migration recommended as primary scheduler replacement",
        ],
        "strategic_recommendations": [
            {
                "priority":       "1",
                "recommendation": "Address CRITICAL risk and criticality jobs first",
                "business_value": "Risk reduction and schedule stability",
                "timeline":       "0-30 days",
            },
            {
                "priority":       "2",
                "recommendation": "Migrate LOW complexity jobs as quick wins",
                "business_value": "Cost savings and team confidence",
                "timeline":       "1-3 months",
            },
            {
                "priority":       "3",
                "recommendation": "Plan Airflow scheduler replacement for Control-M",
                "business_value": "Significant licensing cost reduction",
                "timeline":       "3-6 months",
            },
        ],
        "risk_summary": (
            "Heuristic risk summary generated. Enable GEMINI_API_KEY for AI-powered insights."
        ),
        "modernization_roadmap": {
            "phase1": "Assess and remediate CRITICAL/HIGH risk jobs (0-3 months)",
            "phase2": "Migrate LOW/MEDIUM complexity jobs to Python/Airflow (3-9 months)",
            "phase3": "Migrate HIGH complexity jobs and decommission Control-M (9-18 months)",
        },
    }
