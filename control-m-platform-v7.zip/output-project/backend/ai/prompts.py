"""
All Gemini prompt templates.
Every prompt instructs Gemini to return ONLY a JSON object/array.
No markdown fences. No explanation text.
"""
from __future__ import annotations
import json


def _job_context(job_meta: dict) -> str:
    return (
        f"JobId: {job_meta.get('JobId', '')}\n"
        f"JobName: {job_meta.get('JobName', '')}\n"
        f"Platform: {job_meta.get('Platform', '')}\n"
        f"AppName: {job_meta.get('AppName', '')}\n"
        f"Description: {str(job_meta.get('Description', ''))[:200]}\n"
        f"AvgRuntime: {job_meta.get('AvgRuntime', '')}\n"
        f"Criticality: {job_meta.get('Criticality', '')}\n"
        f"CriticalityScore: {job_meta.get('CriticalityScore', '')}\n"
        f"CriticalityReason: {job_meta.get('CriticalityReason', '')}"
    )


# ── FEATURE 1 — BULK ASSESSMENT ───────────────────────────────────

def bulk_assessment_prompt(jobs_chunk: list, rag_context: str) -> str:
    jobs_text = "\n".join(
        f"- JobId={j.get('JobId','')} | Name={j.get('JobName','')} | "
        f"Platform={j.get('Platform','')} | App={j.get('AppName','')} | "
        f"Runtime={j.get('AvgRuntime','')} | Criticality={j.get('Criticality','')} | "
        f"Score={j.get('CriticalityScore','')} | Desc={str(j.get('Description',''))[:100]}"
        for j in jobs_chunk
    )
    return f"""You are an enterprise batch modernization expert.

KNOWLEDGE BASE:
{rag_context}

Analyze these batch jobs and return a JSON ARRAY.
Each element MUST have exactly these keys:

{{
  "job_id": "string",
  "job_type": "Shell|SQL|Java|Python|SpringBatch|Perl|Unknown",
  "file_operations": "comma-separated: Read,Write,FTP,SFTP,Archive,Delete or None",
  "db_operations": "comma-separated: SELECT,INSERT,UPDATE,DELETE,MERGE or None",
  "utility_usage": "comma-separated utilities or None",
  "output_artifacts": "output files/tables or None",
  "migration_complexity": "Low|Medium|High",
  "modernization_score": 1,
  "modernization_candidate": "Yes|No|Maybe",
  "brief_reason": "one sentence"
}}

modernization_score is an integer from 1 to 10 where 10 = highest modernization urgency.

JOBS TO ANALYZE:
{jobs_text}

Return ONLY the JSON array. No markdown. No extra text.
"""


# ── FEATURE 2 — SOURCE CODE ANALYSIS ─────────────────────────────

def source_code_analysis_prompt(job_meta: dict, source_code: str, rag_context: str) -> str:
    code_snippet = source_code[:6000]
    job_ctx      = _job_context(job_meta)
    return f"""You are a senior code analyst for enterprise batch systems.

KNOWLEDGE BASE:
{rag_context}

JOB METADATA:
{job_ctx}

SOURCE CODE:
```
{code_snippet}
```

Perform deep analysis. Return a single JSON object with EXACTLY these keys:

{{
  "job_id": "string",
  "tables_used": ["table1"],
  "reference_tables": ["ref1"],
  "views_used": ["view1"],
  "stored_procedures": ["proc1"],
  "functions": ["func1"],
  "joins": {{
    "inner": 0,
    "left": 0,
    "right": 0,
    "outer": 0,
    "cross": 0
  }},
  "file_reads": ["path1"],
  "file_writes": ["path1"],
  "file_operations": ["Read","Write","FTP","SFTP","Archive","Delete","Move","Split"],
  "db_operations": ["SELECT","INSERT","UPDATE","DELETE","MERGE"],
  "ftp_usage": false,
  "sftp_usage": false,
  "api_calls": ["endpoint1"],
  "mq_usage": false,
  "utilities": ["SQLPlus","Shell","SpringBatch","Python","Java"],
  "data_transformations": ["description1"],
  "error_handling": {{
    "has_try_catch": false,
    "has_exit_codes": false,
    "has_logging": false,
    "quality": "None|Minimal|Adequate|Comprehensive"
  }},
  "restart_logic": {{
    "has_checkpoints": false,
    "has_retry": false,
    "is_idempotent": false,
    "restart_quality": "None|Minimal|Adequate|Comprehensive"
  }},
  "hardcoded_credentials": false,
  "tech_debt_notes": ["note1"]
}}

Return ONLY the JSON object. No markdown. No explanation.
"""


# ── FEATURE 3 — BOTTLENECK ANALYSIS ──────────────────────────────

def bottleneck_analysis_prompt(job_meta: dict, source_code: str, rag_context: str) -> str:
    code_snippet = source_code[:5000]
    job_ctx      = _job_context(job_meta)
    return f"""You are a performance engineering expert for enterprise batch systems.

KNOWLEDGE BASE:
{rag_context}

JOB METADATA:
{job_ctx}

SOURCE CODE:
```
{code_snippet}
```

Identify all performance bottlenecks. Return a single JSON object:

{{
  "job_id": "string",
  "bottlenecks": [
    {{
      "type": "N+1 Query|Full Table Scan|Sequential File Processing|Nested Loop|Large Join|Missing Index|Memory Issue|Sequential Dependency|FTP Bottleneck|Other",
      "location": "line number or code section description",
      "description": "what the bottleneck is",
      "impact": "Low|Medium|High|Critical",
      "recommendation": "specific actionable fix"
    }}
  ],
  "overall_performance_risk": "Low|Medium|High|Critical",
  "top_recommendation": "single most impactful fix"
}}

Return ONLY the JSON object. No markdown.
"""


# ── FEATURE 4 — RISK ASSESSMENT ──────────────────────────────────

def risk_assessment_prompt(
    job_meta: dict,
    source_code: str,
    fan_in: int,
    fan_out: int,
    rag_context: str,
) -> str:
    code_snippet = source_code[:4000] if source_code else "(no source code provided)"
    job_ctx      = _job_context(job_meta)
    return f"""You are an enterprise risk architect for batch system migrations.

KNOWLEDGE BASE:
{rag_context}

JOB METADATA:
{job_ctx}
Fan-in (predecessor count): {fan_in}
Fan-out (successor count): {fan_out}

SOURCE CODE:
```
{code_snippet}
```

Assess migration risk comprehensively. Return a single JSON object:

{{
  "job_id": "string",
  "risk_level": "Low|Medium|High|Critical",
  "risk_factors": [
    {{
      "factor": "factor name",
      "severity": "Low|Medium|High|Critical",
      "description": "why this is a risk",
      "migration_impact": "what this means for migration"
    }}
  ],
  "dependency_risk": "Low|Medium|High|Critical",
  "data_risk": "Low|Medium|High|Critical",
  "operational_risk": "Low|Medium|High|Critical",
  "migration_recommendation": "specific migration approach",
  "pre_migration_actions": ["action1", "action2"]
}}

Return ONLY the JSON object. No markdown.
"""


# ── FEATURE 5 — MODERNIZATION ASSESSMENT ─────────────────────────

def modernization_assessment_prompt(
    job_meta: dict,
    source_code: str,
    rag_context: str,
) -> str:
    code_snippet = source_code[:4000] if source_code else "(no source code provided)"
    job_ctx      = _job_context(job_meta)
    return f"""You are a cloud architect and batch modernization expert.

KNOWLEDGE BASE:
{rag_context}

JOB METADATA:
{job_ctx}

SOURCE CODE:
```
{code_snippet}
```

Assess the modernization path for this job. Return a single JSON object:

{{
  "job_id": "string",
  "current_technology": "Shell|SQL|Java|SpringBatch|Python|Perl|COBOL|Other",
  "current_scheduler": "Control-M",
  "recommended_technology": "Python|SpringBatch|PySpark|Airflow|CloudRunJob|AWSBatch|AzureBatch",
  "recommended_scheduler": "Airflow|CloudScheduler|AWSEventBridge|AzureLogicApps|Managed",
  "suggested_tools": ["Pandas", "SQLAlchemy", "Paramiko"],
  "migration_complexity": "Low|Medium|High",
  "estimated_effort_days": 5,
  "modernization_benefits": ["benefit1", "benefit2"],
  "migration_steps": ["step1", "step2"],
  "dependencies_to_address": ["dep1"],
  "reasoning": "paragraph explaining the recommendation"
}}

Return ONLY the JSON object. No markdown.
"""


# ── FEATURE 6 — JOB CONVERSION ───────────────────────────────────

def job_conversion_prompt(
    job_meta: dict,
    source_code: str,
    target_technology: str,
    rag_context: str,
) -> str:
    job_ctx = _job_context(job_meta)
    return f"""You are a senior engineer expert at batch job code conversion.

KNOWLEDGE BASE:
{rag_context}

JOB METADATA:
{job_ctx}

SOURCE CODE TO CONVERT:
```
{source_code[:8000]}
```

TARGET TECHNOLOGY: {target_technology}

Convert the source code to {target_technology}.
Return a single JSON object:

{{
  "job_id": "string",
  "source_technology": "detected source language",
  "target_technology": "{target_technology}",
  "converted_code": "complete converted code — use \\n for newlines inside the string",
  "migration_explanation": "paragraph explaining what was changed and why",
  "risks": ["risk1", "risk2"],
  "validation_checklist": [
    "test condition 1",
    "test condition 2"
  ],
  "estimated_effort_hours": 8,
  "manual_review_needed": false,
  "manual_review_reasons": ["reason1"]
}}

Return ONLY the JSON object. No markdown.
"""


# ── EXECUTIVE SUMMARY ─────────────────────────────────────────────

def executive_summary_prompt(stats: dict, rag_context: str) -> str:
    return f"""You are a senior IT executive consultant writing a batch modernization assessment.

KNOWLEDGE BASE:
{rag_context}

ASSESSMENT STATISTICS:
Total Jobs Analyzed: {stats.get('total_jobs', 0)}
Critical Criticality Jobs: {stats.get('critical_count', 0)}
HIGH Criticality Jobs: {stats.get('high_count', 0)}
MEDIUM Criticality Jobs: {stats.get('medium_count', 0)}
LOW Criticality Jobs: {stats.get('low_count', 0)}
High Migration Complexity: {stats.get('high_complexity', 0)}
Medium Migration Complexity: {stats.get('medium_complexity', 0)}
Low Migration Complexity: {stats.get('low_complexity', 0)}
Critical Risk Jobs: {stats.get('critical_risk', 0)}
High Risk Jobs: {stats.get('high_risk', 0)}
Top Applications: {json.dumps(stats.get('top_apps', []))}
Job Types Distribution: {json.dumps(stats.get('job_types', {}))}
Average Modernization Score: {stats.get('avg_mod_score', 0):.1f} / 10

Write a professional executive summary. Return a single JSON object:

{{
  "headline": "one powerful headline sentence",
  "executive_summary": "3-4 paragraph business-friendly summary",
  "key_findings": [
    "finding1",
    "finding2",
    "finding3",
    "finding4",
    "finding5"
  ],
  "strategic_recommendations": [
    {{
      "priority": "1",
      "recommendation": "action",
      "business_value": "value",
      "timeline": "timeframe"
    }}
  ],
  "risk_summary": "paragraph on key risks",
  "modernization_roadmap": {{
    "phase1": "immediate wins 0-3 months",
    "phase2": "core migration 3-9 months",
    "phase3": "optimization 9-18 months"
  }}
}}

Return ONLY the JSON object. No markdown.
"""
