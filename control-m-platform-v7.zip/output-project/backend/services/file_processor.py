import pandas as pd
import json
import io
import re
import uuid
from typing import Dict, List, Tuple, Any, Optional

try:
    import xmltodict
except ImportError:
    xmltodict = None

# ── Session store ─────────────────────────────────────────────────
# Keyed by session_id → dict with keys:
#   "df"       : pd.DataFrame  (normalized unified jobs)
#   "filename" : str
#   "file_type": str  ("controlm" | "exechistory" | "sourceinventory" | "unknown")
#   "bulk_assessments", "risk_assessments_all", etc. (populated by AI router)
SESSION_STORE: Dict[str, Dict[str, Any]] = {}

# ── Control-M column aliases → canonical names ────────────────────
CONTROLM_ALIASES = {
    "jobid": "JobId", "job_id": "JobId", "id": "JobId",
    "jobname": "JobName", "job_name": "JobName", "name": "JobName",
    "appname": "AppName", "app_name": "AppName", "application": "AppName", "app": "AppName",
    "subapplication": "SubApplication", "sub_application": "SubApplication",
    "platform": "Platform", "server": "Platform", "host": "Platform", "type": "Platform",
    "schedule": "Schedule", "cron": "Schedule",
    "predecessors": "Predecessors", "predecessor": "Predecessors",
    "depends_on": "Predecessors", "dependencies": "Predecessors", "parent": "Predecessors",
    "successor": "Successors", "successors": "Successors",
    "priority": "Priority", "order_priority": "Priority",
    "runtime": "AvgRuntime", "avg_runtime": "AvgRuntime", "avg_runtime_min": "AvgRuntime",
    "estimated_runtime": "AvgRuntime", "duration": "AvgRuntime",
    "owner": "Owner", "user": "Owner", "created_by": "Owner",
    "description": "Description", "desc": "Description", "notes": "Description",
    "status": "Status", "state": "Status",
    "folder": "Folder", "group": "Folder",
    "retries": "Retries", "retry_count": "Retries",
    "ordermethod": "OrderMethod", "order_method": "OrderMethod",
    "maxwaittime": "MaxWaitTime", "max_wait_time": "MaxWaitTime", "timeout": "MaxWaitTime",
}

CONTROLM_CANONICAL = [
    "JobId", "JobName", "AppName", "SubApplication", "Platform",
    "Schedule", "Predecessors", "Successors", "Priority",
    "AvgRuntime", "Owner", "Description", "Status", "Folder",
    "Retries", "OrderMethod", "MaxWaitTime",
]

# ── Execution History column aliases ─────────────────────────────
EXECHISTORY_ALIASES = {
    "jobid": "JobId", "job_id": "JobId", "id": "JobId",
    "jobname": "JobName", "job_name": "JobName", "name": "JobName",
    "run_date": "RunDate", "rundate": "RunDate", "date": "RunDate", "execution_date": "RunDate",
    "runtime": "Runtime", "actual_runtime": "Runtime", "duration": "Runtime",
    "status": "ExecStatus", "exec_status": "ExecStatus", "run_status": "ExecStatus",
    "restart_count": "RestartCount", "restarts": "RestartCount",
    "failure_count": "FailureCount", "failures": "FailureCount", "fail_count": "FailureCount",
    "sla_breach": "SlaBreach", "sla_breached": "SlaBreach", "breach": "SlaBreach",
    "avg_runtime": "AvgRuntime", "average_runtime": "AvgRuntime",
}

EXECHISTORY_CANONICAL = [
    "JobId", "JobName", "RunDate", "Runtime", "ExecStatus",
    "RestartCount", "FailureCount", "SlaBreach", "AvgRuntime",
]

# ── Source Inventory column aliases ───────────────────────────────
SOURCEINV_ALIASES = {
    "jobid": "JobId", "job_id": "JobId", "id": "JobId",
    "jobname": "JobName", "job_name": "JobName", "name": "JobName",
    "app": "AppName", "application": "AppName", "app_name": "AppName",
    "job_type": "JobType", "jobtype": "JobType", "type": "JobType",
    "source_file": "SourceFile", "sourcefile": "SourceFile", "file": "SourceFile",
    "source_path": "SourceFile", "script_path": "SourceFile",
    "source_code": "SourceCode", "sourcecode": "SourceCode", "code": "SourceCode",
    "language": "Language", "lang": "Language",
}

SOURCEINV_CANONICAL = [
    "JobId", "JobName", "AppName", "JobType", "SourceFile", "SourceCode", "Language",
]

# ── Required columns per file type ───────────────────────────────
REQUIRED_COLUMNS = {
    "controlm":      ["JobId", "JobName"],
    "exechistory":   ["JobId"],
    "sourceinventory": ["JobId", "JobName"],
}

# ── Unified model columns ─────────────────────────────────────────
UNIFIED_COLUMNS = [
    "JobId", "JobName", "AppName", "SubApplication", "Platform",
    "Schedule", "Predecessors", "Successors", "Priority",
    "AvgRuntime", "Owner", "Description", "Status", "Folder",
    "Retries", "OrderMethod", "MaxWaitTime",
    # From execution history
    "FailureCount", "RestartCount", "SlaBreach",
    # Derived
    "Criticality", "CriticalityScore", "CriticalityReason",
]


def _normalize_cols(df: pd.DataFrame, aliases: dict, canonical: list) -> pd.DataFrame:
    renamed = {}
    assigned = set()
    for col in df.columns:
        key = col.strip().lower().replace(" ", "_").replace("-", "_")
        canon = aliases.get(key)
        if canon and canon not in assigned:
            renamed[col] = canon
            assigned.add(canon)
    df = df.rename(columns=renamed)
    # Keep only canonical + add missing as empty
    keep = [c for c in canonical if c in df.columns]
    df = df[keep].copy()
    for c in canonical:
        if c not in df.columns:
            df[c] = ""
    return df[canonical]


def _validate_required(df: pd.DataFrame, file_type: str) -> Tuple[bool, List[str]]:
    required = REQUIRED_COLUMNS.get(file_type, ["JobId"])
    missing = [c for c in required if c not in df.columns or df[c].replace("", pd.NA).isna().all()]
    return len(missing) == 0, missing


def detect_file_type(df_raw: pd.DataFrame) -> str:
    """Detect which template type a raw DataFrame matches."""
    cols = {c.strip().lower().replace(" ", "_").replace("-", "_") for c in df_raw.columns}
    exec_signals = {"run_date", "rundate", "failure_count", "failurecount",
                    "restart_count", "sla_breach", "exec_status"}
    src_signals  = {"source_file", "sourcefile", "source_code", "sourcecode",
                    "job_type", "jobtype", "language"}
    if exec_signals & cols:
        return "exechistory"
    if src_signals & cols:
        return "sourceinventory"
    return "controlm"


def process_raw_df(df_raw: pd.DataFrame, file_type: str) -> Tuple[pd.DataFrame, bool, List[str]]:
    """Normalize raw DataFrame for given file type. Returns (df, valid, missing_cols)."""
    if file_type == "exechistory":
        df = _normalize_cols(df_raw, EXECHISTORY_ALIASES, EXECHISTORY_CANONICAL)
    elif file_type == "sourceinventory":
        df = _normalize_cols(df_raw, SOURCEINV_ALIASES, SOURCEINV_CANONICAL)
    else:
        df = _normalize_cols(df_raw, CONTROLM_ALIASES, CONTROLM_CANONICAL)

    valid, missing = _validate_required(df, file_type)
    if not valid:
        return df, False, missing

    # Clean JobId
    df["JobId"] = df["JobId"].astype(str).str.strip()
    df = df[df["JobId"].notna() & (df["JobId"] != "") & (df["JobId"] != "nan")]
    if "JobName" in df.columns:
        df["JobName"] = df["JobName"].astype(str).str.strip()
        df.loc[df["JobName"].isin(["", "nan"]), "JobName"] = df["JobId"]

    # Normalize predecessors
    if "Predecessors" in df.columns:
        df["Predecessors"] = df["Predecessors"].apply(_norm_preds)

    df = df.drop_duplicates(subset=["JobId"]).reset_index(drop=True)
    return df, True, []


def _norm_preds(val) -> str:
    try:
        if pd.isna(val):
            return ""
    except Exception:
        pass
    val = str(val).strip()
    if val in ("", "nan", "None", "-", "N/A"):
        return ""
    val = re.sub(r"[;|\s]+", ",", val)
    parts = [p.strip() for p in val.split(",") if p.strip()]
    seen, unique = set(), []
    for p in parts:
        if p not in seen:
            seen.add(p)
            unique.append(p)
    return ",".join(unique)


def merge_sessions(controlm_sid: str, exechistory_sid: Optional[str]) -> pd.DataFrame:
    """Merge Control-M and Execution History into a unified DataFrame."""
    cm_entry = SESSION_STORE.get(controlm_sid, {})
    cm_df    = cm_entry.get("df", pd.DataFrame())

    if not exechistory_sid:
        return _build_unified(cm_df, None)

    eh_entry = SESSION_STORE.get(exechistory_sid, {})
    eh_df    = eh_entry.get("df", pd.DataFrame())

    return _build_unified(cm_df, eh_df)


def _build_unified(cm_df: pd.DataFrame, eh_df: Optional[pd.DataFrame]) -> pd.DataFrame:
    """Build unified job model from Control-M + optional Execution History."""
    # Start with Control-M data
    unified = cm_df.copy() if not cm_df.empty else pd.DataFrame(columns=CONTROLM_CANONICAL)

    # Add execution history columns (all empty by default)
    for col in ["FailureCount", "RestartCount", "SlaBreach", "AvgRuntime_Exec"]:
        if col not in unified.columns:
            unified[col] = ""

    # Merge execution history if provided
    if eh_df is not None and not eh_df.empty and "JobId" in eh_df.columns:
        # Aggregate per job: sum failures, restarts, breaches; avg runtime
        agg = {}
        if "FailureCount" in eh_df.columns:
            eh_df["FailureCount"] = pd.to_numeric(eh_df["FailureCount"], errors="coerce").fillna(0)
            agg["FailureCount"] = ("FailureCount", "sum")
        if "RestartCount" in eh_df.columns:
            eh_df["RestartCount"] = pd.to_numeric(eh_df["RestartCount"], errors="coerce").fillna(0)
            agg["RestartCount"] = ("RestartCount", "sum")
        if "SlaBreach" in eh_df.columns:
            eh_df["SlaBreach_num"] = eh_df["SlaBreach"].astype(str).str.strip().str.upper().map(
                lambda x: 1 if x in ("1", "TRUE", "YES", "Y") else 0
            )
            agg["SlaBreach"] = ("SlaBreach_num", "sum")
        if "AvgRuntime" in eh_df.columns:
            eh_df["AvgRuntime"] = pd.to_numeric(eh_df["AvgRuntime"], errors="coerce")
            agg["AvgRuntime_Exec"] = ("AvgRuntime", "mean")

        if agg:
            grouped = eh_df.groupby("JobId").agg(**{k: v for k, v in agg.items()}).reset_index()
            grouped.columns = ["JobId"] + list(agg.keys())
            grouped = grouped.rename(columns={"AvgRuntime": "AvgRuntime_Exec"})

            # Merge on JobId
            before_cols = [c for c in unified.columns if c not in list(agg.keys()) + ["AvgRuntime_Exec"]]
            unified = unified[before_cols].merge(grouped, on="JobId", how="left")
            for col in list(agg.keys()):
                if col not in unified.columns:
                    unified[col] = 0
            unified = unified.fillna({c: 0 for c in list(agg.keys())})

    # Use exec AvgRuntime if CM doesn't have one
    if "AvgRuntime_Exec" in unified.columns and "AvgRuntime" in unified.columns:
        mask = unified["AvgRuntime"].astype(str).str.strip().isin(["", "nan", "0"])
        unified.loc[mask, "AvgRuntime"] = unified.loc[mask, "AvgRuntime_Exec"].astype(str)
        unified = unified.drop(columns=["AvgRuntime_Exec"], errors="ignore")

    return unified


# ── CSV/JSON/XML parsing ──────────────────────────────────────────

def _read_raw(content: bytes, filename: str) -> pd.DataFrame:
    name = filename.lower()
    if name.endswith(".json"):
        data = json.loads(content.decode("utf-8"))
        if isinstance(data, list):
            return pd.DataFrame(data)
        if isinstance(data, dict):
            for key in ["jobs", "records", "data", "items", "rows"]:
                if key in data and isinstance(data[key], list):
                    return pd.DataFrame(data[key])
            return pd.DataFrame([data])
        raise ValueError("Unsupported JSON structure")
    elif name.endswith(".xml"):
        if xmltodict is None:
            raise ImportError("xmltodict not installed")
        parsed = xmltodict.parse(content.decode("utf-8"))
        records = []
        def _find(obj, depth=0):
            if isinstance(obj, list):
                for item in obj:
                    if isinstance(item, dict):
                        records.append(item)
            elif isinstance(obj, dict):
                for key, val in obj.items():
                    if isinstance(val, list) and val and isinstance(val[0], dict):
                        records.extend(val)
                        return
                    elif isinstance(val, dict) and depth < 3:
                        _find(val, depth + 1)
        _find(parsed)
        if not records:
            raise ValueError("No records found in XML")
        raw = pd.DataFrame(records)
        raw.columns = [c.lstrip("@#") for c in raw.columns]
        return raw
    else:  # CSV (default)
        try:
            return pd.read_csv(io.BytesIO(content), dtype=str)
        except Exception:
            return pd.read_csv(io.BytesIO(content), dtype=str, encoding="latin-1")


def process_upload(content: bytes, filename: str) -> Tuple[pd.DataFrame, str, bool, List[str]]:
    """
    Full upload pipeline.
    Returns (df, file_type, valid, missing_columns).
    """
    raw = _read_raw(content, filename)
    file_type = detect_file_type(raw)
    df, valid, missing = process_raw_df(raw, file_type)
    return df, file_type, valid, missing


# ── Session helpers ───────────────────────────────────────────────

def save_session(df: pd.DataFrame, filename: str = "", file_type: str = "controlm") -> str:
    sid = str(uuid.uuid4())
    SESSION_STORE[sid] = {
        "df":        df,
        "filename":  filename,
        "file_type": file_type,
        "jobs":      df.to_dict(orient="records"),
    }
    return sid


def get_session(session_id: str) -> pd.DataFrame:
    entry = SESSION_STORE.get(session_id)
    if not entry:
        raise KeyError(f"Session {session_id} not found")
    return entry["df"]


def get_session_entry(session_id: str) -> Dict[str, Any]:
    entry = SESSION_STORE.get(session_id)
    if not entry:
        raise KeyError(f"Session {session_id} not found")
    return entry


# ── CSV Templates ─────────────────────────────────────────────────

TEMPLATES = {
    "controlm": {
        "filename": "controlm_export_template.csv",
        "headers": ["JobId", "JobName", "AppName", "SubApplication", "Platform",
                    "Schedule", "Predecessors", "Successors", "Priority",
                    "AvgRuntime", "Owner", "Description", "Status", "Folder",
                    "Retries", "OrderMethod", "MaxWaitTime"],
        "sample": [
            ["JOB_001", "Load_Trades", "TradingApp", "ETL", "Linux",
             "0 6 * * 1-5", "", "JOB_002,JOB_003", "High",
             "45", "ops_team", "Load daily trades", "Active", "TRADING_FOLDER",
             "2", "ODAT", "120"],
            ["JOB_002", "Validate_Trades", "TradingApp", "ETL", "Linux",
             "0 7 * * 1-5", "JOB_001", "JOB_004", "High",
             "20", "ops_team", "Validate trade records", "Active", "TRADING_FOLDER",
             "1", "ODAT", "60"],
        ],
    },
    "exechistory": {
        "filename": "execution_history_template.csv",
        "headers": ["JobId", "JobName", "RunDate", "Runtime", "ExecStatus",
                    "RestartCount", "FailureCount", "SlaBreach", "AvgRuntime"],
        "sample": [
            ["JOB_001", "Load_Trades", "2024-01-15", "43", "Success", "0", "0", "No", "45"],
            ["JOB_001", "Load_Trades", "2024-01-16", "67", "Failed",  "1", "1", "Yes", "45"],
            ["JOB_002", "Validate_Trades", "2024-01-15", "18", "Success", "0", "0", "No", "20"],
        ],
    },
    "sourceinventory": {
        "filename": "source_inventory_template.csv",
        "headers": ["JobId", "JobName", "AppName", "JobType", "SourceFile", "Language"],
        "sample": [
            ["JOB_001", "Load_Trades",    "TradingApp", "Shell",       "/scripts/load_trades.sh",    "Shell"],
            ["JOB_002", "Validate_Trades","TradingApp", "Python",      "/scripts/validate_trades.py","Python"],
            ["JOB_003", "Archive_Trades", "TradingApp", "SQL",         "/sql/archive_trades.sql",    "SQL"],
        ],
    },
}
