from __future__ import annotations
import networkx as nx
import pandas as pd
from typing import List, Tuple, Dict, Any


def build_graph(df: pd.DataFrame) -> nx.DiGraph:
    G = nx.DiGraph()
    for _, row in df.iterrows():
        jid = str(row.get("JobId", "")).strip()
        if not jid:
            continue
        G.add_node(jid)

    for _, row in df.iterrows():
        jid  = str(row.get("JobId", "")).strip()
        pred = str(row.get("Predecessors", "")).strip()
        succ = str(row.get("Successors", "")).strip()
        if not jid:
            continue
        if pred and pred not in ("nan", "None", ""):
            for p in pred.split(","):
                p = p.strip()
                if p and p != jid:
                    if not G.has_node(p):
                        G.add_node(p)
                    G.add_edge(p, jid)
        if succ and succ not in ("nan", "None", ""):
            for s in succ.split(","):
                s = s.strip()
                if s and s != jid:
                    if not G.has_node(s):
                        G.add_node(s)
                    G.add_edge(jid, s)
    return G


def find_critical_path(G: nx.DiGraph) -> List[str]:
    """Longest path by hop count in the DAG. Returns node IDs."""
    if G.number_of_nodes() == 0:
        return []
    try:
        # Use a DAG copy (remove cycles for this computation)
        dag = _to_dag(G)
        path = nx.dag_longest_path(dag)
        return path
    except Exception:
        return []


def _to_dag(G: nx.DiGraph) -> nx.DiGraph:
    """Return a copy of G with cycle-breaking edges removed."""
    try:
        cycles = list(nx.simple_cycles(G))
        dag = G.copy()
        for cycle in cycles:
            # Remove the last edge of each cycle
            if len(cycle) >= 2:
                dag.remove_edge(cycle[-1], cycle[0])
        return dag
    except Exception:
        return G.copy()


def detect_cycles(G: nx.DiGraph) -> Tuple[bool, List[List[str]]]:
    try:
        cycles = list(nx.simple_cycles(G))
        return bool(cycles), cycles[:20]
    except Exception:
        return False, []


def get_impact_analysis(G: nx.DiGraph, job_id: str) -> List[str]:
    if job_id not in G:
        return []
    try:
        return list(nx.descendants(G, job_id))
    except Exception:
        return []


def get_subgraph_for_jobs(G: nx.DiGraph, job_ids: List[str], depth: int = 3) -> nx.DiGraph:
    nodes = set()
    for jid in job_ids:
        if jid not in G:
            continue
        nodes.add(jid)
        # Ancestors up to depth
        try:
            for anc in nx.ancestors(G, jid):
                nodes.add(anc)
        except Exception:
            pass
        # Descendants up to depth
        try:
            for desc in nx.descendants(G, jid):
                nodes.add(desc)
        except Exception:
            pass
    return G.subgraph(nodes).copy() if nodes else G.copy()


def compute_fan_metrics(G: nx.DiGraph) -> Dict[str, Dict[str, int]]:
    return {
        node: {"fan_in": G.in_degree(node), "fan_out": G.out_degree(node)}
        for node in G.nodes()
    }


def graph_to_cytoscape(
    G: nx.DiGraph,
    critical_path: List[str],
    fan_metrics: Dict[str, Dict[str, int]],
    selected_jobs: List[str],
    df: pd.DataFrame,
) -> Tuple[List[dict], List[dict]]:
    """Convert NetworkX graph to Cytoscape-compatible nodes/edges."""
    cp_set   = set(critical_path)
    sel_set  = set(selected_jobs)
    job_map  = dict(zip(df["JobId"], df["JobName"])) if "JobName" in df.columns else {}
    app_map  = dict(zip(df["JobId"], df["AppName"])) if "AppName" in df.columns else {}
    crit_map = dict(zip(df["JobId"], df["Criticality"])) if "Criticality" in df.columns else {}
    score_map = dict(zip(df["JobId"], df["CriticalityScore"])) if "CriticalityScore" in df.columns else {}
    reason_map = dict(zip(df["JobId"], df["CriticalityReason"])) if "CriticalityReason" in df.columns else {}
    factors_map = dict(zip(df["JobId"], df["CriticalityFactors"])) if "CriticalityFactors" in df.columns else {}

    # Group by AppName
    app_ids: Dict[str, str] = {}
    nodes: List[dict] = []
    edges: List[dict] = []

    # Create parent compound nodes for apps
    apps_seen = set()
    for node in G.nodes():
        app = app_map.get(node, "")
        if app and app not in ("", "nan", "None"):
            if app not in apps_seen:
                apps_seen.add(app)
                app_id = f"app_{app}"
                app_ids[app] = app_id
                nodes.append({
                    "data": {"id": app_id, "label": app, "type": "group"},
                    "classes": "app-group",
                })

    for node in G.nodes():
        job_name  = job_map.get(node, node)
        app       = app_map.get(node, "")
        crit      = crit_map.get(node, "Low")
        score     = int(score_map.get(node, 0))
        reason    = reason_map.get(node, "")
        factors   = factors_map.get(node, [])
        fan       = fan_metrics.get(node, {"fan_in": 0, "fan_out": 0})
        label     = job_name if job_name != node else node
        if len(label) > 20:
            label = label[:18] + "…"

        data: Dict[str, Any] = {
            "id":                  node,
            "label":               job_name,
            "displayLabel":        label,
            "criticality":         crit,
            "criticality_score":   score,
            "criticality_reason":  reason,
            "criticality_factors": factors,
            "fan_in":              fan["fan_in"],
            "fan_out":             fan["fan_out"],
            "is_critical_path":    node in cp_set,
            "is_selected":         node in sel_set,
        }
        if app and app in app_ids:
            data["parent"] = app_ids[app]

        nodes.append({"data": data})

    for source, target in G.edges():
        edges.append({
            "data": {
                "id":              f"{source}__{target}",
                "source":          source,
                "target":          target,
                "is_critical_path": (source in cp_set and target in cp_set),
            }
        })

    return nodes, edges
