"""
Phase-1 Criticality Engine.
Derives criticality purely from graph structure + execution history.
No pre-assigned values used.
"""
from __future__ import annotations
import pandas as pd
import networkx as nx
from typing import Dict, List, Tuple


def score_criticality(
    df: pd.DataFrame,
    G: nx.DiGraph,
    critical_path: List[str],
) -> pd.DataFrame:
    """
    Compute criticality score for every job and add columns:
      CriticalityScore  : int (0-12+)
      Criticality       : str (Low | Medium | High | Critical)
      CriticalityReason : str (human-readable explanation)
      CriticalityFactors: list[dict] (for tooltip breakdown)
    """
    cp_set = set(critical_path)
    fan    = {n: {"fan_in": G.in_degree(n), "fan_out": G.out_degree(n)} for n in G.nodes()}

    # Compute dependency depth (longest path from any root to this node)
    depth_map: Dict[str, int] = {}
    try:
        for node in nx.topological_sort(G):
            preds = list(G.predecessors(node))
            depth_map[node] = max((depth_map.get(p, 0) + 1 for p in preds), default=0)
    except Exception:
        depth_map = {n: 0 for n in G.nodes()}

    records = []
    for _, row in df.iterrows():
        jid = row["JobId"]
        factors = []
        score   = 0

        # ── Factor 1: Critical path membership (+3) ──────────────
        if jid in cp_set:
            score += 3
            factors.append({"factor": "Critical Path Job", "points": 3,
                             "detail": "Job lies on the longest dependency chain"})

        # ── Factor 2: Fan-out (+2 if >5, +1 if 3-5) ─────────────
        fo = fan.get(jid, {}).get("fan_out", 0)
        if fo > 5:
            score += 2
            factors.append({"factor": f"High Fan-Out ({fo} downstream jobs)", "points": 2,
                             "detail": f"Failure blocks {fo} downstream jobs"})
        elif fo >= 3:
            score += 1
            factors.append({"factor": f"Moderate Fan-Out ({fo} downstream jobs)", "points": 1,
                             "detail": f"Failure impacts {fo} downstream jobs"})

        # ── Factor 3: Dependency depth (+1 if >5, +2 if >10) ─────
        depth = depth_map.get(jid, 0)
        if depth > 10:
            score += 2
            factors.append({"factor": f"Deep Dependency ({depth} levels)", "points": 2,
                             "detail": "Job sits deep in the dependency hierarchy"})
        elif depth > 5:
            score += 1
            factors.append({"factor": f"Moderate Depth ({depth} levels)", "points": 1,
                             "detail": "Job has significant upstream dependencies"})

        # ── Factor 4: Average runtime (+1 if >30 min) ────────────
        try:
            rt = float(str(row.get("AvgRuntime", "")).strip() or "0")
        except (ValueError, TypeError):
            rt = 0.0
        if rt > 60:
            score += 2
            factors.append({"factor": f"Long Runtime ({rt:.0f} min)", "points": 2,
                             "detail": "Long-running job creates scheduling pressure"})
        elif rt > 30:
            score += 1
            factors.append({"factor": f"Above-Average Runtime ({rt:.0f} min)", "points": 1,
                             "detail": "Runtime exceeds 30-minute threshold"})

        # ── Factor 5: Retry count (+1 if >0, +2 if >2) ───────────
        try:
            retries = float(str(row.get("Retries", "")).strip() or "0")
        except (ValueError, TypeError):
            retries = 0.0
        if retries > 2:
            score += 2
            factors.append({"factor": f"High Retry Count ({retries:.0f})", "points": 2,
                             "detail": "Frequent retries indicate instability"})
        elif retries > 0:
            score += 1
            factors.append({"factor": f"Has Retries ({retries:.0f})", "points": 1,
                             "detail": "Job is configured with retry logic"})

        # ── Factor 6: Failure count from execution history (+2 if >2) ─
        try:
            failures = float(str(row.get("FailureCount", "")).strip() or "0")
        except (ValueError, TypeError):
            failures = 0.0
        if failures > 2:
            score += 2
            factors.append({"factor": f"High Failure Count ({failures:.0f})", "points": 2,
                             "detail": "History of frequent failures detected"})
        elif failures > 0:
            score += 1
            factors.append({"factor": f"Has Failures ({failures:.0f})", "points": 1,
                             "detail": "At least one failure recorded in history"})

        # ── Factor 7: SLA breach (+2) ─────────────────────────────
        try:
            breaches = float(str(row.get("SlaBreach", "")).strip() or "0")
        except (ValueError, TypeError):
            breaches = 0.0
        if breaches > 0:
            score += 2
            factors.append({"factor": f"SLA Breach ({breaches:.0f})", "points": 2,
                             "detail": "Job has breached SLA in execution history"})

        # ── Factor 8: Priority field from Control-M (+1 if High) ──
        priority = str(row.get("Priority", "")).strip().upper()
        if priority in ("HIGH", "URGENT", "CRITICAL", "1", "P1"):
            score += 1
            factors.append({"factor": "High Priority (Control-M)", "points": 1,
                             "detail": "Marked as high priority in Control-M export"})

        # ── Map score → label ─────────────────────────────────────
        if score >= 10:
            label = "Critical"
        elif score >= 7:
            label = "High"
        elif score >= 4:
            label = "Medium"
        else:
            label = "Low"

        # ── Build reason string ───────────────────────────────────
        if factors:
            top = sorted(factors, key=lambda f: -f["points"])[:3]
            reason_parts = [f["factor"] for f in top]
            reason = "; ".join(reason_parts)
        else:
            reason = "No significant risk factors detected"

        records.append({
            "JobId":              jid,
            "CriticalityScore":   score,
            "Criticality":        label,
            "CriticalityReason":  reason,
            "CriticalityFactors": factors,
        })

    crit_df = pd.DataFrame(records).set_index("JobId")

    # Merge into df
    for col in ["CriticalityScore", "Criticality", "CriticalityReason", "CriticalityFactors"]:
        df[col] = df["JobId"].map(crit_df[col])
        if col == "CriticalityScore":
            df[col] = df[col].fillna(0).astype(int)
        elif col == "CriticalityFactors":
            df[col] = df[col].apply(lambda x: x if isinstance(x, list) else [])
        else:
            df[col] = df[col].fillna("Low" if col == "Criticality" else "")

    return df


def compute_bottleneck_ranking(G: nx.DiGraph, df: pd.DataFrame) -> List[dict]:
    """Rank jobs by bottleneck impact = fan_out * (1 + failure_count)."""
    failure_map = {}
    for _, row in df.iterrows():
        try:
            failure_map[row["JobId"]] = float(str(row.get("FailureCount", 0)).strip() or "0")
        except Exception:
            failure_map[row["JobId"]] = 0.0

    job_map = dict(zip(df["JobId"], df["JobName"]))
    crit_map = dict(zip(df["JobId"], df.get("Criticality", pd.Series())))

    bottlenecks = []
    for node in G.nodes():
        fo = G.out_degree(node)
        fi = G.in_degree(node)
        failures = failure_map.get(node, 0)
        impact_score = fo * (1 + failures)
        if fo > 0 or fi > 3:
            bottlenecks.append({
                "job_id":       node,
                "job_name":     job_map.get(node, node),
                "criticality":  crit_map.get(node, "Low"),
                "fan_in":       fi,
                "fan_out":      fo,
                "failure_count": int(failures),
                "impact_score": round(impact_score, 2),
            })

    bottlenecks.sort(key=lambda x: -x["impact_score"])
    return bottlenecks[:20]


def compute_runtime_impact(G: nx.DiGraph, df: pd.DataFrame) -> List[dict]:
    """Estimate cascading runtime impact for key jobs."""
    runtime_map = {}
    for _, row in df.iterrows():
        try:
            runtime_map[row["JobId"]] = float(str(row.get("AvgRuntime", 0)).strip() or "0")
        except Exception:
            runtime_map[row["JobId"]] = 0.0

    job_map = dict(zip(df["JobId"], df["JobName"]))
    result = []
    for node in G.nodes():
        if G.out_degree(node) == 0:
            continue
        try:
            descendants = list(nx.descendants(G, node))
        except Exception:
            descendants = []
        cascading_rt = sum(runtime_map.get(d, 0) for d in descendants)
        own_rt = runtime_map.get(node, 0)
        if cascading_rt > 0:
            result.append({
                "job_id":             node,
                "job_name":           job_map.get(node, node),
                "own_runtime_min":    own_rt,
                "cascading_runtime_min": round(cascading_rt, 1),
                "downstream_jobs":    len(descendants),
            })

    result.sort(key=lambda x: -x["cascading_runtime_min"])
    return result[:15]
