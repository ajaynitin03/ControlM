from __future__ import annotations
import io
import json
from typing import Optional

import pandas as pd
from fastapi import APIRouter, File, HTTPException, Query, UploadFile
from fastapi.responses import StreamingResponse

from services.file_processor import (
    SESSION_STORE, TEMPLATES, get_session, get_session_entry,
    merge_sessions, process_upload, save_session,
)
from services.graph_service import build_graph, find_critical_path
from services.criticality_engine import score_criticality

router = APIRouter()


# ════════════════════════════════════════════════════════════════
# TEMPLATES DOWNLOAD
# ════════════════════════════════════════════════════════════════

@router.get("/templates")
def list_templates():
    return {
        "templates": [
            {"id": k, "filename": v["filename"], "description": _template_desc(k)}
            for k, v in TEMPLATES.items()
        ]
    }


@router.get("/templates/{template_id}")
def download_template(template_id: str):
    if template_id not in TEMPLATES:
        raise HTTPException(404, f"Template '{template_id}' not found. "
                                 f"Available: {list(TEMPLATES.keys())}")
    tmpl = TEMPLATES[template_id]
    buf  = io.StringIO()
    buf.write(",".join(tmpl["headers"]) + "\n")
    for row in tmpl["sample"]:
        buf.write(",".join(str(c) for c in row) + "\n")
    content = buf.getvalue().encode()
    return StreamingResponse(
        io.BytesIO(content),
        media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename={tmpl['filename']}"},
    )


# ════════════════════════════════════════════════════════════════
# UPLOAD — single file
# ════════════════════════════════════════════════════════════════

@router.post("/")
async def upload_file(file: UploadFile = File(...)):
    content  = await file.read()
    filename = file.filename or "upload"

    df, file_type, valid, missing = process_upload(content, filename)

    if not valid:
        raise HTTPException(
            status_code=422,
            detail={
                "error":           "Invalid CSV format. Please use the provided template.",
                "missing_columns": missing,
                "file_type":       file_type,
                "hint":            f"Download the {file_type} template from /api/upload/templates/{file_type}",
            },
        )

    if df.empty:
        raise HTTPException(422, "No valid records found in file.")

    # For Control-M files, derive criticality immediately
    if file_type == "controlm":
        df = _derive_criticality(df)

    sid = save_session(df, filename=filename, file_type=file_type)
    preview = df.head(50).fillna("").to_dict(orient="records")
    _sanitize(preview)

    return {
        "success":     True,
        "message":     f"Processed {len(df)} records successfully",
        "session_id":  sid,
        "file_type":   file_type,
        "row_count":   len(df),
        "columns":     list(df.columns),
        "preview":     preview,
        "total_pages": (len(df) + 49) // 50,
    }


# ════════════════════════════════════════════════════════════════
# MERGE — combine Control-M + Execution History
# ════════════════════════════════════════════════════════════════

@router.post("/merge")
def merge_files(
    controlm_session_id: str,
    exechistory_session_id: Optional[str] = None,
):
    """Merge a Control-M session with an optional Execution History session."""
    if controlm_session_id not in SESSION_STORE:
        raise HTTPException(404, f"Control-M session '{controlm_session_id}' not found")
    cm_entry = SESSION_STORE[controlm_session_id]
    if cm_entry.get("file_type") not in ("controlm", "unknown"):
        raise HTTPException(400, "First session must be a Control-M export")

    if exechistory_session_id and exechistory_session_id not in SESSION_STORE:
        raise HTTPException(404, f"Execution History session '{exechistory_session_id}' not found")

    unified_df = merge_sessions(controlm_session_id, exechistory_session_id)
    unified_df = _derive_criticality(unified_df)

    merged_sid = save_session(unified_df, filename="merged", file_type="merged")
    preview    = unified_df.head(50).fillna("").to_dict(orient="records")
    _sanitize(preview)

    return {
        "success":              True,
        "merged_session_id":    merged_sid,
        "row_count":            len(unified_df),
        "columns":              list(unified_df.columns),
        "preview":              preview,
        "total_pages":          (len(unified_df) + 49) // 50,
        "execution_history":    exechistory_session_id is not None,
    }


# ════════════════════════════════════════════════════════════════
# PREVIEW / JOBS / EXPORT
# ════════════════════════════════════════════════════════════════

@router.get("/preview/{session_id}")
def get_preview(
    session_id: str,
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=10, le=200),
):
    df    = _get_df(session_id)
    start = (page - 1) * page_size
    chunk = df.iloc[start: start + page_size].fillna("")
    data  = chunk.to_dict(orient="records")
    _sanitize(data)
    return {
        "page":        page,
        "page_size":   page_size,
        "total_rows":  len(df),
        "total_pages": (len(df) + page_size - 1) // page_size,
        "data":        data,
        "columns":     list(df.columns),
    }


@router.get("/jobs/{session_id}")
def get_job_list(session_id: str):
    df = _get_df(session_id)
    cols = ["JobId", "JobName", "AppName",
            "Criticality", "CriticalityScore", "CriticalityReason", "CriticalityFactors"]
    avail = [c for c in cols if c in df.columns]
    records = df[avail].fillna("").to_dict(orient="records")
    _sanitize(records)
    return {"jobs": records, "count": len(records)}


@router.get("/export/{session_id}")
def export_csv(session_id: str):
    df  = _get_df(session_id)
    buf = io.StringIO()
    # Drop CriticalityFactors (list column — not CSV-friendly)
    export_df = df.drop(columns=["CriticalityFactors"], errors="ignore")
    export_df.to_csv(buf, index=False)
    return StreamingResponse(
        io.BytesIO(buf.getvalue().encode()),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=normalized_jobs.csv"},
    )


# ════════════════════════════════════════════════════════════════
# HELPERS
# ════════════════════════════════════════════════════════════════

def _get_df(session_id: str) -> pd.DataFrame:
    try:
        return get_session(session_id)
    except KeyError:
        raise HTTPException(404, f"Session '{session_id}' not found")


def _derive_criticality(df: pd.DataFrame) -> pd.DataFrame:
    """Build graph → find critical path → score criticality."""
    try:
        from services.graph_service import build_graph, find_critical_path
        G  = build_graph(df)
        cp = find_critical_path(G)
        df = score_criticality(df, G, cp)
    except Exception as e:
        # Never crash on criticality — just leave defaults
        if "Criticality" not in df.columns:
            df["Criticality"] = "Low"
        if "CriticalityScore" not in df.columns:
            df["CriticalityScore"] = 0
        if "CriticalityReason" not in df.columns:
            df["CriticalityReason"] = ""
        if "CriticalityFactors" not in df.columns:
            df["CriticalityFactors"] = [[] for _ in range(len(df))]
    return df


def _sanitize(records: list):
    """Convert non-JSON-serialisable values in-place."""
    import math
    for rec in records:
        for k, v in rec.items():
            if isinstance(v, float) and (math.isnan(v) or math.isinf(v)):
                rec[k] = None
            elif hasattr(v, "item"):        # numpy scalar
                rec[k] = v.item()


def _template_desc(tid: str) -> str:
    return {
        "controlm":      "Control-M / Autosys / Cron scheduler export",
        "exechistory":   "Job execution history with runtime and failure data",
        "sourceinventory": "Source code inventory mapping jobs to script files",
    }.get(tid, tid)
