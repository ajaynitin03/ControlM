"""
Phase-2 AI Assessment Router.
All endpoints delegate to assessment_engine.py.
Session data is read from and written to file_processor.SESSION_STORE.
"""
from __future__ import annotations
import io
import logging
from typing import Optional

from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from services.file_processor import SESSION_STORE
from ai import assessment_engine as engine
from ai.report_generator import generate_excel_report
from ai.gemini_client import is_available
from models.schemas import (
    SourceCodeRequest, BottleneckRequest,
    RiskRequest, ModernizationRequest, ConversionRequest,
)

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/ai", tags=["Phase-2 AI"])

SUPPORTED_TARGETS = {
    "Python", "SpringBatch", "PySpark",
    "Airflow", "AirflowDAG", "Java", "Shell",
}


# ── Helpers ───────────────────────────────────────────────────────

def _get_session(session_id: str) -> dict:
    entry = SESSION_STORE.get(session_id)
    if not entry:
        raise HTTPException(404, f"Session '{session_id}' not found")
    return entry


def _find_job(entry: dict, job_id: str) -> dict:
    for j in entry.get("jobs", []):
        if j.get("JobId") == job_id:
            return j
    return {"JobId": job_id, "JobName": job_id}


def _sanitize(obj):
    """Recursively convert non-serialisable values."""
    import math
    if isinstance(obj, list):
        return [_sanitize(i) for i in obj]
    if isinstance(obj, dict):
        return {k: _sanitize(v) for k, v in obj.items()}
    if isinstance(obj, float) and (math.isnan(obj) or math.isinf(obj)):
        return None
    if hasattr(obj, "item"):   # numpy scalar
        return obj.item()
    return obj


# ════════════════════════════════════════════════════════════════
# STATUS
# ════════════════════════════════════════════════════════════════

@router.get("/status")
def ai_status():
    from ai.rag_knowledge import _INDEX, _DOCS
    return {
        "gemini_available":  is_available(),
        "rag_docs_loaded":   len(_DOCS),
        "faiss_index_ready": _INDEX is not None,
        "phase2_ready":      True,
    }


# ════════════════════════════════════════════════════════════════
# FEATURE 1 — BULK JOB ASSESSMENT
# ════════════════════════════════════════════════════════════════

@router.post("/bulk-assess/{session_id}")
def bulk_assess(session_id: str):
    entry = _get_session(session_id)
    jobs  = entry.get("jobs", [])
    if not jobs:
        raise HTTPException(400, "No jobs found in session")

    logger.info(f"[BulkAssess] session={session_id} jobs={len(jobs)}")
    results = engine.bulk_assess_jobs(jobs)
    results = _sanitize(results)

    entry["bulk_assessments"] = results
    return {
        "session_id":  session_id,
        "total_jobs":  len(jobs),
        "assessed":    len(results),
        "ai_powered":  is_available(),
        "assessments": results,
    }


# ════════════════════════════════════════════════════════════════
# FEATURE 2 — SOURCE CODE ANALYSIS
# ════════════════════════════════════════════════════════════════

@router.post("/source-analysis/{session_id}")
def source_analysis(session_id: str, req: SourceCodeRequest):
    entry    = _get_session(session_id)
    job_meta = _find_job(entry, req.job_id)

    logger.info(f"[SourceAnalysis] session={session_id} job={req.job_id}")
    result = engine.analyze_source_code(job_meta, req.source_code)
    result = _sanitize(result)

    entry.setdefault("source_analyses", {})[req.job_id] = result
    return {"session_id": session_id, "ai_powered": is_available(), "analysis": result}


# ════════════════════════════════════════════════════════════════
# FEATURE 3 — BOTTLENECK ANALYSIS
# ════════════════════════════════════════════════════════════════

@router.post("/bottleneck/{session_id}")
def bottleneck_analysis(session_id: str, req: BottleneckRequest):
    entry    = _get_session(session_id)
    job_meta = _find_job(entry, req.job_id)

    logger.info(f"[Bottleneck] session={session_id} job={req.job_id}")
    result = engine.analyze_bottlenecks(job_meta, req.source_code)
    result = _sanitize(result)

    entry.setdefault("bottlenecks", {})[req.job_id] = result
    return {"session_id": session_id, "ai_powered": is_available(), "bottleneck": result}


# ════════════════════════════════════════════════════════════════
# FEATURE 4 — RISK ASSESSMENT (single job)
# ════════════════════════════════════════════════════════════════

@router.post("/risk/{session_id}")
def risk_assessment(session_id: str, req: RiskRequest):
    entry    = _get_session(session_id)
    job_meta = _find_job(entry, req.job_id)

    fan_in  = req.fan_in
    fan_out = req.fan_out

    # Auto-populate fan metrics from built graph if available
    graph = entry.get("graph")
    if graph is not None:
        try:
            fan_in  = fan_in  or graph.in_degree(req.job_id)
            fan_out = fan_out or graph.out_degree(req.job_id)
        except Exception:
            pass

    logger.info(f"[Risk] session={session_id} job={req.job_id} fi={fan_in} fo={fan_out}")
    result = engine.assess_risk(job_meta, req.source_code or "", fan_in, fan_out)
    result = _sanitize(result)

    entry.setdefault("risk_assessments", {})[req.job_id] = result
    return {"session_id": session_id, "ai_powered": is_available(), "risk": result}


# ════════════════════════════════════════════════════════════════
# FEATURE 4 — RISK ASSESSMENT (all jobs)
# ════════════════════════════════════════════════════════════════

@router.post("/risk-all/{session_id}")
def risk_all_jobs(session_id: str):
    entry = _get_session(session_id)
    jobs  = entry.get("jobs", [])
    if not jobs:
        raise HTTPException(400, "No jobs in session")

    graph = entry.get("graph")
    results = []

    for job in jobs:
        jid     = job.get("JobId", "")
        fan_in  = 0
        fan_out = 0
        if graph is not None:
            try:
                fan_in  = graph.in_degree(jid)
                fan_out = graph.out_degree(jid)
            except Exception:
                pass
        r = engine.assess_risk(job, "", fan_in, fan_out)
        results.append(r)

    results = _sanitize(results)
    entry["risk_assessments_all"] = results
    return {
        "session_id": session_id,
        "total":      len(results),
        "ai_powered": is_available(),
        "risks":      results,
    }


# ════════════════════════════════════════════════════════════════
# FEATURE 5 — MODERNIZATION ASSESSMENT (single job)
# ════════════════════════════════════════════════════════════════

@router.post("/modernization/{session_id}")
def modernization_assessment(session_id: str, req: ModernizationRequest):
    entry    = _get_session(session_id)
    job_meta = _find_job(entry, req.job_id)

    logger.info(f"[Modernization] session={session_id} job={req.job_id}")
    result = engine.assess_modernization(job_meta, req.source_code or "")
    result = _sanitize(result)

    entry.setdefault("modernizations", {})[req.job_id] = result
    return {"session_id": session_id, "ai_powered": is_available(), "modernization": result}


# ════════════════════════════════════════════════════════════════
# FEATURE 5 — MODERNIZATION ASSESSMENT (all jobs)
# ════════════════════════════════════════════════════════════════

@router.post("/modernization-all/{session_id}")
def modernization_all_jobs(session_id: str):
    entry = _get_session(session_id)
    jobs  = entry.get("jobs", [])
    if not jobs:
        raise HTTPException(400, "No jobs in session")

    results = [engine.assess_modernization(job, "") for job in jobs]
    results = _sanitize(results)

    entry["modernizations_all"] = results
    return {
        "session_id":     session_id,
        "total":          len(results),
        "ai_powered":     is_available(),
        "modernizations": results,
    }


# ════════════════════════════════════════════════════════════════
# FEATURE 6 — JOB CONVERSION
# ════════════════════════════════════════════════════════════════

@router.post("/convert/{session_id}")
def convert_job(session_id: str, req: ConversionRequest):
    if req.target_technology not in SUPPORTED_TARGETS:
        raise HTTPException(
            400,
            f"Unsupported target '{req.target_technology}'. "
            f"Choose from: {sorted(SUPPORTED_TARGETS)}",
        )
    if not req.source_code.strip():
        raise HTTPException(400, "source_code is required for conversion")

    entry    = _get_session(session_id)
    job_meta = _find_job(entry, req.job_id)

    logger.info(f"[Convert] session={session_id} job={req.job_id} → {req.target_technology}")
    result = engine.convert_job(job_meta, req.source_code, req.target_technology)
    result = _sanitize(result)

    entry.setdefault("conversions", {})[req.job_id] = result
    return {"session_id": session_id, "ai_powered": is_available(), "conversion": result}


# ════════════════════════════════════════════════════════════════
# EXECUTIVE SUMMARY
# ════════════════════════════════════════════════════════════════

@router.post("/executive-summary/{session_id}")
def executive_summary(session_id: str):
    entry = _get_session(session_id)
    jobs  = entry.get("jobs", [])

    crit_counts: dict = {}
    apps:        dict = {}
    jtypes:      dict = {}

    for j in jobs:
        c = j.get("Criticality", "Low")
        crit_counts[c] = crit_counts.get(c, 0) + 1
        a = j.get("AppName", "Unknown") or "Unknown"
        apps[a] = apps.get(a, 0) + 1
        t = j.get("Platform", "Unknown") or "Unknown"
        jtypes[t] = jtypes.get(t, 0) + 1

    top_apps = [a for a, _ in sorted(apps.items(), key=lambda x: -x[1])[:5]]
    stats = {
        "total_jobs":     len(jobs),
        "critical_count": crit_counts.get("Critical", 0),
        "high_count":     crit_counts.get("High",     0),
        "medium_count":   crit_counts.get("Medium",   0),
        "low_count":      crit_counts.get("Low",      0),
        "top_apps":       top_apps,
        "job_types":      jtypes,
    }

    assessments = entry.get("bulk_assessments", [])
    result      = engine.generate_executive_summary(assessments, stats)
    result      = _sanitize(result)

    entry["executive_summary"] = result
    return {"session_id": session_id, "ai_powered": is_available(), "summary": result}


# ════════════════════════════════════════════════════════════════
# REPORT DOWNLOAD — Excel
# ════════════════════════════════════════════════════════════════

@router.get("/report/{session_id}")
def download_excel_report(session_id: str):
    entry = _get_session(session_id)

    bulk    = entry.get("bulk_assessments",    [])
    src     = list(entry.get("source_analyses", {}).values())
    mod     = entry.get("modernizations_all",  []) or list(entry.get("modernizations", {}).values())
    risk    = entry.get("risk_assessments_all", []) or list(entry.get("risk_assessments", {}).values())
    summary = entry.get("executive_summary",   {})
    meta    = {
        "filename":   entry.get("filename", "unknown"),
        "total_jobs": len(entry.get("jobs", [])),
    }

    excel_bytes = generate_excel_report(
        bulk_assessments   = bulk,
        source_analyses    = src,
        modernization_data = mod,
        risk_data          = risk,
        executive_summary  = summary,
        session_meta       = meta,
    )

    filename = f"batch_assessment_{session_id[:8]}.xlsx"
    return StreamingResponse(
        io.BytesIO(excel_bytes),
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename={filename}"},
    )


# ════════════════════════════════════════════════════════════════
# REPORT — JSON dump of all session AI data
# ════════════════════════════════════════════════════════════════

@router.get("/report-json/{session_id}")
def report_json(session_id: str):
    entry = _get_session(session_id)
    return _sanitize({
        "session_id":         session_id,
        "filename":           entry.get("filename", ""),
        "bulk_assessments":   entry.get("bulk_assessments",    []),
        "source_analyses":    entry.get("source_analyses",     {}),
        "bottlenecks":        entry.get("bottlenecks",         {}),
        "risk_assessments":   entry.get("risk_assessments",    {}),
        "risk_all":           entry.get("risk_assessments_all",[]),
        "modernizations":     entry.get("modernizations",      {}),
        "modernizations_all": entry.get("modernizations_all",  []),
        "conversions":        entry.get("conversions",         {}),
        "executive_summary":  entry.get("executive_summary",   {}),
    })
