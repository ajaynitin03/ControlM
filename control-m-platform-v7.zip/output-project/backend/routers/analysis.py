from __future__ import annotations
import networkx as nx
from fastapi import APIRouter, HTTPException
from models.schemas import ImpactRequest
from services.file_processor import get_session, get_session_entry
from services.graph_service import (
    build_graph, find_critical_path, get_impact_analysis,
    compute_fan_metrics, detect_cycles,
)
from services.criticality_engine import compute_bottleneck_ranking, compute_runtime_impact

router = APIRouter()


def _get_df_and_graph(session_id: str):
    try:
        df = get_session(session_id)
    except KeyError:
        raise HTTPException(404, f"Session '{session_id}' not found")
    G = build_graph(df)
    return df, G


@router.post("/impact")
def impact_analysis(request: ImpactRequest):
    df, G = _get_df_and_graph(request.session_id)
    affected = get_impact_analysis(G, request.job_id)
    job_map  = dict(zip(df["JobId"], df["JobName"]))
    return {
        "failed_job":       request.job_id,
        "failed_job_name":  job_map.get(request.job_id, request.job_id),
        "affected_jobs":    [{"job_id": j, "job_name": job_map.get(j, j)} for j in affected],
        "affected_count":   len(affected),
    }


@router.get("/critical-path/{session_id}")
def get_critical_path(session_id: str):
    df, G = _get_df_and_graph(session_id)
    path  = find_critical_path(G)
    job_map  = dict(zip(df["JobId"], df["JobName"]))
    crit_map = {}
    score_map = {}
    reason_map = {}
    factors_map = {}
    if "Criticality" in df.columns:
        crit_map = dict(zip(df["JobId"], df["Criticality"]))
    if "CriticalityScore" in df.columns:
        score_map = dict(zip(df["JobId"], df["CriticalityScore"]))
    if "CriticalityReason" in df.columns:
        reason_map = dict(zip(df["JobId"], df["CriticalityReason"]))
    if "CriticalityFactors" in df.columns:
        factors_map = dict(zip(df["JobId"], df["CriticalityFactors"]))

    return {
        "critical_path": [
            {
                "job_id":              j,
                "job_name":            job_map.get(j, j),
                "criticality":         crit_map.get(j, "Low"),
                "criticality_score":   score_map.get(j, 0),
                "criticality_reason":  reason_map.get(j, ""),
                "criticality_factors": factors_map.get(j, []),
            }
            for j in path
        ],
        "path_length": len(path),
    }


@router.get("/fan-metrics/{session_id}")
def get_fan_metrics(session_id: str):
    df, G = _get_df_and_graph(session_id)
    fan   = compute_fan_metrics(G)
    job_map   = dict(zip(df["JobId"], df["JobName"]))
    crit_map  = dict(zip(df["JobId"], df.get("Criticality", pd.Series()))) if "Criticality" in df.columns else {}
    score_map = dict(zip(df["JobId"], df["CriticalityScore"])) if "CriticalityScore" in df.columns else {}
    factors_map = dict(zip(df["JobId"], df["CriticalityFactors"])) if "CriticalityFactors" in df.columns else {}

    metrics = [
        {
            "job_id":              jid,
            "job_name":            job_map.get(jid, jid),
            "criticality":         crit_map.get(jid, "Low"),
            "criticality_score":   score_map.get(jid, 0),
            "criticality_factors": factors_map.get(jid, []),
            "fan_in":              vals["fan_in"],
            "fan_out":             vals["fan_out"],
            "total_connections":   vals["fan_in"] + vals["fan_out"],
        }
        for jid, vals in fan.items()
    ]
    metrics.sort(key=lambda x: -x["total_connections"])
    return {"metrics": metrics, "count": len(metrics)}


@router.get("/cycles/{session_id}")
def get_cycles(session_id: str):
    df, G    = _get_df_and_graph(session_id)
    has_c, cycles = detect_cycles(G)
    job_map  = dict(zip(df["JobId"], df["JobName"]))
    enriched = [
        [{"job_id": j, "job_name": job_map.get(j, j)} for j in cycle]
        for cycle in cycles
    ]
    return {"has_cycles": has_c, "cycle_count": len(cycles), "cycles": enriched}


@router.get("/summary/{session_id}")
def get_summary(session_id: str):
    df, G     = _get_df_and_graph(session_id)
    has_c, cycles = detect_cycles(G)
    cp        = find_critical_path(G)

    crit_counts = {}
    if "Criticality" in df.columns:
        crit_counts = df["Criticality"].value_counts().to_dict()

    return {
        "total_jobs":          len(df),
        "total_edges":         G.number_of_edges(),
        "critical_criticality": crit_counts.get("Critical", 0),
        "high_criticality":    crit_counts.get("High", 0),
        "medium_criticality":  crit_counts.get("Medium", 0),
        "low_criticality":     crit_counts.get("Low", 0),
        "has_cycles":          has_c,
        "cycle_count":         len(cycles),
        "critical_path_length": len(cp),
        "root_jobs":           sum(1 for n in G.nodes() if G.in_degree(n) == 0),
        "leaf_jobs":           sum(1 for n in G.nodes() if G.out_degree(n) == 0),
        "isolated_jobs":       sum(1 for n in G.nodes() if G.degree(n) == 0),
    }


@router.get("/bottlenecks/{session_id}")
def get_bottlenecks(session_id: str):
    df, G = _get_df_and_graph(session_id)
    bots  = compute_bottleneck_ranking(G, df)
    return {"bottlenecks": bots, "count": len(bots)}


@router.get("/runtime-impact/{session_id}")
def get_runtime_impact(session_id: str):
    df, G  = _get_df_and_graph(session_id)
    impact = compute_runtime_impact(G, df)
    return {"runtime_impact": impact, "count": len(impact)}


@router.get("/criticality-distribution/{session_id}")
def get_criticality_distribution(session_id: str):
    df, G = _get_df_and_graph(session_id)
    cp    = find_critical_path(G)
    cp_set = set(cp)

    rows = []
    for _, row in df.iterrows():
        rows.append({
            "job_id":              row["JobId"],
            "job_name":            row.get("JobName", row["JobId"]),
            "criticality":         row.get("Criticality", "Low"),
            "criticality_score":   int(row.get("CriticalityScore", 0)),
            "criticality_reason":  row.get("CriticalityReason", ""),
            "criticality_factors": row.get("CriticalityFactors", []),
            "is_critical_path":    row["JobId"] in cp_set,
            "fan_out":             G.out_degree(row["JobId"]) if row["JobId"] in G else 0,
        })

    dist = {}
    for r in rows:
        k = r["criticality"]
        dist[k] = dist.get(k, 0) + 1

    return {
        "distribution": dist,
        "jobs":         sorted(rows, key=lambda x: -x["criticality_score"]),
    }


# ── needed for fan-metrics ────────────────────────────────────────
import pandas as pd
