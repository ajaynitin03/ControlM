from __future__ import annotations
from typing import List, Optional
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from services.file_processor import get_session, SESSION_STORE, merge_sessions
from services.graph_service import (
    build_graph, detect_cycles, find_critical_path,
    get_subgraph_for_jobs, compute_fan_metrics, graph_to_cytoscape,
)

router = APIRouter()


class GraphRequest(BaseModel):
    session_id:  str
    job_ids:     List[str] = []
    depth:       int = 3


class MultiGraphRequest(BaseModel):
    session_ids: List[str]
    job_ids:     List[str] = []


@router.post("/build")
def build_dependency_graph(request: GraphRequest):
    df = _get_df(request.session_id)
    full_graph = build_graph(df)
    has_cycles, cycle_details = detect_cycles(full_graph)

    if request.job_ids:
        subgraph = get_subgraph_for_jobs(full_graph, request.job_ids, request.depth)
    else:
        subgraph = full_graph

    cp  = find_critical_path(subgraph)
    fan = compute_fan_metrics(subgraph)
    nodes, edges = graph_to_cytoscape(subgraph, cp, fan, request.job_ids, df)

    return {
        "nodes": nodes, "edges": edges,
        "has_cycles": has_cycles, "cycle_details": cycle_details,
        "critical_path": cp,
        "node_count": len(nodes), "edge_count": len(edges),
        "session_id": request.session_id,
    }


@router.get("/full/{session_id}")
def get_full_graph(session_id: str):
    df = _get_df(session_id)
    G  = build_graph(df)
    has_cycles, cycle_details = detect_cycles(G)
    cp  = find_critical_path(G)
    fan = compute_fan_metrics(G)
    nodes, edges = graph_to_cytoscape(G, cp, fan, [], df)

    return {
        "nodes": nodes, "edges": edges,
        "has_cycles": has_cycles, "cycle_details": cycle_details,
        "critical_path": cp,
        "node_count": len(nodes), "edge_count": len(edges),
        "session_id": session_id,
    }


@router.post("/multi")
def build_multi_graph(request: MultiGraphRequest):
    """Merge graphs from multiple sessions into one cytoscape graph."""
    import pandas as pd
    dfs = []
    for sid in request.session_ids:
        if sid not in SESSION_STORE:
            raise HTTPException(404, f"Session '{sid}' not found")
        dfs.append(SESSION_STORE[sid]["df"])

    if not dfs:
        raise HTTPException(400, "No valid sessions provided")

    merged = pd.concat(dfs, ignore_index=True).drop_duplicates(subset=["JobId"])
    G      = build_graph(merged)
    has_cycles, cycle_details = detect_cycles(G)

    if request.job_ids:
        subgraph = get_subgraph_for_jobs(G, request.job_ids, depth=5)
    else:
        subgraph = G

    cp  = find_critical_path(subgraph)
    fan = compute_fan_metrics(subgraph)
    nodes, edges = graph_to_cytoscape(subgraph, cp, fan, request.job_ids, merged)

    return {
        "nodes": nodes, "edges": edges,
        "has_cycles": has_cycles, "cycle_details": cycle_details,
        "critical_path": cp,
        "node_count": len(nodes), "edge_count": len(edges),
        "session_count": len(request.session_ids),
    }


def _get_df(session_id: str):
    try:
        from services.file_processor import get_session
        return get_session(session_id)
    except KeyError:
        raise HTTPException(404, f"Session '{session_id}' not found")
