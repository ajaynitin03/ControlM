from pydantic import BaseModel
from typing import List, Optional


class ImpactRequest(BaseModel):
    session_id: str
    job_id: str


class GraphRequest(BaseModel):
    session_id: str
    job_ids: List[str] = []
    depth: int = 3


class MultiGraphRequest(BaseModel):
    session_ids: List[str]
    job_ids: List[str] = []


class MergeRequest(BaseModel):
    controlm_session_id: str
    exechistory_session_id: Optional[str] = None


class SourceCodeRequest(BaseModel):
    job_id: str
    source_code: str


class BottleneckRequest(BaseModel):
    job_id: str
    source_code: str


class RiskRequest(BaseModel):
    job_id: str
    source_code: Optional[str] = ""
    fan_in: int = 0
    fan_out: int = 0


class ModernizationRequest(BaseModel):
    job_id: str
    source_code: Optional[str] = ""


class ConversionRequest(BaseModel):
    job_id: str
    source_code: str
    target_technology: str
