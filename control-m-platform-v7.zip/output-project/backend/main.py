import logging
from dotenv import load_dotenv

# Load GEMINI_API_KEY (and any other secrets) from backend/.env before anything else
load_dotenv()

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)

app = FastAPI(
    title="Control-M Batch Assessment Platform",
    description="Phase-1: Dependency analysis | Phase-2: AI-powered modernization assessment",
    version="2.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Phase-1 routers
from routers.upload   import router as upload_router
from routers.graph    import router as graph_router
from routers.analysis import router as analysis_router

app.include_router(upload_router,   prefix="/api/upload",   tags=["Upload"])
app.include_router(graph_router,    prefix="/api/graph",    tags=["Graph"])
app.include_router(analysis_router, prefix="/api/analysis", tags=["Analysis"])

# Phase-2 AI router
from routers.ai_assessment import router as ai_router
app.include_router(ai_router)


@app.get("/api/health")
def health():
    from ai.gemini_client import is_available
    from ai.rag_knowledge import _DOCS, _INDEX
    return {
        "status":           "ok",
        "version":          "2.0.0",
        "phase1":           True,
        "phase2":           True,
        "gemini_available": is_available(),
        "rag_docs":         len(_DOCS),
        "faiss_ready":      _INDEX is not None,
    }
