import { useEffect, useState, useCallback } from 'react'
import {
  Target, ArrowDownUp, RefreshCcw, AlertTriangle,
  Loader2, ChevronRight, Download, BarChart2,
  TrendingUp, Activity, CheckCircle2, XCircle
} from 'lucide-react'
import toast from 'react-hot-toast'
import { getCriticalPath, getFanMetrics, getCycles } from '../../services/api'
import { useApp } from '../../hooks/useAppState'

/* ── Badge helpers ───────────────────────────────────────────────── */
function CritBadge({ val }) {
  const styles = {
    HIGH:   { background: '#fef2f2', color: '#dc2626', border: '1px solid #fecaca' },
    MEDIUM: { background: '#fffbeb', color: '#d97706', border: '1px solid #fde68a' },
    LOW:    { background: '#f0fdf4', color: '#16a34a', border: '1px solid #bbf7d0' },
  }
  const s = styles[val] || styles.LOW
  return (
    <span style={{ ...s, padding: '2px 7px', borderRadius: 5, fontSize: 10, fontWeight: 700 }}>
      {val || 'LOW'}
    </span>
  )
}

/* ── Single-file analysis ────────────────────────────────────────── */
function FileAnalysis({ fileEntry, index }) {
  const [data, setData] = useState({ criticalPath: null, fanMetrics: null, cycles: null })
  const [loading, setLoading] = useState({ cp: false, fan: false, cyc: false })
  const [activeSection, setActiveSection] = useState('overview')
  const hue   = (index * 53 + 210) % 360
  const color = `hsl(${hue}, 65%, 45%)`

  const load = useCallback(async () => {
    const sid = fileEntry.sessionId
    setLoading({ cp: true, fan: true, cyc: true })
    const [cpRes, fanRes, cycRes] = await Promise.allSettled([
      getCriticalPath(sid),
      getFanMetrics(sid),
      getCycles(sid),
    ])
    setData({
      criticalPath: cpRes.status === 'fulfilled' ? cpRes.value.data : null,
      fanMetrics:   fanRes.status === 'fulfilled' ? fanRes.value.data : null,
      cycles:       cycRes.status === 'fulfilled' ? cycRes.value.data : null,
    })
    setLoading({ cp: false, fan: false, cyc: false })
  }, [fileEntry.sessionId])

  useEffect(() => { load() }, [load])

  const ud = fileEntry.uploadData
  const sm = fileEntry.summary
  const highCount = sm?.high_criticality ?? 0
  const medCount  = sm?.medium_criticality ?? 0
  const lowCount  = sm?.low_criticality ?? 0
  const total     = ud?.row_count ?? 0

  const SECTIONS = [
    { id: 'overview',  label: 'Overview',      icon: BarChart2   },
    { id: 'critical',  label: 'Critical Path', icon: Target      },
    { id: 'fan',       label: 'Fan Metrics',   icon: ArrowDownUp },
    { id: 'cycles',    label: 'Cycles',        icon: RefreshCcw  },
  ]

  return (
    <div style={{ background: '#ffffff', border: '1px solid #e4e8f0', borderRadius: 16, overflow: 'hidden', boxShadow: '0 2px 8px rgba(0,0,0,0.05)' }}>
      {/* File header */}
      <div style={{ background: '#f8f9fc', borderBottom: '1px solid #e4e8f0', padding: '14px 20px', display: 'flex', alignItems: 'center', gap: 12 }}>
        <div style={{
          width: 32, height: 32, borderRadius: 8, background: color,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: '#fff', fontSize: 12, fontWeight: 700, flexShrink: 0,
        }}>{index + 1}</div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 14, fontWeight: 700, color: '#111827', fontFamily: 'monospace' }}>
            {fileEntry.fileName}
          </div>
          <div style={{ fontSize: 11, color: '#9ca3af', marginTop: 1 }}>
            {total} jobs · {ud?.columns?.length ?? '?'} columns
          </div>
        </div>
        {/* Quick stats chips */}
        <div style={{ display: 'flex', gap: 6 }}>
          {[
            { label: 'HIGH',   value: highCount, bg: '#fef2f2', color: '#dc2626', border: '#fecaca' },
            { label: 'MED',    value: medCount,  bg: '#fffbeb', color: '#d97706', border: '#fde68a' },
            { label: 'LOW',    value: lowCount,  bg: '#f0fdf4', color: '#16a34a', border: '#bbf7d0' },
          ].map(s => (
            <div key={s.label} style={{
              padding: '3px 10px', background: s.bg, border: `1px solid ${s.border}`,
              borderRadius: 99, display: 'flex', alignItems: 'center', gap: 4,
            }}>
              <span style={{ fontSize: 12, fontWeight: 700, color: s.color, fontFamily: 'monospace' }}>{s.value}</span>
              <span style={{ fontSize: 10, color: s.color, fontWeight: 600 }}>{s.label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Sub-nav + content */}
      <div style={{ display: 'flex', minHeight: 0 }}>
        {/* Section tabs */}
        <div style={{ width: 160, flexShrink: 0, borderRight: '1px solid #e4e8f0', padding: '12px 8px' }}>
          {SECTIONS.map(({ id, label, icon: Icon }) => (
            <button key={id} onClick={() => setActiveSection(id)} style={{
              width: '100%', display: 'flex', alignItems: 'center', gap: 8,
              padding: '8px 10px', borderRadius: 7, border: 'none', textAlign: 'left',
              cursor: 'pointer', marginBottom: 2, transition: 'background 0.1s',
              background: activeSection === id ? '#eff4ff' : 'transparent',
              color: activeSection === id ? '#1d4ed8' : '#6b7280',
              fontWeight: activeSection === id ? 600 : 400,
              fontSize: 12,
            }}
              onMouseEnter={e => { if (activeSection !== id) e.currentTarget.style.background = '#f8f9fc' }}
              onMouseLeave={e => { if (activeSection !== id) e.currentTarget.style.background = 'transparent' }}
            >
              <Icon size={13} />
              {label}
            </button>
          ))}
        </div>

        {/* Content */}
        <div style={{ flex: 1, padding: 20, overflowY: 'auto', maxHeight: 480 }}>

          {/* ── Overview ── */}
          {activeSection === 'overview' && (
            <OverviewSection ud={ud} sm={sm} total={total} highCount={highCount} medCount={medCount} lowCount={lowCount} fanMetrics={data.fanMetrics} criticalPath={data.criticalPath} cycles={data.cycles} loadingFan={loading.fan} />
          )}

          {/* ── Critical Path ── */}
          {activeSection === 'critical' && (
            <CriticalPathSection data={data.criticalPath} loading={loading.cp} />
          )}

          {/* ── Fan Metrics ── */}
          {activeSection === 'fan' && (
            <FanMetricsSection data={data.fanMetrics} loading={loading.fan} />
          )}

          {/* ── Cycles ── */}
          {activeSection === 'cycles' && (
            <CyclesSection data={data.cycles} loading={loading.cyc} />
          )}
        </div>
      </div>
    </div>
  )
}

/* ── Section content components ──────────────────────────────────── */

function OverviewSection({ ud, sm, total, highCount, medCount, lowCount, fanMetrics, criticalPath, cycles }) {
  const highPct = total ? Math.round((highCount / total) * 100) : 0
  const topFanOut = fanMetrics?.metrics?.slice(0, 3) || []
  const cpLength  = criticalPath?.path_length ?? 0

  return (
    <div>
      <SectionTitle icon={BarChart2} title="High-Level Job Analysis" />
      <p style={{ fontSize: 12, color: '#6b7280', marginBottom: 20, lineHeight: 1.6 }}>
        Summary of all jobs in this schedule — criticality distribution, dependency structure, and key bottlenecks.
      </p>

      {/* Stat grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10, marginBottom: 20 }}>
        {[
          { label: 'Total Jobs',     value: total,     color: '#2563eb', bg: '#eff4ff', border: '#bfdbfe' },
          { label: 'HIGH Priority',  value: highCount, color: '#dc2626', bg: '#fef2f2', border: '#fecaca',
            sub: `${highPct}% of total` },
          { label: 'MED Priority',   value: medCount,  color: '#d97706', bg: '#fffbeb', border: '#fde68a' },
          { label: 'LOW Priority',   value: lowCount,  color: '#16a34a', bg: '#f0fdf4', border: '#bbf7d0' },
          { label: 'Critical Path',  value: cpLength,  color: '#b45309', bg: '#fffbeb', border: '#fde68a',
            sub: cpLength > 0 ? 'jobs in longest chain' : '' },
          { label: 'Cycle Status',   value: cycles?.has_cycles ? '⚠ Found' : '✓ Clean',
            color: cycles?.has_cycles ? '#dc2626' : '#16a34a',
            bg: cycles?.has_cycles ? '#fef2f2' : '#f0fdf4',
            border: cycles?.has_cycles ? '#fecaca' : '#bbf7d0' },
        ].map(s => (
          <div key={s.label} style={{
            padding: '12px 14px', borderRadius: 10, background: s.bg, border: `1px solid ${s.border}`,
          }}>
            <div style={{ fontSize: 20, fontWeight: 700, color: s.color, fontFamily: 'monospace' }}>{s.value}</div>
            <div style={{ fontSize: 11, color: '#6b7280', marginTop: 2 }}>{s.label}</div>
            {s.sub && <div style={{ fontSize: 10, color: s.color, marginTop: 2 }}>{s.sub}</div>}
          </div>
        ))}
      </div>

      {/* Criticality bar */}
      {total > 0 && (
        <div style={{ marginBottom: 20 }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: '#9ca3af', letterSpacing: '0.07em', textTransform: 'uppercase', marginBottom: 8 }}>
            Criticality Distribution
          </div>
          <div style={{ height: 10, borderRadius: 99, overflow: 'hidden', background: '#f1f3f7', display: 'flex' }}>
            <div style={{ width: `${(highCount/total)*100}%`, background: '#ef4444', transition: 'width 0.5s' }} />
            <div style={{ width: `${(medCount/total)*100}%`,  background: '#f97316', transition: 'width 0.5s' }} />
            <div style={{ width: `${(lowCount/total)*100}%`,  background: '#22c55e', transition: 'width 0.5s' }} />
          </div>
          <div style={{ display: 'flex', gap: 14, marginTop: 6 }}>
            {[['#ef4444','HIGH',highCount],['#f97316','MED',medCount],['#22c55e','LOW',lowCount]].map(([c,l,v]) => (
              <div key={l} style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
                <div style={{ width: 8, height: 8, borderRadius: 2, background: c }} />
                <span style={{ fontSize: 11, color: '#6b7280' }}>{l}: <strong style={{ color: '#374151' }}>{v}</strong></span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Top bottlenecks */}
      {topFanOut.length > 0 && (
        <div>
          <div style={{ fontSize: 11, fontWeight: 700, color: '#9ca3af', letterSpacing: '0.07em', textTransform: 'uppercase', marginBottom: 10 }}>
            Top Bottleneck Jobs (by fan-out)
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            {topFanOut.map((m, i) => (
              <div key={m.job_id} style={{
                display: 'flex', alignItems: 'center', gap: 10, padding: '8px 12px',
                background: '#f8f9fc', borderRadius: 8, border: '1px solid #e4e8f0',
              }}>
                <span style={{ fontSize: 11, fontWeight: 700, color: '#9ca3af', width: 16 }}>#{i+1}</span>
                <CritBadge val={m.criticality} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 12, fontWeight: 600, color: '#374151', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {m.job_name}
                  </div>
                  <div style={{ fontSize: 11, color: '#9ca3af', fontFamily: 'monospace' }}>{m.job_id}</div>
                </div>
                <div style={{ display: 'flex', gap: 12, flexShrink: 0 }}>
                  <div style={{ textAlign: 'center' }}>
                    <div style={{ fontSize: 14, fontWeight: 700, color: '#2563eb', fontFamily: 'monospace' }}>{m.fan_out}</div>
                    <div style={{ fontSize: 10, color: '#9ca3af' }}>fan-out</div>
                  </div>
                  <div style={{ textAlign: 'center' }}>
                    <div style={{ fontSize: 14, fontWeight: 700, color: '#7c3aed', fontFamily: 'monospace' }}>{m.fan_in}</div>
                    <div style={{ fontSize: 10, color: '#9ca3af' }}>fan-in</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

function CriticalPathSection({ data, loading }) {
  if (loading) return <LoadingState label="Calculating critical path…" />
  if (!data) return <NoData />
  return (
    <div>
      <SectionTitle icon={Target} title="Critical Path Analysis" />
      <p style={{ fontSize: 12, color: '#6b7280', marginBottom: 16, lineHeight: 1.6 }}>
        The longest dependency chain in the schedule. Any delay in this path delays the entire schedule.
      </p>
      <div style={{
        display: 'flex', alignItems: 'center', gap: 8, padding: '10px 14px',
        background: '#fffbeb', border: '1px solid #fde68a', borderRadius: 8, marginBottom: 16,
      }}>
        <Target size={14} color="#b45309" />
        <span style={{ fontSize: 12, fontWeight: 600, color: '#b45309' }}>
          {data.path_length} jobs form the critical path
        </span>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
        {data.critical_path?.map((job, i) => (
          <div key={job.job_id} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <div style={{
              width: 22, height: 22, borderRadius: 99, background: '#fffbeb', border: '1px solid #fde68a',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 10, fontWeight: 700, color: '#b45309', flexShrink: 0,
            }}>{i+1}</div>
            <div style={{ flex: 1, display: 'flex', alignItems: 'center', gap: 8, padding: '8px 12px', background: '#ffffff', border: '1px solid #e4e8f0', borderRadius: 8 }}>
              <CritBadge val={job.criticality} />
              <div style={{ minWidth: 0 }}>
                <div style={{ fontSize: 12, fontWeight: 600, color: '#374151', fontFamily: 'monospace' }}>{job.job_id}</div>
                <div style={{ fontSize: 11, color: '#9ca3af' }}>{job.job_name}</div>
              </div>
            </div>
            {i < data.critical_path.length - 1 && <ChevronRight size={13} color="#d1d5db" style={{ flexShrink: 0 }} />}
          </div>
        ))}
      </div>
    </div>
  )
}

function FanMetricsSection({ data, loading }) {
  if (loading) return <LoadingState label="Loading fan metrics…" />
  if (!data) return <NoData />
  const maxConn = data.metrics?.[0]?.total_connections || 1
  return (
    <div>
      <SectionTitle icon={ArrowDownUp} title="Fan-in / Fan-out Metrics" />
      <p style={{ fontSize: 12, color: '#6b7280', marginBottom: 16, lineHeight: 1.6 }}>
        High fan-out jobs are bottlenecks — their failure cascades downstream. High fan-in jobs depend on many predecessors.
      </p>
      <div style={{ overflowX: 'auto', borderRadius: 10, border: '1px solid #e4e8f0' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
          <thead style={{ background: '#f8f9fc', borderBottom: '1px solid #e4e8f0' }}>
            <tr>
              {['Job ID', 'Job Name', 'Priority', 'Fan-in', 'Fan-out', 'Connections'].map(h => (
                <th key={h} style={{ padding: '9px 12px', textAlign: 'left', fontSize: 10, fontWeight: 700, color: '#9ca3af', letterSpacing: '0.06em', textTransform: 'uppercase', whiteSpace: 'nowrap' }}>
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {data.metrics?.map((m, i) => (
              <tr key={m.job_id} style={{ borderBottom: '1px solid #f1f3f7', background: i % 2 === 0 ? '#ffffff' : '#fafbfc' }}>
                <td style={{ padding: '8px 12px', fontFamily: 'monospace', fontSize: 11, color: '#374151' }}>{m.job_id}</td>
                <td style={{ padding: '8px 12px', color: '#6b7280', maxWidth: 160, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{m.job_name}</td>
                <td style={{ padding: '8px 12px' }}><CritBadge val={m.criticality} /></td>
                <td style={{ padding: '8px 12px', fontFamily: 'monospace', fontWeight: 700, color: '#7c3aed' }}>{m.fan_in}</td>
                <td style={{ padding: '8px 12px', fontFamily: 'monospace', fontWeight: 700, color: '#2563eb' }}>{m.fan_out}</td>
                <td style={{ padding: '8px 12px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <span style={{ fontFamily: 'monospace', fontWeight: 700, color: '#374151', minWidth: 20 }}>{m.total_connections}</span>
                    <div style={{ flex: 1, height: 5, background: '#f1f3f7', borderRadius: 99, maxWidth: 80 }}>
                      <div style={{ height: '100%', borderRadius: 99, background: '#2563eb', width: `${(m.total_connections / maxConn) * 100}%`, transition: 'width 0.4s' }} />
                    </div>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

function CyclesSection({ data, loading }) {
  if (loading) return <LoadingState label="Scanning for cycles…" />
  if (!data) return <NoData />
  return (
    <div>
      <SectionTitle icon={RefreshCcw} title="Cycle Detection" />
      <p style={{ fontSize: 12, color: '#6b7280', marginBottom: 16, lineHeight: 1.6 }}>
        Dependency loops prevent correct job execution ordering and must be resolved before scheduling.
      </p>
      {data.has_cycles ? (
        <>
          <div style={{
            display: 'flex', alignItems: 'center', gap: 8, padding: '10px 14px',
            background: '#fef2f2', border: '1px solid #fecaca', borderRadius: 8, marginBottom: 14,
          }}>
            <AlertTriangle size={14} color="#dc2626" />
            <span style={{ fontSize: 12, fontWeight: 600, color: '#dc2626' }}>
              {data.cycle_count} cycle{data.cycle_count > 1 ? 's' : ''} found — invalid circular dependencies
            </span>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {data.cycles?.map((cycle, i) => (
              <div key={i} style={{ background: '#fef2f2', border: '1px solid #fecaca', borderRadius: 10, padding: 12 }}>
                <div style={{ fontSize: 11, fontWeight: 700, color: '#dc2626', marginBottom: 8 }}>Cycle {i+1}</div>
                <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: 5 }}>
                  {cycle.map((job, j) => (
                    <span key={j} style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                      <span style={{ padding: '3px 8px', background: '#fee2e2', border: '1px solid #fca5a5', borderRadius: 5, fontSize: 11, fontFamily: 'monospace', color: '#991b1b' }}>
                        {job.job_id}
                      </span>
                      {j < cycle.length - 1 && <ChevronRight size={11} color="#fca5a5" />}
                    </span>
                  ))}
                  <span style={{ fontSize: 11, color: '#fca5a5' }}>↻</span>
                </div>
              </div>
            ))}
          </div>
        </>
      ) : (
        <div style={{
          display: 'flex', alignItems: 'center', gap: 10, padding: '14px 16px',
          background: '#f0fdf4', border: '1px solid #bbf7d0', borderRadius: 10,
        }}>
          <CheckCircle2 size={18} color="#16a34a" />
          <div>
            <div style={{ fontSize: 13, fontWeight: 600, color: '#16a34a' }}>No cycles detected</div>
            <div style={{ fontSize: 11, color: '#4ade80', marginTop: 1 }}>This schedule forms a valid directed acyclic graph (DAG)</div>
          </div>
        </div>
      )}
    </div>
  )
}

/* ── Shared mini components ──────────────────────────────────────── */
function SectionTitle({ icon: Icon, title }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
      <Icon size={15} color="#2563eb" />
      <span style={{ fontSize: 14, fontWeight: 700, color: '#111827' }}>{title}</span>
    </div>
  )
}
function LoadingState({ label }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '24px 0', color: '#9ca3af' }}>
      <Loader2 size={16} style={{ animation: 'spin 1s linear infinite' }} /> {label}
    </div>
  )
}
function NoData() {
  return <div style={{ fontSize: 13, color: '#9ca3af', padding: '24px 0' }}>No data available</div>
}

/* ── Export analysis helper ──────────────────────────────────────── */
function exportAnalysisAsText(uploadedFiles, analysisDataMap) {
  let txt = `Control-M Analysis Report\nGenerated: ${new Date().toLocaleString()}\n${'='.repeat(60)}\n\n`
  uploadedFiles.forEach((f, i) => {
    const d = analysisDataMap[f.sessionId] || {}
    txt += `FILE ${i+1}: ${f.fileName}\n${'-'.repeat(40)}\n`
    txt += `Total Jobs: ${f.uploadData?.row_count ?? 'N/A'}\n`
    txt += `HIGH: ${f.summary?.high_criticality ?? 0}  MED: ${f.summary?.medium_criticality ?? 0}  LOW: ${f.summary?.low_criticality ?? 0}\n`
    if (d.criticalPath) {
      txt += `\nCritical Path (${d.criticalPath.path_length} jobs):\n`
      d.criticalPath.critical_path?.forEach((j, idx) => { txt += `  ${idx+1}. ${j.job_id} - ${j.job_name} [${j.criticality}]\n` })
    }
    if (d.cycles) {
      txt += `\nCycle Detection: ${d.cycles.has_cycles ? `${d.cycles.cycle_count} cycle(s) found` : 'No cycles - valid DAG'}\n`
    }
    txt += '\n'
  })
  return txt
}

/* ── Main AnalysisPanel ──────────────────────────────────────────── */
export default function AnalysisPanel() {
  const { state } = useApp()
  const { uploadedFiles, selectedFileIds } = state
  const [analysisDataMap] = useState({})

  const filesToAnalyze = uploadedFiles.filter(f => selectedFileIds.includes(f.sessionId))

  const handleExportAnalysis = useCallback(() => {
    const txt = exportAnalysisAsText(filesToAnalyze, analysisDataMap)
    const blob = new Blob([txt], { type: 'text/plain' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `control-m-analysis-${Date.now()}.txt`
    a.click()
    URL.revokeObjectURL(url)
    toast.success('Analysis exported')
  }, [filesToAnalyze, analysisDataMap])

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden', background: '#f8f9fc' }}>
      {/* Top bar */}
      <div style={{
        background: '#ffffff', borderBottom: '1px solid #e4e8f0',
        padding: '12px 24px', display: 'flex', alignItems: 'center', gap: 12, flexShrink: 0,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, flex: 1 }}>
          <BarChart2 size={17} color="#2563eb" />
          <div>
            <span style={{ fontSize: 14, fontWeight: 700, color: '#111827' }}>Analysis</span>
            <span style={{ fontSize: 12, color: '#9ca3af', marginLeft: 10 }}>
              {filesToAnalyze.length} file{filesToAnalyze.length !== 1 ? 's' : ''} · critical path, fan metrics, cycle detection
            </span>
          </div>
        </div>
        {/* Export analysis only */}
        <button
          onClick={handleExportAnalysis}
          disabled={filesToAnalyze.length === 0}
          style={{
            display: 'flex', alignItems: 'center', gap: 6, padding: '7px 14px',
            borderRadius: 8, border: '1px solid #e4e8f0', background: '#ffffff',
            fontSize: 12, fontWeight: 600, color: '#374151', cursor: 'pointer',
            opacity: filesToAnalyze.length === 0 ? 0.4 : 1,
          }}
        >
          <Download size={13} /> Export Analysis
        </button>
      </div>

      {/* Content */}
      <div style={{ flex: 1, overflowY: 'auto', padding: 24 }}>
        {filesToAnalyze.length === 0 ? (
          <div style={{
            display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
            padding: '80px 24px', background: '#ffffff', borderRadius: 16, border: '1px solid #e4e8f0',
          }}>
            <BarChart2 size={36} color="#d1d5db" style={{ marginBottom: 12 }} />
            <div style={{ fontSize: 15, fontWeight: 600, color: '#374151', marginBottom: 4 }}>No files selected</div>
            <div style={{ fontSize: 13, color: '#9ca3af' }}>Select files on the Upload page to see their analysis.</div>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 28 }}>
            {filesToAnalyze.map((f, i) => (
              <FileAnalysis key={f.sessionId} fileEntry={f} index={i} />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
