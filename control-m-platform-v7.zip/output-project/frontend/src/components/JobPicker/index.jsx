import { useEffect, useState, useMemo, useCallback } from 'react'
import {
  Search, CheckSquare, Square, Layers,
  ChevronDown, ChevronRight, LayoutGrid, List,
  X, Loader2, ArrowRight, RefreshCw
} from 'lucide-react'
import toast from 'react-hot-toast'
import { getJobs, buildGraph, getFullGraph } from '../../services/api'
import { useApp } from '../../hooks/useAppState'

const CRIT_CONFIG = {
  HIGH:   { dot: 'bg-red-500',    badge: 'badge-high',   ring: 'ring-red-500/40',    card: 'border-red-800/40 bg-red-950/10'   },
  MEDIUM: { dot: 'bg-orange-500', badge: 'badge-medium', ring: 'ring-orange-500/40', card: 'border-orange-800/40 bg-orange-950/10' },
  LOW:    { dot: 'bg-green-500',  badge: 'badge-low',    ring: 'ring-green-500/30',  card: 'border-green-800/40 bg-green-950/10'  },
}

const APP_COLORS = [
  'from-blue-600/20 to-blue-900/10 border-blue-700/30',
  'from-purple-600/20 to-purple-900/10 border-purple-700/30',
  'from-teal-600/20 to-teal-900/10 border-teal-700/30',
  'from-amber-600/20 to-amber-900/10 border-amber-700/30',
  'from-pink-600/20 to-pink-900/10 border-pink-700/30',
  'from-indigo-600/20 to-indigo-900/10 border-indigo-700/30',
  'from-emerald-600/20 to-emerald-900/10 border-emerald-700/30',
]

const APP_HEADER_COLORS = [
  'text-blue-300',
  'text-purple-300',
  'text-teal-300',
  'text-amber-300',
  'text-pink-300',
  'text-indigo-300',
  'text-emerald-300',
]

export default function JobPicker() {
  const { state, dispatch } = useApp()
  const { sessionId, selectedJobs } = state

  const [allJobs, setAllJobs]       = useState([])
  const [loading, setLoading]       = useState(true)
  const [building, setBuilding]     = useState(false)
  const [searchText, setSearchText] = useState('')
  const [filterCrit, setFilterCrit] = useState('ALL')  // ALL | HIGH | MEDIUM | LOW
  const [viewMode, setViewMode]     = useState('group') // group | grid | list
  const [collapsed, setCollapsed]   = useState({})      // appName -> bool

  // ── Load jobs on mount ──────────────────────────────────────────
  useEffect(() => {
    if (!sessionId) return
    setLoading(true)
    getJobs(sessionId)
      .then(res => setAllJobs(res.data.jobs))
      .catch(() => toast.error('Failed to load jobs'))
      .finally(() => setLoading(false))
  }, [sessionId])

  // ── Derived state ───────────────────────────────────────────────
  const filtered = useMemo(() => {
    return allJobs.filter(j => {
      const matchSearch =
        !searchText ||
        j.JobId.toLowerCase().includes(searchText.toLowerCase()) ||
        j.JobName.toLowerCase().includes(searchText.toLowerCase()) ||
        (j.AppName || '').toLowerCase().includes(searchText.toLowerCase())
      const matchCrit = filterCrit === 'ALL' || j.Criticality === filterCrit
      return matchSearch && matchCrit
    })
  }, [allJobs, searchText, filterCrit])

  // Group by AppName
  const grouped = useMemo(() => {
    const map = {}
    filtered.forEach(j => {
      const app = j.AppName || 'UNGROUPED'
      if (!map[app]) map[app] = []
      map[app].push(j)
    })
    return map
  }, [filtered])

  const appNames   = useMemo(() => Object.keys(grouped).sort(), [grouped])
  const selectedSet = useMemo(() => new Set(selectedJobs), [selectedJobs])
  const isSelected  = useCallback(id => selectedSet.has(id), [selectedSet])

  const toggleJob = useCallback(jobId => {
    dispatch({
      type: 'SET_SELECTED_JOBS',
      payload: selectedSet.has(jobId)
        ? selectedJobs.filter(id => id !== jobId)
        : [...selectedJobs, jobId],
    })
  }, [selectedSet, selectedJobs, dispatch])

  const toggleGroup = useCallback(appName => {
    const ids = (grouped[appName] || []).map(j => j.JobId)
    const allSelected = ids.every(id => selectedSet.has(id))
    dispatch({
      type: 'SET_SELECTED_JOBS',
      payload: allSelected
        ? selectedJobs.filter(id => !ids.includes(id))
        : [...new Set([...selectedJobs, ...ids])],
    })
  }, [grouped, selectedSet, selectedJobs, dispatch])

  const selectAll  = () => dispatch({ type: 'SET_SELECTED_JOBS', payload: allJobs.map(j => j.JobId) })
  const clearAll   = () => dispatch({ type: 'SET_SELECTED_JOBS', payload: [] })
  const toggleCollapse = app => setCollapsed(c => ({ ...c, [app]: !c[app] }))

  // ── Generate graph ──────────────────────────────────────────────
  const generateGraph = useCallback(async () => {
    if (!sessionId) return
    setBuilding(true)
    try {
      const res = selectedJobs.length > 0
        ? await buildGraph(sessionId, selectedJobs, 10)
        : await getFullGraph(sessionId)

      dispatch({ type: 'SET_GRAPH_DATA', payload: res.data })
      dispatch({ type: 'SET_ACTIVE_TAB', payload: 'graph' })

      if (res.data.has_cycles) {
        toast.error(`⚠ ${res.data.cycle_details.length} cycle(s) detected`, { duration: 5000 })
      } else {
        const label = selectedJobs.length === 0
          ? `All ${res.data.node_count} jobs`
          : `${selectedJobs.length} selected job(s) + dependencies`
        toast.success(`Graph ready — ${label}, ${res.data.edge_count} edges`)
      }
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Graph build failed')
    } finally {
      setBuilding(false)
    }
  }, [sessionId, selectedJobs, dispatch])

  // ── Counts ──────────────────────────────────────────────────────
  const critCounts = useMemo(() => {
    const c = { HIGH: 0, MEDIUM: 0, LOW: 0 }
    allJobs.forEach(j => { if (c[j.Criticality] !== undefined) c[j.Criticality]++ })
    return c
  }, [allJobs])

  // ── Loading / empty states ──────────────────────────────────────
  if (loading) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <Loader2 size={28} className="text-brand-400 animate-spin" />
          <p className="text-sm text-slate-400">Loading job catalogue…</p>
        </div>
      </div>
    )
  }

  if (!allJobs.length) {
    return (
      <div className="flex-1 flex items-center justify-center text-slate-500">
        <p>No jobs found. Upload a file first.</p>
      </div>
    )
  }

  return (
    <div className="flex-1 flex flex-col min-h-0 overflow-hidden">

      {/* ══ Top header bar ══════════════════════════════════════════ */}
      <div className="flex-shrink-0 border-b border-surface-border bg-surface-card px-5 py-3">
        <div className="flex items-center justify-between gap-4">
          <div>
            <h2 className="text-sm font-bold text-slate-100">Job Selection</h2>
            <p className="text-xs text-slate-500 mt-0.5">
              {allJobs.length} jobs across {appNames.length} applications
            </p>
          </div>

          {/* Summary pills */}
          <div className="flex items-center gap-2 flex-shrink-0">
            {['HIGH','MEDIUM','LOW'].map(c => (
              <button
                key={c}
                onClick={() => setFilterCrit(f => f === c ? 'ALL' : c)}
                className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-xs font-semibold
                  transition-all cursor-pointer select-none
                  ${filterCrit === c
                    ? (c==='HIGH'?'bg-red-900/50 border-red-600 text-red-300':c==='MEDIUM'?'bg-orange-900/50 border-orange-600 text-orange-300':'bg-green-900/50 border-green-600 text-green-300')
                    : 'border-surface-border bg-surface-hover text-slate-400 hover:text-slate-200'}`}
              >
                <span className={`w-1.5 h-1.5 rounded-full ${CRIT_CONFIG[c].dot}`}/>
                {critCounts[c]} {c}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* ══ Toolbar ═════════════════════════════════════════════════ */}
      <div className="flex-shrink-0 px-5 py-2.5 border-b border-surface-border flex items-center gap-3 flex-wrap">
        {/* Search */}
        <div className="relative flex-1 min-w-48 max-w-sm">
          <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none"/>
          <input
            type="text"
            value={searchText}
            onChange={e => setSearchText(e.target.value)}
            placeholder="Search Job ID, name or application…"
            className="w-full pl-8 pr-8 py-1.5 bg-surface-hover border border-surface-border rounded-lg
                       text-xs text-slate-200 placeholder-slate-600 focus:outline-none
                       focus:border-brand-500 transition-colors"
          />
          {searchText && (
            <button onClick={() => setSearchText('')}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300">
              <X size={12}/>
            </button>
          )}
        </div>

        {/* Select all / clear */}
        <div className="flex items-center gap-1.5">
          <button onClick={selectAll}  className="btn-ghost text-xs flex items-center gap-1.5 py-1.5">
            <CheckSquare size={13}/>All
          </button>
          <button onClick={clearAll}   className="btn-ghost text-xs flex items-center gap-1.5 py-1.5">
            <Square size={13}/>None
          </button>
        </div>

        {/* View mode */}
        <div className="flex items-center gap-px bg-surface-hover border border-surface-border rounded-lg p-0.5 ml-auto">
          {[
            { id:'group', icon: Layers,      title:'Grouped by app' },
            { id:'grid',  icon: LayoutGrid,  title:'Card grid'      },
            { id:'list',  icon: List,        title:'List view'      },
          ].map(({ id, icon: Icon, title }) => (
            <button
              key={id}
              onClick={() => setViewMode(id)}
              title={title}
              className={`p-1.5 rounded transition-colors ${viewMode===id ? 'bg-brand-600/30 text-brand-400' : 'text-slate-500 hover:text-slate-300'}`}
            >
              <Icon size={14}/>
            </button>
          ))}
        </div>
      </div>

      {/* ══ Job cards ═══════════════════════════════════════════════ */}
      <div className="flex-1 overflow-y-auto px-5 py-4">
        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-40 text-slate-500 gap-2">
            <Search size={22} className="text-slate-600"/>
            <p className="text-sm">No jobs match your filter</p>
            <button onClick={() => { setSearchText(''); setFilterCrit('ALL') }}
              className="text-xs text-brand-400 hover:underline flex items-center gap-1">
              <RefreshCw size={11}/>Clear filters
            </button>
          </div>
        ) : viewMode === 'group' ? (
          /* ── Grouped view ── */
          <div className="space-y-5">
            {appNames.map((app, appIdx) => {
              const jobs = grouped[app]
              const color = APP_COLORS[appIdx % APP_COLORS.length]
              const headerColor = APP_HEADER_COLORS[appIdx % APP_HEADER_COLORS.length]
              const allSel = jobs.every(j => selectedSet.has(j.JobId))
              const someSel = jobs.some(j => selectedSet.has(j.JobId))
              const isCollapsed = collapsed[app]

              return (
                <div key={app}
                  className={`rounded-xl border bg-gradient-to-br ${color} overflow-hidden`}>
                  {/* Group header */}
                  <div className="flex items-center gap-3 px-4 py-2.5">
                    <button
                      onClick={() => toggleCollapse(app)}
                      className="text-slate-400 hover:text-slate-200 transition-colors"
                    >
                      {isCollapsed
                        ? <ChevronRight size={15}/>
                        : <ChevronDown  size={15}/>}
                    </button>

                    <span className={`text-sm font-bold tracking-wide ${headerColor}`}>{app}</span>
                    <span className="text-xs text-slate-500">{jobs.length} job{jobs.length!==1?'s':''}</span>

                    <div className="ml-auto flex items-center gap-2">
                      {/* criticality mini-badges */}
                      {['HIGH','MEDIUM','LOW'].map(c => {
                        const cnt = jobs.filter(j=>j.Criticality===c).length
                        if (!cnt) return null
                        return (
                          <span key={c} className={`${CRIT_CONFIG[c].badge} text-xs`}>
                            {cnt} {c}
                          </span>
                        )
                      })}

                      {/* Select all in group */}
                      <button
                        onClick={() => toggleGroup(app)}
                        className={`flex items-center gap-1.5 px-2 py-1 rounded text-xs font-medium
                          transition-colors border
                          ${allSel
                            ? 'bg-brand-600/30 border-brand-600/50 text-brand-300'
                            : someSel
                              ? 'bg-brand-600/15 border-brand-600/30 text-brand-400'
                              : 'border-surface-border text-slate-500 hover:text-slate-300 hover:border-slate-500'}`}
                      >
                        {allSel ? <CheckSquare size={11}/> : someSel ? <CheckSquare size={11}/> : <Square size={11}/>}
                        {allSel ? 'Deselect all' : 'Select all'}
                      </button>
                    </div>
                  </div>

                  {/* Job cards in group */}
                  {!isCollapsed && (
                    <div className="px-4 pb-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-2.5">
                      {jobs.map(job => (
                        <JobCard
                          key={job.JobId}
                          job={job}
                          selected={isSelected(job.JobId)}
                          onToggle={toggleJob}
                        />
                      ))}
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        ) : viewMode === 'grid' ? (
          /* ── Flat grid view ── */
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
            {filtered.map(job => (
              <JobCard key={job.JobId} job={job} selected={isSelected(job.JobId)} onToggle={toggleJob}/>
            ))}
          </div>
        ) : (
          /* ── List view ── */
          <div className="rounded-xl border border-surface-border overflow-hidden">
            <table className="w-full text-xs">
              <thead className="sticky top-0 bg-surface-card border-b border-surface-border z-10">
                <tr>
                  {['','Job ID','Job Name','Application','Criticality'].map(h => (
                    <th key={h} className="px-3 py-2.5 text-left text-slate-400 font-semibold uppercase tracking-wider">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map(job => {
                  const sel = isSelected(job.JobId)
                  const cfg = CRIT_CONFIG[job.Criticality] || CRIT_CONFIG.LOW
                  return (
                    <tr
                      key={job.JobId}
                      onClick={() => toggleJob(job.JobId)}
                      className={`border-b border-surface-border/50 cursor-pointer transition-colors
                        ${sel ? 'bg-brand-600/10' : 'hover:bg-surface-hover'}`}
                    >
                      <td className="px-3 py-2.5">
                        <div className={`w-4 h-4 rounded border-2 flex items-center justify-center transition-all
                          ${sel ? 'bg-brand-600 border-brand-500' : 'border-slate-600'}`}>
                          {sel && <span className="text-white text-xs leading-none font-bold">✓</span>}
                        </div>
                      </td>
                      <td className="px-3 py-2.5 font-mono text-slate-200">{job.JobId}</td>
                      <td className="px-3 py-2.5 text-slate-300 font-medium">{job.JobName}</td>
                      <td className="px-3 py-2.5 text-slate-400">{job.AppName}</td>
                      <td className="px-3 py-2.5">
                        <span className={cfg.badge}>{job.Criticality}</span>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* ══ Bottom action bar ═══════════════════════════════════════ */}
      <div className="flex-shrink-0 border-t border-surface-border bg-surface-card px-5 py-3">
        <div className="flex items-center gap-4">
          {/* Selection summary */}
          <div className="flex items-center gap-3 flex-1 min-w-0">
            {selectedJobs.length === 0 ? (
              <div className="flex items-center gap-2 text-slate-500">
                <Square size={15}/>
                <span className="text-sm">No jobs selected — will generate diagram for all jobs</span>
              </div>
            ) : (
              <div className="flex items-center gap-2.5">
                <div className="flex items-center gap-1.5 px-2.5 py-1 bg-brand-600/20 border border-brand-600/30 rounded-lg">
                  <CheckSquare size={13} className="text-brand-400"/>
                  <span className="text-sm font-semibold text-brand-300">
                    {selectedJobs.length} job{selectedJobs.length!==1?'s':''} selected
                  </span>
                </div>
                <span className="text-xs text-slate-500 hidden sm:block">
                  Graph will include all upstream &amp; downstream dependencies automatically
                </span>
                <button onClick={clearAll} className="text-xs text-slate-500 hover:text-red-400 transition-colors flex items-center gap-1">
                  <X size={11}/> Clear
                </button>
              </div>
            )}
          </div>

          {/* Selected job chips (up to 5) */}
          {selectedJobs.length > 0 && selectedJobs.length <= 6 && (
            <div className="hidden md:flex items-center gap-1.5 flex-wrap max-w-xs">
              {selectedJobs.slice(0, 5).map(id => (
                <span key={id}
                  className="flex items-center gap-1 px-2 py-0.5 bg-surface-hover border border-surface-border rounded text-xs font-mono text-slate-300">
                  {id}
                  <button onClick={e => { e.stopPropagation(); toggleJob(id) }} className="text-slate-600 hover:text-red-400">
                    <X size={9}/>
                  </button>
                </span>
              ))}
              {selectedJobs.length > 5 && (
                <span className="text-xs text-slate-500">+{selectedJobs.length - 5} more</span>
              )}
            </div>
          )}

          {/* Generate button */}
          <button
            onClick={generateGraph}
            disabled={building}
            className="flex items-center gap-2.5 px-5 py-2.5 bg-brand-600 hover:bg-brand-500
                       text-white font-semibold text-sm rounded-xl transition-all
                       disabled:opacity-50 disabled:cursor-not-allowed
                       shadow-lg shadow-brand-600/20 hover:shadow-brand-500/30
                       flex-shrink-0 border border-brand-500/50"
          >
            {building ? (
              <><Loader2 size={15} className="animate-spin"/>Building…</>
            ) : (
              <><DiagramIcon size={15}/>
                {selectedJobs.length === 0 ? 'Generate Full Diagram' : `Generate Flow Diagram`}
                <ArrowRight size={14}/>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  )
}

/* ── Individual job card ─────────────────────────────────────────── */
function JobCard({ job, selected, onToggle }) {
  const cfg = CRIT_CONFIG[job.Criticality] || CRIT_CONFIG.LOW

  return (
    <div
      onClick={() => onToggle(job.JobId)}
      className={`relative group cursor-pointer rounded-xl border p-3 transition-all duration-150
        ${selected
          ? `ring-2 ${cfg.ring} border-transparent bg-surface-card`
          : `border-surface-border bg-surface-card hover:border-slate-600 hover:bg-surface-hover`
        }`}
    >
      {/* Checkbox */}
      <div className={`absolute top-2.5 right-2.5 w-4 h-4 rounded border-2 flex items-center justify-center
        transition-all flex-shrink-0
        ${selected ? 'bg-brand-600 border-brand-500' : 'border-slate-600 group-hover:border-slate-400'}`}>
        {selected && <span className="text-white text-xs leading-none font-bold">✓</span>}
      </div>

      {/* Criticality dot + badge */}
      <div className="flex items-center gap-2 mb-2 pr-6">
        <span className={`w-2 h-2 rounded-full flex-shrink-0 ${cfg.dot}`}/>
        <span className={cfg.badge}>{job.Criticality}</span>
      </div>

      {/* Job name (big) */}
      <p className="text-xs font-bold text-slate-100 leading-tight mb-0.5 pr-5 break-words">
        {job.JobName}
      </p>

      {/* Job ID */}
      <p className="text-xs font-mono text-slate-500 leading-tight truncate">
        ({job.JobId})
      </p>

      {/* App name */}
      {job.AppName && (
        <p className="text-xs text-slate-500 mt-1.5 truncate">{job.AppName}</p>
      )}

      {/* Selected overlay indicator */}
      {selected && (
        <div className="absolute inset-0 rounded-xl ring-2 ring-brand-500/50 pointer-events-none"/>
      )}
    </div>
  )
}

function DiagramIcon({ size = 15, className = '' }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"
      className={className}>
      <rect x="16" y="16" width="6" height="6" rx="1"/>
      <rect x="2"  y="16" width="6" height="6" rx="1"/>
      <rect x="9"  y="2"  width="6" height="6" rx="1"/>
      <path d="M5 16v-3a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v3"/>
      <path d="M12 12V8"/>
    </svg>
  )
}
