import { useState, useCallback, useRef } from 'react'
import { useApp } from '../../hooks/useAppState'
import { getFullGraph } from '../../services/api'
import { exportPNG, exportSVG } from '../../utils/cytoscapeBuilder'
import toast from 'react-hot-toast'
import FileCard from './FileCard'
import { LayoutList, GitBranch, Download, Loader2, PackageCheck } from 'lucide-react'

export default function MultiFileView() {
  const { state, dispatch } = useApp()
  const { uploadedFiles, selectedFileIds } = state
  const [generatingAll, setGeneratingAll] = useState(false)

  // ── useRef map — never goes stale inside callbacks ──────────────
  // Shape: { [sessionId]: React.MutableRefObject<CytoscapeCore | null> }
  const cyRefsMap = useRef({})

  const selectedFiles = uploadedFiles.filter(f => selectedFileIds.includes(f.sessionId))

  // FileCard calls this once with its own stable ref object
  const registerCyRef = useCallback((sessionId, refObject) => {
    cyRefsMap.current[sessionId] = refObject
  }, [])

  // Unregister when a file card unmounts
  const unregisterCyRef = useCallback((sessionId) => {
    delete cyRefsMap.current[sessionId]
  }, [])

  // ── Generate all diagrams sequentially ─────────────────────────
  const handleGenerateAll = useCallback(async () => {
    if (selectedFiles.length === 0) { toast.error('No files selected'); return }
    setGeneratingAll(true)
    let count = 0
    for (const f of selectedFiles) {
      if (f.graphData) { count++; continue }
      const toastId = `graph-${f.sessionId}`
      try {
        toast.loading(`Building graph for "${f.fileName}"…`, { id: toastId })
        const res = await getFullGraph(f.sessionId)
        dispatch({ type: 'UPDATE_FILE_GRAPH', sessionId: f.sessionId, payload: res.data })
        toast.success(`"${f.fileName}" graphed`, { id: toastId })
        count++
      } catch {
        toast.error(`Failed: ${f.fileName}`, { id: toastId })
      }
    }
    setGeneratingAll(false)
    if (count > 0) toast.success(`${count} diagram${count !== 1 ? 's' : ''} ready`)
  }, [selectedFiles, dispatch])

  // ── Export all graphs — reads from ref map (always current) ─────
  const handleExportAll = useCallback(async () => {
    const entries = Object.entries(cyRefsMap.current)
    if (entries.length === 0) {
      toast.error('Generate diagrams first — no active graphs found')
      return
    }

    const toastId = 'export-all'
    toast.loading('Exporting graphs…', { id: toastId })
    let exported = 0

    for (const [sid, refObj] of entries) {
      const cy = refObj?.current
      if (!cy) continue

      const file = uploadedFiles.find(f => f.sessionId === sid)
      const base = (file?.fileName.replace(/\.[^.]+$/, '') || sid)

      // PNG export
      try {
        const blob = exportPNG(cy)
        triggerDownload(URL.createObjectURL(blob), `${base}-graph.png`)
        exported++
      } catch (e) {
        console.error('PNG export failed:', e)
      }

      // Small delay so browser doesn't block multiple downloads
      await sleep(200)

      // SVG export (async — builds from canvas PNG)
      try {
        const svgStr = await exportSVG(cy)
        if (svgStr) {
          const blob = new Blob([svgStr], { type: 'image/svg+xml;charset=utf-8' })
          triggerDownload(URL.createObjectURL(blob), `${base}-graph.svg`)
        }
      } catch (e) {
        console.error('SVG export failed:', e)
      }

      await sleep(200)
    }

    if (exported > 0) {
      toast.success(`Exported ${exported} graph${exported !== 1 ? 's' : ''} (PNG + SVG)`, { id: toastId })
    } else {
      toast.error('Nothing to export — open the Diagram tab in each card first', { id: toastId })
    }
  }, [uploadedFiles])

  const allGraphed = selectedFiles.length > 0 && selectedFiles.every(f => f.graphData)

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden', background: '#f8f9fc' }}>

      {/* Top bar */}
      <div style={{
        background: '#ffffff', borderBottom: '1px solid #e4e8f0',
        padding: '12px 24px', display: 'flex', alignItems: 'center', gap: 10, flexShrink: 0,
      }}>
        <LayoutList size={17} color="#2563eb" />
        <div style={{ flex: 1 }}>
          <span style={{ fontSize: 14, fontWeight: 700, color: '#111827' }}>Diagrams &amp; Data</span>
          <span style={{ fontSize: 12, color: '#9ca3af', marginLeft: 10 }}>
            {selectedFiles.length} of {uploadedFiles.length} files selected
          </span>
        </div>

        <div style={{ display: 'flex', gap: 8 }}>
          <button
            onClick={handleGenerateAll}
            disabled={generatingAll || selectedFiles.length === 0}
            style={{
              display: 'flex', alignItems: 'center', gap: 6,
              padding: '7px 14px', borderRadius: 8, cursor: 'pointer',
              border: `1px solid ${allGraphed ? '#bbf7d0' : '#bfdbfe'}`,
              background: allGraphed ? '#f0fdf4' : '#eff4ff',
              fontSize: 12, fontWeight: 600,
              color: allGraphed ? '#16a34a' : '#1d4ed8',
              opacity: (generatingAll || selectedFiles.length === 0) ? 0.45 : 1,
              transition: 'opacity 0.15s',
            }}
          >
            {generatingAll
              ? <><Loader2 size={13} style={{ animation: 'spin 1s linear infinite' }} /> Generating…</>
              : allGraphed
                ? <><PackageCheck size={13} /> All Graphed</>
                : <><GitBranch size={13} /> Generate All Diagrams</>}
          </button>

          <button
            onClick={handleExportAll}
            style={{
              display: 'flex', alignItems: 'center', gap: 6,
              padding: '7px 14px', borderRadius: 8, cursor: 'pointer',
              border: '1px solid #e4e8f0', background: '#ffffff',
              fontSize: 12, fontWeight: 600, color: '#374151',
            }}
          >
            <Download size={13} /> Export All Graphs
          </button>
        </div>
      </div>

      {/* Content */}
      <div style={{ flex: 1, overflowY: 'auto', padding: 24 }}>
        {uploadedFiles.length === 0 ? (
          <EmptyState label="No files uploaded" sub="Upload CSV, JSON, or XML files using the Upload page." />
        ) : selectedFiles.length === 0 ? (
          <EmptyState label="No files selected" sub="Select files on the Upload page to view them here." />
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 32 }}>
            {selectedFiles.map((fileEntry, idx) => (
              <FileCard
                key={fileEntry.sessionId}
                fileEntry={fileEntry}
                index={idx}
                onRegisterCyRef={registerCyRef}
                onUnregisterCyRef={unregisterCyRef}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

function EmptyState({ label, sub }) {
  return (
    <div style={{
      display: 'flex', flexDirection: 'column', alignItems: 'center',
      justifyContent: 'center', padding: '80px 24px',
      background: '#ffffff', borderRadius: 16, border: '1px solid #e4e8f0',
    }}>
      <LayoutList size={36} color="#d1d5db" style={{ marginBottom: 12 }} />
      <div style={{ fontSize: 15, fontWeight: 600, color: '#374151', marginBottom: 4 }}>{label}</div>
      <div style={{ fontSize: 13, color: '#9ca3af' }}>{sub}</div>
    </div>
  )
}

function triggerDownload(url, filename) {
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
  setTimeout(() => URL.revokeObjectURL(url), 3000)
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)) }
