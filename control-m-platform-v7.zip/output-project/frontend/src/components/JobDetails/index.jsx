import { X, Zap, Target } from 'lucide-react'
import { useApp } from '../../hooks/useAppState'
import { getImpactAnalysis } from '../../services/api'
import { highlightImpact, highlightCriticalPath, resetHighlight } from '../../utils/cytoscapeBuilder'
import toast from 'react-hot-toast'

const CRIT_STYLE = {
  HIGH:   'badge-high',
  MEDIUM: 'badge-medium',
  LOW:    'badge-low',
}

export default function JobDetails({ cyRef }) {
  const { state, dispatch } = useApp()
  const { selectedNode, sessionId, graphData } = state

  if (!selectedNode) return null

  const nd = selectedNode

  const runImpact = async () => {
    try {
      const res = await getImpactAnalysis(sessionId, nd.id)
      const affected = res.data.affected_jobs.map((j) => j.job_id)
      dispatch({ type: 'SET_IMPACT_DATA', payload: res.data })
      if (cyRef.current) {
        highlightImpact(cyRef.current, [nd.id, ...affected])
      }
      toast.success(`${res.data.affected_count} downstream jobs would be affected`)
    } catch {
      toast.error('Impact analysis failed')
    }
  }

  const runCriticalPath = () => {
    if (!graphData?.critical_path?.length) {
      toast.error('No critical path available')
      return
    }
    if (cyRef.current) {
      highlightCriticalPath(cyRef.current, graphData.critical_path)
    }
  }

  const fields = [
    { label: 'Job ID',       value: nd.id },
    { label: 'Job Name',     value: nd.label },
    { label: 'App Name',     value: nd.app_name },
    { label: 'Platform',     value: nd.platform },
    { label: 'Schedule',     value: nd.schedule },
    { label: 'Runtime',      value: nd.runtime },
    { label: 'Owner',        value: nd.owner },
    { label: 'Status',       value: nd.status },
    { label: 'Folder',       value: nd.folder },
    { label: 'Description',  value: nd.description },
  ].filter((f) => f.value)

  return (
    <div className="absolute right-4 top-4 w-72 card shadow-2xl z-20 overflow-hidden">
      {/* Header */}
      <div className={`px-4 py-3 border-b border-surface-border flex items-center justify-between ${
        nd.criticality === 'HIGH' ? 'bg-red-950/30' :
        nd.criticality === 'MEDIUM' ? 'bg-orange-950/30' : 'bg-green-950/30'
      }`}>
        <div className="flex items-center gap-2 min-w-0">
          <span className={CRIT_STYLE[nd.criticality] || 'badge-low'}>{nd.criticality || 'LOW'}</span>
          <span className="text-sm font-semibold text-slate-100 truncate">{nd.label}</span>
        </div>
        <button
          onClick={() => dispatch({ type: 'SET_SELECTED_NODE', payload: null })}
          className="text-slate-400 hover:text-slate-200 flex-shrink-0 ml-1"
        >
          <X size={15} />
        </button>
      </div>

      {/* Fan metrics */}
      <div className="grid grid-cols-2 divide-x divide-surface-border border-b border-surface-border">
        <div className="px-4 py-3 text-center">
          <p className="text-lg font-bold font-mono text-brand-400">{nd.fan_in ?? 0}</p>
          <p className="text-xs text-slate-500">Fan-in</p>
        </div>
        <div className="px-4 py-3 text-center">
          <p className="text-lg font-bold font-mono text-brand-400">{nd.fan_out ?? 0}</p>
          <p className="text-xs text-slate-500">Fan-out</p>
        </div>
      </div>

      {/* Fields */}
      <div className="px-4 py-3 space-y-2.5 max-h-60 overflow-y-auto">
        {fields.map(({ label, value }) => (
          <div key={label}>
            <p className="text-xs text-slate-500 font-medium">{label}</p>
            <p className="text-xs text-slate-200 font-mono break-all">{value}</p>
          </div>
        ))}
      </div>

      {/* Actions */}
      <div className="px-4 py-3 border-t border-surface-border flex gap-2">
        <button
          onClick={runImpact}
          className="btn-primary flex-1 flex items-center justify-center gap-1.5 text-xs py-1.5"
        >
          <Zap size={12} />
          Impact Analysis
        </button>
        <button
          onClick={runCriticalPath}
          className="btn-ghost flex items-center gap-1.5 text-xs px-2.5 py-1.5 border border-surface-border rounded-lg"
        >
          <Target size={12} />
          Crit. Path
        </button>
      </div>
    </div>
  )
}
