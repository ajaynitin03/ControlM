import { useCallback, useState } from 'react'
import {
  Upload, FileText, X, CheckCircle2, Loader2, AlertCircle,
  FileCode, FileSpreadsheet, Network, ArrowRight
} from 'lucide-react'
import toast from 'react-hot-toast'
import { uploadFile, getSummary } from '../../services/api'
import { useApp } from '../../hooks/useAppState'

const EXT_ICON = {
  csv:  <FileSpreadsheet size={16} color="#16a34a" />,
  json: <FileCode        size={16} color="#ea580c" />,
  xml:  <FileText        size={16} color="#7c3aed" />,
}

function FileRow({ f, onRemove, onSelect, selected }) {
  const ext = f.fileName.split('.').pop().toLowerCase()
  const icon = EXT_ICON[ext] || <FileText size={16} color="#6b7280" />

  return (
    <div
      onClick={() => onSelect(f.sessionId)}
      style={{
        display: 'flex', alignItems: 'center', gap: 12, padding: '12px 16px',
        background: selected ? '#eff4ff' : '#ffffff',
        border: selected ? '1px solid #bfdbfe' : '1px solid #e4e8f0',
        borderRadius: 10, cursor: 'pointer', transition: 'all 0.12s',
        boxShadow: selected ? '0 0 0 2px rgba(37,99,235,0.10)' : '0 1px 2px rgba(0,0,0,0.04)',
      }}
    >
      {/* Checkbox */}
      <div style={{
        width: 18, height: 18, borderRadius: 5, flexShrink: 0,
        border: selected ? '2px solid #2563eb' : '2px solid #d1d5db',
        background: selected ? '#2563eb' : '#ffffff',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        transition: 'all 0.12s',
      }}>
        {selected && <CheckCircle2 size={11} color="#fff" strokeWidth={3} />}
      </div>

      {/* File type icon */}
      <div style={{
        width: 34, height: 34, borderRadius: 8, flexShrink: 0,
        background: selected ? '#dbeafe' : '#f8f9fc',
        border: '1px solid #e4e8f0',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        {icon}
      </div>

      {/* Name + meta */}
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 13, fontWeight: 600, color: '#111827', marginBottom: 2, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
          {f.fileName}
        </div>
        <div style={{ fontSize: 11, color: '#9ca3af' }}>
          {f.uploadData?.row_count ?? '–'} jobs &nbsp;·&nbsp;
          {f.uploadData?.columns?.length ?? '–'} columns &nbsp;·&nbsp;
          <span style={{ textTransform: 'uppercase', fontWeight: 600 }}>{ext}</span>
        </div>
      </div>

      {/* Status */}
      <CheckCircle2 size={15} color="#16a34a" style={{ flexShrink: 0 }} />

      {/* Remove */}
      <button
        onClick={e => { e.stopPropagation(); onRemove(f.sessionId) }}
        style={{
          width: 26, height: 26, borderRadius: 6, flexShrink: 0,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          background: 'transparent', border: 'none', cursor: 'pointer',
          color: '#9ca3af', transition: 'all 0.12s',
        }}
        onMouseEnter={e => { e.currentTarget.style.background = '#fee2e2'; e.currentTarget.style.color = '#dc2626' }}
        onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = '#9ca3af' }}
        title="Remove file"
      >
        <X size={14} />
      </button>
    </div>
  )
}

export default function UploadPage() {
  const { state, dispatch } = useApp()
  const { uploadedFiles, selectedFileIds } = state
  const [dragging, setDragging] = useState(false)
  const [uploading, setUploading] = useState(null) // fileName being uploaded

  const handleFile = useCallback(async file => {
    const ext = '.' + file.name.split('.').pop().toLowerCase()
    if (!['.csv', '.json', '.xml'].includes(ext)) {
      toast.error('Only CSV, JSON, or XML files are supported')
      return
    }
    if (uploadedFiles.some(f => f.fileName === file.name)) {
      toast.error(`"${file.name}" is already loaded`)
      return
    }

    setUploading(file.name)
    try {
      const res = await uploadFile(file, () => {})
      const data = res.data
      const entry = {
        sessionId:  data.session_id,
        fileName:   file.name,
        uploadData: data,
        graphData:  null,
        summary:    null,
      }
      dispatch({ type: 'ADD_UPLOADED_FILE', payload: entry })
      dispatch({ type: 'SET_SESSION',       payload: data.session_id })
      dispatch({ type: 'SET_UPLOAD_DATA',   payload: data })
      dispatch({ type: 'SET_SELECTED_JOBS', payload: [] })
      // Auto-select
      dispatch({ type: 'TOGGLE_FILE_SELECTED', payload: data.session_id })

      try {
        const sr = await getSummary(data.session_id)
        dispatch({ type: 'ADD_UPLOADED_FILE', payload: { ...entry, summary: sr.data } })
        dispatch({ type: 'SET_SUMMARY', payload: sr.data })
        dispatch({ type: 'UPDATE_FILE_SUMMARY', sessionId: data.session_id, payload: sr.data })
      } catch {}

      toast.success(`"${file.name}" loaded — ${data.row_count} jobs`)
    } catch (err) {
      toast.error(err.response?.data?.detail || `Upload failed`)
    } finally {
      setUploading(null)
    }
  }, [uploadedFiles, dispatch])

  const onDrop = useCallback(e => {
    e.preventDefault(); setDragging(false)
    Array.from(e.dataTransfer.files).forEach(f => handleFile(f))
  }, [handleFile])

  const toggleSelect = sid => dispatch({ type: 'TOGGLE_FILE_SELECTED', payload: sid })
  const removeFile = sid => {
    dispatch({ type: 'REMOVE_UPLOADED_FILE', payload: sid })
    toast('File removed', { icon: '🗑' })
  }
  const selectAll = () => dispatch({ type: 'SET_SELECTED_FILE_IDS', payload: uploadedFiles.map(f => f.sessionId) })
  const clearAll  = () => dispatch({ type: 'SET_SELECTED_FILE_IDS', payload: [] })

  return (
    <div style={{ flex: 1, display: 'flex', height: '100%', overflow: 'hidden', background: '#f8f9fc' }}>
      {/* ── Left: upload + file list ─────────────────── */}
      <div style={{ flex: 1, overflowY: 'auto', padding: 32 }}>
        {/* Header */}
        <div style={{ marginBottom: 28 }}>
          <h1 style={{ fontSize: 22, fontWeight: 700, color: '#111827', margin: 0, letterSpacing: '-0.03em' }}>
            Upload Job Schedules
          </h1>
          <p style={{ fontSize: 13, color: '#6b7280', marginTop: 6 }}>
            Import CSV, JSON, or XML files to visualize dependency graphs and analyze job flows.
          </p>
        </div>

        {/* Drop zone */}
        <label
          onDragOver={e => { e.preventDefault(); setDragging(true) }}
          onDragLeave={() => setDragging(false)}
          onDrop={onDrop}
          style={{
            display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
            padding: '40px 24px', borderRadius: 16, cursor: 'pointer',
            border: dragging ? '2px dashed #2563eb' : '2px dashed #d1d5db',
            background: dragging ? '#eff4ff' : '#ffffff',
            marginBottom: 24, transition: 'all 0.15s',
            boxShadow: '0 1px 4px rgba(0,0,0,0.04)',
          }}
        >
          <input type="file" accept=".csv,.json,.xml" multiple className="hidden"
            onChange={e => { Array.from(e.target.files || []).forEach(f => handleFile(f)); e.target.value = '' }}
          />
          {uploading ? (
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10 }}>
              <Loader2 size={32} color="#2563eb" style={{ animation: 'spin 1s linear infinite' }} />
              <div style={{ fontSize: 13, color: '#374151', fontWeight: 500 }}>Uploading {uploading}…</div>
            </div>
          ) : (
            <>
              <div style={{
                width: 52, height: 52, borderRadius: 14,
                background: dragging ? '#dbeafe' : '#f1f4f9',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                marginBottom: 14, transition: 'all 0.15s',
              }}>
                <Upload size={24} color={dragging ? '#2563eb' : '#6b7280'} />
              </div>
              <div style={{ fontSize: 14, fontWeight: 600, color: '#374151', marginBottom: 4 }}>
                Drop files here, or <span style={{ color: '#2563eb' }}>browse</span>
              </div>
              <div style={{ fontSize: 12, color: '#9ca3af', marginBottom: 14 }}>
                Multiple files supported
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                {['.csv', '.json', '.xml'].map(ext => (
                  <span key={ext} style={{
                    padding: '3px 10px', background: '#f8f9fc', border: '1px solid #e4e8f0',
                    borderRadius: 6, fontSize: 11, fontFamily: 'monospace', color: '#6b7280', fontWeight: 600,
                  }}>{ext}</span>
                ))}
              </div>
            </>
          )}
        </label>

        {/* File list */}
        {uploadedFiles.length > 0 && (
          <div>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
              <div style={{ fontSize: 13, fontWeight: 600, color: '#374151' }}>
                {uploadedFiles.length} file{uploadedFiles.length !== 1 ? 's' : ''} uploaded
                <span style={{ fontWeight: 400, color: '#9ca3af', marginLeft: 6 }}>
                  · {selectedFileIds.length} selected
                </span>
              </div>
              <div style={{ display: 'flex', gap: 6 }}>
                <button
                  onClick={selectAll}
                  style={{
                    padding: '4px 12px', fontSize: 12, fontWeight: 600, borderRadius: 6,
                    border: '1px solid #e4e8f0', background: '#ffffff', color: '#374151',
                    cursor: 'pointer',
                  }}
                >Select all</button>
                <button
                  onClick={clearAll}
                  style={{
                    padding: '4px 12px', fontSize: 12, fontWeight: 600, borderRadius: 6,
                    border: '1px solid #e4e8f0', background: '#ffffff', color: '#374151',
                    cursor: 'pointer',
                  }}
                >Clear</button>
              </div>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {uploadedFiles.map(f => (
                <FileRow
                  key={f.sessionId}
                  f={f}
                  selected={selectedFileIds.includes(f.sessionId)}
                  onSelect={toggleSelect}
                  onRemove={removeFile}
                />
              ))}
            </div>

            {/* CTA */}
            {selectedFileIds.length > 0 && (
              <div style={{
                marginTop: 20, padding: '14px 18px', borderRadius: 12,
                background: '#eff4ff', border: '1px solid #bfdbfe',
                display: 'flex', alignItems: 'center', justifyContent: 'space-between',
              }}>
                <div>
                  <div style={{ fontSize: 13, fontWeight: 600, color: '#1d4ed8' }}>
                    {selectedFileIds.length} file{selectedFileIds.length !== 1 ? 's' : ''} ready to view
                  </div>
                  <div style={{ fontSize: 11, color: '#3b82f6', marginTop: 2 }}>
                    Go to Diagrams & Data to preview and generate dependency graphs
                  </div>
                </div>
                <button
                  onClick={() => dispatch({ type: 'SET_ACTIVE_TAB', payload: 'multiview' })}
                  style={{
                    display: 'flex', alignItems: 'center', gap: 6, padding: '8px 16px',
                    background: '#2563eb', color: '#ffffff', border: 'none', borderRadius: 8,
                    fontSize: 13, fontWeight: 600, cursor: 'pointer', flexShrink: 0,
                  }}
                >
                  View Diagrams <ArrowRight size={14} />
                </button>
              </div>
            )}
          </div>
        )}

        {/* Empty state */}
        {uploadedFiles.length === 0 && !uploading && (
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12, marginTop: 8 }}>
            {[
              { step: '01', title: 'Upload', desc: 'Drop one or more CSV, JSON or XML files' },
              { step: '02', title: 'Select', desc: 'Choose files and jobs to visualize' },
              { step: '03', title: 'Explore', desc: 'Interactive dependency diagrams & analysis' },
            ].map(({ step, title, desc }) => (
              <div key={step} style={{
                padding: 16, background: '#ffffff', border: '1px solid #e4e8f0',
                borderRadius: 12, boxShadow: '0 1px 3px rgba(0,0,0,0.04)',
              }}>
                <div style={{ fontSize: 11, fontWeight: 700, color: '#2563eb', letterSpacing: '0.08em', marginBottom: 6 }}>
                  {step}
                </div>
                <div style={{ fontSize: 13, fontWeight: 600, color: '#111827', marginBottom: 4 }}>{title}</div>
                <div style={{ fontSize: 12, color: '#6b7280' }}>{desc}</div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* ── Right: overview panel ─────────────────────── */}
      <div style={{
        width: 280, flexShrink: 0,
        background: '#ffffff', borderLeft: '1px solid #e4e8f0',
        overflowY: 'auto', padding: 24,
      }}>
        <OverviewPanel />
      </div>
    </div>
  )
}

/* ── Overview panel (right column) ──────────────────────────────── */
function OverviewPanel() {
  const { state } = useApp()
  const { uploadedFiles, selectedFileIds } = state

  const totalJobs = uploadedFiles.reduce((s, f) => s + (f.uploadData?.row_count ?? 0), 0)
  const totalHigh = uploadedFiles.reduce((s, f) => s + (f.summary?.high_criticality ?? 0), 0)
  const totalMed  = uploadedFiles.reduce((s, f) => s + (f.summary?.medium_criticality ?? 0), 0)
  const totalLow  = uploadedFiles.reduce((s, f) => s + (f.summary?.low_criticality ?? 0), 0)

  return (
    <div>
      <div style={{ fontSize: 11, fontWeight: 700, color: '#9ca3af', letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 16 }}>
        Overview
      </div>

      {uploadedFiles.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '32px 0' }}>
          <Network size={32} color="#d1d5db" style={{ margin: '0 auto 10px' }} />
          <div style={{ fontSize: 13, color: '#9ca3af' }}>Upload files to see summary</div>
        </div>
      ) : (
        <>
          {/* Summary stats */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 20 }}>
            {[
              { label: 'Total Jobs',  value: totalJobs,  color: '#2563eb', bg: '#eff4ff' },
              { label: 'Files',       value: uploadedFiles.length, color: '#7c3aed', bg: '#f5f3ff' },
              { label: 'HIGH',        value: totalHigh,  color: '#dc2626', bg: '#fef2f2' },
              { label: 'MEDIUM',      value: totalMed,   color: '#d97706', bg: '#fffbeb' },
              { label: 'LOW',         value: totalLow,   color: '#16a34a', bg: '#f0fdf4' },
              { label: 'Selected',    value: selectedFileIds.length, color: '#0891b2', bg: '#ecfeff' },
            ].map(s => (
              <div key={s.label} style={{
                padding: '10px 12px', borderRadius: 10, background: s.bg,
                border: `1px solid ${s.color}20`,
              }}>
                <div style={{ fontSize: 20, fontWeight: 700, color: s.color, fontFamily: 'monospace' }}>{s.value}</div>
                <div style={{ fontSize: 11, color: '#6b7280', marginTop: 1 }}>{s.label}</div>
              </div>
            ))}
          </div>

          {/* Per-file breakdown */}
          <div style={{ fontSize: 11, fontWeight: 700, color: '#9ca3af', letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 10 }}>
            Files
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {uploadedFiles.map((f, i) => {
              const ext = f.fileName.split('.').pop().toLowerCase()
              return (
                <div key={f.sessionId} style={{
                  padding: '10px 12px', borderRadius: 10,
                  background: selectedFileIds.includes(f.sessionId) ? '#eff4ff' : '#f8f9fc',
                  border: selectedFileIds.includes(f.sessionId) ? '1px solid #bfdbfe' : '1px solid #e4e8f0',
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
                    <div style={{
                      width: 20, height: 20, borderRadius: 5,
                      background: `hsl(${i * 60 + 200}, 65%, 50%)`,
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      color: '#fff', fontSize: 10, fontWeight: 700, flexShrink: 0,
                    }}>{i + 1}</div>
                    <span style={{ fontSize: 12, fontWeight: 600, color: '#374151', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      {f.fileName}
                    </span>
                  </div>
                  <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                    <span style={{ fontSize: 11, color: '#6b7280' }}>{f.uploadData?.row_count ?? '–'} jobs</span>
                    <span style={{ fontSize: 11, color: '#9ca3af', textTransform: 'uppercase' }}>{ext}</span>
                    {f.graphData && <span style={{ fontSize: 11, color: '#16a34a', fontWeight: 600 }}>✓ Graphed</span>}
                  </div>
                </div>
              )
            })}
          </div>

          {/* Feature list */}
          <div style={{ marginTop: 24, fontSize: 11, fontWeight: 700, color: '#9ca3af', letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 10 }}>
            Features
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
            {[
              'Dependency diagrams',
              'Critical path analysis',
              'Fan-in / Fan-out metrics',
              'Cycle detection',
              'LLM job conversion',
              'Export graphs & analysis',
            ].map(f => (
              <div key={f} style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
                <div style={{ width: 5, height: 5, borderRadius: '50%', background: '#2563eb', flexShrink: 0 }} />
                <span style={{ fontSize: 12, color: '#374151' }}>{f}</span>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  )
}
