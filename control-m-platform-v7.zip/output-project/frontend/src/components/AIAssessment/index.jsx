import { useState, useCallback, useEffect } from 'react'
import {
  Brain, Zap, ShieldAlert, TrendingUp, ArrowLeftRight,
  FileText, Download, Loader2, CheckCircle2, AlertTriangle,
  ChevronDown, ChevronUp, Sparkles, BarChart3, FileCode2,
  RefreshCcw, Info,
} from 'lucide-react'
import toast from 'react-hot-toast'
import { useApp } from '../../hooks/useAppState'
import { ai } from '../../services/api'

const CONVERSION_TARGETS = ['Python', 'SpringBatch', 'PySpark', 'Airflow', 'AirflowDAG', 'Java', 'Shell']

/* ─────────────────────────────────────────────────────────────────
   SHARED SMALL COMPONENTS
───────────────────────────────────────────────────────────────── */
function Badge({ label, level }) {
  const map = {
    Critical: { bg: '#ffd7d7', color: '#7f0000', border: '#ffa8a8' },
    High:     { bg: '#ffe4cc', color: '#7a3500', border: '#ffb380' },
    Medium:   { bg: '#fff3cd', color: '#7a5c00', border: '#ffd966' },
    Low:      { bg: '#d4f1e4', color: '#1a5c3a', border: '#6dcfa1' },
  }
  const s = map[level] || { bg: '#f1f5f9', color: '#475569', border: '#e2e8f0' }
  return (
    <span style={{
      padding: '2px 8px', borderRadius: 5, fontSize: 11, fontWeight: 700,
      background: s.bg, color: s.color, border: '1px solid ' + s.border,
      whiteSpace: 'nowrap',
    }}>
      {label || level}
    </span>
  )
}

function SectionCard({ title, icon: Icon, iconColor, children, defaultOpen }) {
  const [open, setOpen] = useState(defaultOpen !== false)
  const color = iconColor || '#2563eb'
  return (
    <div style={{
      background: '#fff', border: '1px solid #e4e8f0', borderRadius: 12,
      marginBottom: 14, overflow: 'hidden',
    }}>
      <button
        onClick={() => setOpen(function(o) { return !o })}
        style={{
          width: '100%', display: 'flex', alignItems: 'center', gap: 9,
          padding: '11px 15px', background: '#f8f9fc', border: 'none',
          borderBottom: open ? '1px solid #e4e8f0' : 'none',
          cursor: 'pointer', textAlign: 'left',
        }}
      >
        <Icon size={14} color={color} />
        <span style={{ fontSize: 13, fontWeight: 700, color: '#111827', flex: 1 }}>{title}</span>
        {open
          ? <ChevronUp size={13} color="#9ca3af" />
          : <ChevronDown size={13} color="#9ca3af" />
        }
      </button>
      {open && <div style={{ padding: 15 }}>{children}</div>}
    </div>
  )
}

function KV({ label, value, mono }) {
  return (
    <div style={{ marginBottom: 8 }}>
      <div style={{
        fontSize: 10, fontWeight: 700, color: '#9ca3af',
        textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 2,
      }}>
        {label}
      </div>
      <div style={{
        fontSize: 12, color: '#374151',
        fontFamily: mono ? 'monospace' : 'inherit',
        wordBreak: 'break-word',
      }}>
        {value || '—'}
      </div>
    </div>
  )
}

function RunBtn({ onClick, loading, children, disabled, variant }) {
  const v = variant || 'primary'
  let bg, color, border
  if (v === 'purple') {
    bg = loading || disabled ? '#c4b5fd' : '#7c3aed'
    color = '#fff'
    border = 'none'
  } else if (v === 'outline') {
    bg = '#fff'
    color = '#374151'
    border = '1px solid #e4e8f0'
  } else {
    bg = loading || disabled ? '#93c5fd' : '#2563eb'
    color = '#fff'
    border = 'none'
  }
  return (
    <button
      onClick={onClick}
      disabled={loading || disabled}
      style={{
        display: 'inline-flex', alignItems: 'center', gap: 6,
        padding: '7px 14px', borderRadius: 8, fontSize: 12, fontWeight: 600,
        cursor: loading || disabled ? 'not-allowed' : 'pointer',
        background: bg, color: color, border: border,
        transition: 'all 0.15s',
      }}
    >
      {loading && <Loader2 size={13} style={{ animation: 'spin 1s linear infinite' }} />}
      {children}
    </button>
  )
}

function EmptyPrompt({ message }) {
  return (
    <div style={{ padding: '36px 0', textAlign: 'center', color: '#9ca3af', fontSize: 13 }}>
      <Info size={22} color="#d1d5db" style={{ margin: '0 auto 8px', display: 'block' }} />
      {message}
    </div>
  )
}

function CodeBlock({ code }) {
  const copy = function() {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(code)
      toast.success('Copied!')
    }
  }
  const display = (code || '').replace(/\\n/g, '\n')
  return (
    <div style={{ position: 'relative', background: '#1a1d27', borderRadius: 8, overflow: 'hidden', border: '1px solid #2d3748' }}>
      <button
        onClick={copy}
        style={{
          position: 'absolute', top: 8, right: 8, padding: '3px 9px',
          background: 'rgba(255,255,255,0.1)', border: '1px solid rgba(255,255,255,0.15)',
          borderRadius: 5, fontSize: 11, color: '#94a3b8', cursor: 'pointer',
        }}
      >
        Copy
      </button>
      <pre style={{
        margin: 0, padding: '14px 16px', overflowX: 'auto', fontSize: 11,
        color: '#e2e8f0', fontFamily: 'monospace', lineHeight: 1.6,
        whiteSpace: 'pre-wrap', wordBreak: 'break-word', maxHeight: 400,
      }}>
        {display}
      </pre>
    </div>
  )
}

function StatusPill({ label, active, sub }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 5, padding: '3px 9px',
      borderRadius: 99, fontSize: 11, fontWeight: 600,
      background: active ? '#f0fdf4' : '#fef2f2',
      border: '1px solid ' + (active ? '#bbf7d0' : '#fecaca'),
      color: active ? '#16a34a' : '#dc2626',
    }}>
      <div style={{
        width: 6, height: 6, borderRadius: '50%',
        background: active ? '#16a34a' : '#dc2626',
      }} />
      {label}{sub ? ' (' + sub + ')' : ''}
    </div>
  )
}

/* ─────────────────────────────────────────────────────────────────
   FEATURE 1 — BULK ASSESSMENT
───────────────────────────────────────────────────────────────── */
function BulkAssessmentPanel({ sessionId }) {
  const [loading, setLoading] = useState(false)
  const [data, setData] = useState(null)
  const [search, setSearch] = useState('')
  const [filterComp, setFilterComp] = useState('ALL')

  async function run() {
    setLoading(true)
    try {
      const res = await ai.bulkAssess(sessionId)
      setData(res.data)
      const label = res.data.ai_powered ? '(AI-powered)' : '(heuristic)'
      toast.success(res.data.assessed + ' jobs assessed ' + label)
    } catch (e) {
      toast.error((e.response && e.response.data && e.response.data.detail) || 'Bulk assessment failed')
    } finally {
      setLoading(false)
    }
  }

  const rows = (data ? data.assessments : []).filter(function(a) {
    const q = search.toLowerCase()
    const matchSearch = !q ||
      (a.job_id && a.job_id.toLowerCase().includes(q)) ||
      (a.job_type && a.job_type.toLowerCase().includes(q))
    const matchComp = filterComp === 'ALL' || a.migration_complexity === filterComp
    return matchSearch && matchComp
  })

  const highCount = rows.filter(function(r) { return r.migration_complexity === 'High' }).length
  const medCount  = rows.filter(function(r) { return r.migration_complexity === 'Medium' }).length
  const lowCount  = rows.filter(function(r) { return r.migration_complexity === 'Low' }).length

  return (
    <div>
      <div style={{ display: 'flex', gap: 10, alignItems: 'center', marginBottom: 14, flexWrap: 'wrap' }}>
        <RunBtn onClick={run} loading={loading}>
          <Brain size={13} />
          {data ? 'Re-run Assessment' : 'Run Bulk Assessment'}
        </RunBtn>
        {data && (
          <>
            <input
              value={search}
              onChange={function(e) { setSearch(e.target.value) }}
              placeholder="Search job ID or type…"
              style={{
                padding: '6px 11px', borderRadius: 7, border: '1px solid #e4e8f0',
                fontSize: 12, color: '#374151', width: 200,
              }}
            />
            {['ALL', 'High', 'Medium', 'Low'].map(function(c) {
              return (
                <button
                  key={c}
                  onClick={function() { setFilterComp(c) }}
                  style={{
                    padding: '4px 10px', borderRadius: 6, fontSize: 11, fontWeight: 600,
                    cursor: 'pointer', border: '1px solid #e4e8f0',
                    background: filterComp === c ? '#eff4ff' : '#fff',
                    color: filterComp === c ? '#2563eb' : '#9ca3af',
                  }}
                >
                  {c}
                </button>
              )
            })}
          </>
        )}
      </div>

      {!data && !loading && (
        <EmptyPrompt message="Click 'Run Bulk Assessment' to analyze all jobs using AI + RAG" />
      )}
      {loading && (
        <EmptyPrompt message="Running AI assessment across all jobs — this may take a moment…" />
      )}

      {data && rows.length > 0 && (
        <>
          <div style={{ display: 'flex', gap: 8, marginBottom: 12, flexWrap: 'wrap' }}>
            {[
              ['Total', data.assessed, '#eff4ff', '#2563eb'],
              ['AI', data.ai_powered ? '✓' : '✗', data.ai_powered ? '#f0fdf4' : '#fef2f2', data.ai_powered ? '#16a34a' : '#dc2626'],
              ['High', highCount, '#fef2f2', '#dc2626'],
              ['Medium', medCount, '#fffbeb', '#d97706'],
              ['Low', lowCount, '#f0fdf4', '#16a34a'],
            ].map(function(item) {
              return (
                <div key={item[0]} style={{
                  padding: '4px 12px', borderRadius: 99, fontSize: 11,
                  fontWeight: 700, background: item[2], color: item[3],
                }}>
                  {item[0]}: {item[1]}
                </div>
              )
            })}
          </div>

          <div style={{ overflowX: 'auto', borderRadius: 10, border: '1px solid #e4e8f0' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
              <thead style={{ background: '#f8f9fc', borderBottom: '1px solid #e4e8f0' }}>
                <tr>
                  {['Job ID', 'Type', 'File Ops', 'DB Ops', 'Complexity', 'Score', 'Candidate', 'Reason'].map(function(h) {
                    return (
                      <th key={h} style={{
                        padding: '9px 12px', textAlign: 'left', fontSize: 10,
                        fontWeight: 700, color: '#9ca3af', textTransform: 'uppercase',
                        letterSpacing: '0.06em', whiteSpace: 'nowrap',
                      }}>
                        {h}
                      </th>
                    )
                  })}
                </tr>
              </thead>
              <tbody>
                {rows.map(function(r, i) {
                  const scoreColor = r.modernization_score >= 7 ? '#dc2626'
                    : r.modernization_score >= 5 ? '#d97706' : '#16a34a'
                  const candColor = r.modernization_candidate === 'Yes' ? '#16a34a'
                    : r.modernization_candidate === 'No' ? '#9ca3af' : '#d97706'
                  return (
                    <tr key={r.job_id} style={{
                      borderBottom: '1px solid #f1f3f7',
                      background: i % 2 === 0 ? '#fff' : '#fafbfc',
                    }}>
                      <td style={{ padding: '8px 12px', fontFamily: 'monospace', fontSize: 11, color: '#374151', whiteSpace: 'nowrap' }}>{r.job_id}</td>
                      <td style={{ padding: '8px 12px', color: '#6b7280' }}>{r.job_type}</td>
                      <td style={{ padding: '8px 12px', color: '#6b7280', maxWidth: 140, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{r.file_operations}</td>
                      <td style={{ padding: '8px 12px', color: '#6b7280', maxWidth: 120, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{r.db_operations}</td>
                      <td style={{ padding: '8px 12px' }}><Badge level={r.migration_complexity} /></td>
                      <td style={{ padding: '8px 12px', textAlign: 'center', fontFamily: 'monospace', fontWeight: 700, fontSize: 13, color: scoreColor }}>
                        {r.modernization_score}/10
                      </td>
                      <td style={{ padding: '8px 12px', fontSize: 11, fontWeight: 600, color: candColor }}>{r.modernization_candidate}</td>
                      <td style={{ padding: '8px 12px', color: '#6b7280', maxWidth: 220, fontSize: 11 }}>{r.brief_reason}</td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  )
}

/* ─────────────────────────────────────────────────────────────────
   FEATURES 2 + 3 — SOURCE CODE ANALYSIS & BOTTLENECKS
───────────────────────────────────────────────────────────────── */
function SourceAnalysisPanel({ sessionId, jobs }) {
  const firstJobId = jobs && jobs.length > 0 ? jobs[0].JobId : ''
  const [selectedJob, setSelectedJob] = useState(firstJobId)
  const [sourceCode, setSourceCode] = useState('')
  const [tab, setTab] = useState('analysis')
  const [loadingA, setLoadingA] = useState(false)
  const [loadingB, setLoadingB] = useState(false)
  const [analysis, setAnalysis] = useState(null)
  const [bottleneck, setBottleneck] = useState(null)

  async function runAnalysis() {
    if (!sourceCode.trim()) { toast.error('Paste source code first'); return }
    setLoadingA(true)
    try {
      const res = await ai.sourceAnalysis(sessionId, selectedJob, sourceCode)
      setAnalysis(res.data.analysis)
      setTab('analysis')
      toast.success('Source analysis complete')
    } catch (e) {
      toast.error((e.response && e.response.data && e.response.data.detail) || 'Analysis failed')
    } finally { setLoadingA(false) }
  }

  async function runBottleneck() {
    if (!sourceCode.trim()) { toast.error('Paste source code first'); return }
    setLoadingB(true)
    try {
      const res = await ai.bottleneck(sessionId, selectedJob, sourceCode)
      setBottleneck(res.data.bottleneck)
      setTab('bottleneck')
      toast.success('Bottleneck analysis complete')
    } catch (e) {
      toast.error('Bottleneck analysis failed')
    } finally { setLoadingB(false) }
  }

  const a = analysis
  const b = bottleneck

  const ehQualityLevel = {
    None: 'High', Minimal: 'Medium', Adequate: 'Low', Comprehensive: 'Low',
  }

  return (
    <div>
      <div style={{ display: 'grid', gridTemplateColumns: '220px 1fr', gap: 14, marginBottom: 14 }}>
        <div>
          <label style={{ fontSize: 11, fontWeight: 700, color: '#9ca3af', textTransform: 'uppercase', letterSpacing: '0.06em', display: 'block', marginBottom: 6 }}>
            Select Job
          </label>
          <select
            value={selectedJob}
            onChange={function(e) { setSelectedJob(e.target.value) }}
            style={{ width: '100%', padding: '7px 10px', borderRadius: 8, border: '1px solid #e4e8f0', fontSize: 12, color: '#374151', background: '#fff' }}
          >
            {(jobs || []).map(function(j) {
              return (
                <option key={j.JobId} value={j.JobId}>
                  {j.JobId} — {(j.JobName || '').slice(0, 28)}
                </option>
              )
            })}
          </select>
        </div>
        <div>
          <label style={{ fontSize: 11, fontWeight: 700, color: '#9ca3af', textTransform: 'uppercase', letterSpacing: '0.06em', display: 'block', marginBottom: 6 }}>
            Paste Source Code
          </label>
          <textarea
            value={sourceCode}
            onChange={function(e) { setSourceCode(e.target.value) }}
            placeholder="Paste Shell script, SQL, Java, Python, Perl… here"
            style={{ width: '100%', height: 100, padding: '8px 12px', borderRadius: 8, border: '1px solid #e4e8f0', fontSize: 11, fontFamily: 'monospace', color: '#374151', resize: 'vertical', boxSizing: 'border-box' }}
          />
        </div>
      </div>

      <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
        <RunBtn onClick={runAnalysis} loading={loadingA}>
          <FileCode2 size={13} /> Deep Code Analysis
        </RunBtn>
        <RunBtn onClick={runBottleneck} loading={loadingB} variant="purple">
          <Zap size={13} /> Bottleneck Analysis
        </RunBtn>
      </div>

      {!a && !b && <EmptyPrompt message="Paste source code and click an analysis button above" />}

      {(a || b) && (
        <div style={{ display: 'flex', background: '#f1f4f9', borderRadius: 8, padding: 3, gap: 2, marginBottom: 14, width: 'fit-content' }}>
          {a && (
            <button
              onClick={function() { setTab('analysis') }}
              style={{ padding: '5px 14px', borderRadius: 6, border: 'none', fontSize: 12, fontWeight: 600, cursor: 'pointer', background: tab === 'analysis' ? '#fff' : 'transparent', color: tab === 'analysis' ? '#1d4ed8' : '#9ca3af' }}
            >
              Code Analysis
            </button>
          )}
          {b && (
            <button
              onClick={function() { setTab('bottleneck') }}
              style={{ padding: '5px 14px', borderRadius: 6, border: 'none', fontSize: 12, fontWeight: 600, cursor: 'pointer', background: tab === 'bottleneck' ? '#fff' : 'transparent', color: tab === 'bottleneck' ? '#7c3aed' : '#9ca3af' }}
            >
              Bottlenecks
            </button>
          )}
        </div>
      )}

      {tab === 'analysis' && a && (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
          <div>
            <SectionCard title="Database Objects" icon={BarChart3}>
              <KV label="Tables Used" value={(a.tables_used || []).join(', ')} />
              <KV label="Reference Tables" value={(a.reference_tables || []).join(', ')} />
              <KV label="Views" value={(a.views_used || []).join(', ')} />
              <KV label="Stored Procedures" value={(a.stored_procedures || []).join(', ')} />
              <KV label="Functions" value={(a.functions || []).join(', ')} />
            </SectionCard>

            <SectionCard title="Joins" icon={ArrowLeftRight}>
              <div style={{ display: 'flex', gap: 14, flexWrap: 'wrap' }}>
                {['inner', 'left', 'right', 'outer', 'cross'].map(function(jt) {
                  const joins = a.joins || {}
                  return (
                    <div key={jt} style={{ textAlign: 'center', minWidth: 48 }}>
                      <div style={{ fontSize: 18, fontWeight: 700, color: '#2563eb', fontFamily: 'monospace' }}>
                        {joins[jt] || 0}
                      </div>
                      <div style={{ fontSize: 10, color: '#9ca3af', textTransform: 'uppercase' }}>{jt}</div>
                    </div>
                  )
                })}
              </div>
            </SectionCard>

            <SectionCard title="File & Network Operations" icon={FileText}>
              <KV label="File Reads"  value={(a.file_reads  || []).join(', ')} />
              <KV label="File Writes" value={(a.file_writes || []).join(', ')} />
              <div style={{ display: 'flex', gap: 8, marginTop: 8, flexWrap: 'wrap' }}>
                {[['FTP', a.ftp_usage], ['SFTP', a.sftp_usage], ['MQ/Queue', a.mq_usage]].map(function(item) {
                  const lbl = item[0]; const val = item[1]
                  return (
                    <span key={lbl} style={{
                      padding: '3px 9px', borderRadius: 5, fontSize: 11, fontWeight: 600,
                      background: val ? '#fef2f2' : '#f0fdf4',
                      color: val ? '#dc2626' : '#16a34a',
                      border: '1px solid ' + (val ? '#fecaca' : '#bbf7d0'),
                    }}>
                      {lbl}: {val ? '⚠ Yes' : '✓ No'}
                    </span>
                  )
                })}
              </div>
            </SectionCard>
          </div>

          <div>
            <SectionCard
              title="Error Handling Quality"
              icon={ShieldAlert}
              iconColor={(a.error_handling && a.error_handling.quality === 'None') ? '#dc2626'
                : (a.error_handling && a.error_handling.quality === 'Minimal') ? '#d97706' : '#16a34a'}
            >
              <Badge
                level={ehQualityLevel[a.error_handling && a.error_handling.quality] || 'Medium'}
                label={'Error Handling: ' + (a.error_handling && a.error_handling.quality || 'Unknown')}
              />
              <div style={{ display: 'flex', gap: 10, marginTop: 10, flexWrap: 'wrap' }}>
                {[
                  ['Try/Catch',  a.error_handling && a.error_handling.has_try_catch],
                  ['Exit Codes', a.error_handling && a.error_handling.has_exit_codes],
                  ['Logging',    a.error_handling && a.error_handling.has_logging],
                ].map(function(item) {
                  return (
                    <span key={item[0]} style={{ fontSize: 11, color: item[1] ? '#16a34a' : '#9ca3af' }}>
                      {item[1] ? '✓' : '✗'} {item[0]}
                    </span>
                  )
                })}
              </div>
            </SectionCard>

            <SectionCard title="Restart & Idempotency" icon={RefreshCcw}>
              <Badge
                level={ehQualityLevel[a.restart_logic && a.restart_logic.restart_quality] || 'Medium'}
                label={'Restart Quality: ' + (a.restart_logic && a.restart_logic.restart_quality || 'Unknown')}
              />
              <div style={{ display: 'flex', gap: 10, marginTop: 10, flexWrap: 'wrap' }}>
                {[
                  ['Checkpoints', a.restart_logic && a.restart_logic.has_checkpoints],
                  ['Retry Logic', a.restart_logic && a.restart_logic.has_retry],
                  ['Idempotent',  a.restart_logic && a.restart_logic.is_idempotent],
                ].map(function(item) {
                  return (
                    <span key={item[0]} style={{ fontSize: 11, color: item[1] ? '#16a34a' : '#9ca3af' }}>
                      {item[1] ? '✓' : '✗'} {item[0]}
                    </span>
                  )
                })}
              </div>
            </SectionCard>

            {a.hardcoded_credentials && (
              <div style={{ padding: '10px 14px', background: '#fef2f2', border: '1px solid #fecaca', borderRadius: 10, marginBottom: 12 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
                  <AlertTriangle size={14} color="#dc2626" />
                  <span style={{ fontSize: 12, fontWeight: 700, color: '#dc2626' }}>⚠ Hardcoded Credentials Detected</span>
                </div>
                <div style={{ fontSize: 11, color: '#7f1d1d', marginTop: 4 }}>
                  Must remediate before cloud migration. Move to secrets manager.
                </div>
              </div>
            )}

            <SectionCard title="API Calls & Transformations" icon={Zap}>
              <KV label="API Calls"            value={(a.api_calls || []).join(', ')} />
              <KV label="Data Transformations" value={(a.data_transformations || []).join(', ')} />
            </SectionCard>

            {(a.tech_debt_notes || []).length > 0 && (
              <SectionCard title="Tech Debt Notes" icon={Info} iconColor="#d97706">
                {a.tech_debt_notes.map(function(n, i) {
                  return <div key={i} style={{ fontSize: 12, color: '#92400e', marginBottom: 4 }}>• {n}</div>
                })}
              </SectionCard>
            )}
          </div>
        </div>
      )}

      {tab === 'bottleneck' && b && (
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14 }}>
            <span style={{ fontSize: 13, fontWeight: 600, color: '#374151' }}>Overall Performance Risk:</span>
            <Badge level={b.overall_performance_risk} />
          </div>
          {b.top_recommendation && (
            <div style={{ padding: '10px 14px', background: '#eff4ff', border: '1px solid #bfdbfe', borderRadius: 9, marginBottom: 14 }}>
              <span style={{ fontSize: 12, fontWeight: 600, color: '#1d4ed8' }}>⚡ Top Fix: </span>
              <span style={{ fontSize: 12, color: '#374151' }}>{b.top_recommendation}</span>
            </div>
          )}
          {(b.bottlenecks || []).length === 0 && (
            <div style={{ padding: 20, textAlign: 'center', color: '#16a34a', fontSize: 13, fontWeight: 600 }}>✓ No bottlenecks detected</div>
          )}
          {(b.bottlenecks || []).map(function(bn, i) {
            return (
              <div key={i} style={{ border: '1px solid #e4e8f0', borderRadius: 10, padding: 14, marginBottom: 10 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                  <Badge level={bn.impact} />
                  <span style={{ fontSize: 12, fontWeight: 700, color: '#374151' }}>{bn.type}</span>
                  <span style={{ fontSize: 11, color: '#9ca3af', marginLeft: 'auto' }}>{bn.location}</span>
                </div>
                <div style={{ fontSize: 12, color: '#6b7280', marginBottom: 6 }}>{bn.description}</div>
                <div style={{ fontSize: 12, color: '#1d4ed8', fontWeight: 600 }}>💡 {bn.recommendation}</div>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}

/* ─────────────────────────────────────────────────────────────────
   FEATURES 4 + 5 — RISK & MODERNIZATION (ALL JOBS)
───────────────────────────────────────────────────────────────── */
function RiskModernizationPanel({ sessionId }) {
  const [loadingR, setLoadingR] = useState(false)
  const [loadingM, setLoadingM] = useState(false)
  const [risks, setRisks] = useState(null)
  const [mods,  setMods]  = useState(null)
  const [tab,   setTab]   = useState('risk')

  async function runRisk() {
    setLoadingR(true)
    try {
      const res = await ai.riskAll(sessionId)
      setRisks(res.data.risks)
      setTab('risk')
      toast.success('Risk assessed for ' + res.data.total + ' jobs')
    } catch (e) {
      toast.error('Risk assessment failed')
    } finally { setLoadingR(false) }
  }

  async function runMod() {
    setLoadingM(true)
    try {
      const res = await ai.modernizationAll(sessionId)
      setMods(res.data.modernizations)
      setTab('mod')
      toast.success('Modernization assessed for ' + res.data.total + ' jobs')
    } catch (e) {
      toast.error('Modernization assessment failed')
    } finally { setLoadingM(false) }
  }

  const riskDist = {}
  if (risks) {
    risks.forEach(function(r) {
      const k = r.risk_level
      riskDist[k] = (riskDist[k] || 0) + 1
    })
  }

  return (
    <div>
      <div style={{ display: 'flex', gap: 8, marginBottom: 14, flexWrap: 'wrap' }}>
        <RunBtn onClick={runRisk} loading={loadingR}>
          <ShieldAlert size={13} /> Assess Risk (All Jobs)
        </RunBtn>
        <RunBtn onClick={runMod} loading={loadingM} variant="purple">
          <TrendingUp size={13} /> Modernization Plan (All Jobs)
        </RunBtn>
      </div>

      {risks && (
        <div style={{ display: 'flex', gap: 8, marginBottom: 12, flexWrap: 'wrap' }}>
          {[
            ['Critical', '#ffd7d7', '#7f0000'],
            ['High',     '#ffe4cc', '#7a3500'],
            ['Medium',   '#fff3cd', '#7a5c00'],
            ['Low',      '#d4f1e4', '#1a5c3a'],
          ].map(function(item) {
            const lvl = item[0]
            if (!riskDist[lvl]) return null
            return (
              <div key={lvl} style={{ padding: '4px 12px', borderRadius: 99, background: item[1], fontSize: 11, fontWeight: 700, color: item[2] }}>
                {lvl}: {riskDist[lvl]}
              </div>
            )
          })}
        </div>
      )}

      {(risks || mods) && (
        <div style={{ display: 'flex', background: '#f1f4f9', borderRadius: 8, padding: 3, gap: 2, marginBottom: 14, width: 'fit-content' }}>
          {risks && (
            <button onClick={function() { setTab('risk') }} style={{ padding: '5px 14px', borderRadius: 6, border: 'none', fontSize: 12, fontWeight: 600, cursor: 'pointer', background: tab === 'risk' ? '#fff' : 'transparent', color: tab === 'risk' ? '#1d4ed8' : '#9ca3af' }}>
              Risk Assessment
            </button>
          )}
          {mods && (
            <button onClick={function() { setTab('mod') }} style={{ padding: '5px 14px', borderRadius: 6, border: 'none', fontSize: 12, fontWeight: 600, cursor: 'pointer', background: tab === 'mod' ? '#fff' : 'transparent', color: tab === 'mod' ? '#7c3aed' : '#9ca3af' }}>
              Modernization Plan
            </button>
          )}
        </div>
      )}

      {!risks && !mods && <EmptyPrompt message="Run risk or modernization assessment for all jobs" />}

      {tab === 'risk' && risks && (
        <div style={{ overflowX: 'auto', borderRadius: 10, border: '1px solid #e4e8f0' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
            <thead style={{ background: '#f8f9fc', borderBottom: '1px solid #e4e8f0' }}>
              <tr>
                {['Job ID', 'Risk Level', 'Dep. Risk', 'Data Risk', 'Op. Risk', 'Top Risk Factor', 'Recommendation'].map(function(h) {
                  return (
                    <th key={h} style={{ padding: '9px 12px', textAlign: 'left', fontSize: 10, fontWeight: 700, color: '#9ca3af', textTransform: 'uppercase', letterSpacing: '0.06em', whiteSpace: 'nowrap' }}>
                      {h}
                    </th>
                  )
                })}
              </tr>
            </thead>
            <tbody>
              {risks.map(function(r, i) {
                const topFactor = r.risk_factors && r.risk_factors[0]
                const factorText = topFactor
                  ? '[' + topFactor.severity + '] ' + topFactor.factor + ': ' + topFactor.description
                  : '—'
                return (
                  <tr key={r.job_id} style={{ borderBottom: '1px solid #f1f3f7', background: i % 2 === 0 ? '#fff' : '#fafbfc' }}>
                    <td style={{ padding: '8px 12px', fontFamily: 'monospace', fontSize: 11, color: '#374151', whiteSpace: 'nowrap' }}>{r.job_id}</td>
                    <td style={{ padding: '8px 12px' }}><Badge level={r.risk_level} /></td>
                    <td style={{ padding: '8px 12px' }}><Badge level={r.dependency_risk} /></td>
                    <td style={{ padding: '8px 12px' }}><Badge level={r.data_risk} /></td>
                    <td style={{ padding: '8px 12px' }}><Badge level={r.operational_risk} /></td>
                    <td style={{ padding: '8px 12px', fontSize: 11, color: '#6b7280', maxWidth: 220 }}>{factorText}</td>
                    <td style={{ padding: '8px 12px', fontSize: 11, color: '#374151', maxWidth: 200 }}>{r.migration_recommendation}</td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      )}

      {tab === 'mod' && mods && (
        <div style={{ overflowX: 'auto', borderRadius: 10, border: '1px solid #e4e8f0' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
            <thead style={{ background: '#f8f9fc', borderBottom: '1px solid #e4e8f0' }}>
              <tr>
                {['Job ID', 'Current Tech', '→ Recommended', 'Scheduler', 'Complexity', 'Est. Days', 'Reasoning'].map(function(h) {
                  return (
                    <th key={h} style={{ padding: '9px 12px', textAlign: 'left', fontSize: 10, fontWeight: 700, color: '#9ca3af', textTransform: 'uppercase', letterSpacing: '0.06em', whiteSpace: 'nowrap' }}>
                      {h}
                    </th>
                  )
                })}
              </tr>
            </thead>
            <tbody>
              {mods.map(function(m, i) {
                const reason = (m.reasoning || '').slice(0, 120) + ((m.reasoning || '').length > 120 ? '…' : '')
                return (
                  <tr key={m.job_id} style={{ borderBottom: '1px solid #f1f3f7', background: i % 2 === 0 ? '#fff' : '#fafbfc' }}>
                    <td style={{ padding: '8px 12px', fontFamily: 'monospace', fontSize: 11, color: '#374151', whiteSpace: 'nowrap' }}>{m.job_id}</td>
                    <td style={{ padding: '8px 12px', color: '#6b7280' }}>{m.current_technology}</td>
                    <td style={{ padding: '8px 12px', fontWeight: 700, color: '#2563eb', whiteSpace: 'nowrap' }}>
                      {m.current_technology} → {m.recommended_technology}
                    </td>
                    <td style={{ padding: '8px 12px', color: '#6b7280' }}>{m.recommended_scheduler}</td>
                    <td style={{ padding: '8px 12px' }}><Badge level={m.migration_complexity} /></td>
                    <td style={{ padding: '8px 12px', fontFamily: 'monospace', fontWeight: 700, color: '#374151' }}>{m.estimated_effort_days}d</td>
                    <td style={{ padding: '8px 12px', fontSize: 11, color: '#6b7280', maxWidth: 240 }}>{reason}</td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}

/* ─────────────────────────────────────────────────────────────────
   FEATURE 6 — JOB CONVERSION
───────────────────────────────────────────────────────────────── */
function ConversionPanel({ sessionId, jobs }) {
  const firstJobId = jobs && jobs.length > 0 ? jobs[0].JobId : ''
  const [selectedJob, setSelectedJob] = useState(firstJobId)
  const [sourceCode, setSourceCode] = useState('')
  const [target, setTarget] = useState('Python')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState(null)

  async function run() {
    if (!sourceCode.trim()) { toast.error('Paste source code to convert'); return }
    setLoading(true)
    try {
      const res = await ai.convert(sessionId, selectedJob, sourceCode, target)
      setResult(res.data.conversion)
      toast.success('Converted to ' + target)
    } catch (e) {
      toast.error((e.response && e.response.data && e.response.data.detail) || 'Conversion failed')
    } finally { setLoading(false) }
  }

  const r = result

  return (
    <div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 150px', gap: 12, marginBottom: 12 }}>
        <div>
          <label style={{ fontSize: 11, fontWeight: 700, color: '#9ca3af', textTransform: 'uppercase', letterSpacing: '0.06em', display: 'block', marginBottom: 5 }}>Job</label>
          <select
            value={selectedJob}
            onChange={function(e) { setSelectedJob(e.target.value) }}
            style={{ width: '100%', padding: '7px 10px', borderRadius: 8, border: '1px solid #e4e8f0', fontSize: 12, color: '#374151', background: '#fff' }}
          >
            {(jobs || []).map(function(j) {
              return <option key={j.JobId} value={j.JobId}>{j.JobId}</option>
            })}
          </select>
        </div>
        <div>
          <label style={{ fontSize: 11, fontWeight: 700, color: '#9ca3af', textTransform: 'uppercase', letterSpacing: '0.06em', display: 'block', marginBottom: 5 }}>Target Technology</label>
          <select
            value={target}
            onChange={function(e) { setTarget(e.target.value) }}
            style={{ width: '100%', padding: '7px 10px', borderRadius: 8, border: '1px solid #e4e8f0', fontSize: 12, color: '#374151', background: '#fff' }}
          >
            {CONVERSION_TARGETS.map(function(t) { return <option key={t}>{t}</option> })}
          </select>
        </div>
        <div style={{ display: 'flex', alignItems: 'flex-end' }}>
          <RunBtn onClick={run} loading={loading} variant="purple">
            <Sparkles size={13} /> Convert
          </RunBtn>
        </div>
      </div>

      <div style={{ marginBottom: 16 }}>
        <label style={{ fontSize: 11, fontWeight: 700, color: '#9ca3af', textTransform: 'uppercase', letterSpacing: '0.06em', display: 'block', marginBottom: 5 }}>Source Code</label>
        <textarea
          value={sourceCode}
          onChange={function(e) { setSourceCode(e.target.value) }}
          placeholder="Paste the job source code here (Shell, SQL, Perl, Java…)"
          style={{ width: '100%', height: 130, padding: '10px 12px', borderRadius: 9, border: '1px solid #e4e8f0', fontSize: 11, fontFamily: 'monospace', color: '#374151', resize: 'vertical', boxSizing: 'border-box', lineHeight: 1.6 }}
        />
      </div>

      {!r && !loading && <EmptyPrompt message="Paste source code and click Convert to get AI-generated target code" />}

      {r && (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
          <div>
            <div style={{ fontSize: 11, fontWeight: 700, color: '#9ca3af', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 8 }}>
              Converted Code — {r.target_technology}
              {r.manual_review_needed && (
                <span style={{ marginLeft: 8, color: '#d97706' }}>⚠ Manual review needed</span>
              )}
            </div>
            <CodeBlock code={r.converted_code} />
          </div>
          <div>
            <SectionCard title="Migration Explanation" icon={FileText}>
              <p style={{ fontSize: 12, color: '#374151', lineHeight: 1.7, margin: 0 }}>{r.migration_explanation}</p>
            </SectionCard>
            <SectionCard title="Risks" icon={AlertTriangle} iconColor="#d97706">
              {(r.risks || []).map(function(risk, i) {
                return <div key={i} style={{ fontSize: 12, color: '#92400e', marginBottom: 4 }}>⚠ {risk}</div>
              })}
            </SectionCard>
            <SectionCard title="Validation Checklist" icon={CheckCircle2} iconColor="#16a34a">
              {(r.validation_checklist || []).map(function(item, i) {
                return (
                  <div key={i} style={{ display: 'flex', gap: 7, alignItems: 'flex-start', marginBottom: 5 }}>
                    <input type="checkbox" style={{ marginTop: 2, flexShrink: 0 }} />
                    <span style={{ fontSize: 12, color: '#374151' }}>{item}</span>
                  </div>
                )
              })}
            </SectionCard>
            <div style={{ padding: '8px 12px', background: '#f0fdf4', border: '1px solid #bbf7d0', borderRadius: 8 }}>
              <span style={{ fontSize: 11, color: '#15803d' }}>
                Estimated effort: <strong>{r.estimated_effort_hours}h</strong>
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

/* ─────────────────────────────────────────────────────────────────
   FEATURE 9 — EXECUTIVE SUMMARY + EXPORT
───────────────────────────────────────────────────────────────── */
function ExecutiveSummaryPanel({ sessionId }) {
  const [loading, setLoading] = useState(false)
  const [summary, setSummary] = useState(null)
  const [dlLoading, setDlLoading] = useState(false)

  async function run() {
    setLoading(true)
    try {
      const res = await ai.executiveSummary(sessionId)
      setSummary(res.data.summary)
      toast.success('Executive summary generated')
    } catch (e) {
      toast.error('Summary generation failed')
    } finally { setLoading(false) }
  }

  function downloadReport() {
    setDlLoading(true)
    const url = ai.reportUrl(sessionId)
    const a = document.createElement('a')
    a.href = url
    a.download = 'assessment_' + sessionId.slice(0, 8) + '.xlsx'
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    toast.success('Excel report downloading…')
    setDlLoading(false)
  }

  const s = summary

  return (
    <div>
      <div style={{ display: 'flex', gap: 8, marginBottom: 14, flexWrap: 'wrap' }}>
        <RunBtn onClick={run} loading={loading}>
          <Brain size={13} /> Generate Executive Summary
        </RunBtn>
        <RunBtn onClick={downloadReport} loading={dlLoading} variant="outline">
          <Download size={13} /> Download Excel Report (.xlsx)
        </RunBtn>
      </div>

      {!s && !loading && (
        <EmptyPrompt message="Run bulk assessment and risk/modernization first, then generate executive summary" />
      )}

      {s && (
        <div>
          {s.headline && (
            <div style={{ padding: '14px 20px', background: '#1e3a5f', borderRadius: 12, marginBottom: 16, color: '#ffffff', fontSize: 15, fontWeight: 700, letterSpacing: '-0.02em' }}>
              {s.headline}
            </div>
          )}

          {s.executive_summary && (
            <SectionCard title="Executive Summary" icon={FileText} iconColor="#2563eb">
              <p style={{ fontSize: 13, color: '#374151', lineHeight: 1.8, margin: 0 }}>{s.executive_summary}</p>
            </SectionCard>
          )}

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
            {(s.key_findings || []).length > 0 && (
              <SectionCard title="Key Findings" icon={CheckCircle2} iconColor="#16a34a">
                {s.key_findings.map(function(f, i) {
                  return (
                    <div key={i} style={{ fontSize: 12, color: '#374151', marginBottom: 6, display: 'flex', gap: 7 }}>
                      <span style={{ color: '#2563eb', fontWeight: 700, flexShrink: 0 }}>{i + 1}.</span>
                      {f}
                    </div>
                  )
                })}
              </SectionCard>
            )}

            {(s.strategic_recommendations || []).length > 0 && (
              <SectionCard title="Strategic Recommendations" icon={TrendingUp} iconColor="#7c3aed">
                {s.strategic_recommendations.map(function(rec, i) {
                  return (
                    <div key={i} style={{ marginBottom: 12 }}>
                      <div style={{ fontSize: 12, fontWeight: 700, color: '#374151' }}>
                        P{rec.priority}: {rec.recommendation}
                      </div>
                      <div style={{ fontSize: 11, color: '#6b7280', marginTop: 2 }}>
                        {rec.business_value} · {rec.timeline}
                      </div>
                    </div>
                  )
                })}
              </SectionCard>
            )}
          </div>

          {s.risk_summary && (
            <SectionCard title="Risk Summary" icon={ShieldAlert} iconColor="#dc2626">
              <p style={{ fontSize: 12, color: '#374151', lineHeight: 1.7, margin: 0 }}>{s.risk_summary}</p>
            </SectionCard>
          )}

          {s.modernization_roadmap && (
            <SectionCard title="Modernization Roadmap" icon={TrendingUp} iconColor="#16a34a">
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12 }}>
                {[
                  ['Phase 1', s.modernization_roadmap.phase1, '#eff4ff', '#2563eb'],
                  ['Phase 2', s.modernization_roadmap.phase2, '#f5f3ff', '#7c3aed'],
                  ['Phase 3', s.modernization_roadmap.phase3, '#f0fdf4', '#16a34a'],
                ].map(function(item) {
                  if (!item[1]) return null
                  return (
                    <div key={item[0]} style={{ padding: '12px 14px', background: item[2], borderRadius: 9, border: '1px solid ' + item[3] + '30' }}>
                      <div style={{ fontSize: 11, fontWeight: 700, color: item[3], marginBottom: 5 }}>{item[0]}</div>
                      <div style={{ fontSize: 12, color: '#374151', lineHeight: 1.6 }}>{item[1]}</div>
                    </div>
                  )
                })}
              </div>
            </SectionCard>
          )}
        </div>
      )}
    </div>
  )
}

/* ─────────────────────────────────────────────────────────────────
   MAIN AI ASSESSMENT PAGE
───────────────────────────────────────────────────────────────── */
const AI_TABS = [
  { id: 'bulk',     label: 'Bulk Assessment',     icon: Brain,         color: '#2563eb' },
  { id: 'source',   label: 'Source & Bottleneck', icon: FileCode2,     color: '#7c3aed' },
  { id: 'riskmods', label: 'Risk & Modernization', icon: ShieldAlert,  color: '#dc2626' },
  { id: 'convert',  label: 'Job Conversion',      icon: ArrowLeftRight, color: '#059669' },
  { id: 'summary',  label: 'Summary & Export',    icon: FileText,      color: '#d97706' },
]

export default function AIAssessmentPage() {
  const { state } = useApp()
  const { uploadedFiles, selectedFileIds } = state
  const [activeAiTab, setActiveAiTab] = useState('bulk')
  const [aiStatus, setAiStatus] = useState(null)

  const activeFile = uploadedFiles.find(function(f) {
    return selectedFileIds.includes(f.sessionId)
  }) || uploadedFiles[0]

  const sessionId = activeFile ? activeFile.sessionId : null
  const jobs = (activeFile && activeFile.uploadData && activeFile.uploadData.preview) || []

  const checkStatus = useCallback(async function() {
    if (!sessionId) return
    try {
      const res = await ai.status()
      setAiStatus(res.data)
    } catch (e) {
      // silently ignore — status is non-critical
    }
  }, [sessionId])

  useEffect(function() {
    checkStatus()
  }, [checkStatus])

  if (!sessionId) {
    return (
      <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#f8f9fc' }}>
        <div style={{ textAlign: 'center' }}>
          <Brain size={40} color="#d1d5db" style={{ marginBottom: 12 }} />
          <div style={{ fontSize: 15, fontWeight: 600, color: '#374151', marginBottom: 4 }}>No files uploaded</div>
          <div style={{ fontSize: 13, color: '#9ca3af' }}>Upload a job schedule CSV / JSON / XML to run AI assessment</div>
        </div>
      </div>
    )
  }

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden', background: '#f8f9fc' }}>
      {/* Top bar */}
      <div style={{ background: '#ffffff', borderBottom: '1px solid #e4e8f0', padding: '12px 24px', display: 'flex', alignItems: 'center', gap: 12, flexShrink: 0 }}>
        <Brain size={17} color="#2563eb" />
        <div style={{ flex: 1 }}>
          <span style={{ fontSize: 14, fontWeight: 700, color: '#111827' }}>AI Assessment</span>
          <span style={{ fontSize: 12, color: '#9ca3af', marginLeft: 10 }}>
            {activeFile && activeFile.fileName} · {activeFile && activeFile.uploadData && activeFile.uploadData.row_count} jobs
          </span>
        </div>
        {aiStatus && (
          <div style={{ display: 'flex', gap: 8 }}>
            <StatusPill label="Gemini" active={aiStatus.gemini_available} />
            <StatusPill label="RAG"    active={aiStatus.rag_docs_loaded > 0} sub={aiStatus.rag_docs_loaded + ' docs'} />
            <StatusPill label="FAISS"  active={aiStatus.faiss_index_ready} />
          </div>
        )}
      </div>

      {/* Tab nav */}
      <div style={{ background: '#ffffff', borderBottom: '1px solid #e4e8f0', padding: '0 24px', display: 'flex', flexShrink: 0, overflowX: 'auto' }}>
        {AI_TABS.map(function(t) {
          const Icon = t.icon
          const active = activeAiTab === t.id
          return (
            <button
              key={t.id}
              onClick={function() { setActiveAiTab(t.id) }}
              style={{
                display: 'flex', alignItems: 'center', gap: 7,
                padding: '10px 16px', border: 'none', background: 'transparent',
                cursor: 'pointer', fontSize: 12, fontWeight: active ? 700 : 500,
                color: active ? t.color : '#9ca3af',
                borderBottom: active ? '2px solid ' + t.color : '2px solid transparent',
                transition: 'all 0.12s', whiteSpace: 'nowrap',
              }}
            >
              <Icon size={13} />
              {t.label}
            </button>
          )
        })}
      </div>

      {/* Content */}
      <div style={{ flex: 1, overflowY: 'auto', padding: 24 }}>
        <div style={{ background: '#ffffff', border: '1px solid #e4e8f0', borderRadius: 14, padding: 22, boxShadow: '0 2px 8px rgba(0,0,0,0.04)' }}>
          {activeAiTab === 'bulk'     && <BulkAssessmentPanel     sessionId={sessionId} />}
          {activeAiTab === 'source'   && <SourceAnalysisPanel     sessionId={sessionId} jobs={jobs} />}
          {activeAiTab === 'riskmods' && <RiskModernizationPanel  sessionId={sessionId} />}
          {activeAiTab === 'convert'  && <ConversionPanel         sessionId={sessionId} jobs={jobs} />}
          {activeAiTab === 'summary'  && <ExecutiveSummaryPanel   sessionId={sessionId} />}
        </div>
      </div>
    </div>
  )
}
