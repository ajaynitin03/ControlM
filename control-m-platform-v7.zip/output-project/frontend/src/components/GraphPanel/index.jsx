import { useEffect, useRef, useState, useCallback } from 'react'
import {
  ZoomIn, ZoomOut, Maximize2, Download, Image, FileCode,
  RotateCcw, Target, AlertTriangle, AlignLeft, AlignCenter,
  Layers
} from 'lucide-react'
import toast from 'react-hot-toast'
import { useApp } from '../../hooks/useAppState'
import {
  initCytoscape, resetHighlight, highlightCriticalPath,
  exportPNG, exportSVG, relayout
} from '../../utils/cytoscapeBuilder'
import JobDetails from '../JobDetails'

const LEGEND = [
  { label: 'HIGH',          color: 'bg-red-500',    border: 'border-red-500',    desc: 'Critical priority' },
  { label: 'MEDIUM',        color: 'bg-orange-500', border: 'border-orange-500', desc: 'Medium priority'   },
  { label: 'LOW',           color: 'bg-green-500',  border: 'border-green-500',  desc: 'Low priority'      },
  { label: 'Critical Path', color: 'bg-amber-400',  border: 'border-amber-400',  desc: 'Longest chain'     },
  { label: 'Impact',        color: 'bg-red-700',    border: 'border-red-700',    desc: 'Failure cascade'   },
]

export default function GraphPanel() {
  const { state, dispatch } = useApp()
  const { graphData } = state
  const containerRef = useRef(null)
  const cyRef = useRef(null)
  const [showLegend, setShowLegend] = useState(true)
  const [layoutDir, setLayoutDir] = useState('TB')

  useEffect(() => {
    if (!containerRef.current || !graphData) return

    if (cyRef.current) { cyRef.current.destroy(); cyRef.current = null }

    const elements = [...graphData.nodes, ...graphData.edges]

    cyRef.current = initCytoscape(
      containerRef.current,
      elements,
      (nodeData) => dispatch({ type: 'SET_SELECTED_NODE', payload: nodeData })
    )

    return () => { if (cyRef.current) { cyRef.current.destroy(); cyRef.current = null } }
  }, [graphData, dispatch])

  // Re-layout when direction toggles
  useEffect(() => {
    if (cyRef.current) relayout(cyRef.current, layoutDir)
  }, [layoutDir])

  const handleExportPNG = useCallback(async () => {
    if (!cyRef.current) return
    const blob = exportPNG(cyRef.current)
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url; a.download = 'dependency-graph.png'; a.click()
    URL.revokeObjectURL(url)
    toast.success('PNG exported')
  }, [])

  const handleExportSVG = useCallback(() => {
    if (!cyRef.current) return
    const svg = exportSVG(cyRef.current)
    const blob = new Blob([svg], { type: 'image/svg+xml' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url; a.download = 'dependency-graph.svg'; a.click()
    URL.revokeObjectURL(url)
    toast.success('SVG exported')
  }, [])

  const handleFit     = () => cyRef.current?.fit(undefined, 50)
  const handleZoomIn  = () => cyRef.current?.zoom(cyRef.current.zoom() * 1.3)
  const handleZoomOut = () => cyRef.current?.zoom(cyRef.current.zoom() * 0.77)
  const handleReset   = () => {
    if (!cyRef.current) return
    resetHighlight(cyRef.current)
    dispatch({ type: 'SET_SELECTED_NODE', payload: null })
    toast('Highlights cleared', { icon: '✓' })
  }
  const handleCriticalPath = () => {
    if (!cyRef.current || !graphData?.critical_path?.length) {
      toast.error('No critical path available'); return
    }
    highlightCriticalPath(cyRef.current, graphData.critical_path)
    toast.success(`Critical path: ${graphData.critical_path.length} jobs highlighted`)
  }

  if (!graphData) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center gap-5 text-slate-500 bg-surface">
        <div className="w-20 h-20 rounded-2xl bg-surface-card border border-surface-border flex items-center justify-center">
          <Layers size={32} className="text-slate-600" />
        </div>
        <div className="text-center">
          <p className="text-slate-300 font-semibold text-base">No graph yet</p>
          <p className="text-sm mt-1 text-slate-500">
            Select jobs in the sidebar and click <span className="text-brand-400 font-medium">Build Graph</span>
          </p>
        </div>
        {/* Feature chips */}
        <div className="flex flex-wrap justify-center gap-2 max-w-xs mt-2">
          {['Application Groups','Risk Highlighting','Critical Path','Impact Analysis','Cycle Detection'].map(f => (
            <span key={f} className="px-2.5 py-1 bg-surface-card border border-surface-border rounded-full text-xs text-slate-400">{f}</span>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="flex-1 relative overflow-hidden bg-surface">
      {/* ── Toolbar ─────────────────────────────────── */}
      <div className="absolute top-3 left-3 z-10 flex items-center gap-1.5 flex-wrap">
        {/* Zoom */}
        <div className="flex items-center gap-px bg-surface-card border border-surface-border rounded-lg p-1 shadow-lg">
          <button onClick={handleZoomIn}  className="btn-ghost p-1.5" title="Zoom in"><ZoomIn  size={14}/></button>
          <button onClick={handleZoomOut} className="btn-ghost p-1.5" title="Zoom out"><ZoomOut size={14}/></button>
          <button onClick={handleFit}     className="btn-ghost p-1.5" title="Fit all"><Maximize2 size={14}/></button>
          <div className="w-px h-4 bg-surface-border mx-0.5"/>
          <button onClick={handleReset}   className="btn-ghost p-1.5" title="Clear highlights"><RotateCcw size={14}/></button>
        </div>

        {/* Layout direction */}
        <div className="flex items-center gap-px bg-surface-card border border-surface-border rounded-lg p-1 shadow-lg">
          <button
            onClick={() => setLayoutDir('TB')}
            className={`p-1.5 rounded flex items-center gap-1.5 text-xs transition-colors ${layoutDir==='TB' ? 'bg-brand-600/30 text-brand-400' : 'btn-ghost'}`}
            title="Top → Bottom layout"
          >
            <AlignCenter size={14}/><span className="hidden sm:inline">TB</span>
          </button>
          <button
            onClick={() => setLayoutDir('LR')}
            className={`p-1.5 rounded flex items-center gap-1.5 text-xs transition-colors ${layoutDir==='LR' ? 'bg-brand-600/30 text-brand-400' : 'btn-ghost'}`}
            title="Left → Right layout"
          >
            <AlignLeft size={14}/><span className="hidden sm:inline">LR</span>
          </button>
        </div>

        {/* Analysis */}
        <div className="flex items-center gap-px bg-surface-card border border-surface-border rounded-lg p-1 shadow-lg">
          <button
            onClick={handleCriticalPath}
            className="btn-ghost p-1.5 flex items-center gap-1.5 text-xs"
            title="Highlight critical path"
          >
            <Target size={14} className="text-amber-400"/>
            <span className="hidden sm:inline text-amber-400 font-medium">Critical Path</span>
          </button>
        </div>

        {/* Export */}
        <div className="flex items-center gap-px bg-surface-card border border-surface-border rounded-lg p-1 shadow-lg">
          <button onClick={handleExportPNG} className="btn-ghost p-1.5 flex items-center gap-1.5 text-xs" title="Export PNG">
            <Image size={14}/><span className="hidden sm:inline">PNG</span>
          </button>
          <button onClick={handleExportSVG} className="btn-ghost p-1.5 flex items-center gap-1.5 text-xs" title="Export SVG">
            <FileCode size={14}/><span className="hidden sm:inline">SVG</span>
          </button>
        </div>
      </div>

      {/* ── Cycle warning ────────────────────────────── */}
      {graphData.has_cycles && (
        <div className="absolute top-3 left-1/2 -translate-x-1/2 z-10">
          <div className="flex items-center gap-2 px-3 py-2 bg-red-950/80 border border-red-600/40 rounded-lg backdrop-blur-sm shadow-lg">
            <AlertTriangle size={13} className="text-red-400"/>
            <span className="text-xs text-red-300 font-medium">
              ⚠ {graphData.cycle_details.length} dependency cycle{graphData.cycle_details.length>1?'s':''} detected — check Analysis tab
            </span>
          </div>
        </div>
      )}

      {/* ── Graph stats bar ──────────────────────────── */}
      <div className="absolute bottom-3 left-3 z-10">
        <div className="flex items-center gap-3 px-3 py-1.5 bg-surface-card/90 border border-surface-border rounded-lg backdrop-blur-sm text-xs">
          <span className="text-slate-400"><span className="font-mono text-slate-200">{graphData.node_count}</span> nodes</span>
          <span className="text-slate-600">·</span>
          <span className="text-slate-400"><span className="font-mono text-slate-200">{graphData.edge_count}</span> edges</span>
          {graphData.critical_path?.length > 0 && <>
            <span className="text-slate-600">·</span>
            <span className="text-slate-400">Path: <span className="font-mono text-amber-400">{graphData.critical_path.length}</span> jobs</span>
          </>}
          <span className="text-slate-600">·</span>
          <span className="text-slate-500 font-mono">{layoutDir === 'TB' ? '↓ Top→Bottom' : '→ Left→Right'}</span>
        </div>
      </div>

      {/* ── Legend ──────────────────────────────────── */}
      {showLegend && (
        <div className="absolute bottom-3 right-3 z-10">
          <div className="px-3 py-2.5 bg-surface-card/95 border border-surface-border rounded-xl backdrop-blur-sm shadow-xl">
            <div className="flex items-center justify-between mb-2">
              <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Legend</p>
              <button onClick={()=>setShowLegend(false)} className="text-slate-600 hover:text-slate-300 ml-4 text-sm leading-none">×</button>
            </div>
            <div className="space-y-1.5 mb-3">
              {LEGEND.map(({label,color,desc}) => (
                <div key={label} className="flex items-center gap-2.5">
                  <div className={`w-3 h-3 rounded-sm ${color} flex-shrink-0 shadow-sm`}/>
                  <span className="text-xs text-slate-300 w-20 font-medium">{label}</span>
                  <span className="text-xs text-slate-500">{desc}</span>
                </div>
              ))}
            </div>
            <div className="border-t border-surface-border pt-2">
              <div className="flex items-center gap-2.5">
                <div className="w-3 h-3 rounded border-2 border-dashed border-slate-500 flex-shrink-0"/>
                <span className="text-xs text-slate-400">App group (compound)</span>
              </div>
            </div>
          </div>
        </div>
      )}
      {!showLegend && (
        <button
          onClick={()=>setShowLegend(true)}
          className="absolute bottom-3 right-3 z-10 btn-ghost text-xs border border-surface-border rounded-lg px-3 py-1.5 bg-surface-card/90"
        >Legend</button>
      )}

      {/* ── Cytoscape canvas ────────────────────────── */}
      <div ref={containerRef} id="cy-container" style={{width:'100%',height:'100%'}}/>

      {/* ── Node details panel ───────────────────────── */}
      <JobDetails cyRef={cyRef}/>
    </div>
  )
}
