import axios from 'axios'

const api = axios.create({
  baseURL: '/api',
  timeout: 60000,   // 60s — AI calls can take time
})

const BASE = '/api'

// ════════════════════════════════════════════════════════════════
// PHASE-1 — Upload & Analysis
// ════════════════════════════════════════════════════════════════

export const uploadFile = (file, onProgress) => {
  const formData = new FormData()
  formData.append('file', file)
  return api.post('/upload/', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
    onUploadProgress: onProgress,
  })
}

export const getPreview = (sessionId, page = 1, pageSize = 50) =>
  api.get(`/upload/preview/${sessionId}`, { params: { page, page_size: pageSize } })

export const getJobs = (sessionId) =>
  api.get(`/upload/jobs/${sessionId}`)

export const buildGraph = (sessionId, jobIds, depth = 3) =>
  api.post('/graph/build', { session_id: sessionId, job_ids: jobIds, depth })

export const getFullGraph = (sessionId) =>
  api.get(`/graph/full/${sessionId}`)

export const getImpactAnalysis = (sessionId, jobId) =>
  api.post('/analysis/impact', { session_id: sessionId, job_id: jobId })

export const getCriticalPath = (sessionId) =>
  api.get(`/analysis/critical-path/${sessionId}`)

export const getFanMetrics = (sessionId) =>
  api.get(`/analysis/fan-metrics/${sessionId}`)

export const getCycles = (sessionId) =>
  api.get(`/analysis/cycles/${sessionId}`)

export const getSummary = (sessionId) =>
  api.get(`/analysis/summary/${sessionId}`)

export const exportCsv = (sessionId) =>
  `${BASE}/upload/export/${sessionId}`

// ════════════════════════════════════════════════════════════════
// PHASE-2 — AI Assessment (Gemini + RAG)
// ════════════════════════════════════════════════════════════════

export const ai = {
  /** Check if Gemini + RAG are ready */
  status: () =>
    api.get(`/ai/status`),

  /** Feature 1 — Bulk assess all jobs in session */
  bulkAssess: (sessionId) =>
    api.post(`/ai/bulk-assess/${sessionId}`),

  /** Feature 2 — Deep source code analysis */
  sourceAnalysis: (sessionId, jobId, sourceCode) =>
    api.post(`/ai/source-analysis/${sessionId}`, {
      job_id: jobId,
      source_code: sourceCode,
    }),

  /** Feature 3 — Bottleneck analysis */
  bottleneck: (sessionId, jobId, sourceCode) =>
    api.post(`/ai/bottleneck/${sessionId}`, {
      job_id: jobId,
      source_code: sourceCode,
    }),

  /** Feature 4 — Risk assessment for one job */
  risk: (sessionId, jobId, sourceCode = '', fanIn = 0, fanOut = 0) =>
    api.post(`/ai/risk/${sessionId}`, {
      job_id: jobId,
      source_code: sourceCode,
      fan_in: fanIn,
      fan_out: fanOut,
    }),

  /** Feature 4 — Risk assessment for ALL jobs (metadata only) */
  riskAll: (sessionId) =>
    api.post(`/ai/risk-all/${sessionId}`),

  /** Feature 5 — Modernization assessment for one job */
  modernization: (sessionId, jobId, sourceCode = '') =>
    api.post(`/ai/modernization/${sessionId}`, {
      job_id: jobId,
      source_code: sourceCode,
    }),

  /** Feature 5 — Modernization assessment for ALL jobs */
  modernizationAll: (sessionId) =>
    api.post(`/ai/modernization-all/${sessionId}`),

  /** Feature 6 — Convert job code to target technology */
  convert: (sessionId, jobId, sourceCode, targetTechnology) =>
    api.post(`/ai/convert/${sessionId}`, {
      job_id: jobId,
      source_code: sourceCode,
      target_technology: targetTechnology,
    }),

  /** Feature 9 — Generate executive summary */
  executiveSummary: (sessionId) =>
    api.post(`/ai/executive-summary/${sessionId}`),

  /** Download full Excel report URL (used as <a href> or fetch) */
  reportUrl: (sessionId) =>
    `${BASE}/ai/report/${sessionId}`,

  /** Get full JSON report */
  reportJson: (sessionId) =>
    api.get(`/ai/report-json/${sessionId}`),
}
