# Control-M Batch Assessment Platform
## Phase 1 + Phase 2 (AI-Powered)

---

## Quick Start

### 1. Backend

```bash
cd backend

# Install dependencies
pip install -r requirements.txt

# Optional: enable FAISS vector search (faster RAG)
pip install sentence-transformers faiss-cpu

# Set Gemini API key (required for AI features)
export GEMINI_API_KEY="your-key-here"
# Get key: https://aistudio.google.com/app/apikey

# Start server
uvicorn main:app --reload --port 8000
```

### 2. Frontend

```bash
cd frontend
npm install
npm run dev
# Opens at http://localhost:5173
```

---

## Phase 2 — AI Features

| Feature | Endpoint | Description |
|---|---|---|
| AI Status | GET /api/ai/status | Check Gemini + RAG readiness |
| Bulk Assessment | POST /api/ai/bulk-assess/{sid} | Assess all jobs (chunked) |
| Source Analysis | POST /api/ai/source-analysis/{sid} | Deep code analysis |
| Bottleneck | POST /api/ai/bottleneck/{sid} | Performance bottleneck detection |
| Risk (single) | POST /api/ai/risk/{sid} | Risk for one job |
| Risk (all) | POST /api/ai/risk-all/{sid} | Risk for all jobs |
| Modernization | POST /api/ai/modernization/{sid} | Modernization path |
| Mod (all) | POST /api/ai/modernization-all/{sid} | All jobs modernization |
| Convert | POST /api/ai/convert/{sid} | Convert job code |
| Summary | POST /api/ai/executive-summary/{sid} | AI executive summary |
| Excel Report | GET /api/ai/report/{sid} | Download .xlsx report |
| JSON Report | GET /api/ai/report-json/{sid} | Full JSON dump |

---

## Without Gemini API Key

All features still work using **heuristic fallback**:
- Rule-based complexity scoring
- Regex-based source code parsing
- Pattern-based risk detection
- RAG keyword search (no embeddings needed)

---

## RAG Knowledge Base

17 knowledge documents across 6 categories:
- `modernization` — Shell→Python, SQL→Spark, Spring Batch, Control-M→Airflow
- `risk` — Fan-in/out, long runtime, FTP, hardcoded credentials
- `restartability` — Checkpoint, idempotency, dead letter queue
- `conversion` — Code templates for each migration path
- `bottleneck` — N+1 query, sequential processing, missing index
- `architecture` — Cloud batch, scheduler migration best practices

Optional FAISS vector index (install sentence-transformers) for semantic search.
Falls back to keyword search automatically.

---

## Folder Structure

```
backend/
  ai/
    __init__.py
    rag_knowledge.py      # RAG knowledge base + FAISS/keyword retrieval
    gemini_client.py      # Gemini API wrapper with retry + JSON parsing
    prompts.py            # All prompt templates
    assessment_engine.py  # Business logic — orchestrates RAG + Gemini
    report_generator.py   # Excel report (6 sheets) + JSON export
  routers/
    upload.py             # Phase-1: file upload
    graph.py              # Phase-1: graph build
    analysis.py           # Phase-1: critical path, fan metrics
    ai_assessment.py      # Phase-2: all AI endpoints
  main.py                 # FastAPI app — Phase 1 + 2 routers

frontend/src/
  components/
    AIAssessment/
      index.jsx           # All 5 AI feature tabs
    UploadPage/           # Phase-1 upload
    MultiFileView/        # Phase-1 diagrams
    Analysis/             # Phase-1 analysis
    Sidebar/              # Nav with Phase badges
  services/api.js         # Phase-1 + Phase-2 API calls
  hooks/useAppState.jsx   # Global state
```
