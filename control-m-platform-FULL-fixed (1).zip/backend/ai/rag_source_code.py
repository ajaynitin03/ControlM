"""
RAG pipeline for source code files.
Handles chunking, Google gemini-embedding-001 generation, FAISS indexing, and retrieval.
"""

from __future__ import annotations
import logging
import re
import os
import ssl
import numpy as np

# Global SSL bypass to address corporate network proxy/SSL inspection issues
try:
    ssl._create_default_https_context = ssl._create_unverified_context
except Exception:
    pass

logger = logging.getLogger(__name__)

# Try to import FAISS
try:
    import faiss
    FAISS_AVAILABLE = True
    logger.info("[RAG Source] FAISS is available — will use for fast ANN retrieval.")
except ImportError:
    FAISS_AVAILABLE = False
    logger.warning("[RAG Source] FAISS package not available. Falling back to local NumPy search.")

# Embedding dimension for gemini-embedding-001 is 768. Detected at runtime.
# We detect the actual dimension at index-build time, so this is just a sentinel.
_EMBEDDING_DIM_UNKNOWN = -1


class SourceCodeVectorStore:
    def __init__(self):
        # List of chunks: {text, job_id, job_name, application, source_file, source_type, embedding}
        self.chunks = []
        self.faiss_index = None
        self.embeddings_matrix = None
        self._embedding_dim = _EMBEDDING_DIM_UNKNOWN

    def clear(self):
        self.chunks = []
        self.faiss_index = None
        self.embeddings_matrix = None
        self._embedding_dim = _EMBEDDING_DIM_UNKNOWN

    def chunk_text(self, text: str, chunk_size_chars: int = 5000, overlap_chars: int = 800) -> list[str]:
        """
        Splits text into chunks of roughly 1000-1200 tokens (approx 4000-5000 chars)
        with 150-200 tokens overlap (approx 600-800 chars).
        """
        if not text.strip():
            return []

        chunks = []
        start = 0
        text_len = len(text)

        while start < text_len:
            end = start + chunk_size_chars
            chunk = text[start:end]
            chunks.append(chunk)
            start += (chunk_size_chars - overlap_chars)
            if chunk_size_chars <= overlap_chars:
                break

        return chunks

    def add_source_file(self, filename: str, content: str, mapped_jobs: list[dict]):
        """
        Chunks the file content and creates metadata mapping to all jobs associated with it.
        """
        if not mapped_jobs:
            mapped_jobs = [{
                "Job_ID": "unmapped",
                "Job_Name": "unmapped",
                "Application": "unmapped",
                "Source_File": filename,
                "Source_Type": "Unknown"
            }]

        file_chunks = self.chunk_text(content)
        logger.info(f"[RAG Source] Chunked {filename} into {len(file_chunks)} chunks for {len(mapped_jobs)} jobs.")

        for chunk_text in file_chunks:
            for job in mapped_jobs:
                self.chunks.append({
                    "text": chunk_text,
                    "job_id": job.get("Job_ID", ""),
                    "job_name": job.get("Job_Name", ""),
                    "application": job.get("Application", ""),
                    "source_file": job.get("Source_File", filename),
                    "source_type": job.get("Source_Type", "Unknown"),
                    "embedding": None
                })

    def _embed_text(self, client, text: str) -> list[float] | None:
        """
        Embed a single piece of text using the Gemini embedding model.
        Handles both old SDK shape (response.embedding.values) and
        new SDK shape (response.embeddings[0].values).
        Returns None on failure (caller handles fallback).
        """
        try:
            response = client.models.embed_content(
                model="gemini-embedding-001",
                contents=text,
            )
            # New google-genai SDK (>=0.8): response.embeddings is a list
            if hasattr(response, "embeddings") and response.embeddings:
                return list(response.embeddings[0].values)
            # Older SDK shape: response.embedding.values (single object)
            if hasattr(response, "embedding") and response.embedding:
                return list(response.embedding.values)
        except Exception as e:
            logger.warning(f"[RAG Source] embed_content failed: {e}")
        return None

    def _mock_embedding(self, text: str, dim: int = 768) -> list[float]:
        """Deterministic hash-based fallback embedding when Gemini is offline."""
        vec = np.zeros(dim)
        words = text.split()[:dim]
        for idx, word in enumerate(words):
            val = sum(ord(char) for char in word) % 100 / 100.0
            vec[idx % dim] = val
        return vec.tolist()

    def generate_embeddings(self, api_key: str):
        """
        Generates embeddings for all loaded chunks using gemini-embedding-001.
        Uses centralized gemini_client.embed_text() which handles:
          - Key rotation across multiple free-tier keys (GEMINI_API_KEY, GEMINI_API_KEY_2 ...)
          - 429 rate limit detection and backoff
          - Both old and new SDK response shapes
        Falls back to hash-based mock embeddings per chunk if Gemini unavailable.
        Rate-limits to ~13 RPM (4.5s sleep between calls) to stay safely within 15 RPM free tier.
        """
        if not self.chunks:
            return

        from ai.gemini_client import embed_text, is_available, _RPM_SLEEP

        fallback_dim = 768
        total = len(self.chunks)
        logger.info(f"[RAG Source] Generating embeddings for {total} chunks (rate-limited to ~13 RPM, 4.5s/call)...")

        for idx, chunk in enumerate(self.chunks):
            vec = None
            if is_available():
                vec = embed_text(chunk["text"])
                if vec is not None and self._embedding_dim == _EMBEDDING_DIM_UNKNOWN:
                    self._embedding_dim = len(vec)
                    fallback_dim = len(vec)
                    logger.info(f"[RAG Source] Embedding dim: {self._embedding_dim}")
                # Respect free-tier RPM — sleep between every embedding call
                if idx < total - 1:
                    time.sleep(_RPM_SLEEP)

            chunk["embedding"] = vec if vec is not None else self._mock_embedding(chunk["text"], fallback_dim)

            if (idx + 1) % 10 == 0:
                logger.info(f"[RAG Source] Embedded {idx+1}/{total} chunks...")

        real = sum(1 for c in self.chunks if c["embedding"] and len(c["embedding"]) > 10)
        logger.info(f"[RAG Source] Done. Real: {real}/{total}, Mock fallback: {total-real}/{total}")
        self.build_index()

    def build_index(self):
        """Builds the FAISS index (preferred) or prepares NumPy matrix fallback."""
        if not self.chunks:
            return

        embeddings_list = [c["embedding"] for c in self.chunks if c["embedding"] is not None]
        if not embeddings_list:
            logger.warning("[RAG Source] No embeddings available to build index.")
            return

        embeddings_arr = np.array(embeddings_list, dtype="float32")

        # Normalize for cosine similarity via inner product
        norms = np.linalg.norm(embeddings_arr, axis=1, keepdims=True)
        norms[norms == 0] = 1.0
        embeddings_arr = embeddings_arr / norms

        self.embeddings_matrix = embeddings_arr
        dimension = embeddings_arr.shape[1]

        if FAISS_AVAILABLE:
            try:
                # IndexFlatIP = exact inner-product search on normalized vectors = cosine sim
                self.faiss_index = faiss.IndexFlatIP(dimension)
                self.faiss_index.add(embeddings_arr)
                logger.info(f"[RAG Source] FAISS IndexFlatIP built: {self.faiss_index.ntotal} vectors, dim={dimension}.")
            except Exception as e:
                logger.error(f"[RAG Source] FAISS build failed, falling back to NumPy: {e}")
                self.faiss_index = None
        else:
            logger.info(f"[RAG Source] NumPy matrix ready: {len(embeddings_list)} vectors, dim={dimension}.")

    def _faiss_search(self, q_arr: np.ndarray, job_chunk_indices: list[int], top_k: int) -> list[int]:
        """
        Use the FAISS index to find the top_k most similar chunks from `job_chunk_indices`.
        Returns a list of indices into self.chunks.
        """
        # We must search within a subset. Strategy: search FAISS for top_k * 5 globally,
        # then filter to the job's chunk indices.
        search_k = min(top_k * 10, self.faiss_index.ntotal)
        scores, indices = self.faiss_index.search(q_arr.reshape(1, -1), search_k)
        flat_indices = indices[0].tolist()  # global chunk indices
        job_set = set(job_chunk_indices)

        # Keep only those in this job, preserving score order
        filtered = [idx for idx in flat_indices if idx in job_set and idx != -1]
        return filtered[:top_k]

    def _numpy_search(self, q_arr: np.ndarray, job_chunk_indices: list[int], top_k: int) -> list[int]:
        """NumPy fallback: compute cosine similarity for this job's chunks only."""
        if self.embeddings_matrix is None:
            return job_chunk_indices[:top_k]

        job_matrix = self.embeddings_matrix[job_chunk_indices]  # shape (N, dim)
        scores = job_matrix @ q_arr  # cosine sim since both are normalized
        sorted_local = np.argsort(-scores).tolist()
        return [job_chunk_indices[i] for i in sorted_local[:top_k]]

    def retrieve(self, query: str, job_id: str, api_key: str, top_k: int = 3) -> list[dict]:
        """
        Retrieves top_k chunks for the selected Job_ID using FAISS (if available) or NumPy.
        Filters chunks by Job_ID first, then ranks by query similarity.
        Falls back to TF-IDF keyword scoring if embedding fails.
        """
        # Get indices of chunks belonging to this job
        job_chunk_indices = [i for i, c in enumerate(self.chunks) if c["job_id"] == job_id]
        if not job_chunk_indices:
            logger.info(f"[RAG Source] No chunks found for job_id={job_id} in vector store.")
            return []

        # If we have fewer chunks than top_k, return them all
        if len(job_chunk_indices) <= top_k:
            return [self.chunks[i] for i in job_chunk_indices]

        # Get query embedding via centralized client (handles key rotation + 429)
        query_vector = None
        try:
            from ai.gemini_client import embed_text, is_available
            if is_available():
                query_vector = embed_text(query)
        except Exception as e:
            logger.warning(f"[RAG Source] Query embedding failed: {e}")

        # TF-IDF keyword fallback if query embedding failed
        if query_vector is None:
            logger.info("[RAG Source] Performing keyword fallback retrieval.")
            tokens = set(re.sub(r"[^\w\s]", " ", query.lower()).split())
            scored = []
            for idx in job_chunk_indices:
                score = sum(1 for t in tokens if t in self.chunks[idx]["text"].lower())
                scored.append((score, idx))
            scored.sort(key=lambda x: -x[0])
            return [self.chunks[idx] for _, idx in scored[:top_k]]

        # Normalize query vector
        q_arr = np.array(query_vector, dtype="float32")
        q_norm = np.linalg.norm(q_arr)
        if q_norm > 0:
            q_arr = q_arr / q_norm

        # Use FAISS if available and index is built, else NumPy
        if FAISS_AVAILABLE and self.faiss_index is not None:
            result_indices = self._faiss_search(q_arr, job_chunk_indices, top_k)
        else:
            result_indices = self._numpy_search(q_arr, job_chunk_indices, top_k)

        return [self.chunks[i] for i in result_indices]


# Global RAG store instance
rag_store = SourceCodeVectorStore()

# ── Per-session store registry ────────────────────────────────────────────────
# Each session gets its own isolated SourceCodeVectorStore so that multiple
# concurrent users don't overwrite each other's FAISS indexes.
_session_stores: dict[str, SourceCodeVectorStore] = {}


def get_store(session_id: str) -> SourceCodeVectorStore:
    """Return (creating if needed) the RAG store for a specific session."""
    if session_id not in _session_stores:
        _session_stores[session_id] = SourceCodeVectorStore()
    return _session_stores[session_id]


def clear_store(session_id: str) -> None:
    """Remove the RAG store for a session (called on clear-inputs)."""
    if session_id in _session_stores:
        _session_stores[session_id].clear()
        del _session_stores[session_id]
