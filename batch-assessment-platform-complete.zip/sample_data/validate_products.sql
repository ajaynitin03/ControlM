-- ============================================================
-- FIN_JOB_003 — VALIDATE_PRODUCTS
-- Validates product catalogue loaded in stg_products_master:
--   1. Mandatory field checks
--   2. Tax code lookup against ref.tax_codes
--   3. Base rate range check (must be between 0.001 and 0.99)
--   4. Effective date check (cannot be in past > 30 days)
-- ============================================================

BEGIN;

-- ── 1. Mandatory field nulls ──────────────────────────────────────
INSERT INTO validation_errors (job_id, table_name, error_type, error_detail, run_date)
SELECT
    'FIN_JOB_003', 'stg_products_master', 'NULL_CHECK',
    'product_id=' || COALESCE(product_id::TEXT,'NULL')
        || ' name=' || COALESCE(product_name,'NULL')
        || ' tax_code=' || COALESCE(tax_code,'NULL'),
    NOW()
FROM stg_products_master
WHERE product_id IS NULL
   OR product_name IS NULL
   OR tax_code IS NULL
   OR base_rate IS NULL
   OR effective_date IS NULL;

-- ── 2. Tax code referential integrity ────────────────────────────
INSERT INTO validation_errors (job_id, table_name, error_type, error_detail, run_date)
SELECT
    'FIN_JOB_003', 'stg_products_master', 'INVALID_TAX_CODE',
    'product_id=' || p.product_id::TEXT
        || ' tax_code=' || p.tax_code || ' not in ref.tax_codes',
    NOW()
FROM stg_products_master p
LEFT JOIN ref.tax_codes t
       ON p.tax_code = t.tax_code
      AND t.is_active = TRUE
WHERE t.tax_code IS NULL;

-- ── 3. Rate range check ───────────────────────────────────────────
INSERT INTO validation_errors (job_id, table_name, error_type, error_detail, run_date)
SELECT
    'FIN_JOB_003', 'stg_products_master', 'RATE_OUT_OF_RANGE',
    'product_id=' || product_id::TEXT || ' base_rate=' || base_rate::TEXT,
    NOW()
FROM stg_products_master
WHERE base_rate < 0.001 OR base_rate > 0.99;

-- ── 4. Effective date check ───────────────────────────────────────
INSERT INTO validation_errors (job_id, table_name, error_type, error_detail, run_date)
SELECT
    'FIN_JOB_003', 'stg_products_master', 'STALE_EFFECTIVE_DATE',
    'product_id=' || product_id::TEXT || ' effective_date=' || effective_date::TEXT,
    NOW()
FROM stg_products_master
WHERE effective_date < CURRENT_DATE - INTERVAL '30 days';

-- ── 5. Abort if any errors ────────────────────────────────────────
DO $$
DECLARE v_errors INT;
BEGIN
    SELECT COUNT(*) INTO v_errors FROM validation_errors
    WHERE job_id = 'FIN_JOB_003' AND run_date >= CURRENT_DATE;
    IF v_errors > 0 THEN
        RAISE EXCEPTION 'VALIDATE_PRODUCTS: % error(s). Check validation_errors.', v_errors;
    END IF;
END;
$$;

-- ── 6. Mark valid ─────────────────────────────────────────────────
UPDATE stg_products_master
SET validation_status = 'VALID', validated_at = NOW();

INSERT INTO job_audit_log (job_id, job_name, run_date, rows_loaded, status)
VALUES ('FIN_JOB_003', 'VALIDATE_PRODUCTS', NOW(),
        (SELECT COUNT(*) FROM stg_products_master WHERE validation_status='VALID'),
        'SUCCESS');

COMMIT;
