-- ============================================================
-- FIN_JOB_004 — MERGE_REFERENCE_DATA
-- Merges validated customers and products into a unified
-- reference dimension table used by all downstream jobs.
-- Uses: INNER JOIN, LEFT JOIN, UPSERT (INSERT ON CONFLICT),
--       window functions, and CTEs.
-- ============================================================

BEGIN;

-- ── CTE 1: Latest valid account per customer ──────────────────────
WITH ranked_accounts AS (
    SELECT
        a.account_id,
        a.customer_id,
        a.account_type,
        a.currency,
        a.open_date,
        c.customer_name,
        c.customer_tier,       -- GOLD / SILVER / STANDARD
        c.region,
        c.relationship_manager,
        ROW_NUMBER() OVER (
            PARTITION BY a.customer_id
            ORDER BY a.open_date DESC, a.account_id
        ) AS rn
    FROM stg_accounts_master a
    INNER JOIN crm.customers c
           ON a.customer_id = c.customer_id
          AND c.status = 'ACTIVE'
    WHERE a.validation_status = 'VALID'
),

-- ── CTE 2: Enrich with primary product per account type ──────────
account_with_product AS (
    SELECT
        ra.*,
        p.product_id,
        p.product_name,
        p.base_rate,
        p.tax_code,
        t.tax_rate,
        p.category AS product_category
    FROM ranked_accounts ra
    LEFT JOIN stg_products_master p
           ON ra.account_type = p.category
          AND p.validation_status = 'VALID'
    LEFT JOIN ref.tax_codes t
           ON p.tax_code = t.tax_code
          AND t.is_active = TRUE
    WHERE ra.rn = 1
),

-- ── CTE 3: Derive effective interest and net rate ─────────────────
enriched AS (
    SELECT
        awp.*,
        ROUND(awp.base_rate * (1 - COALESCE(awp.tax_rate, 0)), 6) AS net_rate,
        CASE awp.customer_tier
            WHEN 'GOLD'     THEN awp.base_rate * 0.95
            WHEN 'SILVER'   THEN awp.base_rate * 0.98
            ELSE                 awp.base_rate
        END AS effective_rate
    FROM account_with_product awp
)

-- ── Upsert into reference dimension ──────────────────────────────
INSERT INTO ref.customer_product_dim (
    account_id, customer_id, customer_name, customer_tier,
    region, relationship_manager, account_type, currency,
    open_date, product_id, product_name, product_category,
    base_rate, net_rate, effective_rate, tax_code, tax_rate,
    last_updated
)
SELECT
    account_id, customer_id, customer_name, customer_tier,
    region, relationship_manager, account_type, currency,
    open_date, product_id, product_name, product_category,
    base_rate, net_rate, effective_rate, tax_code, tax_rate,
    NOW()
FROM enriched
ON CONFLICT (account_id) DO UPDATE SET
    customer_name        = EXCLUDED.customer_name,
    customer_tier        = EXCLUDED.customer_tier,
    effective_rate       = EXCLUDED.effective_rate,
    net_rate             = EXCLUDED.net_rate,
    tax_rate             = EXCLUDED.tax_rate,
    last_updated         = NOW();

INSERT INTO job_audit_log (job_id, job_name, run_date, rows_loaded, status)
VALUES ('FIN_JOB_004', 'MERGE_REFERENCE_DATA', NOW(),
        (SELECT COUNT(*) FROM ref.customer_product_dim WHERE last_updated >= CURRENT_DATE),
        'SUCCESS');

COMMIT;
