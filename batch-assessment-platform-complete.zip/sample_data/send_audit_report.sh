#!/bin/bash
# ============================================================
# FIN_JOB_014 — SEND_AUDIT_REPORT
# Delivers the full audit trail CSV to the compliance system
# via encrypted SFTP with PGP signature verification.
# Stricter than other delivery jobs:
#   - PGP signs the file before sending
#   - Sends a delivery manifest to the compliance portal API
#   - Retains local copy in immutable archive
# ============================================================

set -euo pipefail

RUN_DATE=$(date +%Y%m%d)
REPORT_DIR="/data/reports/finance/$(date +%Y/%m/%d)"
ARCHIVE_DIR="/data/archive/compliance/$(date +%Y/%m/%d)"
LOG="/var/log/finance/send_audit_report_${RUN_DATE}.log"

AUDIT_FILE="$REPORT_DIR/audit_trail_${RUN_DATE}.csv"
SIGNED_FILE="$REPORT_DIR/audit_trail_${RUN_DATE}.csv.gpg"

SFTP_HOST="sftp.compliance.internal"
SFTP_USER="fin.audit"
SFTP_REMOTE="/inbound/audit/${RUN_DATE}"

COMPLIANCE_API="https://compliance.fininternal.net/api/v2/delivery"
PGP_KEY_ID="COMPLIANCE_PUBKEY_2024"

echo "[$(date)] START send_audit_report" | tee -a "$LOG"
mkdir -p "$ARCHIVE_DIR"

# ── Step 1: Verify audit file exists and has content ─────────────
if [ ! -f "$AUDIT_FILE" ]; then
  echo "[$(date)] ERROR: Audit file not found: $AUDIT_FILE" | tee -a "$LOG"
  exit 1
fi
ROW_COUNT=$(tail -n +2 "$AUDIT_FILE" | wc -l)
if [ "$ROW_COUNT" -eq 0 ]; then
  echo "[$(date)] ERROR: Audit file is empty" | tee -a "$LOG"
  exit 2
fi
echo "[$(date)] Audit file verified: $ROW_COUNT transaction rows" | tee -a "$LOG"

# ── Step 2: PGP sign and encrypt ─────────────────────────────────
gpg --output "$SIGNED_FILE" \
    --encrypt \
    --sign \
    --recipient "$PGP_KEY_ID" \
    "$AUDIT_FILE"

if [ $? -ne 0 ]; then
  echo "[$(date)] ERROR: PGP signing failed" | tee -a "$LOG"
  exit 3
fi
echo "[$(date)] PGP signature applied: $SIGNED_FILE" | tee -a "$LOG"

# ── Step 3: SHA-256 manifest ──────────────────────────────────────
MANIFEST_FILE="$REPORT_DIR/audit_manifest_${RUN_DATE}.txt"
sha256sum "$AUDIT_FILE" "$SIGNED_FILE" > "$MANIFEST_FILE"
echo "[$(date)] Manifest written: $MANIFEST_FILE" | tee -a "$LOG"

# ── Step 4: SFTP delivery ─────────────────────────────────────────
sftp -b - "$SFTP_USER@$SFTP_HOST" << SFTP_BLOCK >> "$LOG" 2>&1
  mkdir $SFTP_REMOTE
  cd $SFTP_REMOTE
  put $SIGNED_FILE
  put $MANIFEST_FILE
  bye
SFTP_BLOCK

RC=$?
if [ $RC -ne 0 ]; then
  echo "[$(date)] ERROR: SFTP delivery failed (rc=$RC)" | tee -a "$LOG"
  exit 4
fi

# ── Step 5: Notify compliance portal API ─────────────────────────
PAYLOAD=$(cat << JSON
{
  "job_id":        "FIN_JOB_014",
  "report_type":   "AUDIT_TRAIL",
  "report_date":   "$(date +%Y-%m-%d)",
  "row_count":     $ROW_COUNT,
  "file_path":     "$SFTP_REMOTE/$(basename $SIGNED_FILE)",
  "sha256":        "$(sha256sum $AUDIT_FILE | awk '{print $1}')",
  "delivered_by":  "fin.audit",
  "delivered_at":  "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
}
JSON
)
HTTP_STATUS=$(curl -s -o /dev/null -w "%{http_code}" \
  -X POST "$COMPLIANCE_API" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $COMPLIANCE_API_TOKEN" \
  -d "$PAYLOAD")

if [ "$HTTP_STATUS" != "201" ]; then
  echo "[$(date)] WARNING: Compliance portal API returned HTTP $HTTP_STATUS" | tee -a "$LOG"
  # Non-fatal — file already delivered via SFTP
fi

# ── Step 6: Archive immutable copy ───────────────────────────────
cp "$AUDIT_FILE" "$ARCHIVE_DIR/"
cp "$SIGNED_FILE" "$ARCHIVE_DIR/"
cp "$MANIFEST_FILE" "$ARCHIVE_DIR/"
chmod 444 "$ARCHIVE_DIR"/*
echo "[$(date)] Files archived (read-only) to $ARCHIVE_DIR" | tee -a "$LOG"

# ── Audit log ─────────────────────────────────────────────────────
psql -h findb01.internal -U fin_loader -d finance_staging << SQL
INSERT INTO job_audit_log (job_id, job_name, run_date, rows_loaded, status)
VALUES ('FIN_JOB_014', 'SEND_AUDIT_REPORT', NOW(), $ROW_COUNT, 'SUCCESS');
SQL

echo "[$(date)] DONE send_audit_report — $ROW_COUNT transactions delivered to compliance" | tee -a "$LOG"
exit 0
