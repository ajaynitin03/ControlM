-- ============================================================
-- FIN_JOB_008 — CALCULATE_LIMITS
-- Recalculates per-customer daily spending and credit limits.
-- Uses aggregation windows, LAG for change detection,
-- and updates the customer_limits table transactionally.
-- ============================================================

BEGIN;

WITH

-- ── CTE 1: Today's spending per account ──────────────────────────
daily_spend AS (
    SELECT
        ts.account_id,
        SUM(ts.amount) FILTER (WHERE ts.txn_type IN ('PURCHASE','WITHDRAWAL','TRANSFER'))
                                                        AS total_spent_today,
        COUNT(*) FILTER (WHERE ts.txn_type = 'PURCHASE')
                                                        AS purchase_count,
        MAX(ts.amount)                                  AS max_single_txn
    FROM transactions_staging ts
    WHERE ts.load_date = CURRENT_DATE
    GROUP BY ts.account_id
),

-- ── CTE 2: 7-day rolling average spend per account ───────────────
rolling_spend AS (
    SELECT
        account_id,
        AVG(daily_total) OVER (
            PARTITION BY account_id
            ORDER BY spend_date
            ROWS BETWEEN 6 PRECEDING AND CURRENT ROW
        )                                               AS rolling_7d_avg,
        spend_date
    FROM (
        SELECT
            account_id,
            load_date                                   AS spend_date,
            SUM(amount) FILTER (
                WHERE txn_type IN ('PURCHASE','WITHDRAWAL','TRANSFER')
            )                                           AS daily_total
        FROM transactions_staging
        WHERE load_date >= CURRENT_DATE - INTERVAL '7 days'
        GROUP BY account_id, load_date
    ) daily_agg
),

-- ── CTE 3: Current limits from previous cycle ────────────────────
current_limits AS (
    SELECT
        cl.account_id,
        cl.credit_limit,
        cl.daily_limit,
        cl.available_credit,
        cl.limit_band,
        LAG(cl.credit_limit) OVER (
            PARTITION BY cl.account_id ORDER BY cl.effective_date
        )                                               AS prev_credit_limit
    FROM customer_limits cl
    WHERE cl.effective_date = CURRENT_DATE - INTERVAL '1 day'
),

-- ── CTE 4: New limit calculation ─────────────────────────────────
new_limits AS (
    SELECT
        cpd.account_id,
        cpd.customer_id,
        cpd.customer_tier,
        COALESCE(ds.total_spent_today, 0)               AS spent_today,
        COALESCE(rs.rolling_7d_avg, 0)                  AS rolling_7d_avg,
        COALESCE(cl.credit_limit, 0)                    AS current_credit_limit,

        -- New daily limit: tier-based floor + rolling average buffer
        GREATEST(
            CASE cpd.customer_tier
                WHEN 'GOLD'   THEN 10000
                WHEN 'SILVER' THEN  5000
                ELSE               1000
            END,
            ROUND(COALESCE(rs.rolling_7d_avg, 0) * 1.20, 0)  -- 20% buffer over rolling avg
        )                                               AS new_daily_limit,

        -- Available credit = existing credit limit minus today's spend
        GREATEST(0, COALESCE(cl.credit_limit, 0) - COALESCE(ds.total_spent_today, 0))
                                                        AS new_available_credit,

        -- Flag if credit limit changed from yesterday
        CASE
            WHEN cl.credit_limit IS DISTINCT FROM cl.prev_credit_limit THEN TRUE
            ELSE FALSE
        END                                             AS limit_changed_flag

    FROM ref.customer_product_dim cpd
    LEFT JOIN daily_spend ds        ON cpd.account_id = ds.account_id
    LEFT JOIN rolling_spend rs      ON cpd.account_id = rs.account_id
                                   AND rs.spend_date = CURRENT_DATE
    LEFT JOIN current_limits cl     ON cpd.account_id = cl.account_id
)

-- ── Upsert limits ─────────────────────────────────────────────────
INSERT INTO customer_limits (
    account_id, customer_id, customer_tier,
    daily_limit, credit_limit, available_credit,
    spent_today, rolling_7d_avg,
    limit_band, limit_changed_flag, effective_date
)
SELECT
    account_id, customer_id, customer_tier,
    new_daily_limit             AS daily_limit,
    current_credit_limit        AS credit_limit,
    new_available_credit        AS available_credit,
    spent_today,
    rolling_7d_avg,
    CASE
        WHEN new_daily_limit >= 10000 THEN 'PREMIUM'
        WHEN new_daily_limit >= 5000  THEN 'STANDARD'
        ELSE                               'BASIC'
    END                         AS limit_band,
    limit_changed_flag,
    CURRENT_DATE                AS effective_date
FROM new_limits
ON CONFLICT (account_id, effective_date) DO UPDATE SET
    daily_limit          = EXCLUDED.daily_limit,
    available_credit     = EXCLUDED.available_credit,
    spent_today          = EXCLUDED.spent_today,
    rolling_7d_avg       = EXCLUDED.rolling_7d_avg,
    limit_band           = EXCLUDED.limit_band,
    limit_changed_flag   = EXCLUDED.limit_changed_flag;

INSERT INTO job_audit_log (job_id, job_name, run_date, rows_loaded, status)
SELECT 'FIN_JOB_008', 'CALCULATE_LIMITS', NOW(), COUNT(*), 'SUCCESS'
FROM customer_limits WHERE effective_date = CURRENT_DATE;

COMMIT;
