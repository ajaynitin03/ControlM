-- ============================================================
-- FIN_JOB_002 — VALIDATE_CUSTOMERS
-- Full validation suite on stg_accounts_master:
--   1. Null / mandatory field checks
--   2. Referential integrity against CRM customer table
--   3. Duplicate detection
--   4. Business rule checks (account type, currency whitelist)
-- Any failures are written to validation_errors and job aborts.
-- ============================================================

BEGIN;

-- ── 1. Null checks ────────────────────────────────────────────────
INSERT INTO validation_errors (job_id, table_name, error_type, error_detail, run_date)
SELECT
    'FIN_JOB_002',
    'stg_accounts_master',
    'NULL_CHECK',
    'account_id=' || COALESCE(account_id::TEXT, 'NULL')
        || ' customer_id=' || COALESCE(customer_id::TEXT, 'NULL'),
    NOW()
FROM stg_accounts_master
WHERE account_id IS NULL
   OR customer_id IS NULL
   OR account_type IS NULL
   OR currency IS NULL
   OR open_date IS NULL;

-- ── 2. Referential integrity — customer must exist in CRM ────────
INSERT INTO validation_errors (job_id, table_name, error_type, error_detail, run_date)
SELECT
    'FIN_JOB_002',
    'stg_accounts_master',
    'REF_INTEGRITY',
    'customer_id=' || a.customer_id::TEXT || ' not found in crm.customers',
    NOW()
FROM stg_accounts_master a
LEFT JOIN crm.customers c
       ON a.customer_id = c.customer_id
      AND c.status = 'ACTIVE'
WHERE c.customer_id IS NULL;

-- ── 3. Duplicate detection ────────────────────────────────────────
INSERT INTO validation_errors (job_id, table_name, error_type, error_detail, run_date)
SELECT
    'FIN_JOB_002',
    'stg_accounts_master',
    'DUPLICATE',
    'account_id=' || account_id::TEXT || ' appears ' || COUNT(*)::TEXT || ' times',
    NOW()
FROM stg_accounts_master
GROUP BY account_id
HAVING COUNT(*) > 1;

-- ── 4. Business rules — allowed account types and currencies ──────
INSERT INTO validation_errors (job_id, table_name, error_type, error_detail, run_date)
SELECT
    'FIN_JOB_002',
    'stg_accounts_master',
    'BUSINESS_RULE',
    'account_id=' || account_id::TEXT
        || ' invalid account_type=' || account_type
        || ' or currency=' || currency,
    NOW()
FROM stg_accounts_master
WHERE account_type NOT IN ('CURRENT', 'SAVINGS', 'LOAN', 'CREDIT', 'INVESTMENT')
   OR currency NOT IN (
        SELECT currency_code FROM ref.allowed_currencies WHERE is_active = TRUE
   );

-- ── 5. Abort if any errors found ─────────────────────────────────
DO $$
DECLARE
    v_errors INT;
BEGIN
    SELECT COUNT(*) INTO v_errors
    FROM validation_errors
    WHERE job_id = 'FIN_JOB_002'
      AND run_date >= CURRENT_DATE;

    IF v_errors > 0 THEN
        RAISE EXCEPTION 'VALIDATE_CUSTOMERS failed: % validation error(s) found. Check validation_errors table.', v_errors;
    END IF;
END;
$$;

-- ── 6. Mark valid records ─────────────────────────────────────────
UPDATE stg_accounts_master
SET validation_status = 'VALID',
    validated_at = NOW()
WHERE account_id NOT IN (
    SELECT CAST(split_part(error_detail, '=', 2) AS BIGINT)
    FROM validation_errors
    WHERE job_id = 'FIN_JOB_002'
      AND run_date >= CURRENT_DATE
      AND error_detail LIKE 'account_id=%'
);

INSERT INTO job_audit_log (job_id, job_name, run_date, rows_loaded, status)
SELECT 'FIN_JOB_002', 'VALIDATE_CUSTOMERS', NOW(),
       COUNT(*) FILTER (WHERE validation_status = 'VALID'),
       'SUCCESS'
FROM stg_accounts_master;

COMMIT;
