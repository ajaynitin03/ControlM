-- ============================================================
-- FIN_JOB_006 — CALCULATE_FEES
-- Applies tiered fee schedules to each transaction.
-- Joins: transactions_staging × fee_schedules × customer_product_dim
--        × ref.fee_overrides (LEFT JOIN — not all customers have overrides)
-- Writes results to: txn_fees (partitioned by txn_date)
-- ============================================================

BEGIN;

-- Clear today's fee calculations (idempotent)
DELETE FROM txn_fees WHERE calc_date = CURRENT_DATE;

INSERT INTO txn_fees (
    txn_id, account_id, customer_id, customer_tier,
    txn_type, txn_date, amount, currency,
    base_fee_rate, override_fee_rate, effective_fee_rate,
    fee_amount, fee_currency, calc_date
)
SELECT
    ts.txn_id,
    ts.account_id,
    cpd.customer_id,
    cpd.customer_tier,
    ts.txn_type,
    ts.txn_date,
    ts.amount,
    ts.currency,

    -- Base fee rate from fee schedule (INNER JOIN — every txn_type must have a schedule)
    fs.fee_rate                                         AS base_fee_rate,

    -- Optional override (LEFT JOIN — may not exist)
    fo.override_rate                                    AS override_fee_rate,

    -- Effective rate: use override if present, else tier-adjusted base
    COALESCE(
        fo.override_rate,
        CASE cpd.customer_tier
            WHEN 'GOLD'   THEN fs.fee_rate * 0.80   -- 20% discount
            WHEN 'SILVER' THEN fs.fee_rate * 0.90   -- 10% discount
            ELSE               fs.fee_rate
        END
    )                                                   AS effective_fee_rate,

    -- Fee amount in transaction currency
    ROUND(
        ts.amount * COALESCE(
            fo.override_rate,
            CASE cpd.customer_tier
                WHEN 'GOLD'   THEN fs.fee_rate * 0.80
                WHEN 'SILVER' THEN fs.fee_rate * 0.90
                ELSE               fs.fee_rate
            END
        ), 2
    )                                                   AS fee_amount,

    ts.currency                                         AS fee_currency,
    CURRENT_DATE                                        AS calc_date

FROM transactions_staging ts

INNER JOIN ref.customer_product_dim cpd
        ON ts.account_id = cpd.account_id

INNER JOIN ref.fee_schedules fs
        ON ts.txn_type     = fs.txn_type
       AND ts.currency     = fs.currency
       AND CURRENT_DATE BETWEEN fs.effective_from AND COALESCE(fs.effective_to, '9999-12-31')

LEFT JOIN ref.fee_overrides fo
       ON cpd.customer_id  = fo.customer_id
      AND ts.txn_type      = fo.txn_type
      AND CURRENT_DATE BETWEEN fo.valid_from AND COALESCE(fo.valid_to, '9999-12-31')

WHERE ts.load_date = CURRENT_DATE;

-- Sanity: every transaction must have a computed fee
DO $$
DECLARE v_missing INT;
BEGIN
    SELECT COUNT(*) INTO v_missing
    FROM transactions_staging ts
    LEFT JOIN txn_fees f ON ts.txn_id = f.txn_id AND f.calc_date = CURRENT_DATE
    WHERE ts.load_date = CURRENT_DATE
      AND f.txn_id IS NULL;
    IF v_missing > 0 THEN
        RAISE EXCEPTION 'CALCULATE_FEES: % transactions have no computed fee (check fee_schedules coverage)', v_missing;
    END IF;
END;
$$;

INSERT INTO job_audit_log (job_id, job_name, run_date, rows_loaded, status)
SELECT 'FIN_JOB_006', 'CALCULATE_FEES', NOW(), COUNT(*), 'SUCCESS'
FROM txn_fees WHERE calc_date = CURRENT_DATE;

COMMIT;
