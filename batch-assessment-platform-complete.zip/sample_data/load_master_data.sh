#!/bin/bash
# ============================================================
# FIN_JOB_001 — LOAD_MASTER_DATA
# Pulls accounts + products master files from SFTP landing zone,
# verifies checksums, and bulk-loads into staging tables.
# ============================================================

set -euo pipefail

LOG="/var/log/finance/load_master_data_$(date +%Y%m%d).log"
STAGING_DIR="/data/staging/finance"
SFTP_HOST="sftp.findata.internal"
SFTP_USER="fin.admin"
SFTP_REMOTE="/outbound/master"

echo "[$(date)] START load_master_data" | tee -a "$LOG"

# ── Step 1: Pull files from SFTP ─────────────────────────────────
mkdir -p "$STAGING_DIR"
sftp -b - "$SFTP_USER@$SFTP_HOST" << SFTP_CMDS 2>>"$LOG"
  get $SFTP_REMOTE/accounts_master.dat $STAGING_DIR/accounts_master.dat
  get $SFTP_REMOTE/accounts_master.dat.md5 $STAGING_DIR/accounts_master.dat.md5
  get $SFTP_REMOTE/products_master.dat $STAGING_DIR/products_master.dat
  get $SFTP_REMOTE/products_master.dat.md5 $STAGING_DIR/products_master.dat.md5
  bye
SFTP_CMDS

if [ $? -ne 0 ]; then
  echo "[$(date)] ERROR: SFTP transfer failed" | tee -a "$LOG"
  exit 1
fi

# ── Step 2: Checksum verification ────────────────────────────────
for FILE in accounts_master.dat products_master.dat; do
  EXPECTED=$(cat "$STAGING_DIR/${FILE}.md5")
  ACTUAL=$(md5sum "$STAGING_DIR/$FILE" | awk '{print $1}')
  if [ "$EXPECTED" != "$ACTUAL" ]; then
    echo "[$(date)] ERROR: Checksum mismatch for $FILE. Expected=$EXPECTED Got=$ACTUAL" | tee -a "$LOG"
    exit 2
  fi
  echo "[$(date)] Checksum OK: $FILE" | tee -a "$LOG"
done

# ── Step 3: Record counts pre-load ────────────────────────────────
ACCT_LINES=$(wc -l < "$STAGING_DIR/accounts_master.dat")
PROD_LINES=$(wc -l < "$STAGING_DIR/products_master.dat")
echo "[$(date)] Input rows — Accounts: $ACCT_LINES  Products: $PROD_LINES" | tee -a "$LOG"

# ── Step 4: Bulk load into DB staging tables ──────────────────────
DB_HOST="findb01.internal"
DB_NAME="finance_staging"

psql -h "$DB_HOST" -U fin_loader -d "$DB_NAME" << SQL_BLOCK
BEGIN;

TRUNCATE TABLE stg_accounts_master;
TRUNCATE TABLE stg_products_master;

COPY stg_accounts_master (account_id, customer_id, account_type, currency, open_date, status)
FROM '$STAGING_DIR/accounts_master.dat'
WITH (FORMAT csv, HEADER true, DELIMITER '|', NULL 'NULL');

COPY stg_products_master (product_id, product_name, category, base_rate, tax_code, effective_date)
FROM '$STAGING_DIR/products_master.dat'
WITH (FORMAT csv, HEADER true, DELIMITER '|', NULL 'NULL');

-- Audit log entry
INSERT INTO job_audit_log (job_id, job_name, run_date, rows_loaded, status)
VALUES ('FIN_JOB_001', 'LOAD_MASTER_DATA', NOW(),
        (SELECT COUNT(*) FROM stg_accounts_master) + (SELECT COUNT(*) FROM stg_products_master),
        'SUCCESS');

COMMIT;
SQL_BLOCK

RC=$?
if [ $RC -ne 0 ]; then
  echo "[$(date)] ERROR: DB bulk load failed (rc=$RC)" | tee -a "$LOG"
  exit 3
fi

echo "[$(date)] DONE load_master_data — Accounts loaded: $ACCT_LINES  Products loaded: $PROD_LINES" | tee -a "$LOG"
exit 0
