#!/bin/bash
# ============================================================
# FIN_JOB_005 — LOAD_TRANSACTIONS
# Downloads nightly transaction files from SFTP,
# verifies row counts + checksums, then bulk-loads into
# transactions_staging with full restart capability.
# ============================================================

set -euo pipefail

LOG="/var/log/finance/load_transactions_$(date +%Y%m%d).log"
STAGING_DIR="/data/staging/finance/transactions"
ARCHIVE_DIR="/data/archive/finance/transactions/$(date +%Y/%m/%d)"
SFTP_HOST="sftp.clearinghouse.internal"
SFTP_USER="fin.admin"
SFTP_REMOTE="/outbound/transactions/$(date +%Y%m%d)"
DB_HOST="findb01.internal"
DB_NAME="finance_staging"
EXPECTED_MIN_ROWS=1000   # SLA: at least 1000 transactions per night

echo "[$(date)] START load_transactions" | tee -a "$LOG"
mkdir -p "$STAGING_DIR" "$ARCHIVE_DIR"

# ── Step 1: List and download all transaction files ───────────────
echo "[$(date)] Connecting to $SFTP_HOST" | tee -a "$LOG"
sftp -b - "$SFTP_USER@$SFTP_HOST" << SFTP_BLOCK 2>>"$LOG"
  lcd $STAGING_DIR
  cd $SFTP_REMOTE
  mget txn_*.dat
  mget txn_*.dat.md5
  mget txn_*.dat.rowcount
  bye
SFTP_BLOCK

if [ $? -ne 0 ]; then
  echo "[$(date)] ERROR: SFTP download failed" | tee -a "$LOG"
  exit 1
fi

TOTAL_FILES=$(ls "$STAGING_DIR"/txn_*.dat 2>/dev/null | wc -l)
echo "[$(date)] Downloaded $TOTAL_FILES transaction file(s)" | tee -a "$LOG"

if [ "$TOTAL_FILES" -eq 0 ]; then
  echo "[$(date)] ERROR: No transaction files found for $(date +%Y%m%d)" | tee -a "$LOG"
  exit 2
fi

# ── Step 2: Verify each file ──────────────────────────────────────
TOTAL_ROWS=0
for DATFILE in "$STAGING_DIR"/txn_*.dat; do
  BASENAME=$(basename "$DATFILE")

  # Checksum
  EXPECTED_MD5=$(cat "${DATFILE}.md5")
  ACTUAL_MD5=$(md5sum "$DATFILE" | awk '{print $1}')
  if [ "$EXPECTED_MD5" != "$ACTUAL_MD5" ]; then
    echo "[$(date)] ERROR: Checksum mismatch for $BASENAME" | tee -a "$LOG"
    exit 3
  fi

  # Row count
  EXPECTED_ROWS=$(cat "${DATFILE}.rowcount")
  ACTUAL_ROWS=$(tail -n +2 "$DATFILE" | wc -l)  # skip header
  if [ "$ACTUAL_ROWS" -ne "$EXPECTED_ROWS" ]; then
    echo "[$(date)] ERROR: Row count mismatch for $BASENAME. Expected=$EXPECTED_ROWS Got=$ACTUAL_ROWS" | tee -a "$LOG"
    exit 4
  fi

  TOTAL_ROWS=$((TOTAL_ROWS + ACTUAL_ROWS))
  echo "[$(date)] OK: $BASENAME rows=$ACTUAL_ROWS" | tee -a "$LOG"
done

echo "[$(date)] Total rows across all files: $TOTAL_ROWS" | tee -a "$LOG"

# SLA check
if [ "$TOTAL_ROWS" -lt "$EXPECTED_MIN_ROWS" ]; then
  echo "[$(date)] WARNING: Row count $TOTAL_ROWS below SLA minimum $EXPECTED_MIN_ROWS" | tee -a "$LOG"
  # Non-fatal: continue but flag in audit
fi

# ── Step 3: Bulk load — transactional, idempotent ─────────────────
psql -h "$DB_HOST" -U fin_loader -d "$DB_NAME" << SQL_BLOCK
BEGIN;

-- Clear today's staged transactions (idempotent restart)
DELETE FROM transactions_staging
WHERE load_date = CURRENT_DATE;

-- Load each file
$(for DATFILE in "$STAGING_DIR"/txn_*.dat; do
  echo "COPY transactions_staging (
      txn_id, account_id, txn_type, txn_date, amount,
      currency, counterparty_id, channel, reference_code, load_date
  ) FROM '$DATFILE'
  WITH (FORMAT csv, HEADER true, DELIMITER '|', NULL 'NULL');"
  echo "-- Loaded: $(basename $DATFILE)"
done)

-- Post-load integrity: no orphan account_ids
DO \$\$
DECLARE v_orphans INT;
BEGIN
    SELECT COUNT(*) INTO v_orphans
    FROM transactions_staging ts
    LEFT JOIN ref.customer_product_dim cpd ON ts.account_id = cpd.account_id
    WHERE cpd.account_id IS NULL
      AND ts.load_date = CURRENT_DATE;
    IF v_orphans > 0 THEN
        RAISE EXCEPTION 'LOAD_TRANSACTIONS: % orphan account_id(s) — no matching reference dimension', v_orphans;
    END IF;
END;
\$\$;

INSERT INTO job_audit_log (job_id, job_name, run_date, rows_loaded, status)
VALUES ('FIN_JOB_005', 'LOAD_TRANSACTIONS', NOW(), $TOTAL_ROWS, 'SUCCESS');

COMMIT;
SQL_BLOCK

RC=$?
if [ $RC -ne 0 ]; then
  echo "[$(date)] ERROR: DB load failed (rc=$RC)" | tee -a "$LOG"
  exit 5
fi

# ── Step 4: Archive processed files ──────────────────────────────
mv "$STAGING_DIR"/txn_*.dat* "$ARCHIVE_DIR/"
echo "[$(date)] Files archived to $ARCHIVE_DIR" | tee -a "$LOG"

echo "[$(date)] DONE load_transactions — $TOTAL_ROWS rows loaded from $TOTAL_FILES files" | tee -a "$LOG"
exit 0
