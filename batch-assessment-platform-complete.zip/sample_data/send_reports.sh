#!/bin/bash
# ============================================================
# FIN_JOB_011/012/013 — SEND_FINANCE_REPORT / SEND_RISK_REPORT / SEND_LIMIT_REPORT
# Determines which report to send based on REPORT_TYPE env var.
# Delivers the corresponding file from the nightly report folder
# to the target SFTP destination for each stakeholder group.
# ============================================================

set -euo pipefail

REPORT_TYPE="${REPORT_TYPE:-FINANCE}"   # FINANCE | RISK | LIMIT
RUN_DATE=$(date +%Y%m%d)
REPORT_DIR="/data/reports/finance/$(date +%Y/%m/%d)"
LOG="/var/log/finance/send_report_${REPORT_TYPE}_${RUN_DATE}.log"

SFTP_HOST="sftp.findelivery.internal"
SFTP_USER="fin.delivery"

echo "[$(date)] START send_report type=$REPORT_TYPE" | tee -a "$LOG"

# ── Determine which files to send ────────────────────────────────
case "$REPORT_TYPE" in
  FINANCE)
    FILES=("finance_summary_${RUN_DATE}.csv" "finance_summary_${RUN_DATE}.pdf")
    SFTP_REMOTE="/inbound/cfo_reports/${RUN_DATE}"
    RECIPIENTS="CFO distribution list"
    JOB_ID="FIN_JOB_011"
    ;;
  RISK)
    FILES=("risk_exposure_${RUN_DATE}.csv" "risk_exposure_${RUN_DATE}.pdf")
    SFTP_REMOTE="/inbound/risk_committee/${RUN_DATE}"
    RECIPIENTS="Risk committee"
    JOB_ID="FIN_JOB_012"
    ;;
  LIMIT)
    FILES=("limit_delta_${RUN_DATE}.csv")
    SFTP_REMOTE="/inbound/product_team/${RUN_DATE}"
    RECIPIENTS="Product team"
    JOB_ID="FIN_JOB_013"
    ;;
  *)
    echo "[$(date)] ERROR: Unknown REPORT_TYPE=$REPORT_TYPE" | tee -a "$LOG"
    exit 1
    ;;
esac

# ── Verify files exist before attempting delivery ─────────────────
MISSING=0
for FILE in "${FILES[@]}"; do
  if [ ! -f "$REPORT_DIR/$FILE" ]; then
    echo "[$(date)] ERROR: Missing file $REPORT_DIR/$FILE" | tee -a "$LOG"
    MISSING=$((MISSING + 1))
  fi
done

if [ $MISSING -gt 0 ]; then
  echo "[$(date)] ERROR: $MISSING required file(s) missing — aborting delivery" | tee -a "$LOG"
  exit 2
fi

# ── SFTP delivery ─────────────────────────────────────────────────
{
  echo "mkdir $SFTP_REMOTE"
  echo "cd $SFTP_REMOTE"
  for FILE in "${FILES[@]}"; do
    echo "put $REPORT_DIR/$FILE"
  done
  echo "bye"
} | sftp -b - "$SFTP_USER@$SFTP_HOST" >> "$LOG" 2>&1

RC=$?
if [ $RC -ne 0 ]; then
  echo "[$(date)] ERROR: SFTP delivery failed for $REPORT_TYPE (rc=$RC)" | tee -a "$LOG"
  exit 3
fi

# ── Log to DB audit table ─────────────────────────────────────────
psql -h findb01.internal -U fin_loader -d finance_staging << SQL
INSERT INTO job_audit_log (job_id, job_name, run_date, rows_loaded, status)
VALUES ('$JOB_ID', 'SEND_${REPORT_TYPE}_REPORT', NOW(), ${#FILES[@]}, 'SUCCESS');
SQL

echo "[$(date)] DONE — $REPORT_TYPE report(s) delivered to $RECIPIENTS at $SFTP_REMOTE" | tee -a "$LOG"
exit 0
