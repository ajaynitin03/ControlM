-- ============================================================
-- FIN_JOB_007 — CALCULATE_RISK
-- Scores each transaction for credit and fraud risk.
-- This is the most complex job:
--   - 5-table join chain
--   - Window functions: rolling averages, rank, percentile
--   - CASE-based multi-factor scoring
--   - Cross join to risk_weights lookup
--   - Self-join on history for velocity check
-- ============================================================

BEGIN;

DELETE FROM txn_risk_scores WHERE score_date = CURRENT_DATE;

WITH

-- ── CTE 1: Enriched transactions with customer context ────────────
enriched_txns AS (
    SELECT
        ts.txn_id,
        ts.account_id,
        ts.txn_type,
        ts.txn_date,
        ts.amount,
        ts.currency,
        ts.counterparty_id,
        ts.channel,
        cpd.customer_id,
        cpd.customer_tier,
        cpd.region,
        cpd.effective_rate,
        cpd.product_category
    FROM transactions_staging ts
    INNER JOIN ref.customer_product_dim cpd
            ON ts.account_id = cpd.account_id
    WHERE ts.load_date = CURRENT_DATE
),

-- ── CTE 2: 30-day transaction history per account (velocity) ─────
txn_history_stats AS (
    SELECT
        account_id,
        AVG(amount)                                     AS avg_30d_amount,
        STDDEV(amount)                                  AS stddev_30d_amount,
        COUNT(*)                                        AS txn_count_30d,
        MAX(amount)                                     AS max_30d_amount,
        SUM(CASE WHEN txn_type IN ('WITHDRAWAL','TRANSFER') THEN 1 ELSE 0 END)
                                                        AS debit_count_30d
    FROM transactions_staging
    WHERE load_date >= CURRENT_DATE - INTERVAL '30 days'
    GROUP BY account_id
),

-- ── CTE 3: Counterparty risk lookup ──────────────────────────────
counterparty_risk AS (
    SELECT
        e.txn_id,
        COALESCE(cr.risk_flag, 'LOW')                   AS counterparty_risk_flag,
        COALESCE(cr.country_risk_score, 0)              AS country_risk_score
    FROM enriched_txns e
    LEFT JOIN ref.counterparty_risk_registry cr
           ON e.counterparty_id = cr.counterparty_id
),

-- ── CTE 4: Compute raw risk factors ──────────────────────────────
risk_factors AS (
    SELECT
        e.txn_id,
        e.account_id,
        e.customer_id,
        e.customer_tier,
        e.amount,
        e.txn_type,
        e.channel,
        e.txn_date,

        -- Factor A: Amount anomaly (z-score against 30-day history)
        CASE
            WHEN h.stddev_30d_amount = 0 OR h.stddev_30d_amount IS NULL THEN 0
            ELSE LEAST(10, ABS((e.amount - h.avg_30d_amount) / h.stddev_30d_amount))
        END                                             AS amount_zscore,

        -- Factor B: Velocity — is this account unusually active today?
        CASE
            WHEN h.txn_count_30d = 0 THEN 0
            ELSE LEAST(10,
                (SELECT COUNT(*) FROM transactions_staging ts2
                 WHERE ts2.account_id = e.account_id
                   AND ts2.load_date = CURRENT_DATE) * 30.0 / NULLIF(h.txn_count_30d, 0)
            )
        END                                             AS velocity_score,

        -- Factor C: Channel risk
        CASE e.channel
            WHEN 'ONLINE'   THEN 3
            WHEN 'MOBILE'   THEN 2
            WHEN 'ATM'      THEN 4
            WHEN 'BRANCH'   THEN 1
            ELSE                 5
        END                                             AS channel_risk_score,

        -- Factor D: Counterparty risk
        cr.country_risk_score,
        CASE cr.counterparty_risk_flag
            WHEN 'HIGH'     THEN 8
            WHEN 'MEDIUM'   THEN 4
            ELSE                 0
        END                                             AS counterparty_flag_score,

        -- Factor E: Large transaction threshold
        CASE
            WHEN e.amount > 50000  THEN 6
            WHEN e.amount > 10000  THEN 3
            ELSE                        0
        END                                             AS large_txn_score,

        -- Factor F: Debit ratio (high debit activity = more risk)
        CASE
            WHEN COALESCE(h.debit_count_30d, 0) > 20 THEN 4
            WHEN COALESCE(h.debit_count_30d, 0) > 10 THEN 2
            ELSE 0
        END                                             AS debit_activity_score

    FROM enriched_txns e
    LEFT JOIN txn_history_stats h  ON e.account_id = h.account_id
    LEFT JOIN counterparty_risk cr ON e.txn_id     = cr.txn_id
),

-- ── CTE 5: Weighted composite score ──────────────────────────────
weighted_scores AS (
    SELECT
        rf.*,
        -- Cross join to single-row weights table
        w.w_amount, w.w_velocity, w.w_channel,
        w.w_counterparty, w.w_large_txn, w.w_debit,

        ROUND(
            (rf.amount_zscore        * w.w_amount)
          + (rf.velocity_score       * w.w_velocity)
          + (rf.channel_risk_score   * w.w_channel)
          + (rf.counterparty_flag_score * w.w_counterparty)
          + (rf.large_txn_score      * w.w_large_txn)
          + (rf.debit_activity_score * w.w_debit)
        , 2)                                            AS composite_score

    FROM risk_factors rf
    CROSS JOIN ref.risk_weights w
    WHERE w.model_version = (SELECT MAX(model_version) FROM ref.risk_weights)
)

-- ── Final insert ──────────────────────────────────────────────────
INSERT INTO txn_risk_scores (
    txn_id, account_id, customer_id, customer_tier,
    amount, txn_type, txn_date, channel,
    amount_zscore, velocity_score, channel_risk_score,
    counterparty_flag_score, country_risk_score,
    large_txn_score, debit_activity_score,
    composite_score,
    risk_band,
    score_date,
    score_percentile
)
SELECT
    ws.txn_id, ws.account_id, ws.customer_id, ws.customer_tier,
    ws.amount, ws.txn_type, ws.txn_date, ws.channel,
    ws.amount_zscore, ws.velocity_score, ws.channel_risk_score,
    ws.counterparty_flag_score, ws.country_risk_score,
    ws.large_txn_score, ws.debit_activity_score,
    ws.composite_score,

    -- Risk band derived from composite score
    CASE
        WHEN ws.composite_score >= 30 THEN 'CRITICAL'
        WHEN ws.composite_score >= 20 THEN 'HIGH'
        WHEN ws.composite_score >= 10 THEN 'MEDIUM'
        ELSE                               'LOW'
    END                                                 AS risk_band,

    CURRENT_DATE                                        AS score_date,

    -- Percentile rank within today's scored transactions
    PERCENT_RANK() OVER (ORDER BY ws.composite_score)  AS score_percentile

FROM weighted_scores ws;

-- Summary statistics to audit log
INSERT INTO job_audit_log (job_id, job_name, run_date, rows_loaded, status)
SELECT 'FIN_JOB_007', 'CALCULATE_RISK', NOW(), COUNT(*), 'SUCCESS'
FROM txn_risk_scores WHERE score_date = CURRENT_DATE;

COMMIT;
