-- ============================================================
-- FIN_JOB_009 — BUILD_POSITION_VIEW
-- Consolidates fees + risk scores + limits into a single
-- reporting mart for the position dashboard.
-- Full outer join pattern to catch any gaps across the 3 datasets.
-- ============================================================

BEGIN;

TRUNCATE TABLE reporting.position_mart;

INSERT INTO reporting.position_mart (
    account_id, customer_id, customer_name, customer_tier, region,
    txn_date, txn_count,
    total_amount, total_fee_amount, net_amount,
    avg_risk_score, max_risk_score, risk_band,
    critical_txn_count, high_risk_txn_count,
    daily_limit, available_credit, spent_today,
    limit_band, limit_changed_flag,
    report_date
)
WITH

fee_summary AS (
    SELECT
        account_id,
        txn_date,
        COUNT(*)                AS txn_count,
        SUM(amount)             AS total_amount,
        SUM(fee_amount)         AS total_fee_amount,
        SUM(amount) - SUM(fee_amount)
                                AS net_amount
    FROM txn_fees
    WHERE calc_date = CURRENT_DATE
    GROUP BY account_id, txn_date
),

risk_summary AS (
    SELECT
        account_id,
        score_date              AS txn_date,
        AVG(composite_score)    AS avg_risk_score,
        MAX(composite_score)    AS max_risk_score,
        -- Derive overall band from max score
        CASE
            WHEN MAX(composite_score) >= 30 THEN 'CRITICAL'
            WHEN MAX(composite_score) >= 20 THEN 'HIGH'
            WHEN MAX(composite_score) >= 10 THEN 'MEDIUM'
            ELSE                                  'LOW'
        END                     AS risk_band,
        COUNT(*) FILTER (WHERE risk_band = 'CRITICAL')  AS critical_txn_count,
        COUNT(*) FILTER (WHERE risk_band = 'HIGH')      AS high_risk_txn_count
    FROM txn_risk_scores
    WHERE score_date = CURRENT_DATE
    GROUP BY account_id, score_date
),

limits_today AS (
    SELECT account_id, daily_limit, available_credit, spent_today,
           limit_band, limit_changed_flag
    FROM customer_limits
    WHERE effective_date = CURRENT_DATE
)

SELECT
    COALESCE(f.account_id, r.account_id, l.account_id)     AS account_id,
    cpd.customer_id,
    cpd.customer_name,
    cpd.customer_tier,
    cpd.region,
    COALESCE(f.txn_date, r.txn_date, CURRENT_DATE)         AS txn_date,
    COALESCE(f.txn_count, 0)                                AS txn_count,
    COALESCE(f.total_amount, 0)                             AS total_amount,
    COALESCE(f.total_fee_amount, 0)                         AS total_fee_amount,
    COALESCE(f.net_amount, 0)                               AS net_amount,
    COALESCE(r.avg_risk_score, 0)                           AS avg_risk_score,
    COALESCE(r.max_risk_score, 0)                           AS max_risk_score,
    COALESCE(r.risk_band, 'LOW')                            AS risk_band,
    COALESCE(r.critical_txn_count, 0)                       AS critical_txn_count,
    COALESCE(r.high_risk_txn_count, 0)                      AS high_risk_txn_count,
    COALESCE(l.daily_limit, 0)                              AS daily_limit,
    COALESCE(l.available_credit, 0)                         AS available_credit,
    COALESCE(l.spent_today, 0)                              AS spent_today,
    COALESCE(l.limit_band, 'BASIC')                         AS limit_band,
    COALESCE(l.limit_changed_flag, FALSE)                   AS limit_changed_flag,
    CURRENT_DATE                                            AS report_date

FROM fee_summary f
FULL OUTER JOIN risk_summary r
             ON f.account_id = r.account_id AND f.txn_date = r.txn_date
FULL OUTER JOIN limits_today l
             ON COALESCE(f.account_id, r.account_id) = l.account_id
INNER JOIN ref.customer_product_dim cpd
        ON COALESCE(f.account_id, r.account_id, l.account_id) = cpd.account_id;

-- Refresh materialized view for dashboard
REFRESH MATERIALIZED VIEW CONCURRENTLY reporting.mv_position_summary;

INSERT INTO job_audit_log (job_id, job_name, run_date, rows_loaded, status)
SELECT 'FIN_JOB_009', 'BUILD_POSITION_VIEW', NOW(), COUNT(*), 'SUCCESS'
FROM reporting.position_mart WHERE report_date = CURRENT_DATE;

COMMIT;
