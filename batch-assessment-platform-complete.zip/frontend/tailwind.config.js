/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          50:  '#eff4ff',
          100: '#dbeafe',
          200: '#bfdbfe',
          300: '#93c5fd',
          400: '#60a5fa',
          500: '#3b82f6',
          600: '#2563eb',
          700: '#1d4ed8',
          800: '#1e40af',
          900: '#1e3a8a',
          950: '#172554',
        },
        accent: {
          violet: '#7c3aed',
          cyan:   '#06b6d4',
          pink:   '#ec4899',
          amber:  '#f59e0b',
          emerald:'#10b981',
        },
        surface: {
          DEFAULT: '#f6f8fc',
          card:    '#ffffff',
          border:  '#e4e8f0',
          hover:   '#f1f4f9',
          muted:   '#f8f9fc',
        }
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'Fira Code', 'monospace'],
      },
      backgroundImage: {
        'brand-gradient':      'linear-gradient(135deg, #1d4ed8 0%, #2563eb 45%, #06b6d4 100%)',
        'brand-gradient-soft': 'linear-gradient(135deg, #eff4ff 0%, #f0f9ff 100%)',
        'hero-gradient':       'linear-gradient(145deg, #0f1c3f 0%, #1a3575 45%, #1d4ed8 75%, #06b6d4 100%)',
        'card-glow':           'radial-gradient(circle at top right, rgba(37,99,235,0.08), transparent 60%)',
        'mesh-dots':           'radial-gradient(rgba(37,99,235,0.08) 1px, transparent 1px)',
      },
      boxShadow: {
        'card':       '0 1px 3px rgba(0,0,0,0.06), 0 1px 2px rgba(0,0,0,0.04)',
        'card-md':    '0 4px 12px rgba(0,0,0,0.08)',
        'card-lg':    '0 8px 24px rgba(0,0,0,0.10)',
        'card-hover': '0 12px 32px rgba(30,58,138,0.14)',
        'glow-brand': '0 0 0 1px rgba(37,99,235,0.08), 0 8px 24px rgba(37,99,235,0.18)',
        'glow-red':   '0 0 0 1px rgba(220,38,38,0.08), 0 8px 24px rgba(220,38,38,0.16)',
      },
      keyframes: {
        fadeIn:      { '0%': { opacity: 0 }, '100%': { opacity: 1 } },
        fadeSlideUp: { '0%': { opacity: 0, transform: 'translateY(8px)' }, '100%': { opacity: 1, transform: 'none' } },
        scaleIn:     { '0%': { opacity: 0, transform: 'scale(0.96)' }, '100%': { opacity: 1, transform: 'scale(1)' } },
        shimmer:     { '0%': { backgroundPosition: '-400px 0' }, '100%': { backgroundPosition: '400px 0' } },
        floatSlow:   { '0%,100%': { transform: 'translateY(0)' }, '50%': { transform: 'translateY(-6px)' } },
        pulseGlow:   { '0%,100%': { opacity: 1 }, '50%': { opacity: 0.55 } },
      },
      animation: {
        fadeIn:      'fadeIn 0.25s ease-out',
        fadeSlideUp: 'fadeSlideUp 0.3s cubic-bezier(0.16,1,0.3,1)',
        scaleIn:     'scaleIn 0.2s cubic-bezier(0.16,1,0.3,1)',
        shimmer:     'shimmer 1.6s linear infinite',
        floatSlow:   'floatSlow 4s ease-in-out infinite',
        pulseGlow:   'pulseGlow 2.2s ease-in-out infinite',
      },
      transitionTimingFunction: {
        'smooth': 'cubic-bezier(0.16, 1, 0.3, 1)',
      },
    },
  },
  plugins: [],
}
