import { X, Zap, Target, ArrowDownToLine, ArrowUpFromLine, Info } from 'lucide-react'
import { useApp } from '../../hooks/useAppState'
import { getImpactAnalysis } from '../../services/api'
import { highlightImpact, highlightCriticalPath, resetHighlight } from '../../utils/cytoscapeBuilder'
import toast from 'react-hot-toast'
import CriticalityBadge from '../CriticalityBadge'

const HEADER_THEME = {
  Critical: { grad: 'linear-gradient(135deg, #7f1d1d, #991b1b)', accent: '#fca5a5' },
  High:     { grad: 'linear-gradient(135deg, #991b1b, #b91c1c)', accent: '#fecaca' },
  Medium:   { grad: 'linear-gradient(135deg, #92400e, #b45309)', accent: '#fde68a' },
  Low:      { grad: 'linear-gradient(135deg, #065f46, #047857)', accent: '#a7f3d0' },
}

export default function JobDetails({ cyRef }) {
  const { state, dispatch } = useApp()
  const { selectedNode, sessionId, graphData } = state

  if (!selectedNode) return null

  const nd = selectedNode
  const band = nd.criticality_band || (nd.criticality === 'HIGH' ? 'High' : nd.criticality === 'MEDIUM' ? 'Medium' : 'Low')
  const theme = HEADER_THEME[band] || HEADER_THEME.Low

  const runImpact = async () => {
    const toastId = 'impact-run'
    toast.loading('Running impact analysis…', { id: toastId })
    try {
      const res = await getImpactAnalysis(sessionId, nd.id)
      const affected = res.data.affected_jobs.map((j) => j.job_id)
      dispatch({ type: 'SET_IMPACT_DATA', payload: res.data })
      if (cyRef.current) {
        highlightImpact(cyRef.current, [nd.id, ...affected])
      }
      toast.success(`${res.data.affected_count} downstream jobs would be affected`, { id: toastId })
    } catch {
      toast.error('Impact analysis failed', { id: toastId })
    }
  }

  const runCriticalPath = () => {
    if (!graphData?.critical_path?.length) {
      toast.error('No critical path available')
      return
    }
    if (cyRef.current) {
      highlightCriticalPath(cyRef.current, graphData.critical_path)
      toast.success(`Critical path highlighted — ${graphData.critical_path.length} jobs`)
    }
  }

  const fields = [
    { label: 'Job ID',       value: nd.id },
    { label: 'App Name',     value: nd.app_name },
    { label: 'Platform',     value: nd.platform },
    { label: 'Schedule',     value: nd.schedule },
    { label: 'Runtime',      value: nd.runtime ? `${nd.runtime} min` : null },
    { label: 'Priority',     value: nd.priority },
    { label: 'Owner',        value: nd.owner },
    { label: 'Status',       value: nd.status },
    { label: 'Folder',       value: nd.folder },
    { label: 'Description',  value: nd.description },
  ].filter((f) => f.value)

  const onCriticalPath = graphData?.critical_path?.includes(nd.id)

  return (
    <div
      className="absolute right-4 top-4 w-80 rounded-2xl overflow-hidden z-20 animate-scaleIn"
      style={{
        background: '#ffffff',
        border: '1px solid #e4e8f0',
        boxShadow: '0 20px 50px rgba(15,23,42,0.18), 0 4px 14px rgba(15,23,42,0.08)',
      }}
    >
      {/* Header — gradient by criticality */}
      <div style={{ background: theme.grad, padding: '14px 16px' }} className="relative">
        {onCriticalPath && (
          <div className="absolute top-2 right-9 flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold"
               style={{ background: 'rgba(251,191,36,0.22)', color: '#fde68a', border: '1px solid rgba(251,191,36,0.4)' }}>
            <Target size={9} /> On Critical Path
          </div>
        )}
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0">
            <CriticalityBadge source={nd} />
          </div>
          <button
            onClick={() => dispatch({ type: 'SET_SELECTED_NODE', payload: null })}
            className="text-white/70 hover:text-white flex-shrink-0 transition-colors duration-150 hover:rotate-90 transform"
            style={{ transitionProperty: 'color, transform' }}
          >
            <X size={16} />
          </button>
        </div>
        <div className="mt-2">
          <p className="text-sm font-bold text-white truncate leading-tight">{nd.label}</p>
          <p className="text-[11px] mt-0.5 font-mono" style={{ color: theme.accent, opacity: 0.9 }}>{nd.id}</p>
        </div>
      </div>

      {/* Fan metrics — richer tiles */}
      <div className="grid grid-cols-2 gap-2 p-3">
        <div className="rounded-xl p-3 text-center" style={{ background: '#eff4ff', border: '1px solid #dbeafe' }}>
          <div className="flex items-center justify-center gap-1 mb-1">
            <ArrowDownToLine size={11} className="text-brand-500" />
          </div>
          <p className="text-xl font-extrabold font-mono text-brand-700 leading-none">{nd.fan_in ?? 0}</p>
          <p className="text-[10px] text-brand-500 font-semibold uppercase tracking-wide mt-1">Fan-in</p>
        </div>
        <div className="rounded-xl p-3 text-center" style={{ background: '#f5f3ff', border: '1px solid #ede9fe' }}>
          <div className="flex items-center justify-center gap-1 mb-1">
            <ArrowUpFromLine size={11} className="text-violet-500" />
          </div>
          <p className="text-xl font-extrabold font-mono text-violet-700 leading-none">{nd.fan_out ?? 0}</p>
          <p className="text-[10px] text-violet-500 font-semibold uppercase tracking-wide mt-1">Fan-out</p>
        </div>
      </div>

      {/* Criticality reason, if present */}
      {nd.criticality_reason && (
        <div className="mx-3 mb-2 px-3 py-2 rounded-lg flex items-start gap-2" style={{ background: '#fffbeb', border: '1px solid #fde68a' }}>
          <Info size={12} className="text-amber-600 flex-shrink-0 mt-0.5" />
          <p className="text-[11px] text-amber-800 leading-snug">{nd.criticality_reason}</p>
        </div>
      )}

      {/* Fields */}
      <div className="px-4 pb-3 space-y-2.5 max-h-56 overflow-y-auto">
        {fields.map(({ label, value }, i) => (
          <div key={label} className="animate-fadeSlideUp" style={{ animationDelay: `${i * 25}ms`, animationFillMode: 'backwards' }}>
            <p className="text-[10px] text-gray-400 font-semibold uppercase tracking-wider">{label}</p>
            <p className="text-xs text-gray-800 font-medium break-all mt-0.5">{value}</p>
          </div>
        ))}
      </div>

      {/* Actions */}
      <div className="px-3 pb-3 pt-1 flex gap-2 border-t border-surface-border mt-1">
        <button
          onClick={runImpact}
          className="btn-primary flex-1 flex items-center justify-center gap-1.5 text-xs py-2 mt-2"
        >
          <Zap size={12} />
          Impact Analysis
        </button>
        <button
          onClick={runCriticalPath}
          className="flex items-center gap-1.5 text-xs px-3 py-2 mt-2 rounded-lg font-semibold text-amber-700 bg-amber-50 border border-amber-200 hover:bg-amber-100 transition-all duration-150 hover:-translate-y-0.5"
        >
          <Target size={12} />
          Crit. Path
        </button>
      </div>
    </div>
  )
}
