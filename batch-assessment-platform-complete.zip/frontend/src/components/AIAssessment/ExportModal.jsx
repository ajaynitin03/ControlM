import { useState } from 'react'
import { FileSpreadsheet, FileText, FileCode, X, Download } from 'lucide-react'

export default function ExportModal({ isOpen, onClose, onConfirm }) {
  const [selectedFormat, setSelectedFormat] = useState('xlsx')

  if (!isOpen) return null

  const formats = [
    {
      id: 'xlsx',
      name: 'Excel (.xlsx)',
      desc: 'Styled workbook with header summary & formatted grids',
      color: '#16a34a',
      bg: '#f0fdf4',
      icon: FileSpreadsheet
    },
    {
      id: 'pdf',
      name: 'PDF (.pdf)',
      desc: 'Executive summary & detailed tables formatted for printing',
      color: '#dc2626',
      bg: '#fef2f2',
      icon: FileText
    },
    {
      id: 'csv',
      name: 'CSV (.csv)',
      desc: 'Standard comma-separated plain text data representation',
      color: '#2563eb',
      bg: '#eff4ff',
      icon: FileCode
    }
  ]

  const handleDownload = () => {
    onConfirm(selectedFormat)
    onClose()
  }

  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      background: 'rgba(15, 23, 42, 0.45)',
      backdropFilter: 'blur(4px)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 99999,
      fontFamily: "'Inter', sans-serif"
    }}>
      <div style={{
        background: '#ffffff',
        width: '100%',
        maxWidth: 420,
        borderRadius: 16,
        boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)',
        border: '1px solid #e2e8f0',
        overflow: 'hidden',
        display: 'flex',
        flexDirection: 'column'
      }}>
        {/* Header */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '16px 20px',
          borderBottom: '1px solid #e2e8f0',
          background: '#f8fafc'
        }}>
          <h3 style={{ fontSize: 15, fontWeight: 700, color: '#0f172a', margin: 0 }}>
            Export Assessment Report
          </h3>
          <button
            onClick={onClose}
            style={{
              background: 'none',
              border: 'none',
              cursor: 'pointer',
              color: '#94a3b8',
              padding: 4,
              display: 'flex',
              alignItems: 'center',
              borderRadius: 6
            }}
            onMouseEnter={(e) => e.currentTarget.style.background = '#e2e8f0'}
            onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
          >
            <X size={16} />
          </button>
        </div>

        {/* Body */}
        <div style={{ padding: '20px 20px 16px', display: 'flex', flexDirection: 'column', gap: 14 }}>
          <p style={{ fontSize: 13, color: '#64748b', margin: '0 0 4px', lineHeight: 1.5 }}>
            Please select the output format you wish to generate for this report card:
          </p>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {formats.map((fmt) => {
              const selected = selectedFormat === fmt.id
              const Icon = fmt.icon
              return (
                <div
                  key={fmt.id}
                  onClick={() => setSelectedFormat(fmt.id)}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 12,
                    padding: '12px 14px',
                    borderRadius: 10,
                    border: selected ? `2px solid ${fmt.color}` : '1.5px solid #e2e8f0',
                    background: selected ? fmt.bg : '#ffffff',
                    cursor: 'pointer',
                    transition: 'all 0.1s ease',
                    userSelect: 'none'
                  }}
                  onMouseEnter={(e) => {
                    if (!selected) {
                      e.currentTarget.style.borderColor = '#94a3b8'
                      e.currentTarget.style.background = '#f8fafc'
                    }
                  }}
                  onMouseLeave={(e) => {
                    if (!selected) {
                      e.currentTarget.style.borderColor = '#e2e8f0'
                      e.currentTarget.style.background = '#ffffff'
                    }
                  }}
                >
                  <div style={{
                    width: 38,
                    height: 38,
                    borderRadius: 8,
                    background: selected ? '#ffffff' : fmt.bg,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: fmt.color,
                    flexShrink: 0,
                    boxShadow: selected ? '0 2px 4px rgba(0,0,0,0.05)' : 'none'
                  }}>
                    <Icon size={18} />
                  </div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 13, fontWeight: 700, color: '#1e293b' }}>
                      {fmt.name}
                    </div>
                    <div style={{ fontSize: 11, color: '#64748b', marginTop: 2, lineHeight: 1.3 }}>
                      {fmt.desc}
                    </div>
                  </div>
                  <div style={{
                    width: 16,
                    height: 16,
                    borderRadius: '50%',
                    border: selected ? `5px solid ${fmt.color}` : '2px solid #cbd5e1',
                    background: '#ffffff',
                    boxShadow: selected ? '0 0 0 2px rgba(0,0,0,0.03)' : 'none',
                    boxSizing: 'border-box'
                  }} />
                </div>
              )
            })}
          </div>
        </div>

        {/* Footer */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'flex-end',
          gap: 10,
          padding: '12px 20px',
          borderTop: '1px solid #e2e8f0',
          background: '#f8fafc'
        }}>
          <button
            onClick={onClose}
            style={{
              padding: '8px 16px',
              borderRadius: 8,
              border: '1.5px solid #cbd5e1',
              background: '#ffffff',
              color: '#475569',
              fontSize: 12.5,
              fontWeight: 600,
              cursor: 'pointer',
              transition: 'background 0.15s'
            }}
            onMouseEnter={(e) => e.currentTarget.style.background = '#f1f5f9'}
            onMouseLeave={(e) => e.currentTarget.style.background = '#ffffff'}
          >
            Cancel
          </button>
          <button
            onClick={handleDownload}
            style={{
              padding: '8px 16px',
              borderRadius: 8,
              border: 'none',
              background: '#2563eb',
              color: '#ffffff',
              fontSize: 12.5,
              fontWeight: 700,
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: 6,
              transition: 'background 0.15s',
              boxShadow: '0 2px 4px rgba(37,99,235,0.2)'
            }}
            onMouseEnter={(e) => e.currentTarget.style.background = '#1d4ed8'}
            onMouseLeave={(e) => e.currentTarget.style.background = '#2563eb'}
          >
            <Download size={13} />
            <span>Export Report</span>
          </button>
        </div>
      </div>
    </div>
  )
}
