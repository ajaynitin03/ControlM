import { useState, useCallback, useEffect } from 'react'
import {
  Brain, Zap, ShieldAlert, TrendingUp, ArrowLeftRight,
  FileText, Download, Loader2, CheckCircle2, AlertTriangle,
  ChevronDown, ChevronUp, Sparkles, BarChart3, FileCode2,
  RefreshCcw, Info, Upload, Trash2
} from 'lucide-react'
import toast from 'react-hot-toast'
import { useApp } from '../../hooks/useAppState'
import { ai } from '../../services/api'
import ExportModal from './ExportModal'

const CONVERSION_TARGETS = ['Python', 'SpringBatch', 'PySpark', 'Airflow', 'AirflowDAG', 'Java', 'Shell']

/* ─────────────────────────────────────────────────────────────────
   SHARED SMALL COMPONENTS
   ───────────────────────────────────────────────────────────────── */
function Badge({ label, level }) {
  const map = {
    Critical: { bg: '#ffd7d7', color: '#7f0000', border: '#ffa8a8' },
    High:     { bg: '#ffe4cc', color: '#7a3500', border: '#ffb380' },
    Medium:   { bg: '#fff3cd', color: '#7a5c00', border: '#ffd966' },
    Low:      { bg: '#d4f1e4', color: '#1a5c3a', border: '#6dcfa1' },
    HIGH:     { bg: '#ffd7d7', color: '#7f0000', border: '#ffa8a8' },
    MEDIUM:   { bg: '#fff3cd', color: '#7a5c00', border: '#ffd966' },
    LOW:      { bg: '#d4f1e4', color: '#1a5c3a', border: '#6dcfa1' },
  }
  const s = map[level] || { bg: '#f1f5f9', color: '#475569', border: '#e2e8f0' }
  return (
    <span style={{
      padding: '3px 8px', borderRadius: 6, fontSize: 11, fontWeight: 700,
      background: s.bg, color: s.color, border: '1px solid ' + s.border,
      whiteSpace: 'nowrap', display: 'inline-block'
    }}>
      {label || level}
    </span>
  )
}

function SectionCard({ title, icon: Icon, iconColor, children, defaultOpen }) {
  const [open, setOpen] = useState(defaultOpen !== false)
  const color = iconColor || '#2563eb'
  return (
    <div style={{
      background: '#fff', border: '1px solid #e4e8f0', borderRadius: 12,
      marginBottom: 14, overflow: 'hidden', boxShadow: '0 1px 3px rgba(0,0,0,0.02)'
    }}>
      <button
        onClick={() => setOpen(o => !o)}
        style={{
          width: '100%', display: 'flex', alignItems: 'center', gap: 9,
          padding: '12px 16px', background: '#f8fafc', border: 'none',
          borderBottom: open ? '1px solid #e4e8f0' : 'none',
          cursor: 'pointer', textAlign: 'left', outline: 'none'
        }}
      >
        <Icon size={14} color={color} />
        <span style={{ fontSize: 13, fontWeight: 700, color: '#1e293b', flex: 1 }}>{title}</span>
        {open ? <ChevronUp size={13} color="#94a3b8" /> : <ChevronDown size={13} color="#94a3b8" />}
      </button>
      {open && <div style={{ padding: 16 }}>{children}</div>}
    </div>
  )
}

function KV({ label, value, mono }) {
  return (
    <div style={{ marginBottom: 10 }}>
      <div style={{
        fontSize: 10, fontWeight: 700, color: '#94a3b8',
        textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 3,
      }}>
        {label}
      </div>
      <div style={{
        fontSize: 12, color: '#334155',
        fontFamily: mono ? 'monospace' : 'inherit',
        wordBreak: 'break-word', lineHeight: 1.4
      }}>
        {value || '—'}
      </div>
    </div>
  )
}

function RunBtn({ onClick, loading, children, disabled, variant }) {
  const v = variant || 'primary'
  let bg, color, border
  if (v === 'purple') {
    bg = loading || disabled ? '#ddd6fe' : '#7c3aed'
    color = '#fff'
    border = 'none'
  } else if (v === 'outline') {
    bg = '#fff'
    color = '#374151'
    border = '1px solid #cbd5e1'
  } else {
    bg = loading || disabled ? '#93c5fd' : '#2563eb'
    color = '#fff'
    border = 'none'
  }
  return (
    <button
      onClick={onClick}
      disabled={loading || disabled}
      style={{
        display: 'inline-flex', alignItems: 'center', gap: 6,
        padding: '8px 16px', borderRadius: 8, fontSize: 12, fontWeight: 600,
        cursor: loading || disabled ? 'not-allowed' : 'pointer',
        background: bg, color: color, border: border,
        transition: 'all 0.15s',
      }}
    >
      {loading && <Loader2 size={13} style={{ animation: 'spin 1s linear infinite' }} />}
      {children}
    </button>
  )
}

function EmptyPrompt({ message }) {
  return (
    <div style={{ padding: '48px 0', textAlign: 'center', color: '#94a3b8', fontSize: 13 }}>
      <Info size={24} color="#cbd5e1" style={{ margin: '0 auto 10px', display: 'block' }} />
      {message}
    </div>
  )
}

function CodeBlock({ code }) {
  const copy = function() {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(code)
      toast.success('Copied!')
    }
  }
  const display = (code || '').replace(/\\n/g, '\n')
  return (
    <div style={{ position: 'relative', background: '#0f172a', borderRadius: 8, overflow: 'hidden', border: '1px solid #1e293b' }}>
      <button
        onClick={copy}
        style={{
          position: 'absolute', top: 8, right: 8, padding: '3px 9px',
          background: 'rgba(255,255,255,0.1)', border: '1px solid rgba(255,255,255,0.15)',
          borderRadius: 5, fontSize: 11, color: '#94a3b8', cursor: 'pointer',
        }}
      >
        Copy
      </button>
      <pre style={{
        margin: 0, padding: '14px 16px', overflowX: 'auto', fontSize: 11,
        color: '#f8fafc', fontFamily: 'monospace', lineHeight: 1.6,
        whiteSpace: 'pre-wrap', wordBreak: 'break-word', maxHeight: 400,
      }}>
        {display}
      </pre>
    </div>
  )
}

function StatusPill({ label, active, sub }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 5, padding: '4px 10px',
      borderRadius: 99, fontSize: 11, fontWeight: 600,
      background: active ? '#f0fdf4' : '#fef2f2',
      border: '1px solid ' + (active ? '#bbf7d0' : '#fecaca'),
      color: active ? '#16a34a' : '#dc2626',
    }}>
      <div style={{
        width: 6, height: 6, borderRadius: '50%',
        background: active ? '#16a34a' : '#dc2626',
      }} />
      {label}{sub ? ' (' + sub + ')' : ''}
    </div>
  )
}

/* ─────────────────────────────────────────────────────────────────
   SUBMODULE 1 — INPUT SETUP
   ───────────────────────────────────────────────────────────────── */
function InputSetupPanel({ sessionId, onSetupComplete, aiStatus }) {
  const [invFile, setInvFile] = useState(null)
  const [srcFiles, setSrcFiles] = useState([])
  const [srcUploadType, setSrcUploadType] = useState('files') // 'files' or 'folder'
  const [uploadingInv, setUploadingInv] = useState(false)
  const [uploadingSrc, setUploadingSrc] = useState(false)
  const [failureLogFiles, setFailureLogFiles] = useState([])
  const [uploadingLogs, setUploadingLogs] = useState(false)
  const [starting, setStarting] = useState(false)

  async function handleInvUpload(file) {
    if (!file) return
    setUploadingInv(true)
    try {
      const res = await ai.uploadInventory(sessionId, file)
      setInvFile(file)
      toast.success(res.data.message || 'Inventory uploaded successfully')
      onSetupComplete()
    } catch (e) {
      const detail = e.response?.data?.detail
      const errorMsg = typeof detail === 'object' ? `${detail.error}: ${detail.missing.join(', ')}` : (detail || 'Upload failed')
      toast.error(errorMsg)
    } finally {
      setUploadingInv(false)
    }
  }

  async function handleSrcUpload(files) {
    if (!files || files.length === 0) return
    setUploadingSrc(true)
    try {
      const res = await ai.uploadSourceFiles(sessionId, files)
      setSrcFiles(prev => [...prev, ...Array.from(files)])
      toast.success(res.data.message || 'Source files uploaded successfully')
      onSetupComplete()
    } catch (e) {
      toast.error(e.response?.data?.detail || 'Source upload failed')
    } finally {
      setUploadingSrc(false)
    }
  }

  async function handleFailureLogUpload(files) {
    if (!files || files.length === 0) return
    if (!isInventoryUploaded) {
      toast.error('Upload the Job Inventory CSV first — failure logs are matched against it by Job ID.', { duration: 5500 })
      return
    }
    setUploadingLogs(true)
    try {
      const res = await ai.uploadFailureLogs(sessionId, files)
      setFailureLogFiles(prev => [...prev, ...Array.from(files)])
      const { matched_count, unmatched_files, inventory_empty } = res.data
      if (inventory_empty) {
        toast.error(res.data.message, { duration: 7000 })
      } else if (unmatched_files && unmatched_files.length > 0) {
        toast(
          `${matched_count} log(s) matched to jobs. ${unmatched_files.length} file(s) could not be matched to a Job ID: ${unmatched_files.join(', ')}`,
          { icon: '⚠️', duration: 6000 }
        )
      } else {
        toast.success(res.data.message || 'Failure logs uploaded and matched successfully')
      }
      onSetupComplete()
    } catch (e) {
      toast.error(e.response?.data?.detail || 'Failure log upload failed')
    } finally {
      setUploadingLogs(false)
    }
  }

  async function handleClear() {
    try {
      await ai.clearInputs(sessionId)
      setInvFile(null)
      setSrcFiles([])
      setFailureLogFiles([])
      toast.success('Inputs cleared successfully')
      onSetupComplete()
    } catch (e) {
      toast.error('Failed to clear inputs')
    }
  }

  async function handleStart() {
    setStarting(true)
    try {
      const res = await ai.startAssessment(sessionId)
      toast.success(res.data.message || 'Assessment initialized!')
      onSetupComplete()
    } catch (e) {
      toast.error(e.response?.data?.detail || 'Failed to start assessment')
    } finally {
      setStarting(false)
    }
  }

  const isInventoryUploaded = aiStatus?.inventory_uploaded || !!invFile
  const isSourceUploaded = aiStatus?.source_uploaded || srcFiles.length > 0
  const isReady = isInventoryUploaded && isSourceUploaded

  return (
    <div style={{ maxWidth: 850, margin: '0 auto', padding: '10px 0' }}>
      <h2 style={{ fontSize: 18, fontWeight: 700, color: '#0f172a', marginBottom: 6 }}>Modernization Tool Setup</h2>
      <p style={{ fontSize: 13, color: '#475569', marginBottom: 24, lineHeight: 1.5 }}>
        Upload the Job Inventory metadata CSV and the raw job script files. These inputs will be indexed into FAISS for RAG-based context retrieval and rule mapping.
      </p>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24, marginBottom: 24 }}>
        {/* Card 1: Job Inventory CSV */}
        <div style={{
          border: '1px solid #e2e8f0', borderRadius: 12, padding: 20, background: '#fff',
          display: 'flex', flexDirection: 'column', gap: 14
        }}>
          <div>
            <span style={{ fontSize: 11, fontWeight: 700, color: '#2563eb', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Required Input 1</span>
            <h3 style={{ fontSize: 14, fontWeight: 700, color: '#1e293b', marginTop: 4 }}>Job Inventory CSV</h3>
            <p style={{ fontSize: 12, color: '#64748b', marginTop: 4, lineHeight: 1.5 }}>
              Provide the scheduler jobs index. Must contain columns: <code style={{ fontSize: 11, color: '#b91c1c', background: '#fef2f2', padding: '2px 4px', borderRadius: 4 }}>Job_ID</code>, <code style={{ fontSize: 11, color: '#b91c1c', background: '#fef2f2', padding: '2px 4px', borderRadius: 4 }}>Job_Name</code>, <code style={{ fontSize: 11, color: '#b91c1c', background: '#fef2f2', padding: '2px 4px', borderRadius: 4 }}>Application</code>, <code style={{ fontSize: 11, color: '#b91c1c', background: '#fef2f2', padding: '2px 4px', borderRadius: 4 }}>Source_File</code>, and <code style={{ fontSize: 11, color: '#b91c1c', background: '#fef2f2', padding: '2px 4px', borderRadius: 4 }}>Source_Type</code>.
            </p>
          </div>

          {isInventoryUploaded ? (
            <div style={{
              background: '#f0fdf4', border: '1px solid #bbf7d0', borderRadius: 8, padding: '14px 16px',
              display: 'flex', alignItems: 'center', gap: 10
            }}>
              <CheckCircle2 size={16} color="#16a34a" />
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 12, fontWeight: 700, color: '#166534' }}>Inventory CSV Loaded</div>
                <div style={{ fontSize: 11, color: '#15803d', marginTop: 2 }}>
                  {aiStatus?.inventory_jobs_count || 'Verified'} jobs available in session
                </div>
              </div>
            </div>
          ) : (
            <label style={{
              border: '2px dashed #cbd5e1', borderRadius: 10, padding: '24px 16px', textAlign: 'center',
              cursor: uploadingInv ? 'not-allowed' : 'pointer', background: '#f8fafc',
              transition: 'all 0.2s', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8
            }}>
              {uploadingInv ? (
                <Loader2 size={24} color="#2563eb" style={{ animation: 'spin 1s linear infinite' }} />
              ) : (
                <Upload size={24} color="#64748b" />
              )}
              <span style={{ fontSize: 12, fontWeight: 600, color: '#475569' }}>
                {uploadingInv ? 'Uploading...' : 'Select Job Inventory CSV'}
              </span>
              <span style={{ fontSize: 10, color: '#94a3b8' }}>Click to browse CSV files</span>
              <input
                type="file"
                accept=".csv"
                disabled={uploadingInv}
                onChange={e => handleInvUpload(e.target.files?.[0])}
                style={{ display: 'none' }}
              />
            </label>
          )}
        </div>

        {/* Card 2: Source Code */}
        <div style={{
          border: '1px solid #e2e8f0', borderRadius: 12, padding: 20, background: '#fff',
          display: 'flex', flexDirection: 'column', gap: 14
        }}>
          <div>
            <span style={{ fontSize: 11, fontWeight: 700, color: '#7c3aed', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Required Input 2</span>
            <h3 style={{ fontSize: 14, fontWeight: 700, color: '#1e293b', marginTop: 4 }}>Job Source Code</h3>
            <p style={{ fontSize: 12, color: '#64748b', marginTop: 4, lineHeight: 1.5 }}>
              Upload the job scripts (Shell, SQL, Python, SSIS, Talend, Informatica XMLs, etc.). Filenames must match the <code style={{ fontSize: 11, color: '#b91c1c' }}>Source_File</code> column in the inventory CSV.
            </p>
          </div>

          <div style={{ display: 'flex', gap: 8, background: '#f1f5f9', padding: 3, borderRadius: 6, width: 'fit-content' }}>
            <button
              onClick={() => setSrcUploadType('files')}
              style={{
                border: 'none', background: srcUploadType === 'files' ? '#fff' : 'transparent',
                padding: '4px 10px', borderRadius: 4, fontSize: 11, fontWeight: 600,
                color: srcUploadType === 'files' ? '#1e293b' : '#64748b', cursor: 'pointer'
              }}
            >
              Select Files
            </button>
            <button
              onClick={() => setSrcUploadType('folder')}
              style={{
                border: 'none', background: srcUploadType === 'folder' ? '#fff' : 'transparent',
                padding: '4px 10px', borderRadius: 4, fontSize: 11, fontWeight: 600,
                color: srcUploadType === 'folder' ? '#1e293b' : '#64748b', cursor: 'pointer'
              }}
            >
              Select Folder
            </button>
          </div>

          {isSourceUploaded ? (
            <div style={{
              background: '#f0fdf4', border: '1px solid #bbf7d0', borderRadius: 8, padding: '14px 16px',
              display: 'flex', alignItems: 'center', gap: 10
            }}>
              <CheckCircle2 size={16} color="#16a34a" />
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 12, fontWeight: 700, color: '#166534' }}>Source Files Loaded</div>
                <div style={{ fontSize: 11, color: '#15803d', marginTop: 2 }}>
                  {aiStatus?.source_files_count || srcFiles.length} files uploaded
                </div>
              </div>
            </div>
          ) : (
            <label style={{
              border: '2px dashed #cbd5e1', borderRadius: 10, padding: '20px 16px', textAlign: 'center',
              cursor: uploadingSrc ? 'not-allowed' : 'pointer', background: '#f8fafc',
              transition: 'all 0.2s', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8
            }}>
              {uploadingSrc ? (
                <Loader2 size={24} color="#7c3aed" style={{ animation: 'spin 1s linear infinite' }} />
              ) : (
                <Upload size={24} color="#64748b" />
              )}
              <span style={{ fontSize: 12, fontWeight: 600, color: '#475569' }}>
                {uploadingSrc ? 'Uploading...' : srcUploadType === 'folder' ? 'Select Source Folder' : 'Select Source Files'}
              </span>
              <span style={{ fontSize: 10, color: '#94a3b8' }}>
                {srcUploadType === 'folder' ? 'Uploads directory tree' : 'Click to select multiple files'}
              </span>
              {srcUploadType === 'folder' ? (
                <input
                  type="file"
                  multiple
                  webkitdirectory=""
                  directory=""
                  disabled={uploadingSrc}
                  onChange={e => handleSrcUpload(e.target.files)}
                  style={{ display: 'none' }}
                />
              ) : (
                <input
                  type="file"
                  multiple
                  disabled={uploadingSrc}
                  onChange={e => handleSrcUpload(e.target.files)}
                  style={{ display: 'none' }}
                />
              )}
            </label>
          )}
        </div>
      </div>

      {/* Card 3: Failure Logs (Optional) — full width */}
      <div style={{
        border: '1px solid #fde68a', borderRadius: 12, padding: 20, background: '#fffbeb',
        marginBottom: 24, display: 'flex', flexDirection: 'column', gap: 14
      }}>
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 12 }}>
          <div>
            <span style={{ fontSize: 11, fontWeight: 700, color: '#d97706', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Optional Input — Failure Diagnostics</span>
            <h3 style={{ fontSize: 14, fontWeight: 700, color: '#1e293b', marginTop: 4 }}>Job Failure Logs (Control-M or other schedulers)</h3>
            <p style={{ fontSize: 12, color: '#64748b', marginTop: 4, lineHeight: 1.5, maxWidth: 600 }}>
              Upload one or more <code style={{ fontSize: 11, color: '#b45309', background: '#fef3c7', padding: '2px 4px', borderRadius: 4 }}>.log</code> or <code style={{ fontSize: 11, color: '#b45309', background: '#fef3c7', padding: '2px 4px', borderRadius: 4 }}>.txt</code> execution logs for jobs that failed.
              Each file is auto-matched to its Job ID — if multiple jobs failed, upload one log file per job and select them all at once.
              These logs power evidence-based <strong>Failure Analysis</strong> in Detailed AI and raise Risk &amp; Modernization scores where real failures occurred.
            </p>
          </div>
          {(aiStatus?.failure_logs_count > 0 || failureLogFiles.length > 0) && (
            <div style={{
              background: '#f0fdf4', border: '1px solid #bbf7d0', borderRadius: 8, padding: '8px 12px',
              display: 'flex', alignItems: 'center', gap: 8, flexShrink: 0
            }}>
              <CheckCircle2 size={14} color="#16a34a" />
              <span style={{ fontSize: 11, fontWeight: 700, color: '#166534' }}>
                {aiStatus?.failure_logs_count ?? failureLogFiles.length} matched
              </span>
            </div>
          )}
        </div>

        <label style={{
          border: `2px dashed ${isInventoryUploaded ? '#fbbf24' : '#d1d5db'}`, borderRadius: 10, padding: '18px 16px', textAlign: 'center',
          cursor: (uploadingLogs || !isInventoryUploaded) ? 'not-allowed' : 'pointer',
          background: isInventoryUploaded ? '#fffdf5' : '#f8f9fc',
          opacity: isInventoryUploaded ? 1 : 0.65,
          transition: 'all 0.2s', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8
        }}>
          {uploadingLogs ? (
            <Loader2 size={22} color="#d97706" style={{ animation: 'spin 1s linear infinite' }} />
          ) : (
            <Upload size={22} color={isInventoryUploaded ? '#d97706' : '#9ca3af'} />
          )}
          <span style={{ fontSize: 12, fontWeight: 600, color: isInventoryUploaded ? '#92400e' : '#6b7280' }}>
            {uploadingLogs ? 'Uploading & matching logs...' : isInventoryUploaded ? 'Select Failure Log File(s)' : 'Upload Job Inventory first (above) to enable this'}
          </span>
          <span style={{ fontSize: 10, color: isInventoryUploaded ? '#b45309' : '#9ca3af' }}>
            Select multiple .log / .txt files at once — each is matched to its own job automatically
          </span>
          <input
            type="file"
            accept=".log,.txt"
            multiple
            disabled={uploadingLogs || !isInventoryUploaded}
            onChange={e => handleFailureLogUpload(e.target.files)}
            style={{ display: 'none' }}
          />
        </label>
      </div>

      <div style={{
        border: '1px solid #e2e8f0', borderRadius: 12, padding: 20, background: '#f8fafc',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between'
      }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: '#334155' }}>Start Assessment Engine</div>
          <div style={{ fontSize: 11, color: '#64748b' }}>
            {isReady ? 'All inputs verified. Click start to build FAISS store and run High-Level rules.' : 'Upload both required inputs above to activate.'}
          </div>
        </div>

        <div style={{ display: 'flex', gap: 10 }}>
          {(isInventoryUploaded || isSourceUploaded || aiStatus?.failure_logs_count > 0 || failureLogFiles.length > 0) && (
            <button
              onClick={handleClear}
              style={{
                display: 'inline-flex', alignItems: 'center', gap: 6,
                padding: '8px 14px', borderRadius: 8, fontSize: 12, fontWeight: 600,
                cursor: 'pointer', background: '#fff', border: '1px solid #cbd5e1', color: '#64748b'
              }}
            >
              <Trash2 size={13} /> Clear
            </button>
          )}
          <button
            onClick={handleStart}
            disabled={!isReady || starting}
            style={{
              display: 'inline-flex', alignItems: 'center', gap: 6,
              padding: '8px 18px', borderRadius: 8, fontSize: 12, fontWeight: 600,
              cursor: !isReady || starting ? 'not-allowed' : 'pointer',
              background: !isReady || starting ? '#cbd5e1' : '#2563eb',
              color: '#fff', border: 'none', transition: 'all 0.15s'
            }}
          >
            {starting && <Loader2 size={13} style={{ animation: 'spin 1s linear infinite' }} />}
            <Sparkles size={13} /> Start Assessment
          </button>
        </div>
      </div>
    </div>
  )
}

/* ─────────────────────────────────────────────────────────────────
   SUBMODULE 2 — HIGH LEVEL ASSESSMENT
   ───────────────────────────────────────────────────────────────── */
function HighLevelPanel({ sessionId, onNext, onExport }) {
  const [loading, setLoading] = useState(false)
  const [data, setData] = useState([])
  const [search, setSearch] = useState('')
  const [appFilter, setAppFilter] = useState('ALL')
  const [riskFilter, setRiskFilter] = useState('ALL')
  const [dlLoading, setDlLoading] = useState(false)

  const fetchHighLevel = useCallback(async function() {
    setLoading(true)
    try {
      const res = await ai.getHighLevel(sessionId)
      setData(res.data.assessments || [])
    } catch (e) {
      toast.error('Failed to load high-level assessments. Has setup completed?')
    } finally {
      setLoading(false)
    }
  }, [sessionId])

  useEffect(() => {
    fetchHighLevel()
  }, [fetchHighLevel])

  function downloadReport() {
    onExport('highlevel')
  }

  const apps = Array.from(new Set(data.map(d => d.application || 'Unknown'))).filter(Boolean)

  const filtered = data.filter(r => {
    const q = search.toLowerCase()
    const matchesSearch = !q ||
      r.job_id.toLowerCase().includes(q) ||
      r.job_name.toLowerCase().includes(q) ||
      (r.job_type || '').toLowerCase().includes(q)
    
    const matchesApp = appFilter === 'ALL' || r.application === appFilter
    const matchesRisk = riskFilter === 'ALL' || r.risk_indicator === riskFilter
    return matchesSearch && matchesApp && matchesRisk
  })

  if (loading) {
    return <EmptyPrompt message="Loading High-Level Assessments..." />
  }

  if (data.length === 0) {
    return <EmptyPrompt message="Please complete the Setup tab and click 'Start Assessment' first to generate High Level rules assessment." />
  }

  return (
    <div>
      {/* Top guided wizard workflow next button */}
      <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 14 }}>
        <button
          onClick={onNext}
          style={{
            display: 'inline-flex', alignItems: 'center', gap: 6,
            padding: '8px 16px', borderRadius: 8, fontSize: 12, fontWeight: 700,
            background: '#7c3aed', color: '#fff', border: 'none', cursor: 'pointer',
            transition: 'all 0.15s'
          }}
        >
          Next: Detailed AI Analysis &rarr;
        </button>
      </div>

      <div style={{ display: 'flex', gap: 12, alignItems: 'center', marginBottom: 16, flexWrap: 'wrap' }}>
        <input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Search by Job ID, name, or type..."
          style={{
            padding: '7px 12px', borderRadius: 8, border: '1px solid #cbd5e1',
            fontSize: 12, color: '#334155', width: 220, outline: 'none'
          }}
        />

        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <span style={{ fontSize: 11, fontWeight: 700, color: '#64748b' }}>App:</span>
          <select
            value={appFilter}
            onChange={e => setAppFilter(e.target.value)}
            style={{
              padding: '6px 10px', borderRadius: 8, border: '1px solid #cbd5e1',
              fontSize: 12, color: '#334155', background: '#fff', outline: 'none'
            }}
          >
            <option value="ALL">All Applications</option>
            {apps.map(a => <option key={a} value={a}>{a}</option>)}
          </select>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <span style={{ fontSize: 11, fontWeight: 700, color: '#64748b' }}>Risk:</span>
          <select
            value={riskFilter}
            onChange={e => setRiskFilter(e.target.value)}
            style={{
              padding: '6px 10px', borderRadius: 8, border: '1px solid #cbd5e1',
              fontSize: 12, color: '#334155', background: '#fff', outline: 'none'
            }}
          >
            <option value="ALL">All Risks</option>
            <option value="HIGH">High</option>
            <option value="MEDIUM">Medium</option>
            <option value="LOW">Low</option>
          </select>
        </div>

        <div style={{ marginLeft: 'auto' }}>
          <RunBtn onClick={downloadReport} loading={dlLoading} variant="outline">
            <Download size={13} /> Export High Level Report (.xlsx)
          </RunBtn>
        </div>
      </div>

      <div style={{ overflowX: 'auto', borderRadius: 10, border: '1px solid #e2e8f0' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
          <thead style={{ background: '#f8fafc', borderBottom: '1px solid #e2e8f0' }}>
            <tr>
              {['Job ID', 'Job Name', 'Application', 'Job Type', 'File Ops', 'DB Ops', 'Utilities', 'Risk', 'Recommendation'].map(h => (
                <th key={h} style={{
                  padding: '10px 12px', textAlign: 'left', fontSize: 10,
                  fontWeight: 700, color: '#64748b', textTransform: 'uppercase',
                  letterSpacing: '0.06em', whiteSpace: 'nowrap'
                }}>
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map((r, idx) => {
              const riskColor = r.risk_indicator === 'HIGH' ? 'Critical'
                : r.risk_indicator === 'MEDIUM' ? 'Medium' : 'Low'
              return (
                <tr key={r.job_id} style={{
                  borderBottom: '1px solid #f1f5f9',
                  background: idx % 2 === 0 ? '#fff' : '#fafbfc'
                }}>
                  <td style={{ padding: '10px 12px', fontFamily: 'monospace', fontWeight: 600, color: '#334155' }}>{r.job_id}</td>
                  <td style={{ padding: '10px 12px', color: '#1e293b', fontWeight: 500 }}>{r.job_name}</td>
                  <td style={{ padding: '10px 12px', color: '#64748b' }}>{r.application}</td>
                  <td style={{ padding: '10px 12px', color: '#475569' }}>{r.job_type}</td>
                  <td style={{ padding: '10px 12px', color: '#64748b', whiteSpace: 'nowrap' }}>{r.file_operations}</td>
                  <td style={{ padding: '10px 12px', color: '#64748b', whiteSpace: 'nowrap' }}>{r.db_operations}</td>
                  <td style={{ padding: '10px 12px', color: '#64748b' }}>{r.utilities}</td>
                  <td style={{ padding: '10px 12px' }}>
                    <Badge level={riskColor} label={r.risk_indicator} />
                  </td>
                  <td style={{ padding: '10px 12px', color: '#2563eb', fontWeight: 600 }}>{r.modernization_recommendation}</td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
    </div>
  )
}

/* ─────────────────────────────────────────────────────────────────
   SUBMODULE 3 — DETAILED AI ANALYSIS
   ───────────────────────────────────────────────────────────────── */
function DetailedAnalysisPanel({ sessionId, selectedJob, setSelectedJob, jobs, onNext, onPrevious, onLoaded, selectedModel, onExport }) {
  const [loading, setLoading] = useState(false)
  const [analysis, setAnalysis] = useState(null)
  const [isCached, setIsCached] = useState(false)
  const [dlLoading, setDlLoading] = useState(false)

  async function handleAnalyze(jobId) {
    const id = jobId || selectedJob
    if (!id) return
    setLoading(true)
    try {
      const res = await ai.detailedAnalysis(sessionId, id)
      setAnalysis(res.data.analysis)
      setIsCached(res.data.cached)
      onLoaded(id, true)
    } catch (e) {
      toast.error('Detailed Analysis failed')
      onLoaded(id, false)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    if (selectedJob) {
      handleAnalyze(selectedJob)
    }
  }, [selectedJob, selectedModel])

  function downloadReport() {
    onExport('detailed')
  }

  if (jobs.length === 0) {
    return <EmptyPrompt message="Please complete the Setup tab and click 'Start Assessment' first." />
  }

  const a = analysis
  const isDetailedDone = !!a && !loading

  return (
    <div>
      {/* Top navigation header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
        <button
          onClick={onPrevious}
          style={{
            padding: '8px 16px', borderRadius: 8, fontSize: 12, fontWeight: 700,
            background: '#fff', border: '1px solid #cbd5e1', color: '#475569', cursor: 'pointer'
          }}
        >
          &larr; Previous: High Level Assessment
        </button>
        <button
          onClick={onNext}
          disabled={!isDetailedDone}
          style={{
            padding: '8px 16px', borderRadius: 8, fontSize: 12, fontWeight: 700,
            background: isDetailedDone ? '#dc2626' : '#cbd5e1', color: '#fff', border: 'none',
            cursor: isDetailedDone ? 'pointer' : 'not-allowed'
          }}
        >
          Next: Risk & Modernization &rarr;
        </button>
      </div>

      <div style={{ display: 'flex', gap: 14, alignItems: 'center', marginBottom: 18, borderBottom: '1px solid #f1f5f9', paddingBottom: 14 }}>
        <div style={{ minWidth: 260 }}>
          <label style={{ fontSize: 11, fontWeight: 700, color: '#64748b', textTransform: 'uppercase', display: 'block', marginBottom: 6 }}>
            Select Job to Analyze
          </label>
          <select
            value={selectedJob}
            onChange={e => setSelectedJob(e.target.value)}
            style={{ width: '100%', padding: '8px 12px', borderRadius: 8, border: '1px solid #cbd5e1', fontSize: 12, color: '#1e293b', background: '#fff' }}
          >
            {jobs.map(j => <option key={j.job_id} value={j.job_id}>{j.job_id} — {j.job_name}</option>)}
          </select>
        </div>

        {a && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 18 }}>
            <div style={{
              display: 'flex', alignItems: 'center', gap: 6, padding: '4px 10px', borderRadius: 99,
              fontSize: 11, fontWeight: 600,
              background: isCached ? '#ecfdf5' : '#eff6ff',
              border: `1px solid ${isCached ? '#10b98130' : '#3b82f630'}`,
              color: isCached ? '#047857' : '#1d4ed8'
            }}>
              <div style={{ width: 6, height: 6, borderRadius: '50%', background: isCached ? '#10b981' : '#3b82f6' }} />
              {isCached ? 'Loaded from Cache (0 Tokens)' : 'Generated via AI Model'}
            </div>
          </div>
        )}

        <div style={{ marginLeft: 'auto', marginTop: 18 }}>
          <RunBtn onClick={downloadReport} loading={dlLoading} variant="outline">
            <Download size={13} /> Export Detailed Report (.xlsx)
          </RunBtn>
        </div>
      </div>

      {loading && <EmptyPrompt message="Retrieving FAISS code chunks and performing Gemini Detailed Analysis..." />}

      {!loading && !a && <EmptyPrompt message="Select a job to perform Detailed AI RAG Analysis" />}

      {!loading && a && (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
          {/* Left Column */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <SectionCard title="Retrieved Source Code Chunks (RAG)" icon={FileCode2} iconColor="#ec4899">
              {(!a.retrieved_chunks || a.retrieved_chunks.length === 0) ? (
                <span style={{ fontSize: 11, color: '#94a3b8' }}>No code chunks found in FAISS store for this job.</span>
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                  {a.retrieved_chunks.map((chunk, idx) => (
                    <div key={idx} style={{ border: '1px solid #f1f5f9', borderRadius: 8, overflow: 'hidden' }}>
                      <div style={{ background: '#f8fafc', padding: '6px 12px', borderBottom: '1px solid #f1f5f9', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <span style={{ fontSize: 11, fontWeight: 700, color: '#475569' }}>FAISS Chunk #{idx + 1}</span>
                      </div>
                      <CodeBlock code={chunk} />
                    </div>
                  ))}
                </div>
              )}
            </SectionCard>

            <SectionCard title="Technical Assessment Narrative" icon={FileText} iconColor="#1d4ed8">
              <p style={{ fontSize: 12, color: '#334155', lineHeight: 1.7, margin: 0 }}>
                {a.detailed_technical_assessment}
              </p>
            </SectionCard>
          </div>

          {/* Right Column */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <SectionCard title="Database Objects Used" icon={BarChart3} iconColor="#059669">
              <KV label="Tables" value={a.tables?.join(', ')} />
              <KV label="Views" value={a.views?.join(', ')} />
              <KV label="Reference Tables" value={a.reference_tables?.join(', ')} />
              <KV label="Functions" value={a.functions?.join(', ')} />
              <KV label="Stored Procedures" value={a.stored_procedures?.join(', ')} />
            </SectionCard>

            <SectionCard title="SQL Joins Overview" icon={ArrowLeftRight} iconColor="#7c3aed">
              <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
                {['inner', 'left', 'right', 'outer'].map(jt => {
                  const joinVal = a.joins?.[jt]
                  const count = Array.isArray(joinVal) ? joinVal.length : (joinVal || 0)
                  return (
                    <div key={jt} style={{ textAlign: 'center', minWidth: 55, border: '1px solid #f1f5f9', padding: '8px 10px', borderRadius: 8 }}>
                      <div style={{ fontSize: 16, fontWeight: 700, color: '#2563eb', fontFamily: 'monospace' }}>
                        {count}
                      </div>
                      <div style={{ fontSize: 10, color: '#94a3b8', textTransform: 'uppercase', fontWeight: 600 }}>{jt}</div>
                    </div>
                  )
                })}
              </div>
            </SectionCard>

            <SectionCard title="System & Operation Semantics" icon={Zap} iconColor="#eab308">
              <KV label="File Operations" value={a.file_operations?.join(', ')} />
              <KV label="Database Operations" value={a.db_operations?.join(', ')} />
              <KV label="Utilities / Binaries called" value={a.utilities?.join(', ')} />
            </SectionCard>

            <SectionCard title="Error Handling & Resiliency" icon={ShieldAlert} iconColor="#dc2626">
              <KV label="Error Handling Logic" value={a.error_handling} />
              <KV label="Restart Protocol" value={a.restart_logic} />
              <KV label="Retry Policy" value={a.retry_logic} />
              <KV label="Checkpoint Logic" value={a.checkpoint_logic} />
              <KV label="Failure Recovery Action" value={a.failure_recovery} />
            </SectionCard>
          </div>
        </div>
      )}

      {!loading && a && (
        <div style={{ marginTop: 20 }}>
          <SectionCard
            title="Failure Analysis"
            icon={AlertTriangle}
            iconColor={a.failure_analysis && !a.failure_analysis.startsWith('No failure log') ? '#dc2626' : '#94a3b8'}
            defaultOpen
          >
            {a.failure_analysis && !a.failure_analysis.startsWith('No failure log') ? (
              <div>
                <div style={{
                  display: 'inline-flex', alignItems: 'center', gap: 6, marginBottom: 12,
                  padding: '4px 10px', borderRadius: 99, fontSize: 11, fontWeight: 700,
                  background: '#fef2f2', border: '1px solid #fecaca', color: '#b91c1c'
                }}>
                  <AlertTriangle size={12} /> Evidence-based — from uploaded failure log
                </div>
                <p style={{ fontSize: 12.5, color: '#334155', lineHeight: 1.75, margin: 0 }}>
                  {a.failure_analysis}
                </p>
              </div>
            ) : (
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 0' }}>
                <Info size={15} color="#94a3b8" style={{ flexShrink: 0 }} />
                <p style={{ fontSize: 12, color: '#64748b', lineHeight: 1.6, margin: 0 }}>
                  {a.failure_analysis || 'No failure log uploaded for this job. Upload a Control-M execution log (.log or .txt) in the Setup tab to enable evidence-based failure analysis.'}
                </p>
              </div>
            )}
          </SectionCard>
        </div>
      )}
    </div>
  )
}

/* ─────────────────────────────────────────────────────────────────
   SUBMODULE 4 — RISK & MODERNIZATION
   ───────────────────────────────────────────────────────────────── */
function RiskModernizationPanel({ sessionId, selectedJob, setSelectedJob, jobs, onNext, onPrevious, onLoaded, selectedModel, onExport }) {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState(null)
  const [isCached, setIsCached] = useState(false)
  const [dlLoading, setDlLoading] = useState(false)

  async function handleLoad(jobId) {
    const id = jobId || selectedJob
    if (!id) return
    setLoading(true)
    try {
      const res = await ai.riskModernization(sessionId, id)
      setResult(res.data.result)
      setIsCached(res.data.cached)
      onLoaded(id, true)
    } catch (e) {
      toast.error('Risk evaluation failed')
      onLoaded(id, false)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    if (selectedJob) {
      handleLoad(selectedJob)
    }
  }, [selectedJob, selectedModel])

  function downloadReport() {
    onExport('riskmods')
  }

  if (jobs.length === 0) {
    return <EmptyPrompt message="Please complete the Setup tab and click 'Start Assessment' first." />
  }

  const r = result
  const isRiskDone = !!r && !loading

  return (
    <div>
      {/* Top navigation header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
        <button
          onClick={onPrevious}
          style={{
            padding: '8px 16px', borderRadius: 8, fontSize: 12, fontWeight: 700,
            background: '#fff', border: '1px solid #cbd5e1', color: '#475569', cursor: 'pointer'
          }}
        >
          &larr; Previous: Detailed AI Analysis
        </button>
        <button
          onClick={onNext}
          disabled={!isRiskDone}
          style={{
            padding: '8px 16px', borderRadius: 8, fontSize: 12, fontWeight: 700,
            background: isRiskDone ? '#059669' : '#cbd5e1', color: '#fff', border: 'none',
            cursor: isRiskDone ? 'pointer' : 'not-allowed'
          }}
        >
          Next: Job Conversion &rarr;
        </button>
      </div>

      <div style={{ display: 'flex', gap: 14, alignItems: 'center', marginBottom: 18, borderBottom: '1px solid #f1f5f9', paddingBottom: 14 }}>
        <div style={{ minWidth: 260 }}>
          <label style={{ fontSize: 11, fontWeight: 700, color: '#64748b', textTransform: 'uppercase', display: 'block', marginBottom: 6 }}>
            Select Job for Risk Assessment
          </label>
          <select
            value={selectedJob}
            onChange={e => setSelectedJob(e.target.value)}
            style={{ width: '100%', padding: '8px 12px', borderRadius: 8, border: '1px solid #cbd5e1', fontSize: 12, color: '#1e293b', background: '#fff' }}
          >
            {jobs.map(j => <option key={j.job_id} value={j.job_id}>{j.job_id} — {j.job_name}</option>)}
          </select>
        </div>

        {r && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 18 }}>
            <div style={{
              display: 'flex', alignItems: 'center', gap: 6, padding: '4px 10px', borderRadius: 99,
              fontSize: 11, fontWeight: 600,
              background: isCached ? '#ecfdf5' : '#eff6ff',
              border: `1px solid ${isCached ? '#10b98130' : '#3b82f630'}`,
              color: isCached ? '#047857' : '#1d4ed8'
            }}>
              <div style={{ width: 6, height: 6, borderRadius: '50%', background: isCached ? '#10b981' : '#3b82f6' }} />
              {isCached ? 'Loaded from Cache (0 Tokens)' : 'Generated via AI Model'}
            </div>
          </div>
        )}

        <div style={{ marginLeft: 'auto', marginTop: 18 }}>
          <RunBtn onClick={downloadReport} loading={dlLoading} variant="outline">
            <Download size={13} /> Export Risk Report (.xlsx)
          </RunBtn>
        </div>
      </div>

      {loading && <EmptyPrompt message="Performing Gemini Risk & Modernization evaluation..." />}

      {!loading && !r && <EmptyPrompt message="Select a job to calculate migration risk metrics" />}

      {!loading && r && (
        <div>
          {/* Stats Metrics Cards */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 14, marginBottom: 20 }}>
            {[
              ['Risk Level', r.risk_level,
                r.risk_level === 'CRITICAL' ? '#fecaca' : r.risk_level === 'HIGH' ? '#fed7aa' : '#d1fae5',
                r.risk_level === 'CRITICAL' ? '#991b1b' : r.risk_level === 'HIGH' ? '#9a3412' : '#065f46'],
              ['Complexity', r.migration_complexity, '#fef3c7', '#92400e'],
              ['Modernization Priority', r.modernization_priority, '#e0f2fe', '#0369a1'],
              ['Technical Debt Score', `${r.technical_debt_score || 0}/10`, '#f5f3ff', '#6d28d9'],
              ['Restartability Score', `${r.restartability_score || 0}/10`, '#fdf2f8', '#be185d'],
            ].map(item => (
              <div key={item[0]} style={{
                background: item[2], border: '1px solid ' + item[3] + '15',
                borderRadius: 10, padding: '14px 12px', textAlign: 'center'
              }}>
                <div style={{ fontSize: 10, fontWeight: 700, color: item[3], textTransform: 'uppercase', letterSpacing: '0.04em' }}>{item[0]}</div>
                <div style={{ fontSize: 18, fontWeight: 800, color: item[3], marginTop: 8 }}>{item[1]}</div>
              </div>
            ))}
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1fr', gap: 20 }}>
            {/* Risk Factors */}
            <SectionCard title="Migration Risk Factors" icon={ShieldAlert} iconColor="#dc2626">
              {r.has_failure_log && (
                <div style={{
                  display: 'flex', alignItems: 'center', gap: 6, marginBottom: 12,
                  padding: '6px 10px', borderRadius: 8, fontSize: 11, fontWeight: 600,
                  background: '#fef2f2', border: '1px solid #fecaca', color: '#b91c1c'
                }}>
                  <AlertTriangle size={12} /> Risk elevated using real failure log evidence — see Detailed AI tab for full root-cause narrative
                </div>
              )}
              {(!r.risk_factors || r.risk_factors.length === 0) ? (
                <div style={{ fontSize: 12, color: '#16a34a', fontWeight: 600 }}>✓ No critical risks detected for this job migration.</div>
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                  {r.risk_factors.map((factor, idx) => {
                    const sev = (factor.severity || '').toUpperCase()
                    const badgeLevel = sev === 'CRITICAL' ? 'Critical' : sev === 'HIGH' ? 'High' : sev === 'MEDIUM' ? 'Medium' : 'Low'
                    const isFromLog = factor.factor?.toLowerCase().includes('failure log') || factor.factor?.toLowerCase().includes('production failure')
                    return (
                      <div key={idx} style={{
                        border: isFromLog ? '1px solid #fecaca' : '1px solid #f1f5f9',
                        background: isFromLog ? '#fffbfb' : 'transparent',
                        borderRadius: 8, padding: 12
                      }}>
                        <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 4 }}>
                          <Badge level={badgeLevel} label={factor.severity} />
                          <span style={{ fontSize: 12, fontWeight: 700, color: '#1e293b' }}>{factor.factor}</span>
                          {isFromLog && <AlertTriangle size={12} color="#dc2626" style={{ marginLeft: 'auto', flexShrink: 0 }} />}
                        </div>
                        <div style={{ fontSize: 11, color: '#475569', lineHeight: 1.5 }}>{factor.description}</div>
                      </div>
                    )
                  })}
                </div>
              )}
            </SectionCard>

            {/* Recommendations */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              <SectionCard title="Migration Recommendation" icon={TrendingUp} iconColor="#2563eb">
                <KV label="Modernization Recommendation" value={r.migration_recommendation} />
                <KV label="Target Framework/Technology" value={r.target_technology} />
                <KV label="Target Scheduler Recommendation" value={r.target_scheduler} />
              </SectionCard>

              <SectionCard title="Migration Strategy Reasoning" icon={FileText}>
                <p style={{ fontSize: 12, color: '#475569', lineHeight: 1.6, margin: 0 }}>
                  {r.reasoning}
                </p>
              </SectionCard>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

/* ─────────────────────────────────────────────────────────────────
   SUBMODULE 5 — JOB CONVERSION
   ───────────────────────────────────────────────────────────────── */
const mapRecommendedTech = (techStr) => {
  if (!techStr) return 'Python';
  const s = techStr.toLowerCase();
  if (s.includes('pyspark') || s.includes('spark')) return 'PySpark';
  if (s.includes('spring') || s.includes('springbatch')) return 'SpringBatch';
  if (s.includes('airflow') && s.includes('dag')) return 'AirflowDAG';
  if (s.includes('airflow')) return 'Airflow';
  if (s.includes('python') || s.includes('py')) return 'Python';
  if (s.includes('java')) return 'Java';
  if (s.includes('shell') || s.includes('bash')) return 'Shell';
  return 'Python';
}

function ConversionPanel({ sessionId, selectedJob, setSelectedJob, jobs, onNext, onPrevious, onLoaded, selectedModel, onExport }) {
  const [target, setTarget] = useState('Python')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState(null)
  const [isCached, setIsCached] = useState(false)
  const [dlLoading, setDlLoading] = useState(false)

  const [fetchingSource, setFetchingSource] = useState(false)
  const [originalSource, setOriginalSource] = useState('')

  useEffect(() => {
    async function loadJobData() {
      if (!selectedJob) return
      setFetchingSource(true)
      try {
        // Fetch original source code
        const srcRes = await ai.getJobSource(sessionId, selectedJob)
        setOriginalSource(srcRes.data.source_code || '')

        // Fetch Risk & Modernization cached recommendation to set the target technology
        const riskRes = await ai.riskModernization(sessionId, selectedJob)
        if (riskRes.data.success && riskRes.data.result) {
          const recTech = riskRes.data.result.target_technology || ''
          const mapped = mapRecommendedTech(recTech)
          setTarget(mapped)
        } else {
          // Fallback to high level recommendation
          const currentJob = jobs.find(j => j.job_id === selectedJob)
          if (currentJob) {
            const mapped = mapRecommendedTech(currentJob.modernization_recommendation)
            setTarget(mapped)
          }
        }
      } catch (e) {
        // Fallback to high level recommendation
        const currentJob = jobs.find(j => j.job_id === selectedJob)
        if (currentJob) {
          const mapped = mapRecommendedTech(currentJob.modernization_recommendation)
          setTarget(mapped)
        }
      } finally {
        setFetchingSource(false)
      }
    }
    loadJobData()
  }, [selectedJob, sessionId, jobs])

  async function run() {
    if (!selectedJob) return
    setLoading(true)
    try {
      const res = await ai.convertJob(sessionId, selectedJob, target)
      setResult(res.data.conversion)
      setIsCached(res.data.cached)
      toast.success('Successfully converted to ' + target)
      onLoaded(selectedJob, true)
    } catch (e) {
      toast.error('Conversion failed')
      onLoaded(selectedJob, false)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    setResult(null)
  }, [selectedJob, target])

  function downloadReport() {
    onExport('convert')
  }

  if (jobs.length === 0) {
    return <EmptyPrompt message="Please complete the Setup tab and click 'Start Assessment' first." />
  }

  const r = result
  const currentJob = jobs.find(j => j.job_id === selectedJob)
  const isConvertDone = !!r && !loading

  return (
    <div>
      {/* Top navigation header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
        <button
          onClick={onPrevious}
          style={{
            padding: '8px 16px', borderRadius: 8, fontSize: 12, fontWeight: 700,
            background: '#fff', border: '1px solid #cbd5e1', color: '#475569', cursor: 'pointer'
          }}
        >
          &larr; Previous: Risk & Modernization
        </button>
        <button
          onClick={onNext}
          disabled={!isConvertDone}
          style={{
            padding: '8px 16px', borderRadius: 8, fontSize: 12, fontWeight: 700,
            background: isConvertDone ? '#d97706' : '#cbd5e1', color: '#fff', border: 'none',
            cursor: isConvertDone ? 'pointer' : 'not-allowed'
          }}
        >
          Next: Summary & Export &rarr;
        </button>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1fr 150px', gap: 16, marginBottom: 20 }}>
        <div>
          <label style={{ fontSize: 11, fontWeight: 700, color: '#64748b', textTransform: 'uppercase', display: 'block', marginBottom: 6 }}>
            Select Job
          </label>
          <select
            value={selectedJob}
            onChange={e => setSelectedJob(e.target.value)}
            style={{ width: '100%', padding: '8px 12px', borderRadius: 8, border: '1px solid #cbd5e1', fontSize: 12, color: '#1e293b', background: '#fff' }}
          >
            {jobs.map(j => <option key={j.job_id} value={j.job_id}>{j.job_id} — {j.job_name}</option>)}
          </select>
        </div>

        <div>
          <label style={{ fontSize: 11, fontWeight: 700, color: '#64748b', textTransform: 'uppercase', display: 'block', marginBottom: 6 }}>
            Target Technology
          </label>
          <select
            value={target}
            onChange={e => setTarget(e.target.value)}
            style={{ width: '100%', padding: '8px 12px', borderRadius: 8, border: '1px solid #cbd5e1', fontSize: 12, color: '#1e293b', background: '#fff' }}
          >
            {CONVERSION_TARGETS.map(t => <option key={t} value={t}>{t}</option>)}
          </select>
        </div>

        <div style={{ display: 'flex', alignItems: 'flex-end', gap: 8 }}>
          <RunBtn onClick={run} loading={loading} variant="purple">
            <Sparkles size={13} /> Convert Code
          </RunBtn>
        </div>
      </div>

      {currentJob && (
        <div style={{ marginBottom: 16, background: '#f8fafc', padding: '10px 14px', borderRadius: 8, border: '1px solid #e2e8f0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ fontSize: 12, color: '#475569' }}>
            Mapped Source File: <strong style={{ color: '#0f172a' }}>{currentJob.source_file || currentJob.job_name}</strong> ({currentJob.job_type || 'Unknown'})
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            {r && (
              <div style={{
                display: 'flex', alignItems: 'center', gap: 6, padding: '2px 8px', borderRadius: 99,
                fontSize: 10, fontWeight: 600,
                background: isCached ? '#ecfdf5' : '#eff6ff',
                border: `1px solid ${isCached ? '#10b98130' : '#3b82f630'}`,
                color: isCached ? '#047857' : '#1d4ed8'
              }}>
                <div style={{ width: 5, height: 5, borderRadius: '50%', background: isCached ? '#10b981' : '#3b82f6' }} />
                {isCached ? 'Cached' : 'Generated via AI Model'}
              </div>
            )}
            <RunBtn onClick={downloadReport} loading={dlLoading} variant="outline">
              <Download size={13} /> Export Conversion Report (.xlsx)
            </RunBtn>
          </div>
        </div>
      )}

      {/* Side-by-side comparison layout */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20, marginBottom: 20 }}>
        {/* Left Panel: Original Source Code */}
        <div>
          <div style={{ fontSize: 11, fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 8 }}>
            Original Source Code ({currentJob?.job_type || 'Unknown'})
          </div>
          {fetchingSource ? (
            <div style={{ height: 300, background: '#0f172a', borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#94a3b8', fontSize: 12 }}>
              <Loader2 size={18} style={{ animation: 'spin 1s linear infinite', marginRight: 8 }} />
              Retrieving original source code...
            </div>
          ) : originalSource ? (
            <CodeBlock code={originalSource} />
          ) : (
            <div style={{ height: 300, background: '#0f172a', borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#94a3b8', fontSize: 12, padding: 16, textAlign: 'center' }}>
              No source code file uploaded or mapped to this job. Upload it in the Setup tab.
            </div>
          )}
        </div>

        {/* Right Panel: Target Converted Code */}
        <div>
          <div style={{ fontSize: 11, fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 8, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <span>Modernized target code ({r?.target_technology || target})</span>
            {r?.manual_review_needed && (
              <span style={{ color: '#d97706', display: 'inline-flex', alignItems: 'center', gap: 4, textTransform: 'none', fontWeight: 600 }}>
                <AlertTriangle size={12} /> Manual review required
              </span>
            )}
          </div>
          {loading ? (
            <div style={{ height: 300, background: '#0f172a', borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#94a3b8', fontSize: 12 }}>
              <Loader2 size={18} style={{ animation: 'spin 1s linear infinite', marginRight: 8 }} />
              Compiling legacy job logic into modernized {target}...
            </div>
          ) : r ? (
            <CodeBlock code={r.converted_code} />
          ) : (
            <div style={{ height: 300, background: '#0f172a', borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#94a3b8', fontSize: 12, padding: 16, textAlign: 'center' }}>
              Click 'Convert Code' to run the AI modernized conversion compilation.
            </div>
          )}
        </div>
      </div>

      {r && (
        <div style={{ marginTop: 24 }}>
          <h3 style={{ fontSize: 14, fontWeight: 700, color: '#1e293b', marginBottom: 14 }}>Job Conversion & Migration Reasoning</h3>
          
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 16 }}>
            <div style={{ background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: 8, padding: 12 }}>
              <div style={{ fontSize: 10, fontWeight: 700, color: '#64748b', textTransform: 'uppercase' }}>Current Technology</div>
              <div style={{ fontSize: 12, fontWeight: 600, color: '#1e293b', marginTop: 4 }}>{r.current_technology || currentJob?.job_type || 'Legacy Script'}</div>
            </div>
            <div style={{ background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: 8, padding: 12 }}>
              <div style={{ fontSize: 10, fontWeight: 700, color: '#64748b', textTransform: 'uppercase' }}>Recommended Technology</div>
              <div style={{ fontSize: 12, fontWeight: 600, color: '#2563eb', marginTop: 4 }}>{r.recommended_technology || target}</div>
            </div>
            <div style={{ background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: 8, padding: 12 }}>
              <div style={{ fontSize: 10, fontWeight: 700, color: '#64748b', textTransform: 'uppercase' }}>Migration Complexity</div>
              <div style={{ fontSize: 12, fontWeight: 600, color: r.migration_complexity === 'HIGH' ? '#b91c1c' : '#1e293b', marginTop: 4 }}>{r.migration_complexity || 'Medium'}</div>
            </div>
            <div style={{ background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: 8, padding: 12 }}>
              <div style={{ fontSize: 10, fontWeight: 700, color: '#64748b', textTransform: 'uppercase' }}>Confidence Score</div>
              <div style={{ fontSize: 12, fontWeight: 600, color: '#16a34a', marginTop: 4 }}>{r.confidence_score || '8/10'}</div>
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1fr', gap: 16 }}>
            {/* Left Column */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              <SectionCard title="Reason for Recommendation" icon={Info} iconColor="#2563eb" defaultOpen={true}>
                <p style={{ fontSize: 12, color: '#334155', lineHeight: 1.6, margin: 0 }}>
                  {r.reason_for_recommendation || r.migration_explanation}
                </p>
              </SectionCard>

              <SectionCard title="Business Impact & Benefits" icon={TrendingUp} iconColor="#16a34a" defaultOpen={true}>
                <KV label="Business Impact" value={r.business_impact} />
                <div style={{ marginTop: 10 }}>
                  <div style={{ fontSize: 10, fontWeight: 700, color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 6 }}>Key Benefits</div>
                  {(!r.benefits || r.benefits.length === 0) ? (
                    <span style={{ fontSize: 11, color: '#94a3b8' }}>—</span>
                  ) : (
                    r.benefits.map((b, i) => <div key={i} style={{ fontSize: 12, color: '#334155', marginBottom: 4 }}>• {b}</div>)
                  )}
                </div>
              </SectionCard>
            </div>

            {/* Right Column */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              <SectionCard title="Dependencies & Potential Risks" icon={ShieldAlert} iconColor="#dc2626" defaultOpen={true}>
                <div style={{ marginBottom: 12 }}>
                  <div style={{ fontSize: 10, fontWeight: 700, color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 6 }}>Dependencies</div>
                  {(!r.dependencies || r.dependencies.length === 0) ? (
                    <span style={{ fontSize: 11, color: '#94a3b8' }}>—</span>
                  ) : (
                    r.dependencies.map((d, i) => <span key={i} style={{ display: 'inline-block', background: '#f1f5f9', padding: '2px 6px', borderRadius: 4, fontSize: 11, color: '#475569', marginRight: 6, marginBottom: 6 }}>{d}</span>)
                  )}
                </div>
                <div>
                  <div style={{ fontSize: 10, fontWeight: 700, color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 6 }}>Potential Risks</div>
                  {(!r.potential_risks || r.potential_risks.length === 0) ? (
                    <span style={{ fontSize: 11, color: '#16a34a', fontWeight: 600 }}>✓ No conversion risks identified.</span>
                  ) : (
                    r.potential_risks.map((pr, i) => <div key={i} style={{ fontSize: 12, color: '#b45309', marginBottom: 4 }}>• {pr}</div>)
                  )}
                </div>
              </SectionCard>

              <SectionCard title="Manual Changes & Migration Effort" icon={AlertTriangle} iconColor="#d97706" defaultOpen={true}>
                <div style={{ marginBottom: 12 }}>
                  <div style={{ fontSize: 10, fontWeight: 700, color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 6 }}>Manual Changes Required</div>
                  {(!r.manual_changes_required || r.manual_changes_required.length === 0) ? (
                    <span style={{ fontSize: 11, color: '#16a34a', fontWeight: 600 }}>✓ Fully automated conversion.</span>
                  ) : (
                    r.manual_changes_required.map((mc, i) => <div key={i} style={{ fontSize: 12, color: '#334155', marginBottom: 4 }}>• {mc}</div>)
                  )}
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', background: '#fef3c7', border: '1px solid #fde68a', borderRadius: 8, padding: '8px 12px' }}>
                  <span style={{ fontSize: 11, color: '#92400e', fontWeight: 700 }}>Estimated Migration Effort:</span>
                  <span style={{ fontSize: 12, color: '#92400e', fontWeight: 800 }}>{r.estimated_effort_hours || 0} Hours</span>
                </div>
              </SectionCard>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

/* ─────────────────────────────────────────────────────────────────
   SUBMODULE 6 — EXECUTIVE SUMMARY & EXPORT
   ───────────────────────────────────────────────────────────────── */
function ExecutiveSummaryPanel({ sessionId, onPrevious, onExport }) {
  const [loading, setLoading] = useState(false)
  const [summary, setSummary] = useState(null)
  const [dlLoading, setDlLoading] = useState(false)
  const [evLoading, setEvLoading] = useState(false)

  async function run() {
    setLoading(true)
    try {
      const res = await ai.executiveSummary(sessionId)
      setSummary(res.data.summary)
      toast.success('Executive summary generated')
    } catch (e) {
      toast.error('Summary generation failed')
    } finally {
      setLoading(false)
    }
  }

  function downloadSummaryReport() {
    onExport('summary')
  }

  const downloadEverythingReport = () => {
    onExport('everything')
  }

  const s = summary

  return (
    <div>
      {/* Top navigation header */}
      <div style={{ display: 'flex', justifyContent: 'flex-start', marginBottom: 14 }}>
        <button
          onClick={onPrevious}
          style={{
            padding: '8px 16px', borderRadius: 8, fontSize: 12, fontWeight: 700,
            background: '#fff', border: '1px solid #cbd5e1', color: '#475569', cursor: 'pointer'
          }}
        >
          &larr; Previous: Job Conversion
        </button>
      </div>

      <div style={{ display: 'flex', gap: 12, marginBottom: 16, flexWrap: 'wrap' }}>
        <RunBtn onClick={run} loading={loading}>
          <Brain size={13} /> Generate Executive Summary
        </RunBtn>
        <RunBtn onClick={downloadSummaryReport} loading={dlLoading} variant="outline">
          <Download size={13} /> Export Summary Report (.xlsx)
        </RunBtn>
        <RunBtn onClick={downloadEverythingReport} loading={evLoading} variant="outline">
          <Download size={13} /> Export Everything (All Consolidated) (.xlsx)
        </RunBtn>
      </div>

      {!s && !loading && (
        <EmptyPrompt message="Run setup, high level rules, and detailed analysis, then click Generate Executive Summary." />
      )}

      {s && (
        <div>
          {s.headline && (
            <div style={{ padding: '14px 20px', background: '#1e3a5f', borderRadius: 12, marginBottom: 16, color: '#ffffff', fontSize: 15, fontWeight: 700, letterSpacing: '-0.02em' }}>
              {s.headline}
            </div>
          )}

          {s.executive_summary && (
            <SectionCard title="Executive Summary Narrative" icon={FileText} iconColor="#2563eb">
              <p style={{ fontSize: 13, color: '#374151', lineHeight: 1.8, margin: 0 }}>{s.executive_summary}</p>
            </SectionCard>
          )}

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
            {(s.key_findings || []).length > 0 && (
              <SectionCard title="Key Strategic Findings" icon={CheckCircle2} iconColor="#16a34a">
                {s.key_findings.map(function(f, i) {
                  return (
                    <div key={i} style={{ fontSize: 12, color: '#374151', marginBottom: 8, display: 'flex', gap: 7 }}>
                      <span style={{ color: '#2563eb', fontWeight: 700, flexShrink: 0 }}>{i + 1}.</span>
                      {f}
                    </div>
                  )
                })}
              </SectionCard>
            )}

            {(s.strategic_recommendations || []).length > 0 && (
              <SectionCard title="Strategic Recommendations" icon={TrendingUp} iconColor="#7c3aed">
                {s.strategic_recommendations.map(function(rec, i) {
                  return (
                    <div key={i} style={{ marginBottom: 12 }}>
                      <div style={{ fontSize: 12, fontWeight: 700, color: '#374151' }}>
                        P{rec.priority}: {rec.recommendation}
                      </div>
                      <div style={{ fontSize: 11, color: '#6b7280', marginTop: 2 }}>
                        {rec.business_value} · {rec.timeline}
                      </div>
                    </div>
                  )
                })}
              </SectionCard>
            )}
          </div>

          {s.risk_summary && (
            <SectionCard title="Aggregate Risk Summary" icon={ShieldAlert} iconColor="#dc2626">
              <p style={{ fontSize: 12, color: '#374151', lineHeight: 1.7, margin: 0 }}>{s.risk_summary}</p>
            </SectionCard>
          )}

          {s.modernization_roadmap && (
            <SectionCard title="Modernization Implementation Roadmap" icon={TrendingUp} iconColor="#16a34a">
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12 }}>
                {[
                  ['Phase 1', s.modernization_roadmap.phase1, '#eff4ff', '#2563eb'],
                  ['Phase 2', s.modernization_roadmap.phase2, '#f5f3ff', '#7c3aed'],
                  ['Phase 3', s.modernization_roadmap.phase3, '#f0fdf4', '#16a34a'],
                ].map(function(item) {
                  if (!item[1]) return null
                  return (
                    <div key={item[0]} style={{ padding: '12px 14px', background: item[2], borderRadius: 9, border: '1px solid ' + item[3] + '30' }}>
                      <div style={{ fontSize: 11, fontWeight: 700, color: item[3], marginBottom: 5 }}>{item[0]}</div>
                      <div style={{ fontSize: 12, color: '#374151', lineHeight: 1.6 }}>{item[1]}</div>
                    </div>
                  )
                })}
              </div>
            </SectionCard>
          )}
        </div>
      )}
    </div>
  )
}

/* ─────────────────────────────────────────────────────────────────
   MAIN AI ASSESSMENT PAGE
   ───────────────────────────────────────────────────────────────── */
const AI_TABS = [
  { id: 'setup',     label: 'Input Setup',         icon: FileCode2,     color: '#2563eb' },
  { id: 'highlevel', label: 'High Level',          icon: BarChart3,     color: '#7c3aed' },
  { id: 'detailed',  label: 'Detailed AI',         icon: Brain,         color: '#ec4899' },
  { id: 'riskmods',  label: 'Risk & Modernization', icon: ShieldAlert,  color: '#dc2626' },
  { id: 'convert',   label: 'Job Conversion',      icon: ArrowLeftRight, color: '#059669' },
  { id: 'summary',   label: 'Summary & Export',    icon: FileText,      color: '#d97706' },
]

export default function AIAssessmentPage() {
  const { state } = useApp()
  const { uploadedFiles, selectedFileIds } = state
  const [activeAiTab, setActiveAiTab] = useState('setup')
  const [aiStatus, setAiStatus] = useState(null)
  
  // Hoisted workflow states
  const [jobs, setJobs] = useState([])
  const [selectedJob, setSelectedJob] = useState('')
  const [selectedModel, setSelectedModel] = useState('gemini-2.5-flash')
  const [models, setModels] = useState([])
  const [loadingModels, setLoadingModels] = useState(false)
  const [completedStages, setCompletedStages] = useState({})

  const activeFile = uploadedFiles.find(function(f) {
    return selectedFileIds.includes(f.sessionId)
  }) || uploadedFiles[0]

  const sessionId = activeFile ? activeFile.sessionId : null

  // Fetch status of setup inputs and model selection
  const checkStatus = useCallback(async function() {
    if (!sessionId) return
    try {
      const res = await ai.status(sessionId)
      setAiStatus(res.data)
      if (res.data.selected_model) {
        setSelectedModel(res.data.selected_model)
      }
    } catch (e) { }
  }, [sessionId])

  // Fetch available models config
  useEffect(() => {
    async function loadModels() {
      setLoadingModels(true)
      try {
        const res = await ai.getModels()
        setModels(res.data || [])
      } catch (e) {
        toast.error('Failed to load configurable models list')
      } finally {
        setLoadingModels(false)
      }
    }
    loadModels()
  }, [])

  // Fetch jobs once setup complete to synchronize selection
  useEffect(() => {
    async function loadJobs() {
      if (!sessionId || !aiStatus?.assessment_started) return
      try {
        const res = await ai.getHighLevel(sessionId)
        const items = res.data.assessments || []
        setJobs(items)
        if (items.length > 0 && !selectedJob) {
          setSelectedJob(items[0].job_id)
        }
      } catch (e) { }
    }
    loadJobs()
  }, [sessionId, aiStatus?.assessment_started])

  useEffect(function() {
    checkStatus()
  }, [checkStatus])

  const handleModelChange = async (modelId) => {
    setSelectedModel(modelId)
    try {
      await ai.selectModel(sessionId, modelId)
      toast.success(`Switched AI Model to ${models.find(m => m.id === modelId)?.name || modelId}`)
      // Clear completion stages for the current job to force re-runs
      setCompletedStages(prev => ({
        ...prev,
        [selectedJob]: {
          detailed: false,
          riskmods: false,
          convert: false
        }
      }))
    } catch (e) {
      toast.error('Failed to switch AI model on backend')
    }
  }

  const handleStageLoaded = (jobId, stage, isComplete) => {
    setCompletedStages(prev => ({
      ...prev,
      [jobId]: {
        ...(prev[jobId] || {}),
        [stage]: isComplete
      }
    }))
  }

  const isTabDisabled = (tabId) => {
    if (tabId === 'setup') return false
    if (!aiStatus?.assessment_started) return true
    if (tabId === 'highlevel') return false
    if (tabId === 'detailed') return false // Open detailed after HL assessment starts
    
    // Strict guided workflow checks:
    if (tabId === 'riskmods') {
      return !completedStages[selectedJob]?.detailed
    }
    if (tabId === 'convert') {
      return !completedStages[selectedJob]?.riskmods
    }
    if (tabId === 'summary') {
      return !completedStages[selectedJob]?.convert
    }
    return false
  }

  const navigateTo = (tabId) => {
    if (!isTabDisabled(tabId)) {
      setActiveAiTab(tabId)
    }
  }

  const [exportModalOpen, setExportModalOpen] = useState(false)
  const [exportModule, setExportModule] = useState('everything')

  const triggerExport = (moduleName) => {
    setExportModule(moduleName)
    setExportModalOpen(true)
  }

  const handleExportConfirm = (format) => {
    const url = ai.finalReportUrl(sessionId, exportModule, format)
    window.location.href = url
    toast.success(`${exportModule.toUpperCase()} report export in ${format.toUpperCase()} initiated!`)
  }

  if (!sessionId) {
    return (
      <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#f8f9fc' }}>
        <div style={{ textAlign: 'center' }}>
          <Brain size={40} color="#d1d5db" style={{ marginBottom: 12 }} />
          <div style={{ fontSize: 15, fontWeight: 600, color: '#374151', marginBottom: 4 }}>No session active</div>
          <div style={{ fontSize: 13, color: '#9ca3af' }}>Please upload schedule files in Phase 1 first to initialize a session</div>
        </div>
      </div>
    )
  }

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden', background: '#f8f9fc' }}>
      {/* Top bar */}
      <div style={{ background: '#ffffff', borderBottom: '1px solid #e4e8f0', padding: '12px 24px', display: 'flex', alignItems: 'center', gap: 12, flexShrink: 0 }}>
        <Brain size={17} color="#2563eb" />
        <div style={{ flex: 1 }}>
          <span style={{ fontSize: 14, fontWeight: 700, color: '#111827' }}>AI Assessment & Modernization</span>
          <span style={{ fontSize: 12, color: '#9ca3af', marginLeft: 10 }}>
            Session ID: {sessionId.slice(0, 8)}
          </span>
        </div>

        {/* Model Selector */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginRight: 16 }}>
          <span style={{ fontSize: 11, fontWeight: 700, color: '#475569' }}>AI Model:</span>
          {loadingModels ? (
            <Loader2 size={12} style={{ animation: 'spin 1s linear infinite' }} />
          ) : (
            <select
              value={selectedModel}
              onChange={(e) => handleModelChange(e.target.value)}
              style={{
                padding: '6px 12px', borderRadius: 8, border: '1px solid #cbd5e1',
                fontSize: 12, color: '#1e293b', background: '#fff', outline: 'none',
                fontWeight: 600, cursor: 'pointer'
              }}
            >
              {models.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}
            </select>
          )}
        </div>

        {aiStatus && (
          <div style={{ display: 'flex', gap: 8 }}>
            <StatusPill
              label={models.find(m => m.id === selectedModel)?.name || "Gemini 2.0 Flash"}
              active={aiStatus.gemini_available}
              sub={aiStatus.gemini_available ? 'ready' : 'no key'}
            />
            <StatusPill
              label="Job Inventory"
              active={aiStatus.inventory_uploaded}
              sub={aiStatus.inventory_uploaded ? `${aiStatus.inventory_jobs_count} jobs` : 'missing'}
            />
            <StatusPill
              label="Source Code"
              active={aiStatus.source_uploaded}
              sub={aiStatus.source_uploaded ? `${aiStatus.source_files_count} files` : 'missing'}
            />
            <StatusPill
              label="FAISS Status"
              active={aiStatus.assessment_started}
              sub={aiStatus.assessment_started ? 'Assessed' : 'Idle'}
            />
          </div>
        )}
      </div>

      {/* Tab nav */}
      <div style={{ background: '#ffffff', borderBottom: '1px solid #e4e8f0', padding: '0 24px', display: 'flex', flexShrink: 0, overflowX: 'auto' }}>
        {AI_TABS.map(function(t) {
          const Icon = t.icon
          const active = activeAiTab === t.id
          const disabled = isTabDisabled(t.id)
          return (
            <button
              key={t.id}
              onClick={function() { if (!disabled) navigateTo(t.id) }}
              disabled={disabled}
              title={disabled ? 'This stage is locked. Please complete preceding workflow steps first.' : ''}
              style={{
                display: 'flex', alignItems: 'center', gap: 7,
                padding: '12px 16px', border: 'none', background: 'transparent',
                cursor: disabled ? 'not-allowed' : 'pointer', fontSize: 12, fontWeight: active ? 700 : 500,
                color: disabled ? '#cbd5e1' : active ? t.color : '#64748b',
                borderBottom: active ? '2px solid ' + t.color : '2px solid transparent',
                transition: 'all 0.12s', whiteSpace: 'nowrap',
              }}
            >
              <Icon size={13} />
              {t.label}
            </button>
          )
        })}
      </div>

      {/* Content */}
      <div style={{ flex: 1, overflowY: 'auto', padding: 24 }}>
        <div style={{ background: '#ffffff', border: '1px solid #e4e8f0', borderRadius: 14, padding: 22, boxShadow: '0 2px 8px rgba(0,0,0,0.04)' }}>
          {activeAiTab === 'setup'     && (
            <InputSetupPanel
              sessionId={sessionId}
              onSetupComplete={checkStatus}
              aiStatus={aiStatus}
            />
          )}
          {activeAiTab === 'highlevel' && (
            <HighLevelPanel
              sessionId={sessionId}
              onNext={() => navigateTo('detailed')}
              onExport={triggerExport}
            />
          )}
          {activeAiTab === 'detailed'  && (
            <DetailedAnalysisPanel
              sessionId={sessionId}
              selectedJob={selectedJob}
              setSelectedJob={setSelectedJob}
              jobs={jobs}
              selectedModel={selectedModel}
              onLoaded={(jobId, isOk) => handleStageLoaded(jobId, 'detailed', isOk)}
              onNext={() => navigateTo('riskmods')}
              onPrevious={() => navigateTo('highlevel')}
              onExport={triggerExport}
            />
          )}
          {activeAiTab === 'riskmods'  && (
            <RiskModernizationPanel
              sessionId={sessionId}
              selectedJob={selectedJob}
              setSelectedJob={setSelectedJob}
              jobs={jobs}
              selectedModel={selectedModel}
              onLoaded={(jobId, isOk) => handleStageLoaded(jobId, 'riskmods', isOk)}
              onNext={() => navigateTo('convert')}
              onPrevious={() => navigateTo('detailed')}
              onExport={triggerExport}
            />
          )}
          {activeAiTab === 'convert'   && (
            <ConversionPanel
              sessionId={sessionId}
              selectedJob={selectedJob}
              setSelectedJob={setSelectedJob}
              jobs={jobs}
              selectedModel={selectedModel}
              onLoaded={(jobId, isOk) => handleStageLoaded(jobId, 'convert', isOk)}
              onNext={() => navigateTo('summary')}
              onPrevious={() => navigateTo('riskmods')}
              onExport={triggerExport}
            />
          )}
          {activeAiTab === 'summary'   && (
            <ExecutiveSummaryPanel
              sessionId={sessionId}
              onPrevious={() => navigateTo('convert')}
              onExport={triggerExport}
            />
          )}
        </div>
      </div>

      <ExportModal
        isOpen={exportModalOpen}
        onClose={() => setExportModalOpen(false)}
        onConfirm={handleExportConfirm}
      />
    </div>
  )
}
