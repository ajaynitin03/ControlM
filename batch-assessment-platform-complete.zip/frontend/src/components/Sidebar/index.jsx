import { Network, Upload, LayoutList, BarChart2, Brain, ChevronRight, Info } from 'lucide-react'
import { useApp } from '../../hooks/useAppState'

const NAV_ITEMS = [
  { id: 'upload',    icon: Upload,     label: 'Upload Files',     desc: 'Import job schedules' },
  { id: 'multiview', icon: LayoutList, label: 'Diagrams & Data',  desc: 'Preview, select jobs & graphs' },
  { id: 'analysis',  icon: BarChart2,  label: 'Analysis',         desc: 'Critical path, fan metrics, cycles' },
  { id: 'ai',        icon: Brain,      label: 'AI Assessment',    desc: 'Bulk assess, convert, report' },
]

export default function Sidebar() {
  const { state, dispatch } = useApp()
  const { activeTab, uploadedFiles } = state

  const setTab = id => dispatch({ type: 'SET_ACTIVE_TAB', payload: id })

  const isEnabled = id => {
    if (id === 'upload') return true
    return uploadedFiles.length > 0
  }

  return (
    <aside style={{
      width: 232, minWidth: 232,
      background: '#ffffff', borderRight: '1px solid #e4e8f0',
      display: 'flex', flexDirection: 'column', height: '100vh', flexShrink: 0,
    }}>
      {/* Logo */}
      <div style={{ padding: '18px 18px 14px', borderBottom: '1px solid #e4e8f0' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{
            width: 36, height: 36, borderRadius: 10, flexShrink: 0,
            background: 'linear-gradient(135deg, #2563eb 0%, #1d4ed8 60%, #06b6d4 100%)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: '0 4px 12px rgba(37,99,235,0.35)',
          }}>
            <Network size={18} color="#fff" />
          </div>
          <div>
            <div style={{ fontSize: 13, fontWeight: 800, letterSpacing: '-0.02em', lineHeight: 1.2 }}>
              <span className="gradient-text">Batch Assessment</span>
            </div>
            <div style={{ fontSize: 11, color: '#9ca3af', marginTop: 2 }}>
              Tool · Migration Platform
            </div>
          </div>
        </div>
      </div>

      {/* Phase badges */}
      <div style={{ padding: '8px 14px', borderBottom: '1px solid #f1f3f7', display: 'flex', gap: 6 }}>
        {[['Phase 1', '#dbeafe', '#1d4ed8'], ['Phase 2 AI', '#f3e8ff', '#7c3aed']].map(([l, bg, c]) => (
          <span key={l} style={{
            padding: '2px 8px', borderRadius: 99, fontSize: 10, fontWeight: 700,
            background: bg, color: c,
          }}>{l}</span>
        ))}
      </div>

      {/* Nav */}
      <nav style={{ padding: '10px 10px 0', flex: 1 }}>
        <div style={{ fontSize: 10, fontWeight: 700, color: '#c0c6d4', letterSpacing: '0.09em', textTransform: 'uppercase', padding: '0 8px 8px' }}>
          Workspace
        </div>

        {NAV_ITEMS.map(({ id, icon: Icon, label, desc }) => {
          const enabled = isEnabled(id)
          const active  = activeTab === id
          const isAI    = id === 'ai'

          return (
            <button
              key={id}
              onClick={() => enabled && setTab(id)}
              disabled={!enabled}
              style={{
                width: '100%', display: 'flex', alignItems: 'center', gap: 10,
                padding: '9px 10px', borderRadius: 9, marginBottom: 2,
                cursor: enabled ? 'pointer' : 'not-allowed',
                background: active ? (isAI ? '#f5f3ff' : '#eff4ff') : 'transparent',
                border: 'none', textAlign: 'left', outline: 'none',
                transition: 'background 0.18s cubic-bezier(0.16,1,0.3,1), transform 0.18s cubic-bezier(0.16,1,0.3,1)',
                opacity: enabled ? 1 : 0.38,
                borderRight: active ? `3px solid ${isAI ? '#7c3aed' : '#2563eb'}` : '3px solid transparent',
                boxShadow: active ? (isAI ? '0 2px 10px rgba(124,58,237,0.12)' : '0 2px 10px rgba(37,99,235,0.12)') : 'none',
              }}
              onMouseEnter={e => {
                if (!active && enabled) { e.currentTarget.style.background = '#f8f9fc'; e.currentTarget.style.transform = 'translateX(2px)' }
              }}
              onMouseLeave={e => {
                if (!active) { e.currentTarget.style.background = 'transparent' }
                e.currentTarget.style.transform = 'none'
              }}
            >
              <div style={{
                width: 30, height: 30, borderRadius: 7, flexShrink: 0,
                background: active ? (isAI ? '#ede9fe' : '#dbeafe') : '#f1f4f9',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                transition: 'background 0.18s ease-out, transform 0.18s ease-out',
                transform: active ? 'scale(1.05)' : 'scale(1)',
              }}>
                <Icon size={14} color={active ? (isAI ? '#7c3aed' : '#2563eb') : '#6b7280'} />
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 13, fontWeight: active ? 600 : 500,
                  color: active ? (isAI ? '#6d28d9' : '#1d4ed8') : '#374151', lineHeight: 1.3 }}>
                  {label}
                  {isAI && <span style={{ marginLeft: 5, fontSize: 9, fontWeight: 700, background: '#7c3aed', color: '#fff', padding: '1px 5px', borderRadius: 3 }}>NEW</span>}
                </div>
                <div style={{ fontSize: 11, color: '#9ca3af', marginTop: 1, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                  {desc}
                </div>
              </div>
              {active && <ChevronRight size={13} color={isAI ? '#7c3aed' : '#2563eb'} style={{ flexShrink: 0 }} />}
            </button>
          )
        })}

        {/* Job selection hint */}
        {uploadedFiles.length > 0 && (
          <div style={{ margin: '12px 0 0', padding: '10px 12px', background: '#f8f9fc', border: '1px solid #e4e8f0', borderRadius: 9, display: 'flex', gap: 8 }}>
            <Info size={13} color="#9ca3af" style={{ flexShrink: 0, marginTop: 1 }} />
            <div style={{ fontSize: 11, color: '#6b7280', lineHeight: 1.5 }}>
              <strong style={{ color: '#374151' }}>Job selection</strong> is inside each file card under{' '}
              <strong style={{ color: '#374151' }}>Dependency Diagram → Select Jobs</strong>.
            </div>
          </div>
        )}
      </nav>

      {/* File count */}
      {uploadedFiles.length > 0 && (
        <div style={{ padding: '10px 18px', borderTop: '1px solid #f1f3f7' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '7px 11px', background: '#f8f9fc', border: '1px solid #e4e8f0', borderRadius: 8 }}>
            <span style={{ fontSize: 12, color: '#6b7280' }}>Files loaded</span>
            <span style={{ fontSize: 12, fontWeight: 700, color: '#2563eb', background: '#dbeafe', padding: '1px 8px', borderRadius: 99 }}>
              {uploadedFiles.length}
            </span>
          </div>
        </div>
      )}

      {/* Footer */}
      <div style={{ padding: '8px 18px 14px', borderTop: '1px solid #f1f3f7' }}>
        <div style={{ fontSize: 11, color: '#c0c6d4' }}>v2.0.0 · Phase 1 + 2 · Gemini RAG</div>
      </div>
    </aside>
  )
}
