import { useEffect, useState } from 'react'
import { ChevronLeft, ChevronRight, Download } from 'lucide-react'
import { getPreview } from '../../services/api'
import { useApp } from '../../hooks/useAppState'

const CRIT_BADGE = {
  HIGH:   <span className="badge-high">HIGH</span>,
  MEDIUM: <span className="badge-medium">MED</span>,
  LOW:    <span className="badge-low">LOW</span>,
}

export default function DataPreview() {
  const { state } = useApp()
  const { sessionId, uploadData } = state
  const [page, setPage] = useState(1)
  const [data, setData] = useState(uploadData?.preview || [])
  const [totalPages, setTotalPages] = useState(uploadData?.total_pages || 1)
  const [loading, setLoading] = useState(false)
  const [columns] = useState(uploadData?.columns || [])

  useEffect(() => {
    if (!sessionId || page === 1) {
      setData(uploadData?.preview || [])
      setTotalPages(uploadData?.total_pages || 1)
      return
    }
    setLoading(true)
    getPreview(sessionId, page)
      .then((res) => {
        setData(res.data.data)
        setTotalPages(res.data.total_pages)
      })
      .finally(() => setLoading(false))
  }, [sessionId, page, uploadData])

  if (!uploadData) {
    return (
      <div className="flex-1 flex items-center justify-center text-gray-400">
        <p>Upload a file to preview data</p>
      </div>
    )
  }

  const renderCell = (col, val) => {
    if (col === 'Criticality') return CRIT_BADGE[val] || <span className="badge-low">{val || 'LOW'}</span>
    if (col === 'Predecessors' && val) {
      const preds = val.split(',').filter(Boolean)
      return (
        <div className="flex flex-wrap gap-1">
          {preds.map((p) => (
            <span key={p} className="px-1.5 py-0.5 bg-brand-50 border border-brand-200 rounded text-xs font-mono text-brand-700 font-semibold">
              {p}
            </span>
          ))}
        </div>
      )
    }
    return <span className="text-gray-700 text-xs">{val || '—'}</span>
  }

  return (
    <div className="flex-1 flex flex-col min-h-0 p-4 animate-fadeIn">
      {/* Header */}
      <div className="flex items-center justify-between mb-3">
        <div>
          <h2 className="text-sm font-bold text-gray-900">Data Preview</h2>
          <p className="text-xs text-gray-500">
            {uploadData.row_count} total rows · {columns.length} columns
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-gray-500 font-medium">
            Page {page} of {totalPages}
          </span>
          <button
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            disabled={page === 1 || loading}
            className="p-1.5 rounded-lg text-gray-500 hover:text-brand-600 hover:bg-brand-50 transition-all duration-150 disabled:opacity-30 disabled:pointer-events-none"
          >
            <ChevronLeft size={15} />
          </button>
          <button
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            disabled={page === totalPages || loading}
            className="p-1.5 rounded-lg text-gray-500 hover:text-brand-600 hover:bg-brand-50 transition-all duration-150 disabled:opacity-30 disabled:pointer-events-none"
          >
            <ChevronRight size={15} />
          </button>
        </div>
      </div>

      {/* Table */}
      <div className="flex-1 min-h-0 overflow-auto rounded-xl border border-surface-border shadow-card">
        <table className="w-full text-left text-xs border-collapse">
          <thead className="sticky top-0 z-10">
            <tr className="bg-surface-muted border-b border-surface-border">
              <th className="px-3 py-2.5 text-gray-400 font-bold text-xs uppercase tracking-wider">#</th>
              {columns.map((col) => (
                <th
                  key={col}
                  className="px-3 py-2.5 text-gray-400 font-bold text-xs uppercase tracking-wider whitespace-nowrap"
                >
                  {col}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan={columns.length + 1} className="text-center py-8 text-gray-400">
                  <span className="inline-block w-4 h-4 border-2 border-brand-300 border-t-brand-600 rounded-full animate-spin mr-2 align-middle" />
                  Loading…
                </td>
              </tr>
            ) : data.map((row, idx) => (
              <tr
                key={idx}
                className="border-b border-surface-border/60 hover:bg-brand-50/60 transition-colors duration-150"
              >
                <td className="px-3 py-2 text-gray-400 font-mono">
                  {(page - 1) * 50 + idx + 1}
                </td>
                {columns.map((col) => (
                  <td key={col} className="px-3 py-2 max-w-[200px]">
                    {renderCell(col, row[col])}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
