import { useEffect, useRef, useState, useCallback } from 'react'
import {
  ZoomIn, ZoomOut, Maximize2, Download, Image, FileCode,
  RotateCcw, Target, AlertTriangle, AlignLeft, AlignCenter,
  Layers
} from 'lucide-react'
import toast from 'react-hot-toast'
import { useApp } from '../../hooks/useAppState'
import {
  initCytoscape, resetHighlight, highlightCriticalPath,
  exportPNG, exportSVG, relayout
} from '../../utils/cytoscapeBuilder'
import JobDetails from '../JobDetails'

const LEGEND = [
  { label: 'CRITICAL',      color: 'bg-red-700',    border: 'border-red-700',    desc: 'Score 10+'         },
  { label: 'HIGH',          color: 'bg-red-500',    border: 'border-red-500',    desc: 'Score 7-9'         },
  { label: 'MEDIUM',        color: 'bg-orange-500', border: 'border-orange-500', desc: 'Score 4-6'         },
  { label: 'LOW',           color: 'bg-green-500',  border: 'border-green-500',  desc: 'Score 0-3'         },
  { label: 'Critical Path', color: 'bg-amber-400',  border: 'border-amber-400',  desc: 'Longest chain'     },
  { label: 'Impact',        color: 'bg-red-700',    border: 'border-red-700',    desc: 'Failure cascade'   },
]

export default function GraphPanel() {
  const { state, dispatch } = useApp()
  const { graphData } = state
  const containerRef = useRef(null)
  const cyRef = useRef(null)
  const [showLegend, setShowLegend] = useState(true)
  const [layoutDir, setLayoutDir] = useState('TB')

  useEffect(() => {
    if (!containerRef.current || !graphData) return

    if (cyRef.current) { cyRef.current.destroy(); cyRef.current = null }

    const elements = [...graphData.nodes, ...graphData.edges]

    cyRef.current = initCytoscape(
      containerRef.current,
      elements,
      (nodeData) => dispatch({ type: 'SET_SELECTED_NODE', payload: nodeData })
    )

    return () => { if (cyRef.current) { cyRef.current.destroy(); cyRef.current = null } }
  }, [graphData, dispatch])

  // Re-layout when direction toggles
  useEffect(() => {
    if (cyRef.current) relayout(cyRef.current, layoutDir)
  }, [layoutDir])

  const handleExportPNG = useCallback(async () => {
    if (!cyRef.current) return
    const blob = exportPNG(cyRef.current)
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url; a.download = 'dependency-graph.png'; a.click()
    URL.revokeObjectURL(url)
    toast.success('PNG exported')
  }, [])

  const handleExportSVG = useCallback(() => {
    if (!cyRef.current) return
    const svg = exportSVG(cyRef.current)
    const blob = new Blob([svg], { type: 'image/svg+xml' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url; a.download = 'dependency-graph.svg'; a.click()
    URL.revokeObjectURL(url)
    toast.success('SVG exported')
  }, [])

  const handleFit     = () => cyRef.current?.fit(undefined, 50)
  const handleZoomIn  = () => cyRef.current?.zoom(cyRef.current.zoom() * 1.3)
  const handleZoomOut = () => cyRef.current?.zoom(cyRef.current.zoom() * 0.77)
  const handleReset   = () => {
    if (!cyRef.current) return
    resetHighlight(cyRef.current)
    dispatch({ type: 'SET_SELECTED_NODE', payload: null })
    toast('Highlights cleared', { icon: '✓' })
  }
  const handleCriticalPath = () => {
    if (!cyRef.current || !graphData?.critical_path?.length) {
      toast.error('No critical path available'); return
    }
    highlightCriticalPath(cyRef.current, graphData.critical_path)
    toast.success(`Critical path: ${graphData.critical_path.length} jobs highlighted`)
  }

  if (!graphData) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center gap-5 bg-surface relative overflow-hidden">
        {/* subtle animated dot-mesh backdrop */}
        <div className="absolute inset-0 opacity-[0.4]" style={{
          backgroundImage: 'radial-gradient(rgba(37,99,235,0.10) 1px, transparent 1px)',
          backgroundSize: '22px 22px',
        }} />
        <div
          className="w-20 h-20 rounded-2xl bg-white border border-surface-border flex items-center justify-center animate-floatSlow relative z-10"
          style={{ boxShadow: '0 8px 24px rgba(37,99,235,0.12)' }}
        >
          <Layers size={32} className="text-brand-500" />
        </div>
        <div className="text-center relative z-10">
          <p className="text-gray-800 font-bold text-base">No graph yet</p>
          <p className="text-sm mt-1 text-gray-500">
            Select jobs in the sidebar and click <span className="text-brand-600 font-semibold">Build Graph</span>
          </p>
        </div>
        {/* Feature chips */}
        <div className="flex flex-wrap justify-center gap-2 max-w-xs mt-2 relative z-10">
          {['Application Groups','Risk Highlighting','Critical Path','Impact Analysis','Cycle Detection'].map((f, i) => (
            <span
              key={f}
              className="px-2.5 py-1 bg-white border border-surface-border rounded-full text-xs text-gray-500 font-medium shadow-sm animate-fadeSlideUp"
              style={{ animationDelay: `${i * 60}ms`, animationFillMode: 'backwards' }}
            >{f}</span>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="flex-1 relative overflow-hidden bg-surface">
      {/* ── Toolbar ─────────────────────────────────── */}
      <div className="absolute top-3 left-3 z-10 flex items-center gap-1.5 flex-wrap animate-fadeSlideUp">
        {/* Zoom */}
        <div className="flex items-center gap-px bg-white border border-surface-border rounded-lg p-1 shadow-card-md">
          <button onClick={handleZoomIn}  className="p-1.5 rounded-md text-gray-500 hover:text-brand-600 hover:bg-brand-50 transition-all duration-150" title="Zoom in"><ZoomIn  size={14}/></button>
          <button onClick={handleZoomOut} className="p-1.5 rounded-md text-gray-500 hover:text-brand-600 hover:bg-brand-50 transition-all duration-150" title="Zoom out"><ZoomOut size={14}/></button>
          <button onClick={handleFit}     className="p-1.5 rounded-md text-gray-500 hover:text-brand-600 hover:bg-brand-50 transition-all duration-150" title="Fit all"><Maximize2 size={14}/></button>
          <div className="w-px h-4 bg-surface-border mx-0.5"/>
          <button onClick={handleReset}   className="p-1.5 rounded-md text-gray-500 hover:text-red-600 hover:bg-red-50 transition-all duration-150" title="Clear highlights"><RotateCcw size={14}/></button>
        </div>

        {/* Layout direction */}
        <div className="flex items-center gap-px bg-white border border-surface-border rounded-lg p-1 shadow-card-md">
          <button
            onClick={() => setLayoutDir('TB')}
            className={`p-1.5 rounded-md flex items-center gap-1.5 text-xs font-semibold transition-all duration-150 ${layoutDir==='TB' ? 'bg-brand-600 text-white shadow-sm' : 'text-gray-500 hover:bg-gray-100'}`}
            title="Top → Bottom layout"
          >
            <AlignCenter size={14}/><span className="hidden sm:inline">TB</span>
          </button>
          <button
            onClick={() => setLayoutDir('LR')}
            className={`p-1.5 rounded-md flex items-center gap-1.5 text-xs font-semibold transition-all duration-150 ${layoutDir==='LR' ? 'bg-brand-600 text-white shadow-sm' : 'text-gray-500 hover:bg-gray-100'}`}
            title="Left → Right layout"
          >
            <AlignLeft size={14}/><span className="hidden sm:inline">LR</span>
          </button>
        </div>

        {/* Analysis */}
        <div className="flex items-center gap-px bg-white border border-surface-border rounded-lg p-1 shadow-card-md">
          <button
            onClick={handleCriticalPath}
            className="p-1.5 rounded-md flex items-center gap-1.5 text-xs font-semibold text-amber-600 hover:bg-amber-50 transition-all duration-150"
            title="Highlight critical path"
          >
            <Target size={14}/>
            <span className="hidden sm:inline">Critical Path</span>
          </button>
        </div>

        {/* Export */}
        <div className="flex items-center gap-px bg-white border border-surface-border rounded-lg p-1 shadow-card-md">
          <button onClick={handleExportPNG} className="p-1.5 rounded-md flex items-center gap-1.5 text-xs font-medium text-gray-500 hover:text-brand-600 hover:bg-brand-50 transition-all duration-150" title="Export PNG">
            <Image size={14}/><span className="hidden sm:inline">PNG</span>
          </button>
          <button onClick={handleExportSVG} className="p-1.5 rounded-md flex items-center gap-1.5 text-xs font-medium text-gray-500 hover:text-brand-600 hover:bg-brand-50 transition-all duration-150" title="Export SVG">
            <FileCode size={14}/><span className="hidden sm:inline">SVG</span>
          </button>
        </div>
      </div>

      {/* ── Cycle warning ────────────────────────────── */}
      {graphData.has_cycles && (
        <div className="absolute top-3 left-1/2 -translate-x-1/2 z-10 animate-fadeSlideUp">
          <div className="flex items-center gap-2 px-3 py-2 bg-red-50 border border-red-200 rounded-lg backdrop-blur-sm shadow-glow-red">
            <AlertTriangle size={13} className="text-red-500"/>
            <span className="text-xs text-red-700 font-semibold">
              ⚠ {graphData.cycle_details.length} dependency cycle{graphData.cycle_details.length>1?'s':''} detected — check Analysis tab
            </span>
          </div>
        </div>
      )}

      {/* ── Graph stats bar ──────────────────────────── */}
      <div className="absolute bottom-3 left-3 z-10 animate-fadeSlideUp">
        <div className="flex items-center gap-3 px-3.5 py-2 bg-white/95 border border-surface-border rounded-lg backdrop-blur-sm text-xs shadow-card-md">
          <span className="text-gray-500"><span className="font-mono font-bold text-gray-800">{graphData.node_count}</span> nodes</span>
          <span className="text-gray-300">·</span>
          <span className="text-gray-500"><span className="font-mono font-bold text-gray-800">{graphData.edge_count}</span> edges</span>
          {graphData.critical_path?.length > 0 && <>
            <span className="text-gray-300">·</span>
            <span className="text-gray-500">Path: <span className="font-mono font-bold text-amber-600">{graphData.critical_path.length}</span> jobs</span>
          </>}
          <span className="text-gray-300">·</span>
          <span className="text-gray-400 font-mono">{layoutDir === 'TB' ? '↓ Top→Bottom' : '→ Left→Right'}</span>
        </div>
      </div>

      {/* ── Legend ──────────────────────────────────── */}
      {showLegend && (
        <div className="absolute bottom-3 right-3 z-10 animate-scaleIn">
          <div className="px-3 py-2.5 bg-white/95 border border-surface-border rounded-xl backdrop-blur-sm shadow-card-lg">
            <div className="flex items-center justify-between mb-2">
              <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Legend</p>
              <button onClick={()=>setShowLegend(false)} className="text-gray-400 hover:text-gray-700 ml-4 text-sm leading-none transition-colors">×</button>
            </div>
            <div className="space-y-1.5 mb-3">
              {LEGEND.map(({label,color,desc}) => (
                <div key={label} className="flex items-center gap-2.5">
                  <div className={`w-3 h-3 rounded-sm ${color} flex-shrink-0 shadow-sm`}/>
                  <span className="text-xs text-gray-700 w-20 font-semibold">{label}</span>
                  <span className="text-xs text-gray-400">{desc}</span>
                </div>
              ))}
            </div>
            <div className="border-t border-surface-border pt-2">
              <div className="flex items-center gap-2.5">
                <div className="w-3 h-3 rounded border-2 border-dashed border-gray-400 flex-shrink-0"/>
                <span className="text-xs text-gray-500">App group (compound)</span>
              </div>
            </div>
          </div>
        </div>
      )}
      {!showLegend && (
        <button
          onClick={()=>setShowLegend(true)}
          className="absolute bottom-3 right-3 z-10 text-xs font-medium text-gray-500 hover:text-brand-600 border border-surface-border rounded-lg px-3 py-1.5 bg-white/90 shadow-card-md transition-all duration-150 hover:-translate-y-0.5"
        >Legend</button>
      )}

      {/* ── Cytoscape canvas ────────────────────────── */}
      <div ref={containerRef} id="cy-container" style={{width:'100%',height:'100%'}}/>

      {/* ── Node details panel ───────────────────────── */}
      <JobDetails cyRef={cyRef}/>
    </div>
  )
}
