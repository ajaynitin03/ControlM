import { useEffect, useState, useMemo, useCallback } from 'react'
import {
  Search, CheckSquare, Square, Layers,
  ChevronDown, ChevronRight, LayoutGrid, List,
  X, Loader2, ArrowRight, RefreshCw
} from 'lucide-react'
import toast from 'react-hot-toast'
import { getJobs, buildGraph, getFullGraph } from '../../services/api'
import { useApp } from '../../hooks/useAppState'
import CriticalityBadge from '../CriticalityBadge'

const CRIT_CONFIG = {
  CRITICAL: { dot: 'bg-red-700',    badge: 'badge-critical', ring: 'ring-red-500',    card: 'border-red-200 bg-red-50/60'    },
  HIGH:     { dot: 'bg-red-500',    badge: 'badge-high',     ring: 'ring-red-400',    card: 'border-red-100 bg-red-50/30'    },
  MEDIUM:   { dot: 'bg-orange-500', badge: 'badge-medium',   ring: 'ring-orange-400', card: 'border-orange-100 bg-orange-50/30' },
  LOW:      { dot: 'bg-green-500',  badge: 'badge-low',      ring: 'ring-green-400',  card: 'border-green-100 bg-green-50/30'  },
}

const CRIT_TIERS = ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW']

const APP_COLORS = [
  'from-blue-50 to-blue-50/30 border-blue-200',
  'from-purple-50 to-purple-50/30 border-purple-200',
  'from-teal-50 to-teal-50/30 border-teal-200',
  'from-amber-50 to-amber-50/30 border-amber-200',
  'from-pink-50 to-pink-50/30 border-pink-200',
  'from-indigo-50 to-indigo-50/30 border-indigo-200',
  'from-emerald-50 to-emerald-50/30 border-emerald-200',
]

const APP_HEADER_COLORS = [
  'text-blue-700',
  'text-purple-700',
  'text-teal-700',
  'text-amber-700',
  'text-pink-700',
  'text-indigo-700',
  'text-emerald-700',
]

export default function JobPicker() {
  const { state, dispatch } = useApp()
  const { sessionId, selectedJobs } = state

  const [allJobs, setAllJobs]       = useState([])
  const [loading, setLoading]       = useState(true)
  const [building, setBuilding]     = useState(false)
  const [searchText, setSearchText] = useState('')
  const [filterCrit, setFilterCrit] = useState('ALL')  // ALL | HIGH | MEDIUM | LOW
  const [viewMode, setViewMode]     = useState('group') // group | grid | list
  const [collapsed, setCollapsed]   = useState({})      // appName -> bool

  // ── Load jobs on mount ──────────────────────────────────────────
  useEffect(() => {
    if (!sessionId) return
    setLoading(true)
    getJobs(sessionId)
      .then(res => setAllJobs(res.data.jobs))
      .catch(() => toast.error('Failed to load jobs'))
      .finally(() => setLoading(false))
  }, [sessionId])

  // ── Derived state ───────────────────────────────────────────────
  const filtered = useMemo(() => {
    return allJobs.filter(j => {
      const matchSearch =
        !searchText ||
        j.JobId.toLowerCase().includes(searchText.toLowerCase()) ||
        j.JobName.toLowerCase().includes(searchText.toLowerCase()) ||
        (j.AppName || '').toLowerCase().includes(searchText.toLowerCase())
      const matchCrit = filterCrit === 'ALL' || j.Criticality === filterCrit
      return matchSearch && matchCrit
    })
  }, [allJobs, searchText, filterCrit])

  // Group by AppName
  const grouped = useMemo(() => {
    const map = {}
    filtered.forEach(j => {
      const app = j.AppName || 'UNGROUPED'
      if (!map[app]) map[app] = []
      map[app].push(j)
    })
    return map
  }, [filtered])

  const appNames   = useMemo(() => Object.keys(grouped).sort(), [grouped])
  const selectedSet = useMemo(() => new Set(selectedJobs), [selectedJobs])
  const isSelected  = useCallback(id => selectedSet.has(id), [selectedSet])

  const toggleJob = useCallback(jobId => {
    dispatch({
      type: 'SET_SELECTED_JOBS',
      payload: selectedSet.has(jobId)
        ? selectedJobs.filter(id => id !== jobId)
        : [...selectedJobs, jobId],
    })
  }, [selectedSet, selectedJobs, dispatch])

  const toggleGroup = useCallback(appName => {
    const ids = (grouped[appName] || []).map(j => j.JobId)
    const allSelected = ids.every(id => selectedSet.has(id))
    dispatch({
      type: 'SET_SELECTED_JOBS',
      payload: allSelected
        ? selectedJobs.filter(id => !ids.includes(id))
        : [...new Set([...selectedJobs, ...ids])],
    })
  }, [grouped, selectedSet, selectedJobs, dispatch])

  const selectAll  = () => dispatch({ type: 'SET_SELECTED_JOBS', payload: allJobs.map(j => j.JobId) })
  const clearAll   = () => dispatch({ type: 'SET_SELECTED_JOBS', payload: [] })
  const toggleCollapse = app => setCollapsed(c => ({ ...c, [app]: !c[app] }))

  // ── Generate graph ──────────────────────────────────────────────
  const generateGraph = useCallback(async () => {
    if (!sessionId) return
    setBuilding(true)
    try {
      const res = selectedJobs.length > 0
        ? await buildGraph(sessionId, selectedJobs, 10)
        : await getFullGraph(sessionId)

      dispatch({ type: 'SET_GRAPH_DATA', payload: res.data })
      dispatch({ type: 'SET_ACTIVE_TAB', payload: 'graph' })

      if (res.data.has_cycles) {
        toast.error(`⚠ ${res.data.cycle_details.length} cycle(s) detected`, { duration: 5000 })
      } else {
        const label = selectedJobs.length === 0
          ? `All ${res.data.node_count} jobs`
          : `${selectedJobs.length} selected job(s) + dependencies`
        toast.success(`Graph ready — ${label}, ${res.data.edge_count} edges`)
      }
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Graph build failed')
    } finally {
      setBuilding(false)
    }
  }, [sessionId, selectedJobs, dispatch])

  // ── Counts ──────────────────────────────────────────────────────
  const critCounts = useMemo(() => {
    const c = { CRITICAL: 0, HIGH: 0, MEDIUM: 0, LOW: 0 }
    allJobs.forEach(j => { if (c[j.Criticality] !== undefined) c[j.Criticality]++ })
    return c
  }, [allJobs])

  // ── Loading / empty states ──────────────────────────────────────
  if (loading) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <Loader2 size={28} className="text-brand-500 animate-spin" />
          <p className="text-sm text-gray-400">Loading job catalogue…</p>
        </div>
      </div>
    )
  }

  if (!allJobs.length) {
    return (
      <div className="flex-1 flex items-center justify-center text-gray-400">
        <p>No jobs found. Upload a file first.</p>
      </div>
    )
  }

  return (
    <div className="flex-1 flex flex-col min-h-0 overflow-hidden animate-fadeIn">

      {/* ══ Top header bar ══════════════════════════════════════════ */}
      <div className="flex-shrink-0 border-b border-surface-border bg-white px-5 py-3">
        <div className="flex items-center justify-between gap-4">
          <div>
            <h2 className="text-sm font-bold text-gray-900">Job Selection</h2>
            <p className="text-xs text-gray-500 mt-0.5">
              {allJobs.length} jobs across {appNames.length} applications
            </p>
          </div>

          {/* Summary pills */}
          <div className="flex items-center gap-2 flex-shrink-0">
            {CRIT_TIERS.map(c => (
              <button
                key={c}
                onClick={() => setFilterCrit(f => f === c ? 'ALL' : c)}
                className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-xs font-semibold
                  transition-all duration-150 cursor-pointer select-none
                  ${filterCrit === c
                    ? (c==='CRITICAL'?'bg-red-100 border-red-300 text-red-800':c==='HIGH'?'bg-red-50 border-red-200 text-red-700':c==='MEDIUM'?'bg-orange-50 border-orange-200 text-orange-700':'bg-green-50 border-green-200 text-green-700')
                    : 'border-surface-border bg-surface-hover text-gray-500 hover:text-gray-800 hover:-translate-y-0.5'}`}
              >
                <span className={`w-1.5 h-1.5 rounded-full ${CRIT_CONFIG[c].dot}`}/>
                {critCounts[c]} {c}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* ══ Toolbar ═════════════════════════════════════════════════ */}
      <div className="flex-shrink-0 px-5 py-2.5 border-b border-surface-border bg-white flex items-center gap-3 flex-wrap">
        {/* Search */}
        <div className="relative flex-1 min-w-48 max-w-sm">
          <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none"/>
          <input
            type="text"
            value={searchText}
            onChange={e => setSearchText(e.target.value)}
            placeholder="Search Job ID, name or application…"
            className="w-full pl-8 pr-8 py-1.5 bg-surface-hover border border-surface-border rounded-lg
                       text-xs text-gray-800 placeholder-gray-400 focus:outline-none
                       focus:border-brand-500 focus:ring-2 focus:ring-brand-100 transition-all duration-150"
          />
          {searchText && (
            <button onClick={() => setSearchText('')}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-700 transition-colors">
              <X size={12}/>
            </button>
          )}
        </div>

        {/* Select all / clear */}
        <div className="flex items-center gap-1.5">
          <button onClick={selectAll}  className="btn-ghost text-xs flex items-center gap-1.5 py-1.5">
            <CheckSquare size={13}/>All
          </button>
          <button onClick={clearAll}   className="btn-ghost text-xs flex items-center gap-1.5 py-1.5">
            <Square size={13}/>None
          </button>
        </div>

        {/* View mode */}
        <div className="flex items-center gap-px bg-surface-hover border border-surface-border rounded-lg p-0.5 ml-auto">
          {[
            { id:'group', icon: Layers,      title:'Grouped by app' },
            { id:'grid',  icon: LayoutGrid,  title:'Card grid'      },
            { id:'list',  icon: List,        title:'List view'      },
          ].map(({ id, icon: Icon, title }) => (
            <button
              key={id}
              onClick={() => setViewMode(id)}
              title={title}
              className={`p-1.5 rounded-md transition-all duration-150 ${viewMode===id ? 'bg-brand-600 text-white shadow-sm' : 'text-gray-400 hover:text-gray-700 hover:bg-white'}`}
            >
              <Icon size={14}/>
            </button>
          ))}
        </div>
      </div>

      {/* ══ Job cards ═══════════════════════════════════════════════ */}
      <div className="flex-1 overflow-y-auto px-5 py-4 bg-surface">
        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-40 text-gray-400 gap-2">
            <Search size={22} className="text-gray-300"/>
            <p className="text-sm">No jobs match your filter</p>
            <button onClick={() => { setSearchText(''); setFilterCrit('ALL') }}
              className="text-xs text-brand-600 hover:underline flex items-center gap-1 font-medium">
              <RefreshCw size={11}/>Clear filters
            </button>
          </div>
        ) : viewMode === 'group' ? (
          /* ── Grouped view ── */
          <div className="space-y-5">
            {appNames.map((app, appIdx) => {
              const jobs = grouped[app]
              const color = APP_COLORS[appIdx % APP_COLORS.length]
              const headerColor = APP_HEADER_COLORS[appIdx % APP_HEADER_COLORS.length]
              const allSel = jobs.every(j => selectedSet.has(j.JobId))
              const someSel = jobs.some(j => selectedSet.has(j.JobId))
              const isCollapsed = collapsed[app]

              return (
                <div key={app}
                  className={`rounded-xl border bg-gradient-to-br ${color} overflow-hidden shadow-card transition-shadow duration-200 hover:shadow-card-md animate-fadeSlideUp`}>
                  {/* Group header */}
                  <div className="flex items-center gap-3 px-4 py-2.5">
                    <button
                      onClick={() => toggleCollapse(app)}
                      className="text-gray-400 hover:text-gray-700 transition-all duration-150 hover:scale-110"
                    >
                      {isCollapsed
                        ? <ChevronRight size={15}/>
                        : <ChevronDown  size={15}/>}
                    </button>

                    <span className={`text-sm font-bold tracking-wide ${headerColor}`}>{app}</span>
                    <span className="text-xs text-gray-400 font-medium">{jobs.length} job{jobs.length!==1?'s':''}</span>

                    <div className="ml-auto flex items-center gap-2">
                      {/* criticality mini-badges */}
                      {CRIT_TIERS.map(c => {
                        const cnt = jobs.filter(j=>j.Criticality===c).length
                        if (!cnt) return null
                        return (
                          <span key={c} className={`${CRIT_CONFIG[c].badge} text-xs`}>
                            {cnt} {c}
                          </span>
                        )
                      })}

                      {/* Select all in group */}
                      <button
                        onClick={() => toggleGroup(app)}
                        className={`flex items-center gap-1.5 px-2 py-1 rounded-md text-xs font-semibold
                          transition-all duration-150 border
                          ${allSel
                            ? 'bg-brand-600 border-brand-600 text-white shadow-sm'
                            : someSel
                              ? 'bg-brand-50 border-brand-300 text-brand-700'
                              : 'border-surface-border bg-white text-gray-500 hover:text-gray-800 hover:border-gray-300'}`}
                      >
                        {allSel ? <CheckSquare size={11}/> : someSel ? <CheckSquare size={11}/> : <Square size={11}/>}
                        {allSel ? 'Deselect all' : 'Select all'}
                      </button>
                    </div>
                  </div>

                  {/* Job cards in group */}
                  {!isCollapsed && (
                    <div className="px-4 pb-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-2.5">
                      {jobs.map(job => (
                        <JobCard
                          key={job.JobId}
                          job={job}
                          selected={isSelected(job.JobId)}
                          onToggle={toggleJob}
                        />
                      ))}
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        ) : viewMode === 'grid' ? (
          /* ── Flat grid view ── */
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
            {filtered.map(job => (
              <JobCard key={job.JobId} job={job} selected={isSelected(job.JobId)} onToggle={toggleJob}/>
            ))}
          </div>
        ) : (
          /* ── List view ── */
          <div className="rounded-xl border border-surface-border overflow-hidden shadow-card">
            <table className="w-full text-xs">
              <thead className="sticky top-0 bg-surface-muted border-b border-surface-border z-10">
                <tr>
                  {['','Job ID','Job Name','Application','Criticality'].map(h => (
                    <th key={h} className="px-3 py-2.5 text-left text-gray-400 font-bold uppercase tracking-wider">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map(job => {
                  const sel = isSelected(job.JobId)
                  return (
                    <tr
                      key={job.JobId}
                      onClick={() => toggleJob(job.JobId)}
                      className={`border-b border-surface-border/60 cursor-pointer transition-colors duration-150 bg-white
                        ${sel ? 'bg-brand-50' : 'hover:bg-surface-hover'}`}
                    >
                      <td className="px-3 py-2.5">
                        <div className={`w-4 h-4 rounded border-2 flex items-center justify-center transition-all duration-150
                          ${sel ? 'bg-brand-600 border-brand-600' : 'border-gray-300'}`}>
                          {sel && <span className="text-white text-xs leading-none font-bold">✓</span>}
                        </div>
                      </td>
                      <td className="px-3 py-2.5 font-mono text-gray-700">{job.JobId}</td>
                      <td className="px-3 py-2.5 text-gray-800 font-medium">{job.JobName}</td>
                      <td className="px-3 py-2.5 text-gray-500">{job.AppName}</td>
                      <td className="px-3 py-2.5" onClick={e => e.stopPropagation()}>
                        <CriticalityBadge source={job} />
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* ══ Bottom action bar ═══════════════════════════════════════ */}
      <div className="flex-shrink-0 border-t border-surface-border bg-white px-5 py-3">
        <div className="flex items-center gap-4">
          {/* Selection summary */}
          <div className="flex items-center gap-3 flex-1 min-w-0">
            {selectedJobs.length === 0 ? (
              <div className="flex items-center gap-2 text-gray-400">
                <Square size={15}/>
                <span className="text-sm">No jobs selected — will generate diagram for all jobs</span>
              </div>
            ) : (
              <div className="flex items-center gap-2.5">
                <div className="flex items-center gap-1.5 px-2.5 py-1 bg-brand-50 border border-brand-200 rounded-lg">
                  <CheckSquare size={13} className="text-brand-600"/>
                  <span className="text-sm font-semibold text-brand-700">
                    {selectedJobs.length} job{selectedJobs.length!==1?'s':''} selected
                  </span>
                </div>
                <span className="text-xs text-gray-400 hidden sm:block">
                  Graph will include all upstream &amp; downstream dependencies automatically
                </span>
                <button onClick={clearAll} className="text-xs text-gray-400 hover:text-red-600 transition-colors flex items-center gap-1">
                  <X size={11}/> Clear
                </button>
              </div>
            )}
          </div>

          {/* Selected job chips (up to 5) */}
          {selectedJobs.length > 0 && selectedJobs.length <= 6 && (
            <div className="hidden md:flex items-center gap-1.5 flex-wrap max-w-xs">
              {selectedJobs.slice(0, 5).map(id => (
                <span key={id}
                  className="flex items-center gap-1 px-2 py-0.5 bg-surface-hover border border-surface-border rounded text-xs font-mono text-gray-600">
                  {id}
                  <button onClick={e => { e.stopPropagation(); toggleJob(id) }} className="text-gray-400 hover:text-red-600 transition-colors">
                    <X size={9}/>
                  </button>
                </span>
              ))}
              {selectedJobs.length > 5 && (
                <span className="text-xs text-gray-400">+{selectedJobs.length - 5} more</span>
              )}
            </div>
          )}

          {/* Generate button */}
          <button
            onClick={generateGraph}
            disabled={building}
            className="flex items-center gap-2.5 px-5 py-2.5 rounded-xl transition-all duration-200
                       text-white font-semibold text-sm
                       disabled:opacity-50 disabled:cursor-not-allowed
                       flex-shrink-0"
            style={{
              background: 'linear-gradient(135deg, #1d4ed8, #2563eb)',
              boxShadow: '0 4px 14px rgba(37,99,235,0.3)',
            }}
            onMouseEnter={e => { if (!building) { e.currentTarget.style.transform = 'translateY(-1px)'; e.currentTarget.style.boxShadow = '0 8px 22px rgba(37,99,235,0.4)' } }}
            onMouseLeave={e => { e.currentTarget.style.transform = 'none'; e.currentTarget.style.boxShadow = '0 4px 14px rgba(37,99,235,0.3)' }}
          >
            {building ? (
              <><Loader2 size={15} className="animate-spin"/>Building…</>
            ) : (
              <><DiagramIcon size={15}/>
                {selectedJobs.length === 0 ? 'Generate Full Diagram' : `Generate Flow Diagram`}
                <ArrowRight size={14}/>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  )
}

/* ── Individual job card ─────────────────────────────────────────── */
function JobCard({ job, selected, onToggle }) {
  const cfg = CRIT_CONFIG[job.Criticality] || CRIT_CONFIG.LOW

  return (
    <div
      onClick={() => onToggle(job.JobId)}
      className={`relative group cursor-pointer rounded-xl border p-3 transition-all duration-200 ease-out
        ${selected
          ? `ring-2 ${cfg.ring} border-transparent bg-white shadow-card-md -translate-y-0.5`
          : `border-surface-border bg-white hover:border-brand-200 hover:shadow-card-md hover:-translate-y-0.5`
        }`}
    >
      {/* Checkbox */}
      <div className={`absolute top-2.5 right-2.5 w-4 h-4 rounded border-2 flex items-center justify-center
        transition-all duration-150 flex-shrink-0
        ${selected ? 'bg-brand-600 border-brand-600' : 'border-gray-300 group-hover:border-brand-400'}`}>
        {selected && <span className="text-white text-xs leading-none font-bold">✓</span>}
      </div>

      {/* Criticality dot + badge */}
      <div className="flex items-center gap-2 mb-2 pr-6" onClick={e => e.stopPropagation()}>
        <span className={`w-2 h-2 rounded-full flex-shrink-0 ${cfg.dot}`}/>
        <CriticalityBadge source={job} />
      </div>

      {/* Job name (big) */}
      <p className="text-xs font-bold text-gray-900 leading-tight mb-0.5 pr-5 break-words">
        {job.JobName}
      </p>

      {/* Job ID */}
      <p className="text-xs font-mono text-gray-400 leading-tight truncate">
        ({job.JobId})
      </p>

      {/* App name */}
      {job.AppName && (
        <p className="text-xs text-gray-400 mt-1.5 truncate">{job.AppName}</p>
      )}

      {/* Selected overlay indicator */}
      {selected && (
        <div className="absolute inset-0 rounded-xl ring-2 ring-brand-400/60 pointer-events-none"/>
      )}
    </div>
  )
}

function DiagramIcon({ size = 15, className = '' }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"
      className={className}>
      <rect x="16" y="16" width="6" height="6" rx="1"/>
      <rect x="2"  y="16" width="6" height="6" rx="1"/>
      <rect x="9"  y="2"  width="6" height="6" rx="1"/>
      <path d="M5 16v-3a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v3"/>
      <path d="M12 12V8"/>
    </svg>
  )
}
