import { useState } from 'react'
import { KeyRound, Mail, Eye, EyeOff, ShieldAlert, Database, HelpCircle, Activity } from 'lucide-react'
import toast from 'react-hot-toast'

export default function Login({ onLoginSuccess }) {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState(null)

  const handleSubmit = (e) => {
    e.preventDefault()
    
    const cleanUser = username.trim().toLowerCase()
    const cleanPass = password.trim()

    // Valid credentials: admin/admin or admin@dbmigration.com/admin
    if ((cleanUser === 'admin' || cleanUser === 'admin@dbmigration.com') && cleanPass === 'admin') {
      toast.success('Successfully logged in!')
      onLoginSuccess()
    } else {
      setError('Invalid username or password. Use admin / admin.')
    }
  }

  return (
    <div style={{
      display: 'flex',
      width: '100vw',
      height: '100vh',
      overflow: 'hidden',
      fontFamily: "'Inter', sans-serif",
      background: '#f8fafc'
    }}>
      {/* LEFT SIDE PANEL — Brand & Graphics */}
      <div style={{
        width: '52%',
        background: 'linear-gradient(135deg, #0f172a 0%, #1e3a8a 100%)',
        padding: '48px',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'space-between',
        color: '#ffffff',
        position: 'relative',
        boxShadow: '4px 0 24px rgba(0,0,0,0.15)',
        animation: 'fadeIn 0.4s ease-out'
      }}>
        {/* Top Branding Header */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 6 }}>
            <span style={{ fontSize: 18, fontWeight: 800, letterSpacing: '0.05em', color: '#60a5fa' }}>tcs</span>
            <span style={{ fontSize: 10, fontWeight: 500, color: '#94a3b8', letterSpacing: '0.08em', textTransform: 'uppercase' }}>
              | Tata Consultancy Services
            </span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 14 }}>
            <div style={{
              width: 38,
              height: 38,
              borderRadius: 10,
              background: '#2563eb',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              boxShadow: '0 4px 12px rgba(37,99,235,0.45)'
            }}>
              <Database size={18} color="#fff" />
            </div>
            <div>
              <h1 style={{ fontSize: 22, fontWeight: 800, margin: 0, letterSpacing: '-0.02em', background: 'linear-gradient(to right, #ffffff, #93c5fd)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
                Batch Assessment Tool
              </h1>
              <p style={{ fontSize: 12, color: '#93c5fd', margin: '2px 0 0', fontWeight: 500 }}>
                Assess. Analyze. Modernize with Confidence.
              </p>
            </div>
          </div>
        </div>

        {/* Database Migration Dashboard Mockup */}
        <div style={{
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          flex: 1,
          margin: '40px 0'
        }}>
          {/* Mock Visual */}
          <div style={{
            position: 'relative',
            width: '100%',
            maxWidth: 420,
            height: 200,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            padding: '0 20px',
            background: 'rgba(255,255,255,0.03)',
            border: '1px solid rgba(255,255,255,0.06)',
            borderRadius: 16,
            backdropFilter: 'blur(10px)'
          }}>
            {/* Left DB Cylinder (Source) */}
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
              <div style={{
                width: 70,
                height: 84,
                background: 'linear-gradient(to bottom, #3b82f6, #1d4ed8)',
                borderRadius: '8px/16px',
                position: 'relative',
                boxShadow: '0 12px 24px rgba(29,78,216,0.3)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                flexDirection: 'column',
                gap: 5
              }}>
                <div style={{ width: '100%', height: 12, background: 'rgba(255,255,255,0.2)', borderRadius: '50%', position: 'absolute', top: 0 }} />
                <div style={{ width: '100%', height: 12, background: 'rgba(255,255,255,0.1)', borderTop: '1px solid rgba(255,255,255,0.15)', borderBottom: '1px solid rgba(255,255,255,0.15)', position: 'absolute', top: 26 }} />
                <div style={{ width: '100%', height: 12, background: 'rgba(255,255,255,0.1)', borderTop: '1px solid rgba(255,255,255,0.15)', borderBottom: '1px solid rgba(255,255,255,0.15)', position: 'absolute', top: 48 }} />
                <span style={{ fontSize: 10, fontWeight: 700, marginTop: 14 }}>LEGACY</span>
                <span style={{ fontSize: 8, opacity: 0.8 }}>SOURCE</span>
              </div>
            </div>

            {/* Pulsing Wave Connection */}
            <div style={{
              flex: 1,
              height: 4,
              background: 'linear-gradient(to right, #3b82f6, #10b981)',
              margin: '0 16px',
              borderRadius: 2,
              position: 'relative',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center'
            }}>
              <div style={{
                position: 'absolute',
                width: 14,
                height: 14,
                borderRadius: '50%',
                background: '#10b981',
                boxShadow: '0 0 12px #10b981',
                animation: 'spin 2s linear infinite',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}>
                <Activity size={8} color="#fff" />
              </div>
            </div>

            {/* Right DB Cylinder (Target Cloud) */}
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
              <div style={{
                width: 70,
                height: 84,
                background: 'linear-gradient(to bottom, #e2e8f0, #cbd5e1)',
                borderRadius: '8px/16px',
                position: 'relative',
                boxShadow: '0 12px 24px rgba(203,213,225,0.15)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                flexDirection: 'column',
                gap: 5,
                color: '#334155'
              }}>
                <div style={{ width: '100%', height: 12, background: 'rgba(255,255,255,0.5)', borderRadius: '50%', position: 'absolute', top: 0 }} />
                <div style={{ width: '100%', height: 12, background: 'rgba(255,255,255,0.3)', borderTop: '1px solid rgba(255,255,255,0.3)', borderBottom: '1px solid rgba(255,255,255,0.3)', position: 'absolute', top: 26 }} />
                <div style={{ width: '100%', height: 12, background: 'rgba(255,255,255,0.3)', borderTop: '1px solid rgba(255,255,255,0.3)', borderBottom: '1px solid rgba(255,255,255,0.3)', position: 'absolute', top: 48 }} />
                <span style={{ fontSize: 10, fontWeight: 700, marginTop: 14 }}>MODERN</span>
                <span style={{ fontSize: 8, opacity: 0.8 }}>TARGET</span>
              </div>
            </div>
          </div>
          
          <div style={{ marginTop: 24, textAlign: 'center', maxWidth: 400 }}>
            <h2 style={{ fontSize: 18, fontWeight: 700, margin: 0, color: '#f8fafc' }}>
              Data Migration Intelligence, Simplified.
            </h2>
            <p style={{ fontSize: 12, color: '#cbd5e1', marginTop: 8, lineHeight: 1.6 }}>
              Analyze schema complexity, evaluate operational dependencies, identify code execution risks, and formulate optimal cloud target modernizations.
            </p>
          </div>
        </div>

        {/* Brand Footer pillars */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(4, 1fr)',
          gap: 10,
          borderTop: '1px solid rgba(255,255,255,0.1)',
          paddingTop: 20
        }}>
          {[
            'Comprehensive Analysis',
            'Risk-aware Insights',
            'Migration Readiness',
            'Data-driven Decisions'
          ].map((text) => (
            <div key={text} style={{ textAlign: 'center' }}>
              <div style={{ fontSize: 10, fontWeight: 600, color: '#93c5fd', lineHeight: 1.3 }}>{text}</div>
            </div>
          ))}
        </div>
      </div>

      {/* RIGHT SIDE PANEL — Login form */}
      <div style={{
        flex: 1,
        background: '#ffffff',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        padding: '40px',
        animation: 'fadeSlideUp 0.45s cubic-bezier(0.16,1,0.3,1)'
      }}>
        <div style={{ width: '100%', maxWidth: 400 }}>
          {/* Header */}
          <div style={{ marginBottom: 28 }}>
            <h2 style={{ fontSize: 28, fontWeight: 800, color: '#0f172a', margin: '0 0 6px' }}>
              Welcome Back
            </h2>
            <p style={{ fontSize: 14, color: '#64748b', margin: 0 }}>
              Sign in to your Batch Assessment Tool account
            </p>
          </div>

          {/* Invalid credentials warning banner */}
          {error && (
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: 8,
              padding: '12px 14px',
              background: '#fef2f2',
              border: '1px solid #fecaca',
              borderRadius: 8,
              color: '#b91c1c',
              fontSize: 12.5,
              fontWeight: 500,
              marginBottom: 20,
              lineHeight: 1.4
            }}>
              <ShieldAlert size={15} style={{ flexShrink: 0 }} />
              <span>{error}</span>
            </div>
          )}

          {/* Login Form */}
          <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            {/* Username / Email */}
            <div>
              <label style={{
                display: 'block',
                fontSize: 11,
                fontWeight: 700,
                color: '#475569',
                textTransform: 'uppercase',
                letterSpacing: '0.05em',
                marginBottom: 6
              }}>
                Username or Email
              </label>
              <div style={{ position: 'relative' }}>
                <span style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: '#94a3b8' }}>
                  <Mail size={15} />
                </span>
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="e.g. admin or admin@dbmigration.com"
                  required
                  style={{
                    width: '100%',
                    padding: '10px 12px 10px 38px',
                    borderRadius: 8,
                    border: '1px solid #cbd5e1',
                    fontSize: 13.5,
                    color: '#334155',
                    outline: 'none',
                    transition: 'border-color 0.15s',
                    background: '#ffffff'
                  }}
                  onFocus={(e) => e.target.style.borderColor = '#2563eb'}
                  onBlur={(e) => e.target.style.borderColor = '#cbd5e1'}
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
                <label style={{
                  display: 'block',
                  fontSize: 11,
                  fontWeight: 700,
                  color: '#475569',
                  textTransform: 'uppercase',
                  letterSpacing: '0.05em',
                  margin: 0
                }}>
                  Password
                </label>
                <a
                  href="#forgot"
                  onClick={(e) => { e.preventDefault(); toast('Please contact administrator to reset password.', { icon: '🔑' }) }}
                  style={{ fontSize: 12, color: '#2563eb', fontWeight: 600, textDecoration: 'none' }}
                >
                  Forgot password?
                </a>
              </div>
              <div style={{ position: 'relative' }}>
                <span style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: '#94a3b8' }}>
                  <KeyRound size={15} />
                </span>
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  required
                  style={{
                    width: '100%',
                    padding: '10px 38px 10px 38px',
                    borderRadius: 8,
                    border: '1px solid #cbd5e1',
                    fontSize: 13.5,
                    color: '#334155',
                    outline: 'none',
                    transition: 'border-color 0.15s',
                    background: '#ffffff'
                  }}
                  onFocus={(e) => e.target.style.borderColor = '#2563eb'}
                  onBlur={(e) => e.target.style.borderColor = '#cbd5e1'}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  style={{
                    position: 'absolute',
                    right: 12,
                    top: '50%',
                    transform: 'translateY(-50%)',
                    background: 'none',
                    border: 'none',
                    cursor: 'pointer',
                    color: '#94a3b8',
                    padding: 0,
                    display: 'flex',
                    alignItems: 'center'
                  }}
                >
                  {showPassword ? <EyeOff size={15} /> : <Eye size={15} />}
                </button>
              </div>
            </div>

            {/* Sign In Button */}
            <button
              type="submit"
              style={{
                width: '100%',
                padding: '11px',
                borderRadius: 8,
                background: 'linear-gradient(135deg, #1d4ed8, #2563eb)',
                color: '#ffffff',
                border: 'none',
                fontSize: 13.5,
                fontWeight: 700,
                cursor: 'pointer',
                transition: 'all 0.2s cubic-bezier(0.16,1,0.3,1)',
                marginTop: 8,
                boxShadow: '0 4px 12px rgba(37,99,235,0.3)'
              }}
              onMouseEnter={(e) => {
                e.target.style.background = 'linear-gradient(135deg, #1e40af, #1d4ed8)'
                e.target.style.boxShadow = '0 8px 22px rgba(37,99,235,0.4)'
                e.target.style.transform = 'translateY(-1px)'
              }}
              onMouseLeave={(e) => {
                e.target.style.background = 'linear-gradient(135deg, #1d4ed8, #2563eb)'
                e.target.style.boxShadow = '0 4px 12px rgba(37,99,235,0.3)'
                e.target.style.transform = 'none'
              }}
            >
              Sign In
            </button>
          </form>

          {/* Footer links */}
          <div style={{
            marginTop: 48,
            textAlign: 'center',
            fontSize: 11,
            color: '#64748b',
            lineHeight: 1.6
          }}>
            By signing in, you agree to our{' '}
            <a href="#tos" onClick={(e) => e.preventDefault()} style={{ color: '#64748b', textDecoration: 'underline', fontWeight: 500 }}>
              Terms of Service
            </a>{' '}
            and{' '}
            <a href="#privacy" onClick={(e) => e.preventDefault()} style={{ color: '#64748b', textDecoration: 'underline', fontWeight: 500 }}>
              Privacy Policy
            </a>
          </div>
        </div>
      </div>
    </div>
  )
}
