import { useState } from 'react'
import { Toaster } from 'react-hot-toast'
import { AppProvider, useApp } from './hooks/useAppState'
import Sidebar          from './components/Sidebar'
import UploadPage       from './components/UploadPage'
import MultiFileView    from './components/MultiFileView'
import AnalysisPanel    from './components/Analysis'
import AIAssessmentPage from './components/AIAssessment'
import Login            from './components/Login'
import './index.css'

// Global keyframe + font
const _style = document.createElement('style')
_style.textContent = `
  @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
`
document.head.appendChild(_style)

const TAB_LABELS = {
  upload:    'Upload Files',
  multiview: 'Diagrams & Data',
  analysis:  'Analysis',
  ai:        'AI Assessment',
}

function MainContent() {
  const { state } = useApp()
  const { activeTab, uploadedFiles, selectedFileIds } = state

  return (
    <div style={{ display: 'flex', height: '100vh', width: '100vw', overflow: 'hidden', background: '#f6f8fc' }}>
      <Sidebar />

      <main style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0, overflow: 'hidden' }}>
        {/* Top bar */}
        <header style={{
          height: 48, flexShrink: 0,
          background: '#ffffff', borderBottom: '1px solid #e4e8f0',
          display: 'flex', alignItems: 'center', padding: '0 24px',
          justifyContent: 'space-between', position: 'relative',
        }}>
          {/* subtle gradient accent line */}
          <div style={{
            position: 'absolute', top: 0, left: 0, right: 0, height: 2,
            background: 'linear-gradient(90deg, #1d4ed8, #06b6d4, #7c3aed)',
            opacity: 0.7,
          }} />
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <span style={{ fontSize: 12, fontWeight: 600, color: '#94a3b8' }}>Batch Assessment Platform</span>
            <span style={{ color: '#e4e8f0', fontSize: 12 }}>›</span>
            <span style={{ fontSize: 12, fontWeight: 700, color: '#1e293b' }}>
              {TAB_LABELS[activeTab] ?? activeTab}
            </span>
            {activeTab === 'ai' && (
              <span style={{
                marginLeft: 4, fontSize: 9, fontWeight: 700, color: '#fff', padding: '2px 7px',
                borderRadius: 99, letterSpacing: '0.03em',
                background: 'linear-gradient(135deg, #7c3aed, #a855f7)',
                boxShadow: '0 2px 6px rgba(124,58,237,0.35)',
              }}>
                GEMINI + RAG
              </span>
            )}
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
            {uploadedFiles.length > 0 && (
              <div style={{ display: 'flex', gap: 8 }}>
                <Chip label="Files" value={uploadedFiles.length} color="#2563eb" bg="#eff4ff" />
                {selectedFileIds.length > 0 && (
                  <Chip label="Selected" value={selectedFileIds.length} color="#7c3aed" bg="#f5f3ff" />
                )}
              </div>
            )}
            <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
              <div style={{
                width: 7, height: 7, borderRadius: '50%', background: '#16a34a',
                boxShadow: '0 0 8px rgba(22,163,74,0.65)',
                animation: 'pulseGlow 2.2s ease-in-out infinite',
              }} />
              <span style={{ fontSize: 11, color: '#9ca3af', fontWeight: 500 }}>API connected</span>
            </div>
          </div>
        </header>

        {/* Page content */}
        <div style={{ flex: 1, display: 'flex', minHeight: 0, overflow: 'hidden' }}>
          {activeTab === 'upload'    && <UploadPage />}
          {activeTab === 'multiview' && <MultiFileView />}
          {activeTab === 'analysis'  && <AnalysisPanel />}
          {activeTab === 'ai'        && <AIAssessmentPage />}
        </div>
      </main>

      <Toaster
        position="bottom-right"
        toastOptions={{
          style: {
            background: '#ffffff',
            border: '1px solid #e4e8f0',
            color: '#374151',
            fontSize: '13px',
            boxShadow: '0 8px 28px rgba(30,58,138,0.14)',
            borderRadius: '12px',
          },
          success: { iconTheme: { primary: '#16a34a', secondary: '#ffffff' } },
          error:   { iconTheme: { primary: '#dc2626', secondary: '#ffffff' } },
          loading: { iconTheme: { primary: '#2563eb', secondary: '#ffffff' } },
        }}
      />
    </div>
  )
}

function Chip({ label, value, color, bg }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 5, padding: '2px 9px', background: bg,
      borderRadius: 99, transition: 'transform 0.15s ease-out',
    }}>
      <span style={{ fontSize: 12, fontWeight: 700, color, fontFamily: 'monospace' }}>{value}</span>
      <span style={{ fontSize: 11, color, opacity: 0.75 }}>{label}</span>
    </div>
  )
}

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  return (
    <AppProvider>
      {isLoggedIn ? <MainContent /> : <Login onLoginSuccess={() => setIsLoggedIn(true)} />}
    </AppProvider>
  )
}
