# Batch Assessment & Modernization Platform (Batch Assessment Tool)
## Complete Installation & Setup Guide

---

## 🔑 0. Authentication Credentials

The landing page authentication is hardcoded. Use the following credentials to log in:

* **Username/Email**: `admin` OR `admin@dbmigration.com`
* **Password**: `admin`

---

## Table of Contents

1. [Project Structure — Full File Map](#1-project-structure)
2. [Prerequisites](#2-prerequisites)
3. [Gemini API Key — Where to Get It & Where to Put It](#3-gemini-api-key)
4. [Backend Setup](#4-backend-setup)
5. [Frontend Setup](#5-frontend-setup)
6. [Docker Setup](#6-docker-setup)
7. [Verifying the Installation](#7-verifying-the-installation)
8. [How to Use the App](#8-how-to-use-the-app)
9. [Sample Data Reference](#9-sample-data-reference)
10. [Troubleshooting](#10-troubleshooting)

---

## 1. Project Structure

```
project-root/
│
├── docker-compose.yml              # Runs backend + frontend together
├── README.md
├── SETUP.md
│
├── backend/
│   ├── .env                        ◄── YOUR API KEY GOES HERE
│   ├── .env.example                ◄── Copy this to .env and fill in
│   ├── main.py                     # FastAPI app entry point
│   ├── requirements.txt            # Python dependencies
│   ├── Dockerfile
│   │
│   ├── ai/                         # Phase 2 — AI Assessment
│   │   ├── __init__.py
│   │   ├── gemini_client.py        # httpx-based Gemini client (SSL verify=False)
│   │   ├── rag_source_code.py      # FAISS + Gemini embedding pipeline
│   │   ├── rag_knowledge.py        # Static modernization knowledge base
│   │   ├── assessment_engine.py    # Orchestrates RAG + Gemini calls
│   │   ├── prompts.py              # All Gemini prompt templates
│   │   └── report_generator.py     # 5-sheet Excel export (.xlsx)
│   │
│   ├── models/
│   │   ├── __init__.py
│   │   └── schemas.py              # Pydantic request/response models
│   │
│   ├── routers/
│   │   ├── __init__.py
│   │   ├── upload.py               # /api/upload — file ingestion
│   │   ├── graph.py                # /api/graph — DAG construction
│   │   ├── analysis.py             # /api/analysis — critical path, fan metrics, cycles
│   │   ├── templates.py            # /api/templates — sample CSV downloads
│   │   └── ai_assessment.py        # /api/ai — all Phase 2 AI endpoints
│   │
│   └── services/                   # Phase 1 business logic
│       ├── __init__.py
│       ├── file_processor.py       # CSV / JSON / XML normalization
│       ├── graph_service.py        # NetworkX graph operations
│       ├── phase1_engine.py        # Full Phase 1 pipeline orchestrator
│       ├── criticality_engine.py   # Operational criticality scoring
│       ├── unified_job_model.py    # Merges scheduler export + execution history
│       └── upload_validation.py    # File validation logic
│
├── frontend/
│   ├── Dockerfile
│   ├── nginx.conf                  # Production nginx config (API proxy + SPA)
│   ├── package.json
│   ├── vite.config.js              # Dev proxy: /api → localhost:8000
│   ├── tailwind.config.js
│   └── src/
│       ├── App.jsx
│       ├── hooks/useAppState.jsx
│       ├── services/api.js
│       └── components/             # All React UI components
│
└── sample_data/
    ├── sample_jobs.csv             # Phase 1 — scheduler export example
    ├── job_inventory.csv           # Phase 2 — AI Assessment inventory example
    ├── extract_erp.sh              # Phase 2 — sample shell source file
    ├── sync_erp_crm.sh             # Phase 2 — sample shell source file
    ├── validate_erp.sql            # Phase 2 — sample SQL source file
    └── validate_customer.sql       # Phase 2 — sample SQL source file
```

---

## 2. Prerequisites

| Tool | Required Version | How to Check |
|---|---|---|
| Python | 3.11+ | `python --version` |
| pip | 23+ | `pip --version` |
| Node.js | 20+ | `node --version` |
| npm | 9+ | `npm --version` |
| Docker + Docker Compose | 24+ (Docker route only) | `docker --version` |

---

## 2.5 User Authentication

The landing page requires logging in. Use one of the following hardcoded credentials:

- **Username**: `admin`
- **Email**: `admin@dbmigration.com`
- **Password**: `admin`

---

## 3. Gemini API Key

> The API key powers all AI features in Phase 2.
> Without a key the app still runs — Phase 1 works fully and Phase 2
> falls back to rule-based heuristic analysis automatically.

### Step 1 — Get a free key

1. Go to **https://aistudio.google.com/app/apikey**
2. Sign in with any Google account
3. Click **"Create API Key"**
4. Copy the key (looks like `AIzaSy...`)

### Step 2 — Create your `.env` file

```bash
# Run this from the project root:
cp backend/.env.example backend/.env
```

Then open `backend/.env` and paste your key:

```env
GEMINI_API_KEY=AIzaSyPasteYourRealKeyHere
```

---

## 4. Backend Setup

```bash
cd backend

# Create virtual environment (recommended)
python -m venv venv

# Activate:
# Windows:
venv\Scripts\activate
# Mac/Linux:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Set up API key
cp .env.example .env
# Edit .env → set GEMINI_API_KEY=your_key

# Start backend
python -m uvicorn main:app --reload --host 127.0.0.1 --port 8000
```

✅ API running at: **http://localhost:8000**
📖 Swagger docs: **http://localhost:8000/docs**

### Python Dependencies

| Package | Purpose |
|---|---|
| `fastapi` | Web framework |
| `uvicorn[standard]` | ASGI server |
| `pandas` | CSV/data processing |
| `networkx` | Dependency graph (Phase 1) |
| `httpx` | **Gemini REST API calls with SSL verify=False** |
| `openpyxl` | Excel report generation |
| `python-dotenv` | Loads API key from `.env` |
| `faiss-cpu` *(optional)* | Fast vector search for RAG |
| `numpy` | Embedding math / FAISS fallback |

> **Why httpx instead of the google-genai SDK?**
> On corporate networks with SSL inspection, the `google.genai` SDK times out
> because it ignores Python's `ssl._create_unverified_context`. Using raw
> `httpx` with `verify=False` (the same pattern as TCS GenAI Lab sample code)
> bypasses this entirely. No SDK needed.

---

## 5. Frontend Setup

```bash
cd frontend
npm install
npm run dev
```

✅ App running at: **http://localhost:5173**

---

## 6. Docker Setup

```bash
# Create .env in project ROOT (not inside backend/)
echo "GEMINI_API_KEY=AIzaSyYourKeyHere" > .env

# Build and start
docker compose up --build
```

✅ Frontend: **http://localhost:80**
✅ Backend API: **http://localhost:8000**

---

## 7. Verifying the Installation

### Check backend health

```bash
curl http://localhost:8000/api/health
```

### Check Gemini connectivity

```bash
curl http://localhost:8000/api/ai/status/test-session
```

Expected:
```json
{
  "gemini_key_configured": true,
  "gemini_available": true,
  "inventory_uploaded": false,
  "source_uploaded": false
}
```

### Terminal signs that Gemini is working

When you run Detailed Analysis you should see in the terminal:
```
[Gemini] Prompt length: 3459 chars. Timeout: 120s. Max retries: 3.
[Gemini] Success on attempt 1.
[Detailed AI] Gemini success for JOB201.
```

If you see `Using fallback` — check troubleshooting below.

---

## 8. How to Use the App

### Phase 1 — Schedule Analysis

1. Upload your scheduler export (CSV, JSON, or XML) — use `sample_data/sample_jobs.csv`
2. Optionally upload Execution History CSV
3. Explore: Dependency Graph, Critical Path, Fan Metrics, Cycle Detection, Criticality

### Phase 2 — AI Assessment

Navigate to the **AI Assessment** tab and work through sub-tabs in order:

#### Tab 1 — Input Setup

Upload **two** files:

**Job Inventory CSV** (`sample_data/job_inventory.csv`):

| Column | Description | Example |
|---|---|---|
| `Job_ID` | Unique identifier | `JOB201` |
| `Job_Name` | Human-readable name | `Extract_ERP_Data` |
| `Application` | Application group | `ERP_Integration` |
| `Source_File` | Script filename (**must match uploaded file exactly**) | `extract_erp.sh` |
| `Source_Type` | Technology | `Shell`, `SQL`, `Python`, `Java`, `SpringBatch` |

**Source Code Files** — the actual scripts referenced in `Source_File`.

Click **"Start Assessment"** — builds FAISS index and runs high-level rules for all jobs.

#### Tab 2 — High Level Assessment
Auto-populated with rules-based analysis. No AI tokens used.

#### Tab 3 — Detailed AI Analysis
Select a job → Gemini analyzes RAG-retrieved source code chunks for tables, joins, error handling, restart logic.

#### Tab 4 — Risk & Modernization
Select a job → AI scoring for migration complexity, technical debt, target technology recommendation.

#### Tab 5 — Job Conversion
Select a job + target technology → Gemini generates converted code.

#### Tab 6 — Summary & Export
Generate executive summary → Download 5-sheet Excel report.

---

## 9. Sample Data Reference

| File | Use For |
|---|---|
| `sample_data/sample_jobs.csv` | Phase 1 upload |
| `sample_data/job_inventory.csv` | Phase 2 → Job Inventory |
| `sample_data/extract_erp.sh` | Phase 2 → Source Code |
| `sample_data/sync_erp_crm.sh` | Phase 2 → Source Code |
| `sample_data/validate_erp.sql` | Phase 2 → Source Code |
| `sample_data/validate_customer.sql` | Phase 2 → Source Code |

**Quick test:** Phase 2 → upload `job_inventory.csv` + all 4 script files → Start Assessment → Detailed AI Analysis → select JOB201.

---

## 10. Troubleshooting

### ❌ "Gemini call failed after N attempts: read operation timed out"

**Root cause:** Corporate SSL inspection is blocking `generativelanguage.googleapis.com`.

**This fix is already applied** — the app now uses `httpx` with `verify=False` which bypasses SSL inspection. If you're still seeing this error:

1. Confirm you are running the **new** code (check `backend/ai/gemini_client.py` — it should import `httpx`, not `google.genai`)
2. Check your API key is valid at https://aistudio.google.com/app/apikey
3. Try: `curl -k https://generativelanguage.googleapis.com/v1beta/models` — if this works, your network is fine

### ❌ Detailed Analysis / Risk shows rule-based output instead of AI

Check terminal for one of these patterns:

| Terminal message | Fix |
|---|---|
| `Gemini call failed after N attempts` | See SSL fix above |
| `No chunks found for job_id=JOB201` | Filename mismatch — `Source_File` in CSV must exactly match uploaded filename |
| `Gemini returned invalid schema` | Response parsed but missing required keys — check prompts.py |
| `429 rate limit` | You've hit free-tier RPM limit — wait 60s and retry, or add more API keys |

### ❌ "No module named 'google'" or similar SDK error

The new version does **not** use `google-genai`. If you see this error it means an old import is still present. Run:
```bash
pip install -r requirements.txt
```
The `google-genai` package is now commented out in `requirements.txt`.

### ❌ Start Assessment button greyed out

Both upload cards must show green checkmarks:
- ✓ Job Inventory CSV uploaded
- ✓ Source code files uploaded

### ❌ Source code files not matching jobs

```
Source_File in CSV must EXACTLY match the uploaded filename.

✓ Correct:   Source_File = extract_erp.sh  →  upload extract_erp.sh
✗ Wrong:     Source_File = Extract_ERP.sh  →  case mismatch
```

### ❌ FAISS not available (logs show "falling back to NumPy")

```bash
pip install faiss-cpu
```
Without FAISS, retrieval still works via NumPy — slower but same accuracy.

### ❌ Port already in use

```bash
# Windows:
netstat -ano | findstr :8000
taskkill /PID <pid> /F

# Or use a different port:
python -m uvicorn main:app --reload --port 8001
```

---

## Quick Reference

```bash
# ── LOCAL DEV (fastest) ──────────────────────────────────────────

# Terminal 1 — Backend
cd backend
cp .env.example .env          # add your GEMINI_API_KEY
pip install -r requirements.txt
python -m uvicorn main:app --reload --host 127.0.0.1 --port 8000

# Terminal 2 — Frontend
cd frontend
npm install
npm run dev

# Open: http://localhost:5173


# ── DOCKER ───────────────────────────────────────────────────────

echo "GEMINI_API_KEY=AIzaSyYourKey" > .env   # project root
docker compose up --build

# Open: http://localhost
```

---

## AI Models in Use

| Purpose | Model | Notes |
|---|---|---|
| Source code embeddings (RAG) | `text-embedding-004` | REST API via httpx |
| Analysis & code generation | `gemini-2.0-flash` | REST API via httpx, SSL verify=False |

To switch generation model, change one line in `backend/ai/gemini_client.py`:
```python
_MODEL_NAME = "gemini-2.0-flash"   # change to any Gemini model name
```

---

## Key Architecture Change (v2 → v3)

| | Previous (v2) | Current (v3) |
|---|---|---|
| HTTP client | `google.genai` SDK | `httpx` (raw REST) |
| SSL handling | Python ssl module (ignored by SDK) | `httpx.Client(verify=False)` |
| Timeout | 60s (SDK level, unreliable) | 120s (httpx level, enforced) |
| Corporate proxy | ❌ Times out | ✅ Works |
| Generation model | `gemini-2.0-flash-lite-001` | `gemini-2.0-flash` |
| Embedding model | `gemini-embedding-001` | `text-embedding-004` |
