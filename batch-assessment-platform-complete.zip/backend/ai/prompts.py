"""
All Gemini prompt templates for Phase 2 AI Assessment.
Structured to minimize token usage and enforce strict JSON schemas.
Phase 1 signals (criticality, fan-in/out, critical path, bottleneck, schedule)
are injected into every prompt that benefits from them.
"""

from __future__ import annotations


def _phase1_block(job_meta: dict) -> str:
    """
    Render the Phase 1 signals block for any prompt that needs it.
    Only includes fields that are actually populated — avoids wasting tokens on empty values.
    """
    lines = []
    if job_meta.get("CriticalityBand"):
        lines.append(f"Criticality Band: {job_meta['CriticalityBand']}  (score: {job_meta.get('CriticalityScore', 0)}/10)")
    if job_meta.get("CriticalityReason"):
        lines.append(f"Criticality Reason: {job_meta['CriticalityReason']}")
    factors = job_meta.get("CriticalityFactors", [])
    if factors:
        lines.append(f"Criticality Factors: {', '.join(str(f) for f in factors)}")
    lines.append(f"Fan-In (upstream dependents): {job_meta.get('FanIn', 0)}")
    lines.append(f"Fan-Out (downstream deps):    {job_meta.get('FanOut', 0)}")
    lines.append(f"On Critical Path: {job_meta.get('OnCriticalPath', False)}")
    lines.append(f"Dependency Depth: {job_meta.get('DependencyDepth', 0)}")
    lines.append(f"Is Bottleneck:    {job_meta.get('IsBottleneck', False)}")
    if job_meta.get("Schedule"):
        lines.append(f"Schedule: {job_meta['Schedule']}")
    if job_meta.get("Platform"):
        lines.append(f"Platform: {job_meta['Platform']}")
    if job_meta.get("Owner"):
        lines.append(f"Owner: {job_meta['Owner']}")
    if job_meta.get("Runtime"):
        lines.append(f"Estimated Runtime: {job_meta['Runtime']}")
    return "\n".join(lines)


def _failure_log_block(job_meta: dict) -> str:
    """
    Render the matched Failure Log evidence block, if one was uploaded for this job.
    Returns an empty string if no log is present — callers should branch on this.
    """
    log = job_meta.get("FailureLog")
    if not log:
        return ""
    # Local import to avoid a circular import at module load time
    from ai.failure_log_parser import summarize_for_prompt
    return summarize_for_prompt(log)


# ══════════════════════════════════════════════════════════════════
# SUBMODULE 3 — DETAILED AI ANALYSIS
# ══════════════════════════════════════════════════════════════════

def detailed_analysis_prompt(job_meta: dict, code_chunks: list[str], rag_context: str) -> str:
    chunks_text = "\n\n".join(
        f"--- CODE CHUNK {i+1} ---\n{chunk}" for i, chunk in enumerate(code_chunks)
    )
    phase1 = _phase1_block(job_meta)
    failure_log_text = _failure_log_block(job_meta)

    if failure_log_text:
        failure_section = f"""
ACTUAL FAILURE LOG EVIDENCE (uploaded by the user from Control-M / scheduler logs for THIS job):
{failure_log_text}

A real execution failure log is available above. You MUST use this real evidence — not
generic guesses — to populate "failure_analysis" and to make "failure_recovery" specific
and actionable (reference the actual error code, root cause, and affected module from the log).
"""
        failure_analysis_instruction = (
            'Explain in detail WHY this job failed, using the failure log evidence above: '
            'state the root cause, the technical mechanism that caused it (e.g. resource '
            'exhaustion, bad data, timing/dependency issue), which downstream jobs were '
            'blocked as a result, and the overall business impact. Be specific and reference '
            'the actual error code / message from the log.'
        )
        failure_recovery_instruction = (
            'Use the failure log\'s root cause and recommended actions to give a SPECIFIC, '
            'actionable recovery procedure (not a generic statement) — e.g. exact remediation '
            'steps, what to check before restarting, and the restart point.'
        )
    else:
        failure_section = "\nNo failure log has been uploaded for this job. Base error handling and recovery guidance on the source code only.\n"
        failure_analysis_instruction = (
            'No failure log is available for this job. Set this field to: '
            '"No failure log uploaded for this job. Upload a Control-M execution log in the '
            'AI Assessment Setup tab to enable evidence-based failure analysis."'
        )
        failure_recovery_instruction = "Steps for recovering from failure, based on the source code's error handling logic."

    return f"""You are a senior systems code analyst specializing in enterprise batch systems.

KNOWLEDGE BASE:
{rag_context}

JOB METADATA:
Job ID: {job_meta.get('JobId', '')}
Job Name: {job_meta.get('JobName', '')}
Application: {job_meta.get('AppName', '')}
Source File: {job_meta.get('Source_File', '')}
Source Type: {job_meta.get('Source_Type', '')}

PHASE 1 SIGNALS (from dependency & criticality analysis):
{phase1}
{failure_section}
SOURCE CODE CHUNKS FOR ANALYSIS:
{chunks_text}

Perform a deep technical assessment based ONLY on the provided code chunks.
Use the Phase 1 signals to understand operational context (e.g. a high fan-in job
needs careful analysis of shared tables; a critical-path job needs thorough
error handling review).

Return a single JSON object with these EXACT keys (no markdown, no commentary):
{{
  "job_id": "{job_meta.get('JobId', '')}",
  "tables": ["table1", "table2"],
  "views": ["view1"],
  "reference_tables": ["ref_table1"],
  "functions": ["func1"],
  "stored_procedures": ["proc1"],
  "joins": {{
    "inner": ["table1.col = table2.col"],
    "outer": [],
    "left": [],
    "right": []
  }},
  "file_operations": ["Read file.txt", "Write output.csv"],
  "db_operations": ["Select customer", "Insert logs"],
  "utilities": ["SFTP", "SQLPlus"],
  "error_handling": "Description of error handling logic",
  "restart_logic": "Description of restart capability",
  "retry_logic": "Description of retries configured",
  "checkpoint_logic": "Description of checkpoints/markers",
  "failure_recovery": "{failure_recovery_instruction}",
  "failure_analysis": "{failure_analysis_instruction}",
  "detailed_technical_assessment": "Comprehensive paragraph covering technical functionality, dependencies, and operational impact given Phase 1 criticality context."
}}
"""


# ══════════════════════════════════════════════════════════════════
# SUBMODULE 4 — RISK & MODERNIZATION
# ══════════════════════════════════════════════════════════════════

def risk_modernization_prompt(
    job_meta: dict,
    high_level: dict,
    detailed_analysis: dict,
    exec_metrics: dict,
    rag_context: str
) -> str:
    phase1 = _phase1_block(job_meta)
    failure_log_text = _failure_log_block(job_meta)
    failure_section = ""
    if failure_log_text:
        failure_section = f"""
ACTUAL FAILURE LOG EVIDENCE (real execution failure for this job):
{failure_log_text}

Weigh this real failure evidence heavily — a job with a confirmed production failure
(especially one that breached SLA or blocked downstream jobs) should generally have
HIGHER risk_level, higher modernization_priority, and a risk_factor explicitly citing
the logged root cause, not just the heuristic execution-history counters below.
"""
    detailed_failure_analysis = detailed_analysis.get("failure_analysis", "")
    if detailed_failure_analysis and "No failure log" not in detailed_failure_analysis:
        failure_section += f"\nDETAILED AI'S FAILURE ANALYSIS (from Submodule 3):\n{detailed_failure_analysis}\n"

    return f"""You are an enterprise architect and cloud migration expert.

KNOWLEDGE BASE:
{rag_context}

JOB INFO:
Job ID: {job_meta.get('JobId', '')}
Job Name: {job_meta.get('JobName', '')}
Application: {job_meta.get('AppName', '')}
Source Type: {job_meta.get('Source_Type', 'Unknown')}

PHASE 1 SIGNALS (dependency graph & operational criticality):
{phase1}

HIGH LEVEL ASSESSMENT:
Risk Indicator: {high_level.get('risk_indicator', 'LOW')}
Modernization Rec: {high_level.get('modernization_recommendation', 'Unknown')}
File Ops: {high_level.get('file_operations', 'None')}
DB Ops: {high_level.get('db_operations', 'None')}
Utilities: {high_level.get('utilities', 'None')}

DETAILED CODE ANALYSIS:
Tables: {detailed_analysis.get('tables', [])}
Stored Procedures: {detailed_analysis.get('stored_procedures', [])}
Joins: {detailed_analysis.get('joins', {})}
Error Handling: {detailed_analysis.get('error_handling', 'None')}
Restart Logic: {detailed_analysis.get('restart_logic', 'None')}
Retry Logic: {detailed_analysis.get('retry_logic', 'None')}
Checkpoint Logic: {detailed_analysis.get('checkpoint_logic', 'None')}

EXECUTION HISTORY:
Failed Runs: {exec_metrics.get('failed_runs', 0)}
SLA Breaches: {exec_metrics.get('sla_breaches', 0)}
Avg Runtime (secs): {exec_metrics.get('avg_runtime_secs', 0)}
Total Runs: {exec_metrics.get('total_runs', 0)}
{failure_section}
Use Phase 1 signals heavily:
- High criticality score + on critical path = higher migration risk
- High fan-in (many dependents) = breaking change risk during migration
- Is bottleneck = schedule disruption risk
- No restart/checkpoint logic + critical path = high restartability debt

Recommended target paths:
- Shell → Python or Spring Batch
- SQL ETL → PySpark
- Informatica / DataStage / Talend → PySpark
- SSIS → dbt or AWS Glue
- Legacy Batch → Spring Batch

Return a single JSON object with these EXACT keys:
{{
  "job_id": "{job_meta.get('JobId', '')}",
  "risk_level": "LOW|MEDIUM|HIGH|CRITICAL",
  "migration_complexity": "LOW|MEDIUM|HIGH",
  "modernization_priority": "LOW|MEDIUM|HIGH|CRITICAL",
  "technical_debt_score": 5,
  "restartability_score": 6,
  "migration_recommendation": "Specific cloud-native target path",
  "target_technology": "Target Framework/Language (e.g. Python, PySpark, Spring Batch)",
  "target_scheduler": "Target Scheduler (e.g. Apache Airflow, AWS Step Functions)",
  "reasoning": "Paragraph explaining complexity, Phase 1 criticality context, technical debt, and modernization logic. If a failure log was provided, explicitly reference the real failure evidence here.",
  "risk_factors": [
    {{
      "severity": "HIGH|MEDIUM|LOW",
      "factor": "Specific risk concern",
      "description": "Explanation referencing Phase 1 signals, code analysis evidence, or failure log root cause if available."
    }}
  ]
}}
"""


# ══════════════════════════════════════════════════════════════════
# SUBMODULE 5 — JOB CONVERSION
# ══════════════════════════════════════════════════════════════════

def job_conversion_prompt(
    job_meta: dict,
    source_code: str,
    target_technology: str,
    rag_context: str
) -> str:
    phase1 = _phase1_block(job_meta)
    return f"""You are a senior software engineer expert in enterprise batch code conversion.

KNOWLEDGE BASE:
{rag_context}

JOB METADATA:
Job ID: {job_meta.get('JobId', '')}
Job Name: {job_meta.get('JobName', '')}
Application: {job_meta.get('AppName', '')}
Source Type: {job_meta.get('Source_Type', 'Unknown')}
Target: {target_technology}

PHASE 1 SIGNALS:
{phase1}

SOURCE CODE:
```
{source_code[:12000]}
```

Convert to {target_technology} using clean code and cloud-native practices.
If the job is on the critical path or is a bottleneck, add explicit error handling,
retry logic, and checkpoint/restart support in the converted code.

Supported conversions:
- Shell → Python, Java, Spring Batch
- SQL / PLSQL / Stored Procedure → Python, PySpark
- Cron / Autosys / Control-M → Spring Batch
- Informatica / DataStage / Talend → PySpark

Return a single JSON object with these EXACT keys:
{{
  "job_id": "{job_meta.get('JobId', '')}",
  "target_technology": "{target_technology}",
  "converted_code": "complete converted code (use \\n for newlines, escape quotes)",
  "migration_explanation": "Paragraph detailing migration decisions, libraries used, and configuration changes.",
  "risks": ["Specific conversion risk 1", "Specific conversion risk 2"],
  "validation_checklist": ["Verify DB connection string", "Test restart from checkpoint"],
  "estimated_effort_hours": 8,
  "manual_review_needed": true,
  "current_technology": "e.g. Shell Script, PL/SQL, etc.",
  "recommended_technology": "{target_technology}",
  "reason_for_recommendation": "Detailed explanation of why this target technology was chosen.",
  "migration_complexity": "LOW, MEDIUM, or HIGH",
  "dependencies": ["List of libraries, files, or db dependencies"],
  "potential_risks": ["Risk 1", "Risk 2"],
  "manual_changes_required": ["Manual step 1", "Manual step 2"],
  "business_impact": "Operational, cost, or licensing business impact",
  "benefits": ["Benefit 1", "Benefit 2"],
  "confidence_score": "Confidence score out of 10 (e.g. 9/10)"
}}
"""


# ══════════════════════════════════════════════════════════════════
# SUBMODULE 6 — EXECUTIVE SUMMARY
# ══════════════════════════════════════════════════════════════════

def executive_summary_prompt(stats: dict, rag_context: str) -> str:
    return f"""You are a senior IT consultant writing a batch modernization executive summary.

KNOWLEDGE BASE:
{rag_context}

AGGREGATED METRICS:
Total Jobs Assessed: {stats.get('total_jobs', 0)}
On Critical Path: {stats.get('critical_path_count', 0)}
Bottleneck Jobs: {stats.get('bottleneck_count', 0)}
Avg Criticality Score: {stats.get('avg_criticality_score', 0):.1f}/10
Risk Distribution — HIGH: {stats.get('high_risk_count', 0)}, MEDIUM: {stats.get('medium_risk_count', 0)}, LOW: {stats.get('low_risk_count', 0)}
Avg Technical Debt Score: {stats.get('avg_tech_debt', 5.0):.1f}/10
Avg Restartability Score: {stats.get('avg_restartability', 5.0):.1f}/10
Jobs with No Restart Logic: {stats.get('no_restart_count', 0)}
Jobs with SLA Breaches: {stats.get('sla_breach_count', 0)}

Write a business-friendly executive summary for migrating off legacy batch schedulers.

Return a single JSON object with these EXACT keys:
{{
  "headline": "Modernization Headline",
  "executive_summary": "3-4 paragraphs covering findings, migration paths, and cost/licensing benefits.",
  "key_findings": ["Finding 1", "Finding 2", "Finding 3"],
  "strategic_recommendations": [
    {{
      "priority": "1",
      "recommendation": "Recommendation text",
      "business_value": "Value description",
      "timeline": "0-3 months"
    }}
  ],
  "risk_summary": "Paragraph describing key operational and schedule risks.",
  "modernization_roadmap": {{
    "phase1": "0-3 months",
    "phase2": "3-9 months",
    "phase3": "9-18 months"
  }}
}}
"""
