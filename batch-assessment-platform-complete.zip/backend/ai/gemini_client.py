"""
Gemini API client — uses raw httpx (SSL verification disabled for corporate networks).

Why httpx instead of google.genai SDK?
  The google.genai SDK does not honour ssl._create_unverified_context, so on
  corporate networks with SSL inspection it always times out.  By making the
  HTTP calls ourselves with httpx (verify=False) we bypass that entirely —
  the same pattern used in the TCS GenAI Lab sample code.

KEY ROTATION:
  Set one OR more keys in backend/.env:
    GEMINI_API_KEY=AIzaSy...            ← single key (minimum)
    GEMINI_API_KEY_2=AIzaSy...          ← optional extra key
    ...up to GEMINI_API_KEY_15

  1  key  =  15 RPM,   500 RPD
  5  keys =  75 RPM, 2,500 RPD
  10 keys = 150 RPM, 5,000 RPD
"""

from __future__ import annotations
import json, os, re, time, logging, itertools
from typing import Any

import httpx

logger = logging.getLogger(__name__)

# ── Gemini REST endpoints ─────────────────────────────────────────
_GEMINI_BASE    = "https://generativelanguage.googleapis.com/v1beta"
_MODEL_NAME     = "gemini-2.5-flash"
_EMBED_MODEL    = "models/gemini-embedding-001"   # REST-compatible embedding model


# ── Tuning ────────────────────────────────────────────────────────
_TIMEOUT_SECS   = 120         # httpx total timeout — generous for complex prompts
_MAX_RETRIES    = 3           # retries per call
_RETRY_DELAY    = 10.0        # seconds between retries
_RPM_SLEEP      = 4.5         # seconds between embedding calls (~13 RPM, free tier = 15 RPM)

# ── Shared httpx client (SSL verification OFF for corporate proxy) ─
# This is the key fix — mirrors the TCS sample: httpx.Client(verify=False)
_http = httpx.Client(verify=False, timeout=_TIMEOUT_SECS)

# ── Key registry ─────────────────────────────────────────────────
_keys: list[str] = []
_key_cycle = None


def _load_keys() -> list[str]:
    keys = []
    k = os.environ.get("GEMINI_API_KEY", "").strip()
    if k:
        keys.append(k)
    for i in range(2, 16):
        k = os.environ.get(f"GEMINI_API_KEY_{i}", "").strip()
        if k and k not in keys:
            keys.append(k)
    return keys


def _init_keys():
    global _keys, _key_cycle
    if _keys:
        return
    _keys = _load_keys()
    if not _keys:
        logger.warning("[Gemini] No API keys found. Set GEMINI_API_KEY in backend/.env")
        return
    _key_cycle = itertools.cycle(_keys)
    logger.info(f"[Gemini] Loaded {len(_keys)} API key(s). Round-robin rotation enabled.")


def _next_key() -> str:
    _init_keys()
    if not _keys:
        raise ValueError(
            "No Gemini API key configured.\n"
            "Add GEMINI_API_KEY=your_key to backend/.env and restart the server."
        )
    return next(_key_cycle)


def _first_key() -> str:
    _init_keys()
    if not _keys:
        raise ValueError("No Gemini API key configured.")
    return _keys[0]


# ── Generation ────────────────────────────────────────────────────
def call_gemini(
    prompt: str,
    expect_json: bool = True,
    retries: int = _MAX_RETRIES,
    delay: float = _RETRY_DELAY,
    model: str = "",
) -> Any:
    """
    POST to Gemini generateContent REST API via httpx (SSL disabled).
    Rotates API keys on every attempt, handles 429 backoff, retries.
    """
    model_to_use = model if model and not model.endswith("-mock") and "claude" not in model.lower() and "gpt" not in model.lower() and "local" not in model.lower() else _MODEL_NAME
    url_template = (
        f"{_GEMINI_BASE}/models/{model_to_use}:generateContent?key={{key}}"
    )
    payload = {
        "contents": [{"parts": [{"text": prompt}]}],
        "generationConfig": {
            "temperature": 0.2,
            "maxOutputTokens": 8192,
        },
    }

    logger.info(
        f"[Gemini] Prompt length: {len(prompt)} chars. "
        f"Timeout: {_TIMEOUT_SECS}s. Max retries: {retries}."
    )

    last_err = None
    for attempt in range(retries + 1):
        key = _next_key()
        url = url_template.format(key=key)
        try:
            resp = _http.post(url, json=payload)

            # Handle rate limit
            if resp.status_code == 429:
                wait = delay * (attempt + 1) * 3
                logger.warning(
                    f"[Gemini] 429 rate limit on attempt {attempt+1}. "
                    f"Waiting {wait:.0f}s then retrying with next key..."
                )
                if attempt < retries:
                    time.sleep(wait)
                last_err = Exception(f"429 rate limit: {resp.text[:200]}")
                continue

            resp.raise_for_status()
            data = resp.json()

            # Extract text from response
            text = (
                data.get("candidates", [{}])[0]
                .get("content", {})
                .get("parts", [{}])[0]
                .get("text", "")
                .strip()
            )
            if not text:
                raise ValueError("Empty response from Gemini API")

            logger.info(f"[Gemini] Success on attempt {attempt+1}.")
            return _extract_json(text) if expect_json else text

        except httpx.TimeoutException as e:
            last_err = e
            logger.warning(
                f"[Gemini] Attempt {attempt+1} timed out (>{_TIMEOUT_SECS}s). "
                f"Switching key and retrying in {delay}s..."
            )
            if attempt < retries:
                time.sleep(delay)

        except httpx.HTTPStatusError as e:
            last_err = e
            logger.warning(f"[Gemini] HTTP error on attempt {attempt+1}: {e}")
            if attempt < retries:
                time.sleep(delay)

        except Exception as e:
            last_err = e
            err_str = str(e).lower()
            if "429" in err_str or "quota" in err_str or "rate" in err_str:
                wait = delay * (attempt + 1) * 3
                logger.warning(
                    f"[Gemini] 429 on attempt {attempt+1}. Waiting {wait:.0f}s..."
                )
                if attempt < retries:
                    time.sleep(wait)
            else:
                logger.warning(
                    f"[Gemini] Attempt {attempt+1} failed: {e}. Retrying in {delay}s..."
                )
                if attempt < retries:
                    time.sleep(delay)

    raise RuntimeError(f"Gemini call failed after {retries+1} attempts: {last_err}")


# ── Embedding ─────────────────────────────────────────────────────
def embed_text(text: str, retries: int = 2) -> list[float] | None:
    """
    Embed a single text via Gemini embedContent REST API (SSL disabled via httpx).
    Returns None on failure — caller uses mock fallback.
    """
    key = _first_key()
    url = f"{_GEMINI_BASE}/{_EMBED_MODEL}:embedContent?key={key}"
    payload = {
        "model": _EMBED_MODEL,
        "content": {"parts": [{"text": text}]},
    }

    for attempt in range(retries + 1):
        try:
            resp = _http.post(url, json=payload)
            if resp.status_code == 429:
                wait = _RPM_SLEEP * (attempt + 1) * 3
                logger.warning(f"[Gemini Embed] 429 on attempt {attempt+1}. Sleeping {wait:.1f}s...")
                time.sleep(wait)
                continue
            resp.raise_for_status()
            data = resp.json()
            values = data.get("embedding", {}).get("values", [])
            if values:
                return values
        except Exception as e:
            logger.warning(f"[Gemini Embed] Failed on attempt {attempt+1}: {e}")
            if attempt < retries:
                time.sleep(_RPM_SLEEP)

    return None


# ── JSON extraction ───────────────────────────────────────────────
def _extract_json(text: str) -> Any:
    cleaned = re.sub(r"```(?:json)?\s*", "", text)
    cleaned = re.sub(r"```\s*$", "", cleaned).strip()
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        pass
    for pattern in [r"\{[\s\S]*\}", r"\[[\s\S]*\]"]:
        m = re.search(pattern, cleaned)
        if m:
            try:
                return json.loads(m.group())
            except json.JSONDecodeError:
                pass
    logger.warning("[Gemini] Could not parse JSON — returning raw text")
    return {"raw_response": text, "parse_error": True}


# ── Helpers ───────────────────────────────────────────────────────
def is_available() -> bool:
    _init_keys()
    return len(_keys) > 0


def key_count() -> int:
    _init_keys()
    return len(_keys)


class GeminiUnreachableError(RuntimeError):
    pass
