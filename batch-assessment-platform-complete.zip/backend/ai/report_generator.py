"""
Report generator — produces Excel and JSON reports from assessment data.
Uses openpyxl for professional Excel output.
"""

from __future__ import annotations
import io, json, os
from datetime import datetime
from typing import Any

import pandas as pd

try:
    import openpyxl
    from openpyxl.styles import (
        Font, PatternFill, Alignment, Border, Side
    )
    from openpyxl.utils import get_column_letter
    OPENPYXL_OK = True
except ImportError:
    OPENPYXL_OK = False


# ── Color palette ──────────────────────────────────────────────────
COL = {
    "header_bg":  "1E3A5F",   # navy
    "header_fg":  "FFFFFF",
    "alt_row":    "F0F4FA",
    "high_bg":    "FFDEDE",
    "high_fg":    "8B0000",
    "medium_bg":  "FFF3CD",
    "medium_fg":  "7B4B00",
    "low_bg":     "D4EDDA",
    "low_fg":     "155724",
    "critical_bg":"FFB3B3",
    "critical_fg":"660000",
    "section_bg": "E8F0FE",
    "section_fg": "1A237E",
    "border":     "BCC8D8",
}

THIN_BORDER = None  # initialized lazily


def _border():
    global THIN_BORDER
    if THIN_BORDER is None and OPENPYXL_OK:
        s = Side(style="thin", color=COL["border"])
        THIN_BORDER = Border(left=s, right=s, top=s, bottom=s)
    return THIN_BORDER


def _hfont(**kw):
    return Font(bold=True, color=COL["header_fg"], name="Calibri", size=10, **kw)

def _fill(hex_color: str) -> PatternFill:
    return PatternFill("solid", fgColor=hex_color)

def _cell(ws, row, col, value, bold=False, bg=None, fg=None, wrap=False, size=10):
    c = ws.cell(row=row, column=col, value=value)
    c.font = Font(bold=bold, color=fg or "000000", name="Calibri", size=size)
    if bg:
        c.fill = _fill(bg)
    c.alignment = Alignment(vertical="top", wrap_text=wrap, horizontal="left")
    c.border    = _border()
    return c


# ══════════════════════════════════════════════════════════════════
def generate_excel_report(
    bulk_assessments:   list[dict],
    source_analyses:    list[dict],
    modernization_data: list[dict],
    risk_data:          list[dict],
    executive_summary:  dict,
    session_meta:       dict,
) -> bytes:
    """Generate full multi-sheet Excel report. Returns bytes."""
    if not OPENPYXL_OK:
        return _fallback_csv(bulk_assessments)

    wb = openpyxl.Workbook()
    wb.remove(wb.active)   # remove default sheet

    _sheet_cover(wb, executive_summary, session_meta)
    _sheet_bulk_assessment(wb, bulk_assessments)
    _sheet_source_analysis(wb, source_analyses)
    _sheet_modernization(wb, modernization_data)
    _sheet_risk(wb, risk_data)
    _sheet_summary_charts(wb, bulk_assessments, risk_data)

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf.read()


# ── Sheet 1: Cover / Executive Summary ────────────────────────────
def _sheet_cover(wb, summary: dict, meta: dict):
    ws = wb.create_sheet("Executive Summary")
    ws.sheet_view.showGridLines = False

    def big(row, col, val, size=14, bold=True, bg=None, fg="1E3A5F"):
        c = ws.cell(row=row, column=col, value=val)
        c.font = Font(bold=bold, size=size, color=fg, name="Calibri")
        if bg: c.fill = _fill(bg)
        c.alignment = Alignment(wrap_text=True, vertical="top")
        return c

    ws.column_dimensions["A"].width = 6
    ws.column_dimensions["B"].width = 30
    ws.column_dimensions["C"].width = 80

    row = 2
    big(row, 2, "BATCH MODERNIZATION ASSESSMENT", size=18, bg="1E3A5F", fg="FFFFFF")
    ws.cell(row, 2).fill = _fill("1E3A5F")
    ws.cell(row, 3).fill = _fill("1E3A5F")
    ws.merge_cells(f"B{row}:C{row}")
    ws.row_dimensions[row].height = 36
    row += 1

    big(row, 2, f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}", size=10, bold=False, fg="555555")
    big(row, 3, f"File: {meta.get('filename','N/A')} | Jobs: {meta.get('total_jobs',0)}", size=10, bold=False, fg="555555")
    row += 2

    # Headline
    if summary.get("headline"):
        big(row, 2, summary["headline"], size=13, bg="E8F0FE")
        ws.merge_cells(f"B{row}:C{row}")
        ws.row_dimensions[row].height = 28
        row += 1

    # Executive summary text
    if summary.get("executive_summary"):
        ws.cell(row, 2, "SUMMARY").font = Font(bold=True, size=11, color="1E3A5F")
        row += 1
        c = ws.cell(row, 2, summary["executive_summary"])
        c.alignment = Alignment(wrap_text=True, vertical="top")
        c.font      = Font(size=10, name="Calibri")
        ws.merge_cells(f"B{row}:C{row}")
        ws.row_dimensions[row].height = 90
        row += 2

    # Key findings
    if summary.get("key_findings"):
        ws.cell(row, 2, "KEY FINDINGS").font = Font(bold=True, size=11, color="1E3A5F", name="Calibri")
        row += 1
        for f in summary["key_findings"]:
            c = ws.cell(row, 2, f"• {f}")
            c.font = Font(size=10, name="Calibri")
            ws.merge_cells(f"B{row}:C{row}")
            row += 1
        row += 1

    # Strategic recommendations
    if summary.get("strategic_recommendations"):
        ws.cell(row, 2, "STRATEGIC RECOMMENDATIONS").font = Font(bold=True, size=11, color="1E3A5F")
        row += 1
        for rec in summary["strategic_recommendations"]:
            pri = rec.get("priority", "")
            ws.cell(row, 2, f"Priority {pri}: {rec.get('recommendation','')}")
            ws.cell(row, 2).font = Font(bold=True, size=10, color="1E3A5F", name="Calibri")
            row += 1
            ws.cell(row, 3, f"Value: {rec.get('business_value','')} | Timeline: {rec.get('timeline','')}")
            ws.cell(row, 3).font = Font(size=9, color="555555", name="Calibri")
            row += 1
        row += 1

    # Roadmap
    rm = summary.get("modernization_roadmap", {})
    if rm:
        ws.cell(row, 2, "MODERNIZATION ROADMAP").font = Font(bold=True, size=11, color="1E3A5F")
        row += 1
        for phase, desc in rm.items():
            ws.cell(row, 2, phase.upper()).font = Font(bold=True, size=10, color="155724", name="Calibri")
            ws.cell(row, 2).fill = _fill("D4EDDA")
            ws.cell(row, 3, desc).font = Font(size=10, name="Calibri")
            row += 1


# ── Sheet 2: Bulk Assessment ───────────────────────────────────────
def _sheet_bulk_assessment(wb, data: list[dict]):
    ws  = wb.create_sheet("Bulk Assessment")
    hdr = ["Job ID","Job Type","File Operations","DB Operations",
           "Utility Usage","Output Artifacts","Complexity","Mod. Score","Candidate","Reason"]
    widths = [18, 14, 22, 22, 18, 22, 12, 10, 10, 40]
    _write_header(ws, hdr, widths)

    for i, row in enumerate(data, start=2):
        vals = [
            row.get("job_id",""),
            row.get("job_type",""),
            row.get("file_operations",""),
            row.get("db_operations",""),
            row.get("utility_usage",""),
            row.get("output_artifacts",""),
            row.get("migration_complexity",""),
            row.get("modernization_score",""),
            row.get("modernization_candidate",""),
            row.get("brief_reason",""),
        ]
        _write_row(ws, i, vals)
        _color_complexity_row(ws, i, len(hdr), row.get("migration_complexity",""))


# ── Sheet 3: Source Analysis ───────────────────────────────────────
def _sheet_source_analysis(wb, data: list[dict]):
    ws  = wb.create_sheet("Source Analysis")
    hdr = ["Job ID","Tables","Views","Stored Procs","Inner Joins","Left Joins",
           "File Reads","File Writes","FTP","SFTP","MQ","Error Handling","Restart Quality","Hardcoded Creds"]
    widths = [16,26,20,20,10,10,22,22,7,7,7,16,16,14]
    _write_header(ws, hdr, widths)

    for i, row in enumerate(data, start=2):
        joins = row.get("joins", {})
        eh    = row.get("error_handling", {})
        rl    = row.get("restart_logic", {})
        vals  = [
            row.get("job_id",""),
            ", ".join(row.get("tables_used",[])),
            ", ".join(row.get("views_used",[])),
            ", ".join(row.get("stored_procedures",[])),
            joins.get("inner",0),
            joins.get("left",0),
            ", ".join(row.get("file_reads",[])),
            ", ".join(row.get("file_writes",[])),
            "Yes" if row.get("ftp_usage") else "No",
            "Yes" if row.get("sftp_usage") else "No",
            "Yes" if row.get("mq_usage") else "No",
            eh.get("quality",""),
            rl.get("restart_quality",""),
            "⚠ YES" if row.get("hardcoded_credentials") else "No",
        ]
        _write_row(ws, i, vals)
        # Flag hardcoded creds in red
        if row.get("hardcoded_credentials"):
            ws.cell(i, len(hdr)).fill = _fill(COL["critical_bg"])
            ws.cell(i, len(hdr)).font = Font(bold=True, color=COL["critical_fg"])


# ── Sheet 4: Modernization ─────────────────────────────────────────
def _sheet_modernization(wb, data: list[dict]):
    ws  = wb.create_sheet("Modernization Plan")
    hdr = ["Job ID","Current Tech","Current Scheduler","Recommended Tech",
           "Recommended Scheduler","Complexity","Est. Days","Benefits","Migration Steps","Reasoning"]
    widths = [16,14,16,16,18,12,10,30,30,50]
    _write_header(ws, hdr, widths)

    for i, row in enumerate(data, start=2):
        vals = [
            row.get("job_id",""),
            row.get("current_technology",""),
            row.get("current_scheduler",""),
            row.get("recommended_technology",""),
            row.get("recommended_scheduler",""),
            row.get("migration_complexity",""),
            row.get("estimated_effort_days",""),
            "\n".join(f"• {b}" for b in row.get("modernization_benefits",[])),
            "\n".join(f"{j+1}. {s}" for j,s in enumerate(row.get("migration_steps",[]))),
            row.get("reasoning",""),
        ]
        _write_row(ws, i, vals, wrap=True)
        _color_complexity_row(ws, i, len(hdr), row.get("migration_complexity",""))
        ws.row_dimensions[i].height = max(40, len(row.get("migration_steps",[])) * 14)


# ── Sheet 5: Risk Assessment ───────────────────────────────────────
def _sheet_risk(wb, data: list[dict]):
    ws  = wb.create_sheet("Risk Assessment")
    hdr = ["Job ID","Risk Level","Dep. Risk","Data Risk","Op. Risk",
           "Risk Factors","Migration Recommendation","Pre-Migration Actions"]
    widths = [16,12,12,12,12,40,36,36]
    _write_header(ws, hdr, widths)

    for i, row in enumerate(data, start=2):
        factors_text = "\n".join(
            f"• [{f.get('severity','')}] {f.get('factor','')}: {f.get('description','')}"
            for f in row.get("risk_factors", [])
        )
        vals = [
            row.get("job_id",""),
            row.get("risk_level",""),
            row.get("dependency_risk",""),
            row.get("data_risk",""),
            row.get("operational_risk",""),
            factors_text,
            row.get("migration_recommendation",""),
            "\n".join(f"• {a}" for a in row.get("pre_migration_actions",[])),
        ]
        _write_row(ws, i, vals, wrap=True)
        _color_risk_row(ws, i, len(hdr), row.get("risk_level",""))
        ws.row_dimensions[i].height = max(30, len(row.get("risk_factors",[])) * 18)


# ── Sheet 6: Summary stats ─────────────────────────────────────────
def _sheet_summary_charts(wb, bulk: list[dict], risk: list[dict]):
    ws = wb.create_sheet("Summary Statistics")
    ws.sheet_view.showGridLines = False
    ws.column_dimensions["A"].width = 3
    ws.column_dimensions["B"].width = 32
    ws.column_dimensions["C"].width = 18

    def section(row, title):
        c = ws.cell(row, 2, title)
        c.font = Font(bold=True, size=12, color=COL["section_fg"], name="Calibri")
        c.fill = _fill(COL["section_bg"])
        ws.merge_cells(f"B{row}:C{row}")
        ws.row_dimensions[row].height = 22
        return row + 1

    def stat(row, label, value, bg=None):
        lc = ws.cell(row, 2, label)
        vc = ws.cell(row, 3, value)
        lc.font = Font(size=10, name="Calibri")
        vc.font = Font(bold=True, size=10, name="Calibri")
        if bg:
            lc.fill = _fill(bg)
            vc.fill = _fill(bg)
        return row + 1

    r = 2
    r = section(r, "📊 JOB ASSESSMENT OVERVIEW")

    # complexity
    comp = {}
    for b in bulk:
        k = b.get("migration_complexity","Unknown")
        comp[k] = comp.get(k,0) + 1
    r = stat(r, "Total Jobs Assessed", len(bulk))
    r = stat(r, "High Complexity",   comp.get("High",0),   COL["high_bg"])
    r = stat(r, "Medium Complexity", comp.get("Medium",0), COL["medium_bg"])
    r = stat(r, "Low Complexity",    comp.get("Low",0),    COL["low_bg"])

    r += 1
    r = section(r, "🔴 RISK DISTRIBUTION")
    risk_dist = {}
    for rv in risk:
        k = rv.get("risk_level","Unknown")
        risk_dist[k] = risk_dist.get(k,0) + 1
    for lvl, bg in [("Critical",COL["critical_bg"]),("High",COL["high_bg"]),
                     ("Medium",COL["medium_bg"]),("Low",COL["low_bg"])]:
        r = stat(r, f"{lvl} Risk Jobs", risk_dist.get(lvl,0), bg)

    r += 1
    r = section(r, "⚙️ JOB TYPE DISTRIBUTION")
    jtypes = {}
    for b in bulk:
        k = b.get("job_type","Unknown")
        jtypes[k] = jtypes.get(k,0) + 1
    for jt, cnt in sorted(jtypes.items(), key=lambda x:-x[1]):
        r = stat(r, jt, cnt)

    r += 1
    scores = [b.get("modernization_score",0) for b in bulk if isinstance(b.get("modernization_score"),(int,float))]
    if scores:
        r = section(r, "📈 MODERNIZATION SCORES")
        r = stat(r, "Average Score", f"{sum(scores)/len(scores):.1f} / 10")
        r = stat(r, "Max Score", f"{max(scores)} / 10")
        r = stat(r, "Min Score", f"{min(scores)} / 10")
        high_need = sum(1 for s in scores if s >= 7)
        r = stat(r, "High Modernization Need (≥7)", high_need, COL["high_bg"])


# ── Helpers ───────────────────────────────────────────────────────
def _write_header(ws, headers: list[str], widths: list[int], start_row: int = 1):
    for j, (h, w) in enumerate(zip(headers, widths), start=1):
        c = ws.cell(start_row, j, h.upper())
        c.font      = _hfont()
        c.fill      = _fill(COL["header_bg"])
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        c.border    = _border()
        ws.column_dimensions[get_column_letter(j)].width = w
    ws.row_dimensions[start_row].height = 28
    ws.freeze_panes = f"A{start_row + 1}"


def _write_top_banner(ws, title_text: str, session_id: str, num_columns: int):
    # Row 1: Merged Title Banner
    c1 = ws.cell(row=1, column=1, value=title_text)
    c1.font = Font(bold=True, size=13, color="1E3A5F", name="Calibri")
    c1.alignment = Alignment(vertical="center", horizontal="left")
    
    # Row 2: Sub-header metadata
    generated_on = datetime.now().strftime("%Y-%m-%d %H:%M:%S UTC")
    meta_text = f"Assessment Run Code: {session_id[:8].upper()} | Generated on: {generated_on} | Status: Completed"
    c2 = ws.cell(row=2, column=1, value=meta_text)
    c2.font = Font(italic=True, size=9.5, color="555555", name="Calibri")
    c2.alignment = Alignment(vertical="center", horizontal="left")
    
    # Add border/underline below banner
    border_side = Side(style="medium", color="1E3A5F")
    for col in range(1, num_columns + 1):
        ws.cell(row=1, column=col).border = Border(top=None, bottom=None)
        ws.cell(row=2, column=col).border = Border(bottom=border_side)
    
    ws.row_dimensions[1].height = 24
    ws.row_dimensions[2].height = 18
    # Row 3 is empty/spacer
    ws.row_dimensions[3].height = 10



def _write_row(ws, row: int, values: list, wrap: bool = False):
    alt = row % 2 == 0
    for j, v in enumerate(values, start=1):
        c = ws.cell(row, j, v)
        c.font      = Font(size=9, name="Calibri")
        c.alignment = Alignment(vertical="top", wrap_text=wrap, horizontal="left")
        c.border    = _border()
        if alt:
            c.fill = _fill(COL["alt_row"])


def _color_complexity_row(ws, row: int, ncols: int, complexity: str):
    mapping = {"High": (COL["high_bg"], COL["high_fg"]),
               "Medium": (COL["medium_bg"], COL["medium_fg"]),
               "Low": (COL["low_bg"], COL["low_fg"])}
    bg, fg = mapping.get(complexity, (None, None))
    if not bg: return
    for col in range(1, ncols + 1):
        c = ws.cell(row, col)
        if c.value in [complexity]:   # only the complexity cell gets text color
            c.fill = _fill(bg)
            c.font = Font(bold=True, size=9, color=fg, name="Calibri")
        else:
            # subtle tint
            pass


def _color_risk_row(ws, row: int, ncols: int, risk_level: str):
    mapping = {
        "Critical": (COL["critical_bg"], COL["critical_fg"]),
        "High":     (COL["high_bg"],     COL["high_fg"]),
        "Medium":   (COL["medium_bg"],   COL["medium_fg"]),
        "Low":      (COL["low_bg"],      COL["low_fg"]),
    }
    bg, fg = mapping.get(risk_level, (None, None))
    if not bg: return
    # Color only the risk level cell (col 2)
    c = ws.cell(row, 2)
    c.fill = _fill(bg)
    c.font = Font(bold=True, size=9, color=fg, name="Calibri")


def _fallback_csv(data: list[dict]) -> bytes:
    """Fallback if openpyxl not available."""
    if not data:
        return b"No data"
    df = pd.DataFrame(data)
    return df.to_csv(index=False).encode()


def _sheet_executive_summary(wb, summary: dict, session: dict, selected_model: str, assessment_date: str, generated_time: str):
    ws = wb.create_sheet("Executive Summary")
    ws.sheet_view.showGridLines = False

    ws.column_dimensions["A"].width = 6
    ws.column_dimensions["B"].width = 30
    ws.column_dimensions["C"].width = 80

    def big(row, col, val, size=14, bold=True, bg=None, fg="1E3A5F"):
        c = ws.cell(row=row, column=col, value=val)
        c.font = Font(bold=bold, size=size, color=fg, name="Calibri")
        if bg: c.fill = _fill(bg)
        c.alignment = Alignment(wrap_text=True, vertical="top")
        return c

    row = 2
    big(row, 2, "BATCH MODERNIZATION EXECUTIVE SUMMARY", size=16, bg="1E3A5F", fg="FFFFFF")
    ws.cell(row, 2).fill = _fill("1E3A5F")
    ws.cell(row, 3).fill = _fill("1E3A5F")
    ws.merge_cells(f"B{row}:C{row}")
    ws.row_dimensions[row].height = 36
    row += 2

    # Metadata Block
    big(row, 2, "Assessment Date:", size=10, bold=True, fg="333333")
    big(row, 3, assessment_date, size=10, bold=False, fg="555555")
    row += 1
    big(row, 2, "Selected AI Model:", size=10, bold=True, fg="333333")
    big(row, 3, selected_model, size=10, bold=False, fg="555555")
    row += 1
    big(row, 2, "Generated Timestamp:", size=10, bold=True, fg="333333")
    big(row, 3, generated_time, size=10, bold=False, fg="555555")
    row += 2

    # Headline
    if summary.get("headline"):
        big(row, 2, summary["headline"], size=13, bg="E8F0FE", fg="1E3A5F")
        ws.cell(row, 2).fill = _fill("E8F0FE")
        ws.cell(row, 3).fill = _fill("E8F0FE")
        ws.merge_cells(f"B{row}:C{row}")
        ws.row_dimensions[row].height = 28
        row += 2

    # Executive summary text
    if summary.get("executive_summary"):
        ws.cell(row, 2, "SUMMARY NARRATIVE").font = Font(bold=True, size=11, color="1E3A5F")
        row += 1
        c = ws.cell(row, 2, summary["executive_summary"])
        c.alignment = Alignment(wrap_text=True, vertical="top")
        c.font      = Font(size=10, name="Calibri")
        ws.merge_cells(f"B{row}:C{row}")
        ws.row_dimensions[row].height = 110
        row += 2

    # Key findings
    if summary.get("key_findings"):
        ws.cell(row, 2, "KEY STRATEGIC FINDINGS").font = Font(bold=True, size=11, color="1E3A5F", name="Calibri")
        row += 1
        for f in summary["key_findings"]:
            c = ws.cell(row, 2, f"• {f}")
            c.font = Font(size=10, name="Calibri")
            ws.merge_cells(f"B{row}:C{row}")
            row += 1
        row += 2

    # Strategic recommendations
    if summary.get("strategic_recommendations"):
        ws.cell(row, 2, "STRATEGIC RECOMMENDATIONS").font = Font(bold=True, size=11, color="1E3A5F")
        row += 1
        for rec in summary["strategic_recommendations"]:
            pri = rec.get("priority", "")
            ws.cell(row, 2, f"Priority {pri}: {rec.get('recommendation','')}")
            ws.cell(row, 2).font = Font(bold=True, size=10, color="1E3A5F", name="Calibri")
            row += 1
            ws.cell(row, 3, f"Value: {rec.get('business_value','')} | Timeline: {rec.get('timeline','')}")
            ws.cell(row, 3).font = Font(size=9, color="555555", name="Calibri")
            row += 1
        row += 2

    # Roadmap
    rm = summary.get("modernization_roadmap", {})
    if rm:
        ws.cell(row, 2, "MODERNIZATION ROADMAP").font = Font(bold=True, size=11, color="1E3A5F")
        row += 1
        for phase, desc in rm.items():
            ws.cell(row, 2, phase.upper()).font = Font(bold=True, size=10, color="155724", name="Calibri")
            ws.cell(row, 2).fill = _fill("D4EDDA")
            ws.cell(row, 3, desc).font = Font(size=10, name="Calibri")
            row += 1
        row += 2

    # ─────────────────────────────────────────────────────────────
    # FAILURE DIAGNOSTICS SUMMARY — only rendered if logs were uploaded
    # ─────────────────────────────────────────────────────────────
    failure_logs = session.get("failure_logs", {}) or {}
    if failure_logs:
        ws.cell(row, 2, "FAILURE DIAGNOSTICS SUMMARY").font = Font(bold=True, size=12, color="FFFFFF")
        ws.cell(row, 2).fill = _fill("B91C1C")
        ws.cell(row, 3).fill = _fill("B91C1C")
        ws.merge_cells(f"B{row}:C{row}")
        ws.row_dimensions[row].height = 22
        row += 1

        c = ws.cell(row, 2, f"{len(failure_logs)} job(s) have confirmed production failures on file, based on uploaded Control-M / scheduler execution logs.")
        c.font = Font(size=10, italic=True, color="555555", name="Calibri")
        ws.merge_cells(f"B{row}:C{row}")
        row += 2

        jobs_by_id = {j.get("JobId", ""): j for j in session.get("jobs", [])}
        risk_mods_cache = session.get("risk_mods_cache", {})

        for jid, log in failure_logs.items():
            job_name = jobs_by_id.get(jid, {}).get("JobName", log.get("job_name", ""))
            rm_entry = risk_mods_cache.get(jid, {})

            ws.cell(row, 2, f"{jid} — {job_name}").font = Font(bold=True, size=10.5, color="991B1B", name="Calibri")
            ws.cell(row, 2).fill = _fill("FEF2F2")
            ws.cell(row, 3).fill = _fill("FEF2F2")
            ws.merge_cells(f"B{row}:C{row}")
            row += 1

            facts = []
            if log.get("root_cause"):
                facts.append(f"Root Cause: {log['root_cause']}")
            if log.get("error_code"):
                facts.append(f"Error Code: {log['error_code']}")
            if log.get("severity"):
                facts.append(f"Severity: {log['severity']}")
            if str(log.get("sla_status", "")).upper() == "BREACHED":
                facts.append("SLA Breached")
            if log.get("blocked_jobs"):
                facts.append(f"{len(log['blocked_jobs'])} downstream job(s) blocked")
            if rm_entry.get("risk_level"):
                facts.append(f"Migration Risk: {rm_entry['risk_level']}")

            if facts:
                c = ws.cell(row, 2, "  •  ".join(facts))
                c.font = Font(size=9.5, name="Calibri", color="475569")
                c.alignment = Alignment(wrap_text=True, vertical="top")
                ws.merge_cells(f"B{row}:C{row}")
                row += 1
            row += 1

def generate_redesigned_excel_report(session: dict, module: str = "everything") -> bytes:
    """
    Generate the redesigned Batch Assessment Report containing 5 or 6 sheets dynamically:
    1. Phase 1 Schedule Analysis (Schedule Analysis)
    2. High Level Assessment
    3. Detailed AI Analysis
    4. Risk & Modernization
    5. Job Conversion
    6. Executive Summary
    """
    if not OPENPYXL_OK:
        return b"Excel report requires openpyxl"

    # Get dynamic selected model name and timestamps
    session_id = session.get("session_id", "Unknown")
    model_id = session.get("selected_model", "gemini-2.5-flash")
    model_mapping = {
        "gemini-2.0-flash": "Gemini 2.0 Flash",
        "gemini-1.5-flash": "Gemini 1.5 Flash",
        "gemini-1.5-pro": "Gemini 1.5 Pro",
        "gemini-3.5-flash-mock": "Gemini 3.5 Flash",
        "gemini-3.1-lite-mock": "Gemini 3.1 Lite",
        "gemini-2.5-flash-mock": "Gemini 2.5 Flash",
        "claude-mock": "Claude",
        "gpt-mock": "GPT",
        "local-mock": "(Local Models)"
    }
    selected_model = model_mapping.get(model_id, model_id)
    assessment_date = datetime.now().strftime("%Y-%m-%d")
    generated_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    wb = openpyxl.Workbook()
    wb.remove(wb.active)  # remove default sheet

    jobs = session.get("jobs", [])
    analysis = session.get("phase1_analysis") or {}
    crit_map = analysis.get("criticality_map", {})
    graph = session.get("graph")
    crit_path_jobs = set(analysis.get("critical_path", []))

    # ════════════════════════════════════════════════════════════════
    # SHEET 1 — Phase 1 Schedule Analysis
    # ════════════════════════════════════════════════════════════════
    if module in ("everything", "schedule"):
        ws1 = wb.create_sheet("Schedule Analysis")
        hdr1 = [
            "Job ID", "Job Name", "Application", "Platform", "Criticality",
            "Criticality Score", "Criticality Reason", "Critical Path",
            "Fan In", "Fan Out", "Avg Runtime (Secs)", "Assessment Date", "Selected AI Model", "Generated Timestamp"
        ]
        w1 = [18, 25, 18, 12, 12, 10, 35, 12, 10, 10, 15, 15, 20, 20]
        ws1.sheet_view.showGridLines = True
        _write_top_banner(ws1, "BATCH MODERNIZATION SCHEDULE ANALYSIS REPORT", session_id, len(hdr1))
        _write_header(ws1, hdr1, w1, start_row=4)

        for r_idx, job in enumerate(jobs, start=5):
            jid = job.get("JobId", "")
            crit = crit_map.get(jid, {})
            fan_in = len(list(graph.predecessors(jid))) if graph and jid in graph else 0
            fan_out = len(list(graph.successors(jid))) if graph and jid in graph else 0
            on_crit_path = "Yes" if jid in crit_path_jobs else "No"
            
            row_vals = [
                jid,
                job.get("JobName", ""),
                job.get("AppName", "Unknown"),
                job.get("Platform", "Unknown"),
                crit.get("band", "Low"),
                crit.get("score", 0),
                crit.get("reason", "Standard Execution"),
                on_crit_path,
                fan_in,
                fan_out,
                job.get("Runtime", 0),
                assessment_date,
                selected_model,
                generated_time
            ]
            _write_row(ws1, r_idx, row_vals)
            _color_complexity_row(ws1, r_idx, len(hdr1), crit.get("band", "Low"))

    # ════════════════════════════════════════════════════════════════
    # SHEET 2 — High Level Assessment
    # ════════════════════════════════════════════════════════════════
    if module in ("everything", "highlevel"):
        ws2 = wb.create_sheet("High Level Assessment")
        hdr2 = [
            "Job ID", "Job Name", "Application", "Job Type", "File Operations",
            "DB Operations", "Utilities", "Output Produced", "Risk Indicator",
            "Modernization Recommendation", "Assessment Date", "Selected AI Model", "Generated Timestamp"
        ]
        w2 = [18, 25, 18, 12, 22, 22, 18, 22, 12, 25, 15, 20, 20]
        ws2.sheet_view.showGridLines = True
        _write_top_banner(ws2, "BATCH MODERNIZATION HIGH LEVEL ASSESSMENT REPORT", session_id, len(hdr2))
        _write_header(ws2, hdr2, w2, start_row=4)
        
        high_level_assessments = session.get("high_level_assessments", {})
        for r_idx, job in enumerate(jobs, start=5):
            jid = job.get("JobId", "")
            hl = high_level_assessments.get(jid, {})
            row_vals = [
                jid,
                job.get("JobName", ""),
                job.get("AppName", "Unknown"),
                hl.get("job_type", job.get("Platform", "Unknown")),
                hl.get("file_operations", "None"),
                hl.get("db_operations", "None"),
                hl.get("utilities", "None"),
                hl.get("output_produced", "None"),
                hl.get("risk_indicator", "LOW"),
                hl.get("modernization_recommendation", "Shell -> Python"),
                assessment_date,
                selected_model,
                generated_time
            ]
            _write_row(ws2, r_idx, row_vals)
            _color_risk_row(ws2, r_idx, len(hdr2), hl.get("risk_indicator", "LOW"))

    # ════════════════════════════════════════════════════════════════
    # SHEET 3 — Detailed AI Analysis
    # ════════════════════════════════════════════════════════════════
    if module in ("everything", "detailed"):
        ws3 = wb.create_sheet("Detailed AI Analysis")
        hdr3 = [
            "Job ID", "Job Name", "Application", "Tables", "Views", "Reference Tables", "Functions",
            "Stored Procedures", "Inner Joins", "Outer Joins", "Left Joins",
            "Right Joins", "File Operations", "DB Operations", "Utilities",
            "Error Handling", "Restart Logic", "Retry Logic", "Checkpoint Logic",
            "Failure Recovery", "Failure Log Status", "Failure Analysis", "Detailed Technical Assessment",
            "Retrieved Source Code Chunks (RAG)",
            "Assessment Date", "Selected AI Model", "Generated Timestamp"
        ]
        w3 = [18, 25, 18, 20, 18, 18, 18, 18, 20, 20, 20, 20, 22, 22, 18, 25, 25, 25, 25, 25, 16, 50, 50, 15, 20, 20, 20]
        ws3.sheet_view.showGridLines = True
        _write_top_banner(ws3, "BATCH MODERNIZATION DETAILED AI ANALYSIS REPORT", session_id, len(hdr3))
        _write_header(ws3, hdr3, w3, start_row=4)
        
        detailed_ai_cache = session.get("detailed_ai_cache", {})
        failure_logs_map = session.get("failure_logs", {})
        for r_idx, job in enumerate(jobs, start=5):
            jid = job.get("JobId", "")
            da = detailed_ai_cache.get(jid, {})
            joins = da.get("joins", {})
            
            inner_j = ", ".join(joins.get("inner", [])) if isinstance(joins, dict) else ""
            outer_j = ", ".join(joins.get("outer", [])) if isinstance(joins, dict) else ""
            left_j = ", ".join(joins.get("left", [])) if isinstance(joins, dict) else ""
            right_j = ", ".join(joins.get("right", [])) if isinstance(joins, dict) else ""
            
            retrieved_code = "\n\n".join(da.get("retrieved_chunks", []))
            has_log = jid in failure_logs_map
            failure_status = "Failure Log On File" if has_log else "No Failure Log"
            
            row_vals = [
                jid,
                job.get("JobName", ""),
                job.get("AppName", "Unknown"),
                ", ".join(da.get("tables", [])) if isinstance(da.get("tables"), list) else da.get("tables", ""),
                ", ".join(da.get("views", [])) if isinstance(da.get("views"), list) else da.get("views", ""),
                ", ".join(da.get("reference_tables", [])) if isinstance(da.get("reference_tables"), list) else da.get("reference_tables", ""),
                ", ".join(da.get("functions", [])) if isinstance(da.get("functions"), list) else da.get("functions", ""),
                ", ".join(da.get("stored_procedures", [])) if isinstance(da.get("stored_procedures"), list) else da.get("stored_procedures", ""),
                inner_j,
                outer_j,
                left_j,
                right_j,
                ", ".join(da.get("file_operations", [])) if isinstance(da.get("file_operations"), list) else da.get("file_operations", ""),
                ", ".join(da.get("db_operations", [])) if isinstance(da.get("db_operations"), list) else da.get("db_operations", ""),
                ", ".join(da.get("utilities", [])) if isinstance(da.get("utilities"), list) else da.get("utilities", ""),
                da.get("error_handling", "None"),
                da.get("restart_logic", "None"),
                da.get("retry_logic", "None"),
                da.get("checkpoint_logic", "None"),
                da.get("failure_recovery", "None"),
                failure_status,
                da.get("failure_analysis", "No failure log uploaded for this job."),
                da.get("detailed_technical_assessment", "Heuristic / Pending Detailed AI Analysis"),
                retrieved_code,
                assessment_date,
                selected_model,
                generated_time
            ]
            _write_row(ws3, r_idx, row_vals, wrap=True)
            if has_log:
                # Tint the Failure Log Status + Failure Analysis cells to flag real evidence
                status_col = hdr3.index("Failure Log Status") + 1
                analysis_col = hdr3.index("Failure Analysis") + 1
                for col in (status_col, analysis_col):
                    cell = ws3.cell(row=r_idx, column=col)
                    cell.fill = _fill("FEF2F2")

    # ════════════════════════════════════════════════════════════════
    # SHEET 4 — Risk & Modernization
    # ════════════════════════════════════════════════════════════════
    if module in ("everything", "riskmods"):
        ws4 = wb.create_sheet("Risk & Modernization")
        hdr4 = [
            "Job ID", "Job Name", "Application", "Risk Level", "Migration Complexity", "Modernization Priority",
            "Technical Debt Score", "Restartability Score", "Failure Log Evidence", "Migration Risk Factors", "Recommendations",
            "Detailed Reasoning", "Assessment Date", "Selected AI Model", "Generated Timestamp"
        ]
        w4 = [18, 25, 18, 12, 18, 18, 15, 15, 16, 35, 30, 40, 15, 20, 20]
        ws4.sheet_view.showGridLines = True
        _write_top_banner(ws4, "BATCH MODERNIZATION RISK & MODERNIZATION REPORT", session_id, len(hdr4))
        _write_header(ws4, hdr4, w4, start_row=4)
        
        risk_mods_cache = session.get("risk_mods_cache", {})
        for r_idx, job in enumerate(jobs, start=5):
            jid = job.get("JobId", "")
            rm = risk_mods_cache.get(jid, {})
            
            factors_str = ""
            factors = rm.get("risk_factors", []) or []
            if isinstance(factors, list):
                factors_str = "\n".join([f"{f.get('factor','')} ({f.get('severity','')}) - {f.get('description','')}" for f in factors])
            
            has_failure_log = bool(rm.get("has_failure_log"))
            failure_evidence = "Confirmed Production Failure" if has_failure_log else "None on file"
                
            row_vals = [
                jid,
                job.get("JobName", ""),
                job.get("AppName", "Unknown"),
                rm.get("risk_level", "LOW"),
                rm.get("migration_complexity", "LOW"),
                rm.get("modernization_priority", "LOW"),
                rm.get("technical_debt_score", 5),
                rm.get("restartability_score", 5),
                failure_evidence,
                factors_str,
                ", ".join(rm.get("recommendations", [])) if isinstance(rm.get("recommendations"), list) else rm.get("recommendations", ""),
                rm.get("detailed_reasoning", "Heuristic / Pending Risk & Modernization analysis"),
                assessment_date,
                selected_model,
                generated_time
            ]
            _write_row(ws4, r_idx, row_vals, wrap=True)
            _color_risk_row(ws4, r_idx, len(hdr4), rm.get("risk_level", "LOW"))
            if has_failure_log:
                evidence_col = hdr4.index("Failure Log Evidence") + 1
                ws4.cell(row=r_idx, column=evidence_col).fill = _fill("FEF2F2")

    # ════════════════════════════════════════════════════════════════
    # SHEET 5 — Job Conversion Summary
    # ════════════════════════════════════════════════════════════════
    if module in ("everything", "convert"):
        ws5 = wb.create_sheet("Job Conversion")
        hdr5 = [
            "Job ID", "Job Name", "Application", "Current Technology", "Target Technology", 
            "Original Source Code", "Converted Code", "Complexity", "Confidence Score", 
            "Reason for Recommendation", "Business Impact", "Potential Risks", 
            "Manual Changes Required", "Estimated Effort (Hours)", "Manual Review Needed?",
            "Migration Notes", "Dependencies", "Assessment Date", "Selected AI Model", "Generated Timestamp"
        ]
        w5 = [18, 25, 18, 18, 18, 45, 45, 12, 15, 25, 25, 25, 25, 15, 15, 30, 20, 15, 20, 20]
        ws5.sheet_view.showGridLines = True
        _write_top_banner(ws5, "BATCH MODERNIZATION JOB CONVERSION REPORT", session_id, len(hdr5))
        _write_header(ws5, hdr5, w5, start_row=4)
        
        conversions_cache = session.get("conversions_cache", {})
        for r_idx, job in enumerate(jobs, start=5):
            jid = job.get("JobId", "")
            conv = None
            for key, val in conversions_cache.items():
                if key == jid or key.startswith(jid + "_"):
                    conv = val
                    break
            if not conv:
                conv = {}
                
            orig_code = (session.get("source_code_files", {}).get(conv.get("source_file", "")) or "")
            if not orig_code:
                inventory = session.get("inventory", [])
                src_file = ""
                for j in inventory:
                    if j.get("Job_ID") == jid:
                        src_file = j.get("Source_File", "")
                        break
                if src_file:
                    src_file_clean = src_file.strip().lower()
                    for fname, content in session.get("source_code_files", {}).items():
                        fname_clean = fname.strip().lower()
                        if (fname_clean == src_file_clean or 
                            fname_clean.endswith("/" + src_file_clean) or 
                            fname_clean.endswith("\\" + src_file_clean) or
                            os.path.basename(fname_clean) == os.path.basename(src_file_clean)):
                            orig_code = content
                            break
                            
            row_vals = [
                jid,
                job.get("JobName", ""),
                job.get("AppName", "Unknown"),
                conv.get("current_technology", "Legacy"),
                conv.get("target_technology", "Python"),
                orig_code,
                conv.get("converted_code", "Pending conversion run"),
                conv.get("migration_complexity", "Low"),
                conv.get("confidence_score", "None"),
                conv.get("reason_for_recommendation", "None"),
                conv.get("business_impact", "None"),
                ", ".join(conv.get("potential_risks", [])) if isinstance(conv.get("potential_risks"), list) else str(conv.get("potential_risks", "")),
                ", ".join(conv.get("manual_changes_required", [])) if isinstance(conv.get("manual_changes_required"), list) else str(conv.get("manual_changes_required", "")),
                conv.get("estimated_effort_hours", 0),
                "Yes" if conv.get("manual_review_needed", False) else "No",
                conv.get("migration_notes", "Pending conversion run"),
                ", ".join(conv.get("dependencies", [])) if isinstance(conv.get("dependencies"), list) else str(conv.get("dependencies", "")),
                assessment_date,
                selected_model,
                generated_time
            ]
            _write_row(ws5, r_idx, row_vals, wrap=True)

    # ════════════════════════════════════════════════════════════════
    # SHEET 6 — Executive Summary
    # ════════════════════════════════════════════════════════════════
    if module in ("everything", "summary"):
        summary_data = session.get("executive_summary") or {}
        if not summary_data:
            from ai.assessment_engine import _heuristic_executive_summary
            high_risk_count = sum(1 for hl in session.get("high_level_assessments", {}).values() if hl.get("risk_indicator") == "HIGH")
            summary_data = _heuristic_executive_summary({
                "total_jobs": len(jobs),
                "high_risk_count": high_risk_count,
                "avg_tech_debt": 5.0
            })
        _sheet_executive_summary(wb, summary_data, session, selected_model, assessment_date, generated_time)

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf.read()


def generate_redesigned_pdf_report(session: dict, module: str = "everything") -> bytes:
    """Generate professional PDF Report based on Image 4 structure."""
    try:
        from reportlab.lib.pagesizes import letter, landscape
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, KeepTogether
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib import colors
        from reportlab.pdfgen import canvas
    except ImportError:
        return b"PDF report generation requires reportlab library"

    session_id = session.get("session_id", "UnknownSession")
    model_id = session.get("selected_model", "gemini-2.5-flash")
    assessment_date = datetime.now().strftime("%Y-%m-%d")
    generated_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    buf = io.BytesIO()

    # Determine page layout
    is_summary = (module == "summary")
    pagesize = letter if is_summary else landscape(letter)
    
    doc = SimpleDocTemplate(
        buf,
        pagesize=pagesize,
        leftMargin=36,
        rightMargin=36,
        topMargin=54,
        bottomMargin=54
    )

    # Numbered canvas for page numbers and headers/footers
    class NumberedCanvas(canvas.Canvas):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._saved_page_states = []

        def showPage(self):
            self._saved_page_states.append(dict(self.__dict__))
            self._startPage()

        def save(self):
            num_pages = len(self._saved_page_states)
            for state in self._saved_page_states:
                self.__dict__.update(state)
                self.draw_page_number(num_pages)
                super().showPage()
            super().save()

        def draw_page_number(self, page_count):
            self.saveState()
            self.setFont("Helvetica-Bold", 8)
            self.setFillColor(colors.HexColor("#1e3a5f"))
            
            # Header line
            self.drawString(36, self._pagesize[1] - 30, "BATCH ASSESSMENT TOOL | SYSTEM ASSESSMENT REPORT")
            self.setStrokeColor(colors.HexColor("#cbd5e1"))
            self.setLineWidth(0.5)
            self.line(36, self._pagesize[1] - 34, self._pagesize[0] - 36, self._pagesize[1] - 34)
            
            # Footer line
            page_text = f"Page {self._pageNumber} of {page_count}"
            self.setFont("Helvetica", 8)
            self.setFillColor(colors.HexColor("#64748b"))
            self.drawRightString(self._pagesize[0] - 36, 24, page_text)
            self.drawString(36, 24, "CONFIDENTIAL - TCS INTERNAL USE ONLY")
            self.line(36, 32, self._pagesize[0] - 36, 32)
            
            self.restoreState()

    styles = getSampleStyleSheet()
    
    # Custom styles
    title_style = ParagraphStyle(
        'DocTitle',
        parent=styles['Heading1'],
        fontName='Helvetica-Bold',
        fontSize=15,
        textColor=colors.HexColor('#1e3a5f'),
        spaceAfter=4
    )
    section_style = ParagraphStyle(
        'DocSection',
        parent=styles['Heading2'],
        fontName='Helvetica-Bold',
        fontSize=11,
        textColor=colors.HexColor('#1e3a5f'),
        spaceBefore=14,
        spaceAfter=6,
        keepWithNext=True
    )
    meta_style = ParagraphStyle(
        'DocMeta',
        parent=styles['Normal'],
        fontName='Helvetica-Oblique',
        fontSize=8.5,
        textColor=colors.HexColor('#475569'),
        spaceAfter=12
    )
    body_style = ParagraphStyle(
        'DocBody',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=8.5,
        textColor=colors.HexColor('#334155'),
        leading=11
    )
    cell_style = ParagraphStyle(
        'TableCell',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=7,
        textColor=colors.HexColor('#334155'),
        leading=9
    )
    cell_bold_style = ParagraphStyle(
        'TableCellBold',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=7,
        textColor=colors.HexColor('#1e293b'),
        leading=9
    )
    cell_hdr_style = ParagraphStyle(
        'TableHdr',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=7.5,
        textColor=colors.white,
        leading=9,
        alignment=1 # Centered
    )

    code_block_style = ParagraphStyle(
        'CodeBlock',
        parent=styles['Normal'],
        fontName='Courier',
        fontSize=6.5,
        textColor=colors.HexColor('#0f172a'),
        leading=8,
        spaceBefore=1,
        spaceAfter=1
    )
    label_style = ParagraphStyle(
        'LabelStyle',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=8,
        textColor=colors.HexColor('#1e3a5f'),
        leading=10
    )
    val_style = ParagraphStyle(
        'ValStyle',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=8,
        textColor=colors.HexColor('#334155'),
        leading=10
    )

    story = []

    def _add_pdf_detailed_ai_profiles():
        dac = session.get("detailed_ai_cache", {})
        for job in jobs:
            jid = job.get("JobId", "")
            jname = job.get("JobName", "")
            da = dac.get(jid, {})
            
            story.append(PageBreak())
            story.append(Paragraph(f"DETAILED AI ASSESSMENT: {jid} - {jname}", title_style))
            story.append(Paragraph(f"Model: {model_id} | Date: {assessment_date}", meta_style))
            
            # Technical Narrative
            narrative = da.get("detailed_technical_assessment", "Pending detailed analysis.")
            story.append(Paragraph("Technical Assessment Narrative", section_style))
            story.append(Paragraph(narrative, body_style))
            story.append(Spacer(1, 6))
            
            # 1. Database Objects Used
            story.append(Paragraph("Database Objects Used", section_style))
            tables = da.get("tables", []) or []
            views = da.get("views", []) or []
            ref_tables = da.get("reference_tables", []) or []
            funcs = da.get("functions", []) or []
            procs = da.get("stored_procedures", []) or []
            
            left_objs = [
                Paragraph("<b>TABLES:</b>", label_style),
                Paragraph(", ".join(tables) or "—", val_style),
                Spacer(1, 4),
                Paragraph("<b>VIEWS:</b>", label_style),
                Paragraph(", ".join(views) or "—", val_style),
                Spacer(1, 4),
                Paragraph("<b>REFERENCE TABLES:</b>", label_style),
                Paragraph(", ".join(ref_tables) or "—", val_style),
            ]
            
            right_objs = [
                Paragraph("<b>FUNCTIONS:</b>", label_style),
                Paragraph(", ".join(funcs) or "—", val_style),
                Spacer(1, 4),
                Paragraph("<b>STORED PROCEDURES:</b>", label_style),
                Paragraph(", ".join(procs) or "—", val_style),
            ]
            
            obj_table = Table([[left_objs, right_objs]], colWidths=[pagesize[0]/2.0 - 45, pagesize[0]/2.0 - 45])
            obj_table.setStyle(TableStyle([
                ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                ('LINEAFTER', (0, 0), (0, -1), 0.5, colors.HexColor('#cbd5e1')),
                ('PADDING', (0, 0), (-1, -1), 4),
            ]))
            story.append(obj_table)
            story.append(Spacer(1, 6))
            
            # 2. SQL Joins Overview
            story.append(Paragraph("SQL Joins Overview", section_style))
            joins = da.get("joins", {}) or {}
            inner_j = joins.get("inner", []) or []
            outer_j = joins.get("outer", []) or []
            left_j = joins.get("left", []) or []
            right_j = joins.get("right", []) or []
            
            join_data = [
                [
                    Paragraph(f"<b>INNER:</b> {len(inner_j)} (" + (", ".join(inner_j) or "None") + ")", val_style),
                    Paragraph(f"<b>LEFT:</b> {len(left_j)} (" + (", ".join(left_j) or "None") + ")", val_style),
                    Paragraph(f"<b>RIGHT:</b> {len(right_j)} (" + (", ".join(right_j) or "None") + ")", val_style),
                    Paragraph(f"<b>OUTER:</b> {len(outer_j)} (" + (", ".join(outer_j) or "None") + ")", val_style),
                ]
            ]
            join_table = Table(join_data, colWidths=[pagesize[0]/4.0 - 22]*4)
            join_table.setStyle(TableStyle([
                ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                ('PADDING', (0, 0), (-1, -1), 4),
                ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#cbd5e1')),
            ]))
            story.append(join_table)
            story.append(Spacer(1, 6))
            
            # 3. System & Operation Semantics
            story.append(Paragraph("System & Operation Semantics", section_style))
            file_ops = da.get("file_operations", []) or []
            db_ops = da.get("db_operations", []) or []
            utils_called = da.get("utilities", []) or []
            
            if isinstance(file_ops, list): file_ops_str = ", ".join(file_ops) or "None"
            else: file_ops_str = str(file_ops)
                
            if isinstance(db_ops, list): db_ops_str = ", ".join(db_ops) or "None"
            else: db_ops_str = str(db_ops)
                
            if isinstance(utils_called, list): utils_str = ", ".join(utils_called) or "None"
            else: utils_str = str(utils_called)
                
            sem_flow = [
                Paragraph(f"<b>FILE OPERATIONS:</b> {file_ops_str}", val_style),
                Spacer(1, 4),
                Paragraph(f"<b>DATABASE OPERATIONS:</b> {db_ops_str}", val_style),
                Spacer(1, 4),
                Paragraph(f"<b>UTILITIES / BINARIES CALLED:</b> {utils_str}", val_style),
            ]
            sem_table = Table([[sem_flow]], colWidths=[pagesize[0] - 80])
            sem_table.setStyle(TableStyle([
                ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                ('PADDING', (0, 0), (-1, -1), 4),
                ('BOX', (0, 0), (-1, -1), 0.5, colors.HexColor('#cbd5e1')),
                ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#f8fafc')),
            ]))
            story.append(sem_table)
            story.append(Spacer(1, 6))
            
            # 4. Error Handling & Resiliency
            story.append(Paragraph("Error Handling & Resiliency", section_style))
            res_left = [
                Paragraph("<b>ERROR HANDLING:</b>", label_style),
                Paragraph(da.get("error_handling", "None"), val_style),
                Spacer(1, 4),
                Paragraph("<b>RESTART LOGIC:</b>", label_style),
                Paragraph(da.get("restart_logic", "None"), val_style),
                Spacer(1, 4),
                Paragraph("<b>RETRY LOGIC:</b>", label_style),
                Paragraph(da.get("retry_logic", "None"), val_style),
            ]
            res_right = [
                Paragraph("<b>CHECKPOINT LOGIC:</b>", label_style),
                Paragraph(da.get("checkpoint_logic", "None"), val_style),
                Spacer(1, 4),
                Paragraph("<b>FAILURE RECOVERY:</b>", label_style),
                Paragraph(da.get("failure_recovery", "None"), val_style),
            ]
            res_table = Table([[res_left, res_right]], colWidths=[pagesize[0]/2.0 - 45, pagesize[0]/2.0 - 45])
            res_table.setStyle(TableStyle([
                ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                ('LINEAFTER', (0, 0), (0, -1), 0.5, colors.HexColor('#cbd5e1')),
                ('PADDING', (0, 0), (-1, -1), 4),
            ]))
            story.append(res_table)
            story.append(Spacer(1, 8))

            # 4b. Failure Analysis — evidence-based when a failure log was uploaded for this job
            failure_text = da.get("failure_analysis", "")
            has_log = bool(failure_text) and not failure_text.startswith("No failure log")
            story.append(Paragraph("Failure Analysis", section_style))
            if has_log:
                fa_flow = [
                    Paragraph('<font color="#b91c1c"><b>⚠ EVIDENCE-BASED — FROM UPLOADED FAILURE LOG</b></font>', label_style),
                    Spacer(1, 4),
                    Paragraph(failure_text, val_style),
                ]
                fa_table = Table([[fa_flow]], colWidths=[pagesize[0] - 80])
                fa_table.setStyle(TableStyle([
                    ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                    ('PADDING', (0, 0), (-1, -1), 6),
                    ('BOX', (0, 0), (-1, -1), 0.5, colors.HexColor('#fecaca')),
                    ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#fef2f2')),
                ]))
            else:
                fa_flow = [Paragraph(
                    failure_text or "No failure log uploaded for this job. Upload a Control-M execution log (.log or .txt) in the Setup tab to enable evidence-based failure analysis.",
                    val_style
                )]
                fa_table = Table([[fa_flow]], colWidths=[pagesize[0] - 80])
                fa_table.setStyle(TableStyle([
                    ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                    ('PADDING', (0, 0), (-1, -1), 6),
                    ('BOX', (0, 0), (-1, -1), 0.5, colors.HexColor('#e2e8f0')),
                    ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#f8fafc')),
                ]))
            story.append(fa_table)
            story.append(Spacer(1, 8))
            
            chunks = da.get("retrieved_chunks", []) or []
            if chunks:
                story.append(Paragraph("Retrieved Source Code Chunks (RAG)", section_style))
                for c_idx, chunk in enumerate(chunks, start=1):
                    chunk_esc = chunk.replace("<", "&lt;").replace(">", "&gt;").replace("\r", "")
                    if len(chunk_esc) > 600:
                        chunk_esc = chunk_esc[:600] + "\n\n... [TRUNCATED IN REPORT]"
                    chunk_flow = [Paragraph(f"FAISS Chunk #{c_idx}", label_style), Spacer(1, 2)]
                    for line in chunk_esc.split("\n"):
                        l_esc = line.replace(" ", "&nbsp;")
                        chunk_flow.append(Paragraph(l_esc, code_block_style))
                        
                    ct = Table([[chunk_flow]], colWidths=[pagesize[0] - 80])
                    ct.setStyle(TableStyle([
                        ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#f8fafc')),
                        ('BOX', (0, 0), (-1, -1), 0.5, colors.HexColor('#cbd5e1')),
                        ('PADDING', (0, 0), (-1, -1), 6),
                    ]))
                    story.append(ct)
                    story.append(Spacer(1, 6))

    def _add_pdf_risk_profiles():
        rmc = session.get("risk_mods_cache", {})
        for job in jobs:
            jid = job.get("JobId", "")
            jname = job.get("JobName", "")
            rm = rmc.get(jid, {})
            
            story.append(PageBreak())
            story.append(Paragraph(f"RISK & MODERNIZATION PROFILE: {jid} - {jname}", title_style))
            story.append(Paragraph(f"Model: {model_id} | Date: {assessment_date}", meta_style))

            if rm.get("has_failure_log"):
                banner = Table([[Paragraph(
                    '<font color="#991b1b"><b>⚠ CONFIRMED PRODUCTION FAILURE ON FILE</b></font> — '
                    'risk score elevated using real failure log evidence. See Detailed AI Analysis for the full root-cause narrative.',
                    val_style
                )]], colWidths=[pagesize[0] - 80])
                banner.setStyle(TableStyle([
                    ('PADDING', (0, 0), (-1, -1), 6),
                    ('BOX', (0, 0), (-1, -1), 0.5, colors.HexColor('#fecaca')),
                    ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#fef2f2')),
                ]))
                story.append(banner)
                story.append(Spacer(1, 8))

            risk_flow = [
                Paragraph(f"<b>Risk Level:</b> {rm.get('risk_level', 'LOW')}", val_style),
                Paragraph(f"<b>Migration Complexity:</b> {rm.get('migration_complexity', 'LOW')}", val_style),
                Paragraph(f"<b>Modernization Priority:</b> {rm.get('modernization_priority', 'LOW')}", val_style),
                Paragraph(f"<b>Technical Debt Score:</b> {rm.get('technical_debt_score', 5)} / 10", val_style),
                Paragraph(f"<b>Restartability Score:</b> {rm.get('restartability_score', 5)} / 10", val_style),
                Paragraph(f"<b>Target Technology:</b> {rm.get('target_technology', 'Python')}", val_style),
                Paragraph(f"<b>Target Scheduler:</b> {rm.get('target_scheduler', 'Apache Airflow')}", val_style),
            ]
            
            reasoning = rm.get("detailed_reasoning", "Pending strategy analysis.")
            reasoning_flow = [
                Paragraph("<b>Modernization Strategy Reasoning</b>", label_style),
                Spacer(1, 4),
                Paragraph(reasoning, body_style)
            ]
            
            t_data = [[risk_flow, reasoning_flow]]
            col_w = [pagesize[0]/2.0 - 45, pagesize[0]/2.0 - 45]
            t = Table(t_data, colWidths=col_w)
            t.setStyle(TableStyle([
                ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                ('LINEAFTER', (0, 0), (0, -1), 0.5, colors.HexColor('#e2e8f0')),
                ('PADDING', (0, 0), (-1, -1), 6),
            ]))
            story.append(t)
            story.append(Spacer(1, 10))
            
            factors = rm.get("risk_factors", []) or []
            if factors:
                story.append(Paragraph("Migration Risk Factors", section_style))
                fact_rows = []
                fact_rows.append([
                    Paragraph("<b>Severity</b>", label_style),
                    Paragraph("<b>Risk Factor</b>", label_style),
                    Paragraph("<b>Description</b>", label_style)
                ])
                for f in factors:
                    severity = f.get("severity", "LOW")
                    factor = f.get("factor", "None")
                    desc = f.get("description", "None")
                    fact_rows.append([
                        Paragraph(severity, val_style),
                        Paragraph(factor, val_style),
                        Paragraph(desc, val_style)
                    ])
                ft = Table(fact_rows, colWidths=[60, 150, pagesize[0] - 290])
                row_styles = [
                    ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                    ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#cbd5e1')),
                    ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#f8fafc')),
                    ('PADDING', (0, 0), (-1, -1), 6),
                ]
                for fr_idx, f in enumerate(factors, start=1):
                    factor_name = (f.get("factor") or "").lower()
                    if "failure log" in factor_name or "production failure" in factor_name:
                        row_styles.append(('BACKGROUND', (0, fr_idx), (-1, fr_idx), colors.HexColor('#fef2f2')))
                ft.setStyle(TableStyle(row_styles))
                story.append(ft)
                story.append(Spacer(1, 10))
                
            recs = rm.get("recommendations", []) or []
            if recs:
                story.append(Paragraph("Strategic Recommendations", section_style))
                for idx, r in enumerate(recs, start=1):
                    story.append(Paragraph(f"{idx}. {r}", val_style))

    def _add_pdf_conversion_profiles():
        cc = session.get("conversions_cache", {})
        for job in jobs:
            jid = job.get("JobId", "")
            jname = job.get("JobName", "")
            
            conv = None
            for key, val in cc.items():
                if key == jid or key.startswith(jid + "_"):
                    conv = val
                    break
            if not conv:
                conv = {}
                
            story.append(PageBreak())
            story.append(Paragraph(f"JOB CONVERSION DETAIL: {jid} - {jname}", title_style))
            story.append(Paragraph(f"Model: {model_id} | Date: {assessment_date}", meta_style))
            
            conv_meta_flow = [
                Paragraph(f"<b>Current Tech:</b> {conv.get('current_technology', 'Legacy')}", val_style),
                Paragraph(f"<b>Target Tech:</b> {conv.get('target_technology', 'Python')}", val_style),
                Paragraph(f"<b>Complexity:</b> {conv.get('migration_complexity', 'Low')}", val_style),
                Paragraph(f"<b>Estimated Effort:</b> {conv.get('estimated_effort_hours', 0)} Hours", val_style),
                Paragraph(f"<b>Confidence Score:</b> {conv.get('confidence_score', 'None')}", val_style),
                Paragraph(f"<b>Manual Review Needed:</b> {'Yes' if conv.get('manual_review_needed', False) else 'No'}", val_style),
            ]
            
            reasoning_flow = [
                Paragraph("<b>Reason for Recommendation</b>", label_style),
                Paragraph(conv.get("reason_for_recommendation", "None"), body_style),
                Spacer(1, 4),
                Paragraph("<b>Business Impact & Benefits</b>", label_style),
                Paragraph(conv.get("business_impact", "None"), body_style),
            ]
            
            t_data = [[conv_meta_flow, reasoning_flow]]
            col_w = [pagesize[0]/2.0 - 45, pagesize[0]/2.0 - 45]
            t = Table(t_data, colWidths=col_w)
            t.setStyle(TableStyle([
                ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                ('LINEAFTER', (0, 0), (0, -1), 0.5, colors.HexColor('#e2e8f0')),
                ('PADDING', (0, 0), (-1, -1), 6),
            ]))
            story.append(t)
            story.append(Spacer(1, 10))
            
            orig_esc = (session.get("source_code_files", {}).get(conv.get("source_file", "")) or "")
            if not orig_esc:
                inventory = session.get("inventory", [])
                src_file = ""
                for j in inventory:
                    if j.get("Job_ID") == jid:
                        src_file = j.get("Source_File", "")
                        break
                if src_file:
                    src_file_clean = src_file.strip().lower()
                    for fname, content in session.get("source_code_files", {}).items():
                        fname_clean = fname.strip().lower()
                        if (fname_clean == src_file_clean or 
                            fname_clean.endswith("/" + src_file_clean) or 
                            fname_clean.endswith("\\" + src_file_clean) or
                            os.path.basename(fname_clean) == os.path.basename(src_file_clean)):
                            orig_esc = content
                            break
                            
            orig_esc = orig_esc.replace("<", "&lt;").replace(">", "&gt;").replace("\r", "")
            if len(orig_esc) > 1200:
                orig_esc = orig_esc[:1200] + "\n\n... [TRUNCATED IN REPORT]"
                
            mod_esc = (conv.get("converted_code", "") or "").replace("<", "&lt;").replace(">", "&gt;").replace("\r", "")
            if len(mod_esc) > 1200:
                mod_esc = mod_esc[:1200] + "\n\n... [TRUNCATED IN REPORT]"
                
            orig_lines = [Paragraph("<b>ORIGINAL SOURCE CODE</b>", label_style), Spacer(1, 4)]
            for line in orig_esc.split("\n"):
                orig_lines.append(Paragraph(line.replace(" ", "&nbsp;"), code_block_style))
                
            mod_lines = [Paragraph("<b>MODERNIZED TARGET CODE</b>", label_style), Spacer(1, 4)]
            for line in mod_esc.split("\n"):
                mod_lines.append(Paragraph(line.replace(" ", "&nbsp;"), code_block_style))
                
            ct_data = [[orig_lines, mod_lines]]
            ct = Table(ct_data, colWidths=[pagesize[0]/2.0 - 45, pagesize[0]/2.0 - 45])
            ct.setStyle(TableStyle([
                ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#f8fafc')),
                ('BOX', (0, 0), (-1, -1), 0.5, colors.HexColor('#cbd5e1')),
                ('LINEAFTER', (0, 0), (0, -1), 0.5, colors.HexColor('#cbd5e1')),
                ('PADDING', (0, 0), (-1, -1), 6),
            ]))
            story.append(ct)
            story.append(Spacer(1, 10))
            
            extra_data = [
                [Paragraph("<b>Dependencies:</b> " + (", ".join(conv.get("dependencies", [])) if isinstance(conv.get("dependencies"), list) else str(conv.get("dependencies", ""))), val_style)],
                [Paragraph("<b>Potential Risks:</b> " + (", ".join(conv.get("potential_risks", [])) if isinstance(conv.get("potential_risks"), list) else str(conv.get("potential_risks", ""))), val_style)],
                [Paragraph("<b>Manual Changes Required:</b> " + (", ".join(conv.get("manual_changes_required", [])) if isinstance(conv.get("manual_changes_required"), list) else str(conv.get("manual_changes_required", ""))), val_style)],
                [Paragraph("<b>Migration Notes:</b> " + conv.get("migration_notes", ""), val_style)],
            ]
            et = Table(extra_data, colWidths=[pagesize[0] - 80])
            et.setStyle(TableStyle([
                ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                ('LINEBELOW', (0, 0), (-1, -2), 0.5, colors.HexColor('#f1f5f9')),
                ('PADDING', (0, 0), (-1, -1), 4),
            ]))
            story.append(et)

    story = []

    # 1. Executive Summary page flow
    def add_exec_summary():
        story.append(Paragraph("EXECUTIVE ASSESSMENT SUMMARY", title_style))
        story.append(Paragraph(f"Run Code: {session_id[:8].upper()} | Model: {model_id} | Date: {assessment_date}", meta_style))
        
        summary_data = session.get("executive_summary") or {}
        if not summary_data:
            from ai.assessment_engine import _heuristic_executive_summary
            high_risk_count = sum(1 for hl in session.get("high_level_assessments", {}).values() if hl.get("risk_indicator") == "HIGH")
            summary_data = _heuristic_executive_summary({
                "total_jobs": len(session.get("jobs", [])),
                "high_risk_count": high_risk_count,
                "avg_tech_debt": 5.0
            })

        # Headline
        if summary_data.get("headline"):
            story.append(Spacer(1, 8))
            h_table = Table([[Paragraph(f"<b>Key Headline:</b> {summary_data['headline']}", body_style)]], colWidths=[doc.width])
            h_table.setStyle(TableStyle([
                ('BACKGROUND', (0,0), (-1,-1), colors.HexColor('#eff6ff')),
                ('BOX', (0,0), (-1,-1), 1, colors.HexColor('#bfdbfe')),
                ('PADDING', (0,0), (-1,-1), 8),
            ]))
            story.append(h_table)
            story.append(Spacer(1, 12))

        # Narrative
        if summary_data.get("executive_summary"):
            story.append(Paragraph("1. Executive Analysis Narrative", section_style))
            story.append(Paragraph(summary_data["executive_summary"], body_style))
            story.append(Spacer(1, 12))

        # Strategic Findings
        if summary_data.get("key_findings"):
            story.append(Paragraph("2. Key Strategic Findings", section_style))
            for f in summary_data["key_findings"]:
                story.append(Paragraph(f"• {f}", body_style))
                story.append(Spacer(1, 4))
            story.append(Spacer(1, 10))

        # Recommendations
        if summary_data.get("strategic_recommendations"):
            story.append(Paragraph("3. Strategic Action Recommendations", section_style))
            rec_data = [[
                Paragraph("<b>Priority</b>", cell_hdr_style),
                Paragraph("<b>Recommendation</b>", cell_hdr_style),
                Paragraph("<b>Business Value</b>", cell_hdr_style),
                Paragraph("<b>Timeline</b>", cell_hdr_style)
            ]]
            for rec in summary_data["strategic_recommendations"]:
                rec_data.append([
                    Paragraph(f"P{rec.get('priority', '1')}", cell_bold_style),
                    Paragraph(rec.get('recommendation', ''), cell_style),
                    Paragraph(rec.get('business_value', ''), cell_style),
                    Paragraph(rec.get('timeline', ''), cell_style)
                ])
            # Draw Table
            t_col_widths = [50, doc.width - 290, 120, 120] if not is_summary else [40, doc.width - 240, 100, 100]
            t = Table(rec_data, colWidths=t_col_widths)
            t.setStyle(TableStyle([
                ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#1e3a5f')),
                ('VALIGN', (0,0), (-1,-1), 'TOP'),
                ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#cbd5e1')),
                ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.white, colors.HexColor('#f8fafc')]),
                ('PADDING', (0,0), (-1,-1), 5),
            ]))
            story.append(t)
            story.append(Spacer(1, 12))

        # Roadmap
        if summary_data.get("modernization_roadmap"):
            story.append(Paragraph("4. Target Modernization Roadmap", section_style))
            for phase, desc in summary_data["modernization_roadmap"].items():
                story.append(Paragraph(f"<b>{phase.upper()}</b>: {desc}", body_style))
                story.append(Spacer(1, 4))
            story.append(Spacer(1, 10))

        # Failure Diagnostics Summary — only rendered if logs were uploaded
        failure_logs = session.get("failure_logs", {}) or {}
        if failure_logs:
            story.append(Paragraph("5. Failure Diagnostics Summary", section_style))
            intro = Table([[Paragraph(
                f"<b>{len(failure_logs)} job(s)</b> have confirmed production failures on file, based on uploaded "
                "Control-M / scheduler execution logs. These are summarized below; full root-cause narratives are "
                "available in the Detailed AI Analysis section for each job.",
                body_style
            )]], colWidths=[doc.width])
            intro.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#fef2f2')),
                ('BOX', (0, 0), (-1, -1), 1, colors.HexColor('#fecaca')),
                ('PADDING', (0, 0), (-1, -1), 8),
            ]))
            story.append(intro)
            story.append(Spacer(1, 10))

            jobs_by_id = {j.get("JobId", ""): j for j in session.get("jobs", [])}
            risk_mods_cache = session.get("risk_mods_cache", {})

            fd_rows = []
            fd_rows.append([
                Paragraph("<b>Job</b>", cell_hdr_style),
                Paragraph("<b>Root Cause</b>", cell_hdr_style),
                Paragraph("<b>Severity</b>", cell_hdr_style),
                Paragraph("<b>Blocked Jobs</b>", cell_hdr_style),
                Paragraph("<b>Migration Risk</b>", cell_hdr_style),
            ])
            for jid, log in failure_logs.items():
                job_name = jobs_by_id.get(jid, {}).get("JobName", log.get("job_name", ""))
                rm_entry = risk_mods_cache.get(jid, {})
                blocked_count = len(log.get("blocked_jobs", []) or [])
                fd_rows.append([
                    Paragraph(f"{jid}<br/>{job_name}", cell_style),
                    Paragraph(log.get("root_cause") or log.get("error_code") or "Not specified in log", cell_style),
                    Paragraph(log.get("severity", "—"), cell_bold_style),
                    Paragraph(str(blocked_count) if blocked_count else "0", cell_style),
                    Paragraph(rm_entry.get("risk_level", "—"), cell_bold_style),
                ])
            fd_col_widths = [90, doc.width - 90 - 70 - 90 - 90, 70, 90, 90]
            fd_table = Table(fd_rows, colWidths=fd_col_widths)
            fd_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#991b1b')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
                ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#cbd5e1')),
                ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#fef2f2')]),
                ('PADDING', (0, 0), (-1, -1), 5),
            ]))
            story.append(fd_table)

    # Helper to append table to story
    def add_table_section(title, headers, rows, col_widths, risk_col_idx=None):
        story.append(Paragraph(title, title_style))
        story.append(Paragraph(f"Run Code: {session_id[:8].upper()} | Model: {model_id} | Date: {assessment_date}", meta_style))
        
        # Build flowable grid data
        grid_data = []
        # Header row
        grid_data.append([Paragraph(h, cell_hdr_style) for h in headers])
        
        # Data rows
        for r in rows:
            grid_data.append([Paragraph(str(cell), cell_style) for cell in r])
            
        t = Table(grid_data, colWidths=col_widths)
        t_style = [
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1e3a5f')),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#cbd5e1')),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f8fafc')]),
            ('PADDING', (0, 0), (-1, -1), 4),
        ]
        
        # Highlight risk values
        if risk_col_idx is not None:
            for r_idx, r in enumerate(rows, start=1):
                risk_val = str(r[risk_col_idx]).upper()
                if "HIGH" in risk_val or "CRITICAL" in risk_val:
                    t_style.append(('BACKGROUND', (risk_col_idx, r_idx), (risk_col_idx, r_idx), colors.HexColor('#fecaca')))
                    t_style.append(('TEXTCOLOR', (risk_col_idx, r_idx), (risk_col_idx, r_idx), colors.HexColor('#b91c1c')))
                elif "MEDIUM" in risk_val:
                    t_style.append(('BACKGROUND', (risk_col_idx, r_idx), (risk_col_idx, r_idx), colors.HexColor('#fef3c7')))
                    t_style.append(('TEXTCOLOR', (risk_col_idx, r_idx), (risk_col_idx, r_idx), colors.HexColor('#d97706')))
                elif "LOW" in risk_val:
                    t_style.append(('BACKGROUND', (risk_col_idx, r_idx), (risk_col_idx, r_idx), colors.HexColor('#d1fae5')))
                    t_style.append(('TEXTCOLOR', (risk_col_idx, r_idx), (risk_col_idx, r_idx), colors.HexColor('#065f46')))

        t.setStyle(TableStyle(t_style))
        story.append(t)

    jobs = session.get("jobs", [])
    analysis = session.get("phase1_analysis") or {}
    crit_map = analysis.get("criticality_map", {})
    graph = session.get("graph")
    crit_path_jobs = set(analysis.get("critical_path", []))

    # Add sections based on module selection
    if module == "summary":
        add_exec_summary()
    elif module == "schedule":
        hdrs = ["Job ID", "Job Name", "Application", "Platform", "Criticality", "Score", "Critical Path", "Fan In", "Fan Out", "Runtime"]
        widths = [75, 120, 80, 50, 60, 40, 65, 45, 45, 140]
        rows = []
        for job in jobs:
            jid = job.get("JobId", "")
            crit = crit_map.get(jid, {})
            fan_in = len(list(graph.predecessors(jid))) if graph and jid in graph else 0
            fan_out = len(list(graph.successors(jid))) if graph and jid in graph else 0
            on_crit = "Yes" if jid in crit_path_jobs else "No"
            rows.append([
                jid, job.get("JobName", ""), job.get("AppName", "Unknown"), job.get("Platform", "Unknown"),
                crit.get("band", "Low"), str(crit.get("score", 0)), on_crit, str(fan_in), str(fan_out), f"{job.get('Runtime', 0)}s"
            ])
        add_table_section("SCHEDULE CRITICALITY REPORT", hdrs, rows, widths, risk_col_idx=4)
    elif module == "highlevel":
        hdrs = ["Job ID", "Job Name", "Application", "Job Type", "File Operations", "DB Operations", "Utilities", "Risk", "Modernization Recommendation"]
        widths = [70, 110, 80, 55, 75, 75, 55, 45, 155]
        rows = []
        hla = session.get("high_level_assessments", {})
        for job in jobs:
            jid = job.get("JobId", "")
            hl = hla.get(jid, {})
            rows.append([
                jid, job.get("JobName", ""), job.get("AppName", "Unknown"), hl.get("job_type", "Unknown"),
                hl.get("file_operations", "None"), hl.get("db_operations", "None"), hl.get("utilities", "None"),
                hl.get("risk_indicator", "LOW"), hl.get("modernization_recommendation", "Shell -> Python")
            ])
        add_table_section("HIGH LEVEL ASSESSMENT REPORT", hdrs, rows, widths, risk_col_idx=7)
    elif module == "detailed":
        hdrs = ["Job ID", "Job Name", "Application", "Tables/Views Used", "Error Handling", "Restart Logic", "Detailed Technical Assessment"]
        widths = [70, 100, 80, 110, 80, 80, 200]
        rows = []
        dac = session.get("detailed_ai_cache", {})
        for job in jobs:
            jid = job.get("JobId", "")
            da = dac.get(jid, {})
            tables = da.get("tables", []) or []
            views = da.get("views", []) or []
            tab_views = ", ".join(tables + views) or "None"
            rows.append([
                jid, job.get("JobName", ""), job.get("AppName", "Unknown"), tab_views,
                da.get("error_handling", "None"), da.get("restart_logic", "None"),
                da.get("detailed_technical_assessment", "Pending detailed assessment")
            ])
        add_table_section("DETAILED AI ANALYSIS REPORT", hdrs, rows, widths)
        _add_pdf_detailed_ai_profiles()
    elif module == "riskmods":
        hdrs = ["Job ID", "Job Name", "Risk Level", "Complexity", "Priority", "Debt", "Restart", "Recommendations"]
        widths = [70, 120, 55, 70, 55, 45, 45, 260]
        rows = []
        rmc = session.get("risk_mods_cache", {})
        for job in jobs:
            jid = job.get("JobId", "")
            rm = rmc.get(jid, {})
            recs = rm.get("recommendations", []) or []
            rows.append([
                jid, job.get("JobName", ""), rm.get("risk_level", "LOW"), rm.get("migration_complexity", "LOW"),
                rm.get("modernization_priority", "LOW"), str(rm.get("technical_debt_score", 5)),
                str(rm.get("restartability_score", 5)), ", ".join(recs) if isinstance(recs, list) else str(recs)
            ])
        add_table_section("RISK & MODERNIZATION REPORT", hdrs, rows, widths, risk_col_idx=2)
        _add_pdf_risk_profiles()
    elif module == "convert":
        hdrs = ["Job ID", "Job Name", "Target Tech", "Complexity", "Manual Review?", "Migration Notes", "Dependencies"]
        widths = [75, 110, 75, 60, 60, 240, 100]
        rows = []
        cc = session.get("conversions_cache", {})
        for job in jobs:
            jid = job.get("JobId", "")
            conv = cc.get(jid, {})
            rows.append([
                jid, job.get("JobName", ""), conv.get("target_technology", "Python"), conv.get("complexity", "Low"),
                "Yes" if conv.get("manual_intervention_required", False) else "No",
                conv.get("migration_notes", "Pending conversion run"),
                ", ".join(conv.get("dependencies", [])) if isinstance(conv.get("dependencies"), list) else str(conv.get("dependencies", ""))
            ])
        add_table_section("JOB CONVERSION REPORT", hdrs, rows, widths)
        _add_pdf_conversion_profiles()
    else: # consolidated everything!
        add_exec_summary()
        story.append(PageBreak())
        
        # High Level Assessment table
        hdrs = ["Job ID", "Job Name", "Application", "Job Type", "File Operations", "DB Operations", "Utilities", "Risk", "Modernization Recommendation"]
        widths = [70, 110, 80, 55, 75, 75, 55, 45, 155]
        rows = []
        hla = session.get("high_level_assessments", {})
        for job in jobs:
            jid = job.get("JobId", "")
            hl = hla.get(jid, {})
            rows.append([
                jid, job.get("JobName", ""), job.get("AppName", "Unknown"), hl.get("job_type", "Unknown"),
                hl.get("file_operations", "None"), hl.get("db_operations", "None"), hl.get("utilities", "None"),
                hl.get("risk_indicator", "LOW"), hl.get("modernization_recommendation", "Shell -> Python")
            ])
        add_table_section("HIGH LEVEL ASSESSMENT REPORT", hdrs, rows, widths, risk_col_idx=7)
        story.append(PageBreak())

        # Detailed AI Analysis table
        hdrs = ["Job ID", "Job Name", "Application", "Tables/Views Used", "Error Handling", "Restart Logic", "Detailed Technical Assessment"]
        widths = [70, 100, 80, 110, 80, 80, 200]
        rows = []
        dac = session.get("detailed_ai_cache", {})
        for job in jobs:
            jid = job.get("JobId", "")
            da = dac.get(jid, {})
            tables = da.get("tables", []) or []
            views = da.get("views", []) or []
            tab_views = ", ".join(tables + views) or "None"
            rows.append([
                jid, job.get("JobName", ""), job.get("AppName", "Unknown"), tab_views,
                da.get("error_handling", "None"), da.get("restart_logic", "None"),
                da.get("detailed_technical_assessment", "Pending detailed assessment")
            ])
        add_table_section("DETAILED AI ANALYSIS REPORT", hdrs, rows, widths)
        _add_pdf_detailed_ai_profiles()
        story.append(PageBreak())

        # Risk & Modernization table
        hdrs = ["Job ID", "Job Name", "Risk Level", "Complexity", "Priority", "Debt", "Restart", "Recommendations"]
        widths = [70, 120, 55, 70, 55, 45, 45, 260]
        rows = []
        rmc = session.get("risk_mods_cache", {})
        for job in jobs:
            jid = job.get("JobId", "")
            rm = rmc.get(jid, {})
            recs = rm.get("recommendations", []) or []
            rows.append([
                jid, job.get("JobName", ""), rm.get("risk_level", "LOW"), rm.get("migration_complexity", "LOW"),
                rm.get("modernization_priority", "LOW"), str(rm.get("technical_debt_score", 5)),
                str(rm.get("restartability_score", 5)), ", ".join(recs) if isinstance(recs, list) else str(recs)
            ])
        add_table_section("RISK & MODERNIZATION REPORT", hdrs, rows, widths, risk_col_idx=2)
        _add_pdf_risk_profiles()
        story.append(PageBreak())
 
        # Job Conversion table
        hdrs = ["Job ID", "Job Name", "Target Tech", "Complexity", "Manual Review?", "Migration Notes", "Dependencies"]
        widths = [75, 110, 75, 60, 60, 240, 100]
        rows = []
        cc = session.get("conversions_cache", {})
        for job in jobs:
            jid = job.get("JobId", "")
            conv = None
            for key, val in cc.items():
                if key == jid or key.startswith(jid + "_"):
                    conv = val
                    break
            if not conv:
                conv = {}
            rows.append([
                jid, job.get("JobName", ""), conv.get("target_technology", "Python"), conv.get("complexity", "Low"),
                "Yes" if conv.get("manual_intervention_required", False) else "No",
                conv.get("migration_notes", "Pending conversion run"),
                ", ".join(conv.get("dependencies", [])) if isinstance(conv.get("dependencies"), list) else str(conv.get("dependencies", ""))
            ])
        add_table_section("JOB CONVERSION REPORT", hdrs, rows, widths)
        _add_pdf_conversion_profiles()

    doc.build(story, canvasmaker=NumberedCanvas)
    buf.seek(0)
    return buf.read()


def generate_redesigned_csv_report(session: dict, module: str = "everything") -> bytes:
    """Generate dynamic CSV assessment report."""
    jobs = session.get("jobs", [])
    analysis = session.get("phase1_analysis") or {}
    crit_map = analysis.get("criticality_map", {})
    graph = session.get("graph")
    crit_path_jobs = set(analysis.get("critical_path", []))
    
    high_level_assessments = session.get("high_level_assessments", {})
    detailed_ai_cache = session.get("detailed_ai_cache", {})
    risk_mods_cache = session.get("risk_mods_cache", {})
    conversions_cache = session.get("conversions_cache", {})

    rows = []
    
    def get_job_fields(job):
        jid = job.get("JobId", "")
        crit = crit_map.get(jid, {})
        hl = high_level_assessments.get(jid, {})
        da = detailed_ai_cache.get(jid, {})
        rm = risk_mods_cache.get(jid, {})
        failure_log = session.get("failure_logs", {}).get(jid)
        
        conv = None
        for key, val in conversions_cache.items():
            if key == jid or key.startswith(jid + "_"):
                conv = val
                break
        if not conv:
            conv = {}
            
        fan_in = len(list(graph.predecessors(jid))) if graph and jid in graph else 0
        fan_out = len(list(graph.successors(jid))) if graph and jid in graph else 0
        
        orig_code = (session.get("source_code_files", {}).get(conv.get("source_file", "")) or "")
        if not orig_code:
            inventory = session.get("inventory", [])
            src_file = ""
            for j in inventory:
                if j.get("Job_ID") == jid:
                    src_file = j.get("Source_File", "")
                    break
            if src_file:
                src_file_clean = src_file.strip().lower()
                for fname, content in session.get("source_code_files", {}).items():
                    fname_clean = fname.strip().lower()
                    if (fname_clean == src_file_clean or 
                        fname_clean.endswith("/" + src_file_clean) or 
                        fname_clean.endswith("\\" + src_file_clean) or
                        os.path.basename(fname_clean) == os.path.basename(src_file_clean)):
                        orig_code = content
                        break

        factors_str = ""
        factors = rm.get("risk_factors", []) or []
        if isinstance(factors, list):
            factors_str = "\n".join([f"{f.get('factor','')} ({f.get('severity','')}) - {f.get('description','')}" for f in factors])

        joins = da.get("joins", {}) or {}
        inner_j = ", ".join(joins.get("inner", [])) if isinstance(joins, dict) else ""
        outer_j = ", ".join(joins.get("outer", [])) if isinstance(joins, dict) else ""
        left_j = ", ".join(joins.get("left", [])) if isinstance(joins, dict) else ""
        right_j = ", ".join(joins.get("right", [])) if isinstance(joins, dict) else ""

        return {
            "Job ID": jid,
            "Job Name": job.get("JobName", ""),
            "Application": job.get("AppName", "Unknown"),
            "Platform": job.get("Platform", "Unknown"),
            "Criticality": crit.get("band", "Low"),
            "Criticality Score": crit.get("score", 0),
            "Critical Path": "Yes" if jid in crit_path_jobs else "No",
            "Fan In": fan_in,
            "Fan Out": fan_out,
            "Runtime Secs": job.get("Runtime", 0),
            "Job Type": hl.get("job_type", "Unknown"),
            "File Operations": hl.get("file_operations", "None"),
            "DB Operations": hl.get("db_operations", "None"),
            "Utilities": hl.get("utilities", "None"),
            "Risk Indicator": hl.get("risk_indicator", "LOW"),
            "Modernization Recommendation": hl.get("modernization_recommendation", "Shell -> Python"),
            
            # Detailed AI
            "Tables Used": ", ".join(da.get("tables", [])) if isinstance(da.get("tables"), list) else da.get("tables", ""),
            "Views": ", ".join(da.get("views", [])) if isinstance(da.get("views"), list) else da.get("views", ""),
            "Reference Tables": ", ".join(da.get("reference_tables", [])) if isinstance(da.get("reference_tables"), list) else da.get("reference_tables", ""),
            "Functions": ", ".join(da.get("functions", [])) if isinstance(da.get("functions"), list) else da.get("functions", ""),
            "Stored Procedures": ", ".join(da.get("stored_procedures", [])) if isinstance(da.get("stored_procedures"), list) else da.get("stored_procedures", ""),
            "Inner Joins": inner_j,
            "Outer Joins": outer_j,
            "Left Joins": left_j,
            "Right Joins": right_j,
            "Retry Logic": da.get("retry_logic", "None"),
            "Checkpoint Logic": da.get("checkpoint_logic", "None"),
            "Failure Recovery": da.get("failure_recovery", "None"),
            "Failure Log Status": "Failure Log On File" if failure_log else "No Failure Log",
            "Failure Analysis": da.get("failure_analysis", "No failure log uploaded for this job."),
            "Detailed Technical Assessment": da.get("detailed_technical_assessment", "None"),
            "Retrieved Source Code Chunks (RAG)": "\n\n".join(da.get("retrieved_chunks", [])),
            "Error Handling": da.get("error_handling", "None"),
            "Restart Logic": da.get("restart_logic", "None"),
            
            # Risk & Modernization
            "Risk Level": rm.get("risk_level", "LOW"),
            "Migration Complexity": rm.get("migration_complexity", "LOW"),
            "Modernization Priority": rm.get("modernization_priority", "LOW"),
            "Technical Debt Score": rm.get("technical_debt_score", 5),
            "Restartability Score": rm.get("restartability_score", 5),
            "Failure Log Evidence": "Confirmed Production Failure" if rm.get("has_failure_log") else "None on file",
            "Migration Risk Factors": factors_str,
            "Recommendations": ", ".join(rm.get("recommendations", [])) if isinstance(rm.get("recommendations"), list) else rm.get("recommendations", ""),
            "Detailed Strategy Reasoning": rm.get("detailed_reasoning", "None"),
            
            # Job Conversion
            "Current Technology": conv.get("current_technology", "Legacy"),
            "Target Technology": conv.get("target_technology", "Python"),
            "Original Source Code": orig_code,
            "Converted Code": conv.get("converted_code", "Pending Conversion"),
            "Complexity": conv.get("migration_complexity", "Low"),
            "Confidence Score": conv.get("confidence_score", "None"),
            "Reason for Recommendation": conv.get("reason_for_recommendation", "None"),
            "Business Impact": conv.get("business_impact", "None"),
            "Potential Risks": ", ".join(conv.get("potential_risks", [])) if isinstance(conv.get("potential_risks"), list) else str(conv.get("potential_risks", "")),
            "Manual Changes Required": ", ".join(conv.get("manual_changes_required", [])) if isinstance(conv.get("manual_changes_required"), list) else str(conv.get("manual_changes_required", "")),
            "Estimated Effort (Hours)": conv.get("estimated_effort_hours", 0),
            "Manual Review Needed?": "Yes" if conv.get("manual_review_needed", False) else "No",
            "Migration Notes": conv.get("migration_notes", ""),
            "Dependencies": ", ".join(conv.get("dependencies", [])) if isinstance(conv.get("dependencies"), list) else str(conv.get("dependencies", "")),
        }

    if module == "summary":
        summary_data = session.get("executive_summary") or {}
        rows = []
        if summary_data.get("headline"):
            rows.append({"Category": "Headline", "Key": "Headline", "Value": summary_data["headline"]})
        if summary_data.get("executive_summary"):
            rows.append({"Category": "Narrative", "Key": "Executive Summary", "Value": summary_data["executive_summary"]})
        
        for idx, f in enumerate(summary_data.get("key_findings", []), start=1):
            rows.append({"Category": "Finding", "Key": f"Finding {idx}", "Value": f})
            
        for idx, r in enumerate(summary_data.get("strategic_recommendations", []), start=1):
            rows.append({
                "Category": "Recommendation", 
                "Key": f"Recommendation {idx} (P{r.get('priority','1')})", 
                "Value": f"{r.get('recommendation','')} [Value: {r.get('business_value','None')}, Timeline: {r.get('timeline','None')}]"
            })
        for phase, desc in summary_data.get("modernization_roadmap", {}).items():
            rows.append({"Category": "Roadmap", "Key": phase.upper(), "Value": desc})

        # Failure Diagnostics Summary — only rendered if logs were uploaded
        failure_logs = session.get("failure_logs", {}) or {}
        if failure_logs:
            jobs_by_id = {j.get("JobId", ""): j for j in session.get("jobs", [])}
            risk_mods_cache_s = session.get("risk_mods_cache", {})
            rows.append({
                "Category": "Failure Diagnostics", "Key": "Summary",
                "Value": f"{len(failure_logs)} job(s) have confirmed production failures on file."
            })
            for jid, log in failure_logs.items():
                job_name = jobs_by_id.get(jid, {}).get("JobName", log.get("job_name", ""))
                rm_entry = risk_mods_cache_s.get(jid, {})
                blocked_count = len(log.get("blocked_jobs", []) or [])
                rows.append({
                    "Category": "Failure Diagnostics",
                    "Key": f"{jid} ({job_name})",
                    "Value": (
                        f"Root Cause: {log.get('root_cause') or log.get('error_code') or 'Not specified'} | "
                        f"Severity: {log.get('severity', 'N/A')} | "
                        f"SLA Breached: {'Yes' if str(log.get('sla_status','')).upper() == 'BREACHED' else 'No'} | "
                        f"Blocked Jobs: {blocked_count} | "
                        f"Migration Risk: {rm_entry.get('risk_level', 'N/A')}"
                    )
                })

        df = pd.DataFrame(rows)
    else:
        for job in jobs:
            rows.append(get_job_fields(job))
        df = pd.DataFrame(rows)
        
        if module == "schedule":
            cols = ["Job ID", "Job Name", "Application", "Platform", "Criticality", "Criticality Score", "Critical Path", "Fan In", "Fan Out", "Runtime Secs"]
            df = df[cols]
        elif module == "highlevel":
            cols = ["Job ID", "Job Name", "Application", "Job Type", "File Operations", "DB Operations", "Utilities", "Risk Indicator", "Modernization Recommendation"]
            df = df[cols]
        elif module == "detailed":
            cols = [
                "Job ID", "Job Name", "Application", "Tables Used", "Views", "Reference Tables", "Functions",
                "Stored Procedures", "Inner Joins", "Outer Joins", "Left Joins", "Right Joins", 
                "File Operations", "DB Operations", "Utilities", "Error Handling", "Restart Logic", 
                "Retry Logic", "Checkpoint Logic", "Failure Recovery", "Failure Log Status", "Failure Analysis",
                "Detailed Technical Assessment", "Retrieved Source Code Chunks (RAG)"
            ]
            df = df[cols]
        elif module == "riskmods":
            cols = [
                "Job ID", "Job Name", "Application", "Risk Level", "Migration Complexity", "Modernization Priority", 
                "Technical Debt Score", "Restartability Score", "Failure Log Evidence", "Migration Risk Factors", "Recommendations", 
                "Detailed Strategy Reasoning"
            ]
            df = df[cols]
        elif module == "convert":
            cols = [
                "Job ID", "Job Name", "Application", "Current Technology", "Target Technology", 
                "Original Source Code", "Converted Code", "Complexity", "Confidence Score", 
                "Reason for Recommendation", "Business Impact", "Potential Risks", 
                "Manual Changes Required", "Estimated Effort (Hours)", "Manual Review Needed?",
                "Migration Notes", "Dependencies"
            ]
            df = df[cols]

    return df.to_csv(index=False).encode("utf-8")

