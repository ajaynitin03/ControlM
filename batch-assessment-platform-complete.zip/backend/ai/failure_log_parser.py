"""
Failure Log Parser — Submodule for Phase 2 AI Assessment.

Parses Control-M (or generic scheduler) job-execution failure logs (.log / .txt)
and extracts structured fields used to enrich Detailed AI Analysis and
Risk & Modernization with REAL failure evidence instead of generic heuristics.

Supports loosely-structured logs like:

    Job ID           : JOB_007
    Status           : Ended Not OK
    Return Code      : 12
    ...
    03:06:11 ERROR   ORA-01652: unable to extend temp segment...
    ...
    Failure Category : Database Error
    Error Code       : ORA-01652
    Root Cause       : Temporary tablespace exhausted
    Restart Required : YES
    Recommended Action
    1. Increase TEMP tablespace.
    ...
    Blocked Jobs
    JOB_009 BUILD_POSITION_VIEW
    ...

The parser is intentionally tolerant — every field is optional, and if structured
fields aren't found, the raw log text is still kept and handed to Gemini, which is
far better at extracting meaning from semi-structured text than regex is.
"""

from __future__ import annotations
import re
from typing import Optional


# Matches "Job ID           : JOB_007" or "Job ID: JOB_007" (colon-aligned key/value lines)
_KV_LINE = re.compile(
    r"^[ \t]*([A-Za-z][A-Za-z0-9 /_\-]{1,40}?)[ \t]*:[ \t]*(.+?)[ \t]*$",
    re.MULTILINE,
)

# Common header aliases -> canonical field name
_FIELD_ALIASES = {
    "job id": "job_id",
    "jobid": "job_id",
    "job name": "job_name",
    "jobname": "job_name",
    "order id": "order_id",
    "run date": "run_date",
    "status": "status",
    "return code": "return_code",
    "start time": "start_time",
    "end time": "end_time",
    "elapsed time": "elapsed_time",
    "retries": "retries",
    "final status": "final_status",
    "sla threshold": "sla_threshold",
    "actual runtime": "actual_runtime",
    "sla status": "sla_status",
    "failure category": "failure_category",
    "error code": "error_code",
    "root cause": "root_cause",
    "affected module": "affected_module",
    "restart required": "restart_required",
    "restart point": "restart_point",
    "overall severity": "severity",
    "severity": "severity",
    "application": "application",
    "sub-application": "sub_application",
    "folder": "folder",
    "owner": "owner",
    "host": "host",
}

_RECOMMENDED_ACTION_HEADER = re.compile(r"recommended action", re.IGNORECASE)
_BLOCKED_JOBS_HEADER = re.compile(r"blocked jobs", re.IGNORECASE)
_COMPLETED_JOBS_HEADER = re.compile(r"completed jobs", re.IGNORECASE)
_BUSINESS_IMPACT_HEADER = re.compile(r"business impact", re.IGNORECASE)
_SECTION_HEADER = re.compile(r"^-{5,}|^={5,}", re.MULTILINE)

# Lines like "JOB_009 BUILD_POSITION_VIEW" or "JOB_009, BUILD_POSITION_VIEW" under a jobs list.
# Requires the first token to look like an actual job code (has a digit or underscore) so that
# section headers like "Blocked Jobs" (two plain words) don't get misread as a job entry.
_JOB_LINE = re.compile(r"^[ \t]*([A-Za-z0-9]*[_\-][A-Za-z0-9_\-]{1,30}|[A-Za-z]{2,10}\d{2,10})\b[ ,\t]*([A-Za-z0-9_\- ]{0,60})?[ \t]*$")

# Numbered or bulleted action steps: "1. Increase TEMP tablespace." / "- Do X" / "• Do X"
_ACTION_LINE = re.compile(r"^[ \t]*(?:\d+[\.\)]|[-•*])[ \t]*(.+?)[ \t]*$")

# A log-level execution message line, e.g. "03:06:11 ERROR   ORA-01652: ..."
_MSG_LINE = re.compile(
    r"^[ \t]*\d{1,2}:\d{2}:\d{2}[ \t]+(INFO|WARNING|WARN|ERROR|FATAL|DEBUG)\b[ \t]*(.*)$",
    re.MULTILINE,
)

# Explicit "Job ID" or "JobId" embedded anywhere (looser fallback if structured block missing)
_LOOSE_JOB_ID = re.compile(r"job[_ ]?id[ \t]*[:#][ \t]*([A-Za-z0-9_\-]{2,30})", re.IGNORECASE)


def parse_failure_log(filename: str, content: str) -> dict:
    """
    Parse a single failure log file (.log / .txt) into a structured dict.

    Returns a dict with as many of these keys as could be determined:
        job_id, job_name, application, status, return_code, start_time, end_time,
        elapsed_time, retries, final_status, sla_threshold, actual_runtime, sla_status,
        failure_category, error_code, root_cause, affected_module, restart_required,
        restart_point, recommended_actions (list[str]), severity,
        completed_jobs (list[str]), blocked_jobs (list[str]), business_impact (list[str]),
        error_messages (list[str]),   # lines flagged ERROR/FATAL from the execution log
        raw_text (full original content, capped),
        filename
    """
    result: dict = {"filename": filename, "raw_text": content[:8000]}

    # 1. Structured key:value fields
    for m in _KV_LINE.finditer(content):
        raw_key = m.group(1).strip().lower()
        canonical = _FIELD_ALIASES.get(raw_key)
        if canonical and canonical not in result:
            result[canonical] = m.group(2).strip()

    # 2. Fallback Job ID extraction if the structured pass missed it
    if "job_id" not in result:
        loose = _LOOSE_JOB_ID.search(content)
        if loose:
            result["job_id"] = loose.group(1).strip()

    # 3. ERROR / FATAL execution messages (gives Gemini the smoking gun directly)
    error_msgs = []
    for m in _MSG_LINE.finditer(content):
        level, msg = m.group(1).upper(), m.group(2).strip()
        if level in ("ERROR", "FATAL") and msg:
            error_msgs.append(msg)
    if error_msgs:
        result["error_messages"] = error_msgs[:10]

    # 4. Recommended Action block (numbered/bulleted lines following the header)
    actions = _extract_list_after_header(content, _RECOMMENDED_ACTION_HEADER, line_pattern=_ACTION_LINE)
    if actions:
        result["recommended_actions"] = actions

    # 5. Blocked / Completed jobs lists
    blocked = _extract_job_list_after_header(content, _BLOCKED_JOBS_HEADER)
    if blocked:
        result["blocked_jobs"] = blocked

    completed = _extract_job_list_after_header(content, _COMPLETED_JOBS_HEADER)
    if completed:
        result["completed_jobs"] = completed

    # 6. Business impact bullets
    impact = _extract_list_after_header(content, _BUSINESS_IMPACT_HEADER, line_pattern=_ACTION_LINE)
    if impact:
        result["business_impact"] = impact

    return result


def _extract_list_after_header(content: str, header_re: re.Pattern, line_pattern: re.Pattern) -> list[str]:
    """Grab bullet/numbered lines that immediately follow a section header, until a divider/blank-blank."""
    m = header_re.search(content)
    if not m:
        return []
    tail = content[m.end():]
    lines = tail.split("\n")
    items = []
    blank_streak = 0
    for line in lines[:40]:
        stripped = line.strip()
        if not stripped:
            blank_streak += 1
            if blank_streak >= 2 and items:
                break
            continue
        blank_streak = 0
        if _SECTION_HEADER.match(stripped):
            if items:
                break
            continue  # divider line right after the header itself — skip, keep looking
        lm = line_pattern.match(stripped)
        if lm:
            items.append(lm.group(1).strip())
        elif items:
            # Non-matching line after we've started collecting — likely end of list
            break
    return items[:15]


def _extract_job_list_after_header(content: str, header_re: re.Pattern) -> list[str]:
    """Grab 'JOB_ID  Job Name' style lines following a 'Blocked Jobs' / 'Completed Jobs' header."""
    m = header_re.search(content)
    if not m:
        return []
    tail = content[m.end():]
    lines = tail.split("\n")
    items = []
    blank_streak = 0
    for line in lines[:25]:
        stripped = line.strip()
        if not stripped:
            blank_streak += 1
            if blank_streak >= 2 and items:
                break
            continue
        blank_streak = 0
        if _SECTION_HEADER.match(stripped):
            if items:
                break
            continue
        jm = _JOB_LINE.match(stripped)
        if jm:
            job_id = jm.group(1).strip()
            job_name = (jm.group(2) or "").strip()
            items.append(f"{job_id} ({job_name})" if job_name else job_id)
        elif items:
            break
    return items[:20]


def match_log_to_job(log: dict, inventory: list[dict], known_job_ids: Optional[set] = None) -> Optional[str]:
    """
    Determine which inventory Job_ID this failure log belongs to.

    Priority:
      1. Exact match on parsed 'job_id' field against inventory Job_ID
      2. Case-insensitive match
      3. Job ID found anywhere in the filename
      4. Job ID found anywhere in raw text (already attempted during parse, but re-check broader)
    """
    job_id = (log.get("job_id") or "").strip()
    filename = (log.get("filename") or "").strip()
    raw_text = log.get("raw_text", "")

    valid_ids = known_job_ids or {j.get("Job_ID", "") for j in inventory if j.get("Job_ID")}
    valid_ids_lower = {v.lower(): v for v in valid_ids if v}

    if job_id:
        if job_id in valid_ids:
            return job_id
        if job_id.lower() in valid_ids_lower:
            return valid_ids_lower[job_id.lower()]

    # Try filename — e.g. "JOB_007_failure.log" or "failure_JOB_007.txt"
    fname_lower = filename.lower()
    for vid in valid_ids:
        if vid and vid.lower() in fname_lower:
            return vid

    # Last resort — scan raw text for any known job id substring
    text_lower = raw_text.lower()
    for vid in valid_ids:
        if vid and re.search(r"\b" + re.escape(vid.lower()) + r"\b", text_lower):
            return vid

    return None


def summarize_for_prompt(log: dict, max_chars: int = 3000) -> str:
    """
    Render a parsed failure log into a clean text block to inject into Gemini prompts.
    Prioritizes structured fields; falls back to raw text if little was parsed.
    """
    lines = []
    field_labels = [
        ("job_id", "Job ID"), ("job_name", "Job Name"), ("status", "Status"),
        ("return_code", "Return Code"), ("final_status", "Final Status"),
        ("start_time", "Start Time"), ("end_time", "End Time"), ("elapsed_time", "Elapsed Time"),
        ("retries", "Retries"), ("sla_threshold", "SLA Threshold"),
        ("actual_runtime", "Actual Runtime"), ("sla_status", "SLA Status"),
        ("failure_category", "Failure Category"), ("error_code", "Error Code"),
        ("root_cause", "Root Cause"), ("affected_module", "Affected Module"),
        ("restart_required", "Restart Required"), ("restart_point", "Restart Point"),
        ("severity", "Overall Severity"),
    ]
    for key, label in field_labels:
        if log.get(key):
            lines.append(f"{label}: {log[key]}")

    if log.get("error_messages"):
        lines.append("Error Log Lines:")
        for msg in log["error_messages"][:6]:
            lines.append(f"  - {msg}")

    if log.get("recommended_actions"):
        lines.append("Recommended Actions (from log):")
        for a in log["recommended_actions"]:
            lines.append(f"  - {a}")

    if log.get("blocked_jobs"):
        lines.append(f"Blocked Downstream Jobs: {', '.join(log['blocked_jobs'])}")

    if log.get("completed_jobs"):
        lines.append(f"Completed Upstream Jobs: {', '.join(log['completed_jobs'])}")

    if log.get("business_impact"):
        lines.append("Business Impact (from log):")
        for b in log["business_impact"]:
            lines.append(f"  - {b}")

    text = "\n".join(lines)

    # If almost nothing structured was extracted, fall back to a chunk of raw text
    if len(text) < 80 and log.get("raw_text"):
        text = (text + "\n\nRaw Log Excerpt:\n" + log["raw_text"][:max_chars]).strip()

    return text[:max_chars]
