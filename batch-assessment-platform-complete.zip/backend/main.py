import logging
from dotenv import load_dotenv
load_dotenv()  # reads backend/.env and sets GEMINI_API_KEY etc. as real env vars

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from routers import upload, graph, analysis
from routers import ai_assessment
from routers import templates

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)

app = FastAPI(
    title="Batch Assessment Platform",
    description="Phase-1: Dependency visualization | Phase-2: AI-powered modernization assessment",
    version="2.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Phase-1 routers
app.include_router(upload.router,   prefix="/api/upload",   tags=["Upload"])
app.include_router(graph.router,    prefix="/api/graph",    tags=["Graph"])
app.include_router(analysis.router, prefix="/api/analysis", tags=["Analysis"])
app.include_router(templates.router, prefix="/api/templates", tags=["Templates"])

# Phase-2 router
app.include_router(ai_assessment.router)


@app.get("/api/health")
def health():
    from ai.gemini_client import is_available
    from ai.rag_knowledge import _DOCS, _INDEX
    return {
        "status":            "ok",
        "version":           "2.0.0",
        "phase1":            True,
        "phase2":            True,
        "gemini_available":  is_available(),
        "rag_docs":          len(_DOCS),
        "faiss_ready":       _INDEX is not None,
    }
