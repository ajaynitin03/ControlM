import sys
import os
import unittest
from fastapi.testclient import TestClient

# Add project directories to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Mock Gemini client before importing app
import ai.gemini_client as gc
import ai.assessment_engine as ae

def mock_call_gemini(prompt, expect_json=False, retries=3, model=""):
    prompt_up = prompt.upper()
    if "DETAILED" in prompt_up or "TABLES" in prompt_up:
        return {
            "job_id": "J1",
            "tables": ["erp_table"],
            "views": [],
            "reference_tables": [],
            "functions": [],
            "stored_procedures": [],
            "joins": {"inner": [], "outer": [], "left": [], "right": []},
            "file_operations": ["read"],
            "db_operations": ["select"],
            "utilities": [],
            "error_handling": "Standard exit code check",
            "restart_logic": "Standard restart",
            "retry_logic": "None",
            "checkpoint_logic": "None",
            "failure_recovery": "Re-run",
            "detailed_technical_assessment": "Mock detailed technical assessment text."
        }
    elif "RISK" in prompt_up or "COMPLEXITY" in prompt_up:
        return {
            "job_id": "J1",
            "risk_level": "LOW",
            "migration_complexity": "LOW",
            "modernization_priority": "LOW",
            "technical_debt_score": 3,
            "restartability_score": 5,
            "migration_recommendation": "Shell -> Python",
            "target_technology": "Python",
            "target_scheduler": "Apache Airflow",
            "reasoning": "Mock risk reasoning",
            "risk_factors": []
        }
    elif "CONVERT" in prompt_up or "TRANSLATE" in prompt_up or "MIGRATE" in prompt_up:
        return {
            "job_id": "J1",
            "target_technology": "Python",
            "converted_code": "print('mock converted code')",
            "migration_explanation": "Mock conversion explanation",
            "risks": [],
            "validation_checklist": [],
            "estimated_effort_hours": 8,
            "manual_review_needed": False,
            "current_technology": "Shell",
            "recommended_technology": "Python",
            "reason_for_recommendation": "Mock reason",
            "migration_complexity": "LOW",
            "confidence_score": "9/10",
            "dependencies": [],
            "potential_risks": [],
            "manual_changes_required": [],
            "estimated_effort_hours": 8,
            "business_impact": "None",
            "benefits": []
        }
    elif "EXECUTIVE SUMMARY" in prompt_up or "STRATEGIC" in prompt_up or "ROADMAP" in prompt_up:
        return {
            "headline": "Mock executive summary headline",
            "executive_summary": "Mock executive summary narrative.",
            "key_findings": ["Finding 1", "Finding 2"],
            "strategic_recommendations": [
                {"priority": "1", "recommendation": "Mock recommendation 1", "business_value": "High", "timeline": "Short"}
            ],
            "modernization_roadmap": {
                "phase 1": "Mock roadmap phase 1"
            }
        }
    return {}

gc.is_available = lambda: True
gc.call_gemini = mock_call_gemini
ae.is_available = lambda: True
ae.call_gemini = mock_call_gemini

from main import app
from routers.upload import sessions
import networkx as nx

class TestAIAssessmentIntegration(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)
        self.session_id = "test-integration-session"
        
        # Build mock dependency graph
        g = nx.DiGraph()
        g.add_node("J1")
        
        # Populate mock session data matching Phase 1 output
        sessions[self.session_id] = {
            "filename": "sample_jobs.csv",
            "jobs": [
                {"JobId": "J1", "JobName": "Job_1", "AppName": "App_A", "Platform": "Shell", "Runtime": 100}
            ],
            "graph": g,
            "exec_metrics": {
                "J1": {"failed_runs": 1, "sla_breaches": 0}
            },
            "phase1_analysis": {
                "criticality_map": {
                    "J1": {"band": "High", "score": 8, "reason": "Test critical path"}
                },
                "critical_path": ["J1"]
            },
            "inventory": [
                {
                    "Job_ID": "J1",
                    "Job_Name": "Job_1",
                    "Application": "App_A",
                    "Source_File": "extract_erp.sh",
                    "Source_Type": "Shell"
                }
            ],
            "source_code_files": {
                "extract_erp.sh": "echo 'running extract'\nselect * from erp_table;\n"
            }
        }

    def test_get_models(self):
        response = self.client.get("/api/ai/models")
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertTrue(isinstance(data, list))
        self.assertTrue(any(m["id"] == "gemini-2.0-flash" for m in data))

    def test_select_model(self):
        response = self.client.post(f"/api/ai/select-model/{self.session_id}?model_id=gemini-1.5-pro")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {"success": True, "selected_model": "gemini-1.5-pro"})
        
        # Verify selected model in session and caches reset
        self.assertEqual(sessions[self.session_id].get("selected_model"), "gemini-1.5-pro")
        self.assertEqual(sessions[self.session_id].get("detailed_ai_cache"), {})

    def test_get_job_source_code(self):
        response = self.client.get(f"/api/ai/job-source/{self.session_id}/J1")
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data["success"], True)
        self.assertEqual(data["job_id"], "J1")
        self.assertEqual(data["source_file"], "extract_erp.sh")
        self.assertIn("select * from erp_table", data["source_code"])

    def test_get_assessment_status(self):
        response = self.client.get(f"/api/ai/status/{self.session_id}")
        self.assertEqual(response.status_code, 200)
        data = response.json()
        self.assertEqual(data["inventory_uploaded"], True)
        self.assertEqual(data["source_uploaded"], True)

    def test_start_assessment_and_high_level(self):
        # We mock embedding & RAG generation to avoid real Gemini embedding calls
        from ai.rag_source_code import SourceCodeVectorStore
        original_generate = SourceCodeVectorStore.generate_embeddings
        SourceCodeVectorStore.generate_embeddings = lambda self, api_key: None
        
        try:
            response = self.client.post(f"/api/ai/start-assessment/{self.session_id}")
            self.assertEqual(response.status_code, 200)
            self.assertTrue(response.json()["success"])
            
            # Now test GET high-level assessments
            hl_response = self.client.get(f"/api/ai/high-level/{self.session_id}")
            self.assertEqual(hl_response.status_code, 200)
            hl_data = hl_response.json()
            self.assertTrue(hl_data["success"])
            self.assertEqual(len(hl_data["assessments"]), 1)
            self.assertEqual(hl_data["assessments"][0]["job_id"], "J1")
        finally:
            SourceCodeVectorStore.generate_embeddings = original_generate

    def test_submodule_endpoints(self):
        # Trigger run_high_level_assessment to ensure it's loaded in session
        self.client.post(f"/api/ai/start-assessment/{self.session_id}")

        # 1. Detailed Analysis
        response = self.client.post(f"/api/ai/detailed-analysis/{self.session_id}/J1")
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json()["success"])
        self.assertIn("detailed_technical_assessment", response.json()["analysis"])

        # 2. Risk & Modernization
        response = self.client.post(f"/api/ai/risk-modernization/{self.session_id}/J1")
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json()["success"])
        self.assertIn("risk_level", response.json()["result"])

        # 3. Convert Job
        response = self.client.post(f"/api/ai/convert-job/{self.session_id}/J1?target_technology=Python")
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json()["success"])
        self.assertIn("converted_code", response.json()["conversion"])

        # 4. Executive Summary
        response = self.client.post(f"/api/ai/executive-summary/{self.session_id}")
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json()["success"])
        self.assertIn("headline", response.json()["summary"])

    def test_download_reports(self):
        # Make sure assessment caches are populated first
        self.client.post(f"/api/ai/start-assessment/{self.session_id}")
        self.client.post(f"/api/ai/detailed-analysis/{self.session_id}/J1")
        self.client.post(f"/api/ai/risk-modernization/{self.session_id}/J1")
        self.client.post(f"/api/ai/convert-job/{self.session_id}/J1?target_technology=Python")
        self.client.post(f"/api/ai/executive-summary/{self.session_id}")

        modules = ["everything", "schedule", "highlevel", "detailed", "riskmods", "convert", "summary"]
        for mod in modules:
            with self.subTest(module=mod):
                response = self.client.get(f"/api/ai/final-report/{self.session_id}?module={mod}")
                self.assertEqual(response.status_code, 200)
                self.assertEqual(response.headers["content-type"], "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                self.assertTrue(len(response.content) > 1000)

if __name__ == "__main__":
    unittest.main()
