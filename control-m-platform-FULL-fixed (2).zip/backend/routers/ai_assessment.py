"""
Phase 2 AI Assessment router.
Handles Inventory upload, Source upload, Assessment orchestration, Caching, and Redesigned Report export.
"""

from __future__ import annotations
import logging
import io
import pandas as pd
from typing import Optional, List
from fastapi import APIRouter, HTTPException, UploadFile, File, Query
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

import os
from ai import assessment_engine as engine
from ai.rag_source_code import get_store, clear_store
from ai.gemini_client import is_available, call_gemini, _gemini_reachable, reset_connectivity_check, key_count
from ai.report_generator import generate_redesigned_excel_report

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/ai", tags=["Phase-2 AI"])

# Reference the memory session store from the upload router
from routers.upload import sessions

# ════════════════════════════════════════════════════════════════════
# STATUS
# ════════════════════════════════════════════════════════════════════

@router.get("/status/{session_id}")
def get_assessment_status(session_id: str):
    """
    Checks if setup inputs are uploaded and returns setup status.
    Also performs a live connectivity probe to Google's API on first call.
    """
    session = _get_session(session_id)
    inventory = session.get("inventory", [])
    source_files = session.get("source_code_files", {})
    
    key_configured = is_available()
    # Only probe network if key is configured (avoids unnecessary TCP connection)
    network_reachable = _gemini_reachable() if key_configured else False
    
    return {
        "gemini_available": key_configured and network_reachable,
        "gemini_key_configured": key_configured,
        "gemini_network_reachable": network_reachable,
        "gemini_key_count": key_count(),        # how many keys are loaded
        "inventory_uploaded": len(inventory) > 0,
        "inventory_jobs_count": len(inventory),
        "source_uploaded": len(source_files) > 0,
        "source_files_count": len(source_files),
        "assessment_started": "high_level_assessments" in session
    }

# ════════════════════════════════════════════════════════════════════
# INPUT SETUP UPLOADS
# ════════════════════════════════════════════════════════════════════

@router.post("/upload-inventory/{session_id}")
async def upload_inventory(session_id: str, file: UploadFile = File(...)):
    """
    Upload and validate the Job Inventory CSV.
    Required Columns: Job_ID, Job_Name, Application, Source_File, Source_Type
    """
    session = _get_session(session_id)
    content = await file.read()
    
    try:
        # Load CSV
        df = pd.read_csv(io.BytesIO(content), dtype=str)
    except Exception as e:
        raise HTTPException(422, f"Failed to parse CSV: {str(e)}")
        
    required_cols = {"Job_ID", "Job_Name", "Application", "Source_File", "Source_Type"}
    missing = required_cols - set(df.columns)
    if missing:
        raise HTTPException(
            status_code=422,
            detail={
                "error": "Missing Required Columns",
                "missing": list(missing),
                "required": list(required_cols)
            }
        )
        
    # Store in session
    inventory_records = df.fillna("").to_dict(orient="records")
    session["inventory"] = inventory_records
    
    return {
        "success": True,
        "message": f"Successfully loaded {len(inventory_records)} inventory jobs",
        "row_count": len(inventory_records),
        "columns": list(df.columns)
    }


@router.post("/upload-source/{session_id}")
async def upload_source_code(session_id: str, files: List[UploadFile] = File(...)):
    """
    Upload source code files (supports multiple file uploads).
    """
    session = _get_session(session_id)
    source_files = session.setdefault("source_code_files", {})
    
    uploaded_count = 0
    for file in files:
        filename = file.filename
        try:
            content_bytes = await file.read()
            content = content_bytes.decode("utf-8", errors="ignore")
            source_files[filename] = content
            uploaded_count += 1
        except Exception as e:
            logger.warning(f"Failed to read source file {filename}: {e}")
            
    return {
        "success": True,
        "message": f"Successfully uploaded {uploaded_count} source files",
        "total_source_files": len(source_files)
    }


@router.post("/clear-inputs/{session_id}")
def clear_inputs(session_id: str):
    """Reset Inventory and Source code uploads for the session."""
    session = _get_session(session_id)
    session["inventory"] = []
    session["source_code_files"] = {}
    if "high_level_assessments" in session:
        del session["high_level_assessments"]
    
    # Clear this session's vector store
    clear_store(session_id)
    
    return {"success": True, "message": "Setup inputs cleared"}

# ════════════════════════════════════════════════════════════════════
# START ASSESSMENT
# ════════════════════════════════════════════════════════════════════

@router.post("/start-assessment/{session_id}")
def start_assessment(session_id: str):
    """
    Builds the RAG vector index and generates rules-based High Level Assessments.
    """
    session = _get_session(session_id)
    inventory = session.get("inventory", [])
    source_files = session.get("source_code_files", {})
    
    if not inventory:
        raise HTTPException(400, "Job Inventory CSV must be uploaded first.")
    if not source_files:
        raise HTTPException(400, "Source code files must be uploaded first.")
        
    logger.info(f"[StartAssessment] Building RAG index for session={session_id}...")
    
    # 1. Get or create this session's isolated vector store
    rag_store = get_store(session_id)
    rag_store.clear()
    
    # 2. Add source code chunks and map to inventory jobs
    for filename, content in source_files.items():
        # Find which jobs use this file (matching base filename case-insensitively)
        base_filename = filename.strip().lower()
        mapped_jobs = []
        for job in inventory:
            job_file = job.get("Source_File", "").strip().lower()
            if job_file and (job_file == base_filename or 
                             base_filename.endswith("/" + job_file) or 
                             base_filename.endswith("\\" + job_file) or
                             os.path.basename(base_filename) == os.path.basename(job_file)):
                mapped_jobs.append(job)
                
        rag_store.add_source_file(filename, content, mapped_jobs)
        
    # 3. Generate embeddings
    api_key = os.environ.get("GEMINI_API_KEY", "")  # legacy — rotation handled by gemini_client internally
    rag_store.generate_embeddings(api_key)
    
    # 4. Execute rules-based High Level Assessment (instant, zero tokens!)
    high_level = engine.run_high_level_assessment(session)
    session["high_level_assessments"] = high_level
    
    # 5. Initialize AI caches
    session["detailed_ai_cache"] = {}
    session["risk_mods_cache"] = {}
    session["conversions_cache"] = {}
    
    return {
        "success": True,
        "message": f"Assessment initialized. Indexed {len(rag_store.chunks)} chunks. High Level Assessment ready.",
        "jobs_assessed": len(high_level)
    }

# ════════════════════════════════════════════════════════════════════
# SUBMODULE 2 — GET HIGH LEVEL ASSESSMENTS
# ════════════════════════════════════════════════════════════════════

@router.get("/high-level/{session_id}")
def get_high_level_assessments(session_id: str):
    session = _get_session(session_id)
    high_level = session.get("high_level_assessments", {})
    if not high_level:
        raise HTTPException(400, "Assessment has not been started yet.")
        
    return {
        "success": True,
        "assessments": list(high_level.values())
    }

# ════════════════════════════════════════════════════════════════════
# SUBMODULE 3 — DETAILED AI ANALYSIS (With Caching)
# ════════════════════════════════════════════════════════════════════

@router.post("/detailed-analysis/{session_id}/{job_id}")
def detailed_analysis(session_id: str, job_id: str):
    session = _get_session(session_id)
    cache = session.setdefault("detailed_ai_cache", {})
    
    # Check cache
    if job_id in cache:
        logger.info(f"[Detailed AI] Cache hit for job_id={job_id}")
        return {"success": True, "cached": True, "analysis": cache[job_id]}
        
    # Run analysis
    job_meta = _find_job(session, job_id)
    api_key = os.environ.get("GEMINI_API_KEY", "")  # legacy — rotation handled by gemini_client internally
    
    result = engine.perform_detailed_analysis(job_meta, api_key, session_id)
    cache[job_id] = result
    
    return {"success": True, "cached": False, "analysis": result}

# ════════════════════════════════════════════════════════════════════
# SUBMODULE 4 — RISK & MODERNIZATION (With Caching)
# ════════════════════════════════════════════════════════════════════

@router.post("/risk-modernization/{session_id}/{job_id}")
def risk_modernization(session_id: str, job_id: str):
    session = _get_session(session_id)
    cache = session.setdefault("risk_mods_cache", {})
    
    # Check cache
    if job_id in cache:
         return {"success": True, "cached": True, "result": cache[job_id]}
         
    job_meta = _find_job(session, job_id)
    
    # Gather high-level & detailed analysis metadata inputs
    high_level = session.get("high_level_assessments", {}).get(job_id, {})
    
    # Trigger detailed AI analysis if not already cached (ensures it is available)
    detailed_cache = session.setdefault("detailed_ai_cache", {})
    if job_id not in detailed_cache:
        detailed = engine.perform_detailed_analysis(job_meta, session_id=session_id)
        detailed_cache[job_id] = detailed
    else:
        detailed = detailed_cache[job_id]
        
    # Get execution history metrics (Phase 1)
    exec_metrics = session.get("exec_metrics", {}).get(job_id, {})
    
    api_key = os.environ.get("GEMINI_API_KEY", "")  # legacy — rotation handled by gemini_client internally
    result = engine.perform_risk_modernization(job_meta, high_level, detailed, exec_metrics, api_key)
    cache[job_id] = result
    
    return {"success": True, "cached": False, "result": result}

# ════════════════════════════════════════════════════════════════════
# SUBMODULE 5 — JOB CONVERSION (With Caching)
# ════════════════════════════════════════════════════════════════════

@router.post("/convert-job/{session_id}/{job_id}")
def convert_job(session_id: str, job_id: str, target_technology: str = Query(...)):
    session = _get_session(session_id)
    cache = session.setdefault("conversions_cache", {})
    cache_key = f"{job_id}_{target_technology}"
    
    # Check cache
    if cache_key in cache:
        return {"success": True, "cached": True, "conversion": cache[cache_key]}
        
    job_meta = _find_job(session, job_id)
    
    # Find full source code content for this job
    inventory = session.get("inventory", [])
    source_files = session.get("source_code_files", {})
    
    # Get mapped file
    src_file = ""
    for j in inventory:
        if j.get("Job_ID") == job_id:
            src_file = j.get("Source_File", "")
            break
            
    code = ""
    if src_file:
        src_file_clean = src_file.strip().lower()
        for fname, content in source_files.items():
            fname_clean = fname.strip().lower()
            if (fname_clean == src_file_clean or 
                fname_clean.endswith("/" + src_file_clean) or 
                fname_clean.endswith("\\" + src_file_clean) or
                os.path.basename(fname_clean) == os.path.basename(src_file_clean)):
                code = content
                break
                
    api_key = os.environ.get("GEMINI_API_KEY", "")  # legacy — rotation handled by gemini_client internally
    result = engine.perform_job_conversion(job_meta, code, target_technology, api_key)
    cache[cache_key] = result
    
    return {"success": True, "cached": False, "conversion": result}

# ════════════════════════════════════════════════════════════════════
# SUBMODULE 6 — SUMMARY & EXPORT
# ════════════════════════════════════════════════════════════════════

@router.post("/executive-summary/{session_id}")
def get_executive_summary(session_id: str):
    session = _get_session(session_id)
    high_level = session.get("high_level_assessments", {})
    risk_mods = session.setdefault("risk_mods_cache", {})
    
    total_jobs = len(high_level)
    
    # Aggregate statistics
    high_risk_count = 0
    medium_risk_count = 0
    low_risk_count = 0
    for hl in high_level.values():
        risk = hl.get("risk_indicator", "LOW")
        if risk == "HIGH":
            high_risk_count += 1
        elif risk == "MEDIUM":
            medium_risk_count += 1
        else:
            low_risk_count += 1
            
    debts = []
    restartabilities = []
    for rm in risk_mods.values():
        debts.append(rm.get("technical_debt_score", 5))
        restartabilities.append(rm.get("restartability_score", 5))
        
    avg_tech_debt = sum(debts) / len(debts) if debts else 5.0
    avg_restartability = sum(restartabilities) / len(restartabilities) if restartabilities else 5.0
    
    # Pull Phase 1 aggregate signals
    phase1_analysis = session.get("phase1_analysis") or {}
    critical_path   = set(phase1_analysis.get("critical_path", []))
    bottlenecks     = {b.get("job_id") for b in phase1_analysis.get("bottlenecks", [])}
    criticality_map = phase1_analysis.get("criticality_map", {})
    exec_metrics_all = session.get("exec_metrics", {})

    crit_scores = [v.get("score", 0) for v in criticality_map.values() if isinstance(v, dict)]
    avg_criticality = sum(crit_scores) / len(crit_scores) if crit_scores else 0.0

    no_restart_count = sum(
        1 for rm in risk_mods.values()
        if str(rm.get("restartability_score", 5)) in ("0", "1", "2", 0, 1, 2)
    )
    sla_breach_count = sum(
        1 for em in exec_metrics_all.values()
        if isinstance(em, dict) and em.get("sla_breaches", 0) > 0
    )

    stats = {
        "total_jobs": total_jobs,
        "high_risk_count": high_risk_count,
        "medium_risk_count": medium_risk_count,
        "low_risk_count": low_risk_count,
        "avg_tech_debt": avg_tech_debt,
        "avg_restartability": avg_restartability,
        # Phase 1 enrichment
        "critical_path_count": len(critical_path),
        "bottleneck_count": len(bottlenecks),
        "avg_criticality_score": round(avg_criticality, 1),
        "no_restart_count": no_restart_count,
        "sla_breach_count": sla_breach_count,
    }
    
    api_key = os.environ.get("GEMINI_API_KEY", "")  # legacy — rotation handled by gemini_client internally
    result = engine.perform_executive_summary(stats, api_key)
    session["executive_summary"] = result
    
    return {"success": True, "summary": result}


@router.get("/final-report/{session_id}")
def download_final_report(session_id: str):
    """
    Generate and download the redesigned 5-tab excel Batch Assessment Report.
    """
    session = _get_session(session_id)
    
    # Run auto-high level assessment if not already started
    if "high_level_assessments" not in session:
        session["high_level_assessments"] = engine.run_high_level_assessment(session)
        
    excel_bytes = generate_redesigned_excel_report(session)
    
    filename = f"Batch_Assessment_Report_{session_id[:8]}.xlsx"
    return StreamingResponse(
        io.BytesIO(excel_bytes),
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename={filename}"},
    )

# ── Private Helpers ───────────────────────────────────────────────
def _get_session(session_id: str) -> dict:
    session = sessions.get(session_id)
    if not session:
        raise HTTPException(404, f"Session {session_id} not found")
    return session


def _criticality_for(session: dict, job_id: str) -> dict:
    """Look up derived operational criticality for a job from Phase 1 analysis."""
    analysis = session.get("phase1_analysis")
    if not analysis:
        return {}
    return analysis.get("criticality_map", {}).get(job_id, {})


def _find_job(session: dict, job_id: str) -> dict:
    """
    Build a rich job_meta dict that includes ALL available Phase 1 signals:
    criticality, fan-in/out, critical path membership, dependency depth,
    schedule, platform, bottleneck flag, and execution history.
    These are passed into Gemini prompts to produce more accurate AI analysis.
    """
    analysis = session.get("phase1_analysis") or {}
    fan_metrics   = analysis.get("fan_metrics", {}).get(job_id, {})
    depth_map     = analysis.get("dependency_depth", {})
    critical_path = set(analysis.get("critical_path", []))
    bottlenecks   = {b.get("job_id") for b in analysis.get("bottlenecks", [])}

    def _enrich(job_meta: dict) -> dict:
        """Attach Phase 1 signals onto any job_meta dict."""
        crit = _criticality_for(session, job_id)
        job_meta["Criticality"]        = crit.get("legacy_band", "LOW")
        job_meta["CriticalityBand"]    = crit.get("band", "Low")
        job_meta["CriticalityScore"]   = crit.get("score", 0)
        job_meta["CriticalityReason"]  = crit.get("reason", "")
        job_meta["CriticalityFactors"] = crit.get("factors", [])
        # Fan metrics
        job_meta["FanIn"]    = fan_metrics.get("fan_in", 0)
        job_meta["FanOut"]   = fan_metrics.get("fan_out", 0)
        # Graph position
        job_meta["OnCriticalPath"]   = job_id in critical_path
        job_meta["DependencyDepth"]  = depth_map.get(job_id, 0)
        job_meta["IsBottleneck"]     = job_id in bottlenecks
        return job_meta

    # 1. Search in Phase 2 inventory upload first
    inventory = session.get("inventory", [])
    for j in inventory:
        if j.get("Job_ID") == job_id:
            # Also try to pick up Phase 1 schedule/platform from jobs list
            phase1_job = next(
                (jj for jj in session.get("jobs", []) if jj.get("JobId") == job_id), {}
            )
            job_meta = {
                "JobId":       j.get("Job_ID", ""),
                "JobName":     j.get("Job_Name", ""),
                "AppName":     j.get("Application", "Unknown"),
                "Source_File": j.get("Source_File", ""),
                "Source_Type": j.get("Source_Type", "Unknown"),
                "Platform":    phase1_job.get("Platform", ""),
                "Schedule":    phase1_job.get("Schedule", ""),
                "Owner":       phase1_job.get("Owner", ""),
                "Runtime":     phase1_job.get("Runtime", ""),
            }
            return _enrich(job_meta)

    # 2. Fall back to Phase 1 jobs list
    jobs = session.get("jobs", [])
    for j in jobs:
        if j.get("JobId") == job_id:
            job_meta = {
                "JobId":       j.get("JobId", ""),
                "JobName":     j.get("JobName", ""),
                "AppName":     j.get("AppName", "Unknown"),
                "Source_File": "",
                "Source_Type": j.get("Platform", "Unknown"),
                "Platform":    j.get("Platform", ""),
                "Schedule":    j.get("Schedule", ""),
                "Owner":       j.get("Owner", ""),
                "Runtime":     j.get("Runtime", ""),
            }
            return _enrich(job_meta)

    return _enrich({
        "JobId": job_id, "JobName": job_id, "AppName": "Unknown",
        "Source_File": "", "Source_Type": "Unknown",
        "Platform": "", "Schedule": "", "Owner": "", "Runtime": "",
    })
