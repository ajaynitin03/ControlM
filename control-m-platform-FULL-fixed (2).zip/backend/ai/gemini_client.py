"""
Gemini API client — uses google.genai (new SDK).
Handles key rotation across multiple free-tier keys, rate limiting,
429 backoff, retries, and structured JSON output.

Free tier limits per account (gemini-2.0-flash-lite-001 / Gemini 3.1 Flash Lite):
  - 15 RPM  (requests per minute)
  - 500 RPD (requests per day)
  - 250,000 TPM (tokens per minute)

Free tier limits (gemini-embedding-001):
  - 1,500 RPM
  - 100 RPD batch; generous on single embed calls

KEY ROTATION:
  Set one OR more keys in backend/.env:
    GEMINI_API_KEY=AIzaSy...            ← single key (minimum)
    GEMINI_API_KEY_2=AIzaSy...          ← optional extra key
    GEMINI_API_KEY_3=AIzaSy...          ← optional extra key
    ... up to GEMINI_API_KEY_15

  Keys are rotated round-robin per request so RPM limits are spread
  across all keys (15 RPM per account):
    1  key  =  15 RPM,   500 RPD
    5  keys =  75 RPM, 2,500 RPD
    10 keys = 150 RPM, 5,000 RPD
    15 keys = 225 RPM, 7,500 RPD
"""

from __future__ import annotations
import json, os, re, socket, time, logging, ssl, itertools
from typing import Any

try:
    ssl._create_default_https_context = ssl._create_unverified_context
except Exception:
    pass

logger = logging.getLogger(__name__)

# ── Model config ──────────────────────────────────────────────────
# Change this one line to switch generation model
_MODEL_NAME     = "gemini-2.0-flash-lite-001"   # Gemini 3.1 Flash Lite
_EMBED_MODEL    = "gemini-embedding-001"
_TIMEOUT_SECS   = 15          # per spec
_MAX_RETRIES    = 2           # per spec
_RETRY_DELAY    = 5.0         # seconds between retries (tighter free tier)
_RPM_SLEEP      = 4.5          # seconds between embedding calls (safe for 15 RPM free tier)

# ── Key registry ──────────────────────────────────────────────────
_keys: list[str] = []
_key_cycle = None             # itertools.cycle over _keys
_clients: dict[str, Any] = {}  # key → genai.Client (one client per key, cached)
_connectivity_checked = False
_connectivity_ok = True


def _load_keys() -> list[str]:
    """
    Load all API keys from environment.
    Reads GEMINI_API_KEY, GEMINI_API_KEY_2 … GEMINI_API_KEY_15.
    Returns deduplicated list of non-empty keys.
    """
    keys = []
    # Primary key
    k = os.environ.get("GEMINI_API_KEY", "").strip()
    if k:
        keys.append(k)
    # Extra keys
    for i in range(2, 16):
        k = os.environ.get(f"GEMINI_API_KEY_{i}", "").strip()
        if k and k not in keys:
            keys.append(k)
    return keys


def _init_keys():
    global _keys, _key_cycle
    if _keys:
        return
    _keys = _load_keys()
    if not _keys:
        logger.warning("[Gemini] No API keys found. Set GEMINI_API_KEY in backend/.env")
        return
    _key_cycle = itertools.cycle(_keys)
    logger.info(f"[Gemini] Loaded {len(_keys)} API key(s). Round-robin rotation enabled.")


def _next_client():
    """Return the next client in the rotation. Creates it lazily."""
    import google.genai as genai
    _init_keys()
    if not _keys:
        raise ValueError(
            "No Gemini API key configured.\n"
            "Add GEMINI_API_KEY=your_key to backend/.env and restart the server."
        )
    key = next(_key_cycle)
    if key not in _clients:
        _clients[key] = genai.Client(api_key=key)
        logger.info(f"[Gemini] Created client for key ...{key[-6:]}")
    return _clients[key]


def _embed_client():
    """
    For embeddings we always use the FIRST key (embeddings have high RPM,
    so rotation is less critical and using the same client avoids re-init overhead).
    """
    import google.genai as genai
    _init_keys()
    if not _keys:
        raise ValueError("No Gemini API key configured.")
    key = _keys[0]
    if key not in _clients:
        _clients[key] = genai.Client(api_key=key)
    return _clients[key]


# ── Network probe ─────────────────────────────────────────────────
def _gemini_reachable() -> bool:
    global _connectivity_checked, _connectivity_ok
    if _connectivity_checked:
        return _connectivity_ok
    try:
        sock = socket.create_connection(("generativelanguage.googleapis.com", 443), timeout=5)
        sock.close()
        _connectivity_ok = True
        logger.info("[Gemini] Network probe: reachable.")
    except Exception as e:
        logger.warning(f"[Gemini] Network probe failed: {e}")
        _connectivity_ok = False
    _connectivity_checked = True
    return _connectivity_ok


def reset_connectivity_check():
    global _connectivity_checked
    _connectivity_checked = False


class GeminiUnreachableError(RuntimeError):
    pass


# ── Generation ────────────────────────────────────────────────────
def call_gemini(prompt: str, expect_json: bool = True, retries: int = _MAX_RETRIES, delay: float = _RETRY_DELAY) -> Any:
    """
    Call Gemini with key rotation, 429 backoff, retry, and JSON extraction.
    Each retry uses the NEXT key in the rotation automatically.
    """
    if not _gemini_reachable():
        raise GeminiUnreachableError(
            "Cannot reach generativelanguage.googleapis.com. "
            "Check your network — Google's API may be blocked."
        )

    last_err = None
    for attempt in range(retries + 1):
        try:
            client = _next_client()
            response = client.models.generate_content(
                model=_MODEL_NAME,
                contents=prompt,
                config={"http_options": {"timeout": _TIMEOUT_SECS}},
            )
            text = response.text.strip()
            return _extract_json(text) if expect_json else text

        except Exception as e:
            last_err = e
            err_str = str(e).lower()
            # 429 rate limit — wait longer and switch key automatically (next call)
            if "429" in err_str or "quota" in err_str or "rate" in err_str:
                wait = delay * (attempt + 1) * 3   # 15s, 30s, 45s — needed for 15 RPM tier
                logger.warning(f"[Gemini] 429 rate limit on attempt {attempt+1}. Waiting {wait:.0f}s then retrying with next key...")
                time.sleep(wait)
            elif attempt < retries:
                logger.warning(f"[Gemini] Attempt {attempt+1} failed: {e}. Retrying in {delay}s...")
                time.sleep(delay)

    raise RuntimeError(f"Gemini call failed after {retries+1} attempts: {last_err}")


def embed_text(text: str, retries: int = 2) -> list[float] | None:
    """
    Embed a single text using gemini-embedding-001.
    Handles 429 with backoff. Returns None on failure (caller uses mock fallback).
    """
    for attempt in range(retries + 1):
        try:
            client = _embed_client()
            response = client.models.embed_content(model=_EMBED_MODEL, contents=text)
            # Handle both SDK shapes
            if hasattr(response, "embeddings") and response.embeddings:
                return list(response.embeddings[0].values)
            if hasattr(response, "embedding") and response.embedding:
                return list(response.embedding.values)
        except Exception as e:
            err_str = str(e).lower()
            if "429" in err_str or "quota" in err_str or "rate" in err_str:
                wait = _RPM_SLEEP * (attempt + 1) * 3
                logger.warning(f"[Gemini Embed] 429 on attempt {attempt+1}. Sleeping {wait:.1f}s...")
                time.sleep(wait)
            else:
                logger.warning(f"[Gemini Embed] Failed: {e}")
                return None
    return None


# ── JSON extraction ───────────────────────────────────────────────
def _extract_json(text: str) -> Any:
    cleaned = re.sub(r"```(?:json)?\s*", "", text)
    cleaned = re.sub(r"```\s*$", "", cleaned).strip()
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        pass
    for pattern in [r"\{[\s\S]*\}", r"\[[\s\S]*\]"]:
        m = re.search(pattern, cleaned)
        if m:
            try:
                return json.loads(m.group())
            except json.JSONDecodeError:
                pass
    logger.warning("[Gemini] Could not parse JSON — returning raw text")
    return {"raw_response": text, "parse_error": True}


def is_available() -> bool:
    _init_keys()
    return len(_keys) > 0


def key_count() -> int:
    _init_keys()
    return len(_keys)
