import networkx as nx
from fastapi import APIRouter, HTTPException
from models.schemas import ImpactRequest
from services.file_processor import get_session
from services.graph_service import (
    build_graph, apply_criticality, find_critical_path, get_impact_analysis,
    compute_fan_metrics, detect_cycles
)
from services.criticality_engine import compute_criticality_for_graph, summarize_distribution, GLOSSARY
from services.phase1_engine import run_phase1_analysis
from routers.upload import sessions

router = APIRouter()


def _get_exec_metrics(session_id: str) -> dict:
    return sessions.get(session_id, {}).get("exec_metrics", {})


@router.post("/impact")
async def impact_analysis(request: ImpactRequest):
    """Analyze impact if a specific job fails."""
    try:
        df = get_session(request.session_id)
    except KeyError:
        raise HTTPException(status_code=404, detail="Session not found")

    G = build_graph(df)
    affected = get_impact_analysis(G, request.job_id)

    # Enrich with job names
    job_map = dict(zip(df["JobId"], df["JobName"]))
    affected_enriched = [
        {"job_id": j, "job_name": job_map.get(j, j)} for j in affected
    ]

    return {
        "failed_job": request.job_id,
        "failed_job_name": job_map.get(request.job_id, request.job_id),
        "affected_jobs": affected_enriched,
        "affected_count": len(affected),
    }


@router.get("/critical-path/{session_id}")
async def get_critical_path(session_id: str):
    """Get the critical path (longest dependency chain), with derived criticality (CHANGE 4/5)."""
    try:
        df = get_session(session_id)
    except KeyError:
        raise HTTPException(status_code=404, detail="Session not found")

    G = build_graph(df)
    path = find_critical_path(G)
    fan_metrics = compute_fan_metrics(G)
    exec_metrics = _get_exec_metrics(session_id)
    criticality_map = compute_criticality_for_graph(G, path, fan_metrics, exec_metrics)

    job_map = dict(zip(df["JobId"], df["JobName"]))

    return {
        "critical_path": [
            {
                "job_id": j,
                "job_name": job_map.get(j, j),
                "criticality": criticality_map.get(j, {}).get("legacy_band", "LOW"),
                "criticality_band": criticality_map.get(j, {}).get("band", "Low"),
                "criticality_score": criticality_map.get(j, {}).get("score", 0),
                "criticality_factors": criticality_map.get(j, {}).get("factors", []),
                "criticality_reason": criticality_map.get(j, {}).get("reason", ""),
            }
            for j in path
        ],
        "path_length": len(path),
    }


@router.get("/fan-metrics/{session_id}")
async def get_fan_metrics(session_id: str):
    """Get fan-in / fan-out metrics for all jobs, with derived criticality (CHANGE 4/5)."""
    try:
        df = get_session(session_id)
    except KeyError:
        raise HTTPException(status_code=404, detail="Session not found")

    G = build_graph(df)
    fan = compute_fan_metrics(G)
    critical_path = find_critical_path(G)
    exec_metrics = _get_exec_metrics(session_id)
    criticality_map = compute_criticality_for_graph(G, critical_path, fan, exec_metrics)
    job_map = dict(zip(df["JobId"], df["JobName"]))

    metrics = [
        {
            "job_id": job_id,
            "job_name": job_map.get(job_id, job_id),
            "criticality": criticality_map.get(job_id, {}).get("legacy_band", "LOW"),
            "criticality_band": criticality_map.get(job_id, {}).get("band", "Low"),
            "criticality_score": criticality_map.get(job_id, {}).get("score", 0),
            "criticality_factors": criticality_map.get(job_id, {}).get("factors", []),
            "criticality_reason": criticality_map.get(job_id, {}).get("reason", ""),
            "fan_in": vals["fan_in"],
            "fan_out": vals["fan_out"],
            "total_connections": vals["fan_in"] + vals["fan_out"],
        }
        for job_id, vals in fan.items()
    ]
    # Sort by fan_out and criticality_score descending
    metrics.sort(key=lambda x: (x["fan_out"], x["criticality_score"]), reverse=True)

    return {"metrics": metrics, "count": len(metrics)}


@router.get("/cycles/{session_id}")
async def get_cycles(session_id: str):
    """Detect and return all cycles."""
    try:
        df = get_session(session_id)
    except KeyError:
        raise HTTPException(status_code=404, detail="Session not found")

    G = build_graph(df)
    has_cycles, cycles = detect_cycles(G)
    job_map = dict(zip(df["JobId"], df["JobName"]))

    enriched_cycles = [
        [{"job_id": j, "job_name": job_map.get(j, j)} for j in cycle]
        for cycle in cycles
    ]

    return {
        "has_cycles": has_cycles,
        "cycle_count": len(cycles),
        "cycles": enriched_cycles,
    }


@router.get("/criticality-distribution/{session_id}")
async def get_criticality_distribution(session_id: str):
    """Criticality Distribution + Top Bottlenecks + Critical Jobs (CHANGE 5 / CHANGE 7)."""
    try:
        df = get_session(session_id)
    except KeyError:
        raise HTTPException(status_code=404, detail="Session not found")

    session = sessions.get(session_id, {})
    analysis = session.get("phase1_analysis")
    if analysis is None:
        exec_metrics = _get_exec_metrics(session_id)
        analysis = run_phase1_analysis(df, exec_metrics)

    job_map = dict(zip(df["JobId"], df["JobName"]))
    bottlenecks = [
        {**b, "job_name": job_map.get(b["job_id"], b["job_id"])}
        for b in analysis["bottlenecks"]
    ]

    return {
        "session_id": session_id,
        "criticality_distribution": analysis["criticality_distribution"],
        "top_bottlenecks": bottlenecks,
        "critical_jobs": analysis["critical_jobs"],
        "glossary": GLOSSARY,
    }


@router.get("/criticality/{session_id}/{job_id}")
async def get_job_criticality_detail(session_id: str, job_id: str):
    """Full score breakdown for a single job's criticality badge (CHANGE 12 — 'Why?' tooltip)."""
    try:
        df = get_session(session_id)
    except KeyError:
        raise HTTPException(status_code=404, detail="Session not found")

    G = build_graph(df)
    critical_path = find_critical_path(G)
    fan_metrics = compute_fan_metrics(G)
    exec_metrics = _get_exec_metrics(session_id)
    criticality_map = compute_criticality_for_graph(G, critical_path, fan_metrics, exec_metrics)

    result = criticality_map.get(job_id)
    if not result:
        raise HTTPException(status_code=404, detail=f"Job {job_id} not found in session")

    # Enrich with Phase 1 job metadata from G.nodes
    node_data = G.nodes.get(job_id, {})
    result["job_details"] = {
        "job_id": job_id,
        "job_name": node_data.get("label") or job_id,
        "app_name": node_data.get("app_name") or "Unknown",
        "platform": node_data.get("platform") or "",
        "schedule": node_data.get("schedule") or "",
        "runtime": node_data.get("runtime") or "",
        "owner": node_data.get("owner") or "",
        "description": node_data.get("description") or "",
        "status": node_data.get("status") or "",
        "folder": node_data.get("folder") or "",
        "priority": node_data.get("priority") or "",
        "retries": node_data.get("retries") or "",
    }

    return result


@router.get("/summary/{session_id}")
async def get_summary(session_id: str):
    """Get overall graph statistics summary, with derived criticality (CHANGE 4/5)."""
    try:
        df = get_session(session_id)
    except KeyError:
        raise HTTPException(status_code=404, detail="Session not found")

    G = build_graph(df)
    has_cycles, cycles = detect_cycles(G)
    critical_path = find_critical_path(G)
    fan_metrics = compute_fan_metrics(G)
    exec_metrics = _get_exec_metrics(session_id)
    criticality_map = compute_criticality_for_graph(G, critical_path, fan_metrics, exec_metrics)
    distribution = summarize_distribution(criticality_map)
    crit_counts = distribution["distribution"]

    # Root nodes (no predecessors)
    root_nodes = [n for n in G.nodes() if G.in_degree(n) == 0]
    # Leaf nodes (no successors)
    leaf_nodes = [n for n in G.nodes() if G.out_degree(n) == 0]

    return {
        "total_jobs": len(df),
        "total_edges": G.number_of_edges(),
        "high_criticality": crit_counts.get("High", 0),
        "medium_criticality": crit_counts.get("Medium", 0),
        "low_criticality": crit_counts.get("Low", 0),
        "critical_criticality": crit_counts.get("Critical", 0),
        "has_cycles": has_cycles,
        "cycle_count": len(cycles),
        "critical_path_length": len(critical_path),
        "root_jobs": len(root_nodes),
        "leaf_jobs": len(leaf_nodes),
        "isolated_jobs": len(list(nx_isolated(G))),
    }


def nx_isolated(G):
    """Helper to find isolated nodes."""
    return [n for n in G.nodes() if G.degree(n) == 0]
