"""
Phase 2 AI Assessment router.
Handles Inventory upload, Source upload, Assessment orchestration, Caching, and Redesigned Report export.
"""

from __future__ import annotations
import logging
import io
import pandas as pd
from typing import Optional, List
from fastapi import APIRouter, HTTPException, UploadFile, File, Query
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

import os
from ai import assessment_engine as engine
from ai.rag_source_code import get_store, clear_store
from ai.gemini_client import is_available, call_gemini, key_count
from ai.report_generator import (
    generate_redesigned_excel_report,
    generate_redesigned_pdf_report,
    generate_redesigned_csv_report,
    get_consolidated_jobs
)
from ai.failure_log_parser import parse_failure_log, match_log_to_job

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/ai", tags=["Phase-2 AI"])

# Reference the memory session store from the upload router
from routers.upload import sessions

# ════════════════════════════════════════════════════════════════════
# STATUS
# ════════════════════════════════════════════════════════════════════

# Load supported models configuration
import json as _json
MODELS_CONFIG_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "ai", "models_config.json")
try:
    with open(MODELS_CONFIG_PATH, "r") as f:
        SUPPORTED_MODELS = _json.load(f)
except Exception:
    SUPPORTED_MODELS = [
        {"id": "gemini-2.0-flash", "name": "Gemini 2.0 Flash"},
        {"id": "gemini-1.5-flash", "name": "Gemini 1.5 Flash"},
        {"id": "gemini-1.5-pro", "name": "Gemini 1.5 Pro"}
    ]

@router.get("/models")
def get_supported_models():
    """Returns list of supported AI models."""
    return SUPPORTED_MODELS

@router.post("/select-model/{session_id}")
def select_model(session_id: str, model_id: str = Query(...)):
    """Sets the active model in the session and invalidates downstream caches."""
    session = _get_session(session_id)
    session["selected_model"] = model_id
    # Reset AI caches to force regeneration with new model
    session["detailed_ai_cache"] = {}
    session["risk_mods_cache"] = {}
    session["conversions_cache"] = {}
    if "executive_summary" in session:
        del session["executive_summary"]
    return {"success": True, "selected_model": model_id}

@router.get("/job-source/{session_id}/{job_id}")
def get_job_source_code(session_id: str, job_id: str):
    """Retrieve original source code for job side-by-side comparison."""
    session = _get_session(session_id)
    inventory = session.get("inventory", [])
    source_files = session.get("source_code_files", {})
    
    # Get mapped file
    src_file = ""
    for j in inventory:
        if j.get("Job_ID") == job_id:
            src_file = j.get("Source_File", "")
            break
            
    code = ""
    if src_file:
        src_file_clean = src_file.strip().lower()
        for fname, content in source_files.items():
            fname_clean = fname.strip().lower()
            if (fname_clean == src_file_clean or 
                fname_clean.endswith("/" + src_file_clean) or 
                fname_clean.endswith("\\" + src_file_clean) or
                os.path.basename(fname_clean) == os.path.basename(src_file_clean)):
                code = content
                break
    return {"success": True, "job_id": job_id, "source_file": src_file, "source_code": code}

@router.get("/status/{session_id}")
def get_assessment_status(session_id: str):
    """
    Checks if setup inputs are uploaded and returns setup status.
    Also performs a live connectivity probe to Google's API on first call.
    """
    session = _get_session(session_id)
    inventory = session.get("inventory", [])
    source_files = session.get("source_code_files", {})
    failure_logs = session.get("failure_logs", {})
    
    key_configured = is_available()

    return {
        "gemini_available": key_configured,
        "gemini_key_configured": key_configured,
        "gemini_network_reachable": key_configured,  # httpx handles SSL; if key exists, we try
        "gemini_key_count": key_count(),
        "inventory_uploaded": len(inventory) > 0,
        "inventory_jobs_count": len(inventory),
        "source_uploaded": len(source_files) > 0,
        "source_files_count": len(source_files),
        "failure_logs_uploaded": len(failure_logs) > 0,
        "failure_logs_count": len(failure_logs),
        "assessment_started": "high_level_assessments" in session,
        "selected_model": session.get("selected_model", "gemini-3.1-flash")
    }

# ════════════════════════════════════════════════════════════════════
# INPUT SETUP UPLOADS
# ════════════════════════════════════════════════════════════════════

@router.post("/upload-inventory/{session_id}")
async def upload_inventory(session_id: str, file: UploadFile = File(...)):
    """
    Upload and validate the Job Inventory CSV.
    Required Columns: Job_ID, Job_Name, Application, Source_File, Source_Type
    """
    session = _get_session(session_id)
    content = await file.read()
    
    try:
        # Load CSV
        df = pd.read_csv(io.BytesIO(content), dtype=str)
    except Exception as e:
        raise HTTPException(422, f"Failed to parse CSV: {str(e)}")
        
    required_cols = {"Job_ID", "Job_Name", "Application", "Source_File", "Source_Type"}
    missing = required_cols - set(df.columns)
    if missing:
        raise HTTPException(
            status_code=422,
            detail={
                "error": "Missing Required Columns",
                "missing": list(missing),
                "required": list(required_cols)
            }
        )
        
    # Store in session
    inventory_records = df.fillna("").to_dict(orient="records")
    session["inventory"] = inventory_records
    
    return {
        "success": True,
        "message": f"Successfully loaded {len(inventory_records)} inventory jobs",
        "row_count": len(inventory_records),
        "columns": list(df.columns)
    }


@router.post("/upload-source/{session_id}")
async def upload_source_code(session_id: str, files: List[UploadFile] = File(...)):
    """
    Upload source code files (supports multiple file uploads).
    """
    session = _get_session(session_id)
    source_files = session.setdefault("source_code_files", {})
    
    uploaded_count = 0
    for file in files:
        filename = file.filename
        try:
            content_bytes = await file.read()
            content = content_bytes.decode("utf-8", errors="ignore")
            source_files[filename] = content
            uploaded_count += 1
        except Exception as e:
            logger.warning(f"Failed to read source file {filename}: {e}")
            
    return {
        "success": True,
        "message": f"Successfully uploaded {uploaded_count} source files",
        "total_source_files": len(source_files)
    }


@router.post("/upload-failure-logs/{session_id}")
async def upload_failure_logs(session_id: str, files: List[UploadFile] = File(...)):
    """
    Upload one or more Control-M (or generic scheduler) failure log files (.log / .txt).
    Each file is parsed independently and auto-matched to a Job_ID from the AI Assessment
    inventory (by structured 'Job ID:' field, filename, or raw-text scan, in that priority order).

    NOTE: requires the AI Assessment Job Inventory (uploaded via /upload-inventory) to
    already be present in the session — logs are matched against that inventory's Job_IDs.

    Supports multiple files at once — e.g. if 3 jobs failed in a 14-job batch, upload
    3 separate log files and each will be matched to its own job automatically.
    """
    session = _get_session(session_id)
    inventory = session.get("inventory", [])
    failure_logs = session.setdefault("failure_logs", {})  # job_id -> parsed log dict
    unmatched = session.setdefault("unmatched_failure_logs", [])  # list of filenames

    matched_count = 0
    unmatched_this_batch = []

    for file in files:
        filename = file.filename
        try:
            content_bytes = await file.read()
            content = content_bytes.decode("utf-8", errors="ignore")
        except Exception as e:
            logger.warning(f"Failed to read failure log {filename}: {e}")
            continue

        parsed = parse_failure_log(filename, content)
        job_id = match_log_to_job(parsed, inventory)

        if job_id:
            # If multiple logs map to the same job, keep the most recent upload (overwrite)
            failure_logs[job_id] = parsed
            matched_count += 1
        else:
            unmatched.append(filename)
            unmatched_this_batch.append(filename)

    # If any of these jobs already have cached Detailed AI / Risk results, invalidate
    # them so the next view re-runs analysis WITH the new failure log evidence.
    detailed_cache = session.setdefault("detailed_ai_cache", {})
    risk_cache = session.setdefault("risk_mods_cache", {})
    for jid in list(failure_logs.keys()):
        detailed_cache.pop(jid, None)
        risk_cache.pop(jid, None)

    # Build a clear, actionable message — especially when the inventory itself is
    # empty, since "0 matched" alone doesn't tell the user why.
    if not inventory and unmatched_this_batch:
        message = (
            f"Could not match any of the {len(files)} log file(s) — no Job Inventory has been "
            "uploaded yet for this session. Upload the Job Inventory CSV above first, then "
            "re-upload these failure log(s)."
        )
    else:
        message = f"Processed {len(files)} log file(s): {matched_count} matched to jobs, {len(unmatched_this_batch)} unmatched."

    return {
        "success": True,
        "message": message,
        "matched_count": matched_count,
        "unmatched_files": unmatched_this_batch,
        "total_failure_logs": len(failure_logs),
        "inventory_empty": len(inventory) == 0,
    }


@router.get("/failure-logs/{session_id}")
def list_failure_logs(session_id: str):
    """List all uploaded failure logs and which job each was matched to."""
    session = _get_session(session_id)
    failure_logs = session.get("failure_logs", {})
    unmatched = session.get("unmatched_failure_logs", [])
    return {
        "success": True,
        "logs": [
            {
                "job_id": jid,
                "filename": log.get("filename", ""),
                "status": log.get("status") or log.get("final_status", ""),
                "severity": log.get("severity", ""),
                "root_cause": log.get("root_cause", ""),
            }
            for jid, log in failure_logs.items()
        ],
        "unmatched_files": unmatched,
    }


@router.delete("/failure-logs/{session_id}/{job_id}")
def delete_failure_log(session_id: str, job_id: str):
    """Remove a single job's failure log (e.g. user uploaded the wrong file)."""
    session = _get_session(session_id)
    failure_logs = session.get("failure_logs", {})
    if job_id in failure_logs:
        del failure_logs[job_id]
        session.get("detailed_ai_cache", {}).pop(job_id, None)
        session.get("risk_mods_cache", {}).pop(job_id, None)
        return {"success": True, "message": f"Failure log removed for {job_id}"}
    raise HTTPException(404, f"No failure log found for job {job_id}")



def clear_inputs(session_id: str):
    """Reset Inventory, Source code, and Failure Log uploads for the session."""
    session = _get_session(session_id)
    session["inventory"] = []
    session["source_code_files"] = {}
    session["failure_logs"] = {}
    session["unmatched_failure_logs"] = []
    if "high_level_assessments" in session:
        del session["high_level_assessments"]
    
    # Clear this session's vector store
    clear_store(session_id)
    
    return {"success": True, "message": "Setup inputs cleared"}

# ════════════════════════════════════════════════════════════════════
# START ASSESSMENT
# ════════════════════════════════════════════════════════════════════

@router.post("/start-assessment/{session_id}")
def start_assessment(session_id: str):
    """
    Builds the RAG vector index and generates rules-based High Level Assessments.
    """
    session = _get_session(session_id)
    inventory = session.get("inventory", [])
    source_files = session.get("source_code_files", {})
    
    if not inventory:
        raise HTTPException(400, "Job Inventory CSV must be uploaded first.")
    if not source_files:
        raise HTTPException(400, "Source code files must be uploaded first.")
        
    logger.info(f"[StartAssessment] Building RAG index for session={session_id}...")
    
    # 1. Get or create this session's isolated vector store
    rag_store = get_store(session_id)
    rag_store.clear()
    
    # 2. Add source code chunks and map to inventory jobs
    for filename, content in source_files.items():
        # Find which jobs use this file (matching base filename case-insensitively)
        base_filename = filename.strip().lower()
        mapped_jobs = []
        for job in inventory:
            job_file = job.get("Source_File", "").strip().lower()
            if job_file and (job_file == base_filename or 
                             base_filename.endswith("/" + job_file) or 
                             base_filename.endswith("\\" + job_file) or
                             os.path.basename(base_filename) == os.path.basename(job_file)):
                mapped_jobs.append(job)
                
        rag_store.add_source_file(filename, content, mapped_jobs)
        
    # 3. Generate embeddings
    api_key = os.environ.get("GEMINI_API_KEY", "")  # legacy — rotation handled by gemini_client internally
    rag_store.generate_embeddings(api_key)
    
    # 4. Execute rules-based High Level Assessment (instant, zero tokens!)
    high_level = engine.run_high_level_assessment(session)
    session["high_level_assessments"] = high_level
    
    # 5. Initialize AI caches
    session["detailed_ai_cache"] = {}
    session["risk_mods_cache"] = {}
    session["conversions_cache"] = {}
    
    return {
        "success": True,
        "message": f"Assessment initialized. Indexed {len(rag_store.chunks)} chunks. High Level Assessment ready.",
        "jobs_assessed": len(high_level)
    }

# ════════════════════════════════════════════════════════════════════
# SUBMODULE 2 — GET HIGH LEVEL ASSESSMENTS
# ════════════════════════════════════════════════════════════════════

@router.get("/high-level/{session_id}")
def get_high_level_assessments(session_id: str):
    session = _get_session(session_id)
    high_level = session.get("high_level_assessments", {})
    if not high_level:
        raise HTTPException(400, "Assessment has not been started yet.")
        
    return {
        "success": True,
        "assessments": list(high_level.values())
    }

# ════════════════════════════════════════════════════════════════════
# SUBMODULE 3 — DETAILED AI ANALYSIS (With Caching)
# ════════════════════════════════════════════════════════════════════

@router.post("/detailed-analysis/{session_id}/{job_id}")
def detailed_analysis(session_id: str, job_id: str):
    session = _get_session(session_id)
    cache = session.setdefault("detailed_ai_cache", {})
    
    # Check cache
    if job_id in cache:
        logger.info(f"[Detailed AI] Cache hit for job_id={job_id}")
        return {"success": True, "cached": True, "analysis": cache[job_id]}
        
    # Run analysis
    job_meta = _find_job(session, job_id)
    api_key = os.environ.get("GEMINI_API_KEY", "")  # legacy — rotation handled by gemini_client internally
    model = session.get("selected_model", "")
    
    result = engine.perform_detailed_analysis(job_meta, api_key, session_id, model=model)
    cache[job_id] = result
    
    return {"success": True, "cached": False, "analysis": result}

# ════════════════════════════════════════════════════════════════════
# SUBMODULE 4 — RISK & MODERNIZATION (With Caching)
# ════════════════════════════════════════════════════════════════════

@router.post("/risk-modernization/{session_id}/{job_id}")
def risk_modernization(session_id: str, job_id: str):
    session = _get_session(session_id)
    cache = session.setdefault("risk_mods_cache", {})
    
    # Check cache
    if job_id in cache:
         return {"success": True, "cached": True, "result": cache[job_id]}
         
    job_meta = _find_job(session, job_id)
    model = session.get("selected_model", "")
    
    # Gather high-level & detailed analysis metadata inputs
    high_level = session.get("high_level_assessments", {}).get(job_id, {})
    
    # Trigger detailed AI analysis if not already cached (ensures it is available)
    detailed_cache = session.setdefault("detailed_ai_cache", {})
    if job_id not in detailed_cache:
        detailed = engine.perform_detailed_analysis(job_meta, session_id=session_id, model=model)
        detailed_cache[job_id] = detailed
    else:
        detailed = detailed_cache[job_id]
        
    # Get execution history metrics (Phase 1)
    exec_metrics = session.get("exec_metrics", {}).get(job_id, {})
    
    api_key = os.environ.get("GEMINI_API_KEY", "")  # legacy — rotation handled by gemini_client internally
    result = engine.perform_risk_modernization(job_meta, high_level, detailed, exec_metrics, api_key, model=model)
    cache[job_id] = result
    
    return {"success": True, "cached": False, "result": result}

# ════════════════════════════════════════════════════════════════════
# SUBMODULE 5 — JOB CONVERSION (With Caching)
# ════════════════════════════════════════════════════════════════════

@router.post("/convert-job/{session_id}/{job_id}")
def convert_job(session_id: str, job_id: str, target_technology: str = Query(...)):
    session = _get_session(session_id)
    cache = session.setdefault("conversions_cache", {})
    cache_key = f"{job_id}_{target_technology}"
    
    # Check cache
    if cache_key in cache:
        return {"success": True, "cached": True, "conversion": cache[cache_key]}
        
    job_meta = _find_job(session, job_id)
    
    # Find full source code content for this job
    inventory = session.get("inventory", [])
    source_files = session.get("source_code_files", {})
    
    # Get mapped file
    src_file = ""
    for j in inventory:
        if j.get("Job_ID") == job_id:
            src_file = j.get("Source_File", "")
            break
            
    code = ""
    if src_file:
        src_file_clean = src_file.strip().lower()
        for fname, content in source_files.items():
            fname_clean = fname.strip().lower()
            if (fname_clean == src_file_clean or 
                fname_clean.endswith("/" + src_file_clean) or 
                fname_clean.endswith("\\" + src_file_clean) or
                os.path.basename(fname_clean) == os.path.basename(src_file_clean)):
                code = content
                break
                
    api_key = os.environ.get("GEMINI_API_KEY", "")  # legacy — rotation handled by gemini_client internally
    model = session.get("selected_model", "")
    result = engine.perform_job_conversion(job_meta, code, target_technology, api_key, model=model)
    cache[cache_key] = result
    
    return {"success": True, "cached": False, "conversion": result}

# ════════════════════════════════════════════════════════════════════
# SUBMODULE 6 — SUMMARY & EXPORT
# ════════════════════════════════════════════════════════════════════

@router.post("/executive-summary/{session_id}")
def get_executive_summary(session_id: str):
    session = _get_session(session_id)
    session["session_id"] = session_id  # Save session_id in the session dict!
    
    # Run auto-high level assessment if not already started
    if "high_level_assessments" not in session:
        session["high_level_assessments"] = engine.run_high_level_assessment(session)
        
    # Pre-populate all caches (detailed analysis, risk mods, conversions) for all jobs in the session
    jobs = session.get("jobs", [])
    model = session.get("selected_model", "gemini-2.5-flash")
    
    detailed_cache = session.setdefault("detailed_ai_cache", {})
    risk_cache = session.setdefault("risk_mods_cache", {})
    conversions_cache = session.setdefault("conversions_cache", {})
    
    for job in jobs:
        jid = job.get("JobId", "")
        if not jid:
            continue
        
        job_meta = _find_job(session, jid)
        
        # 1. Detailed AI Cache
        if jid not in detailed_cache:
            detailed_cache[jid] = engine.perform_detailed_analysis(job_meta, session_id=session_id, model=model)
            
        # 2. Risk Modernization Cache
        if jid not in risk_cache:
            hl = session.get("high_level_assessments", {}).get(jid, {})
            exec_metrics = session.get("exec_metrics", {}).get(jid, {})
            api_key = os.environ.get("GEMINI_API_KEY", "")
            risk_cache[jid] = engine.perform_risk_modernization(job_meta, hl, detailed_cache[jid], exec_metrics, api_key, model=model)
            
        # 3. Conversions Cache
        rm_val = risk_cache.get(jid, {})
        target_tech = rm_val.get("target_technology")
        if not target_tech:
            hl_val = session.get("high_level_assessments", {}).get(jid, {})
            rec = hl_val.get("modernization_recommendation", "Python")
            if "pyspark" in rec.lower():
                target_tech = "PySpark"
            elif "spring" in rec.lower():
                target_tech = "Spring Batch"
            elif "java" in rec.lower():
                target_tech = "Java"
            else:
                target_tech = "Python"
        cache_key = f"{jid}_{target_tech}"
        if cache_key not in conversions_cache:
            inventory = session.get("inventory", [])
            source_files = session.get("source_code_files", {})
            src_file = ""
            for j in inventory:
                if j.get("Job_ID") == jid:
                    src_file = j.get("Source_File", "")
                    break
            code = ""
            if src_file:
                src_file_clean = src_file.strip().lower()
                for fname, content in source_files.items():
                    fname_clean = fname.strip().lower()
                    if (fname_clean == src_file_clean or 
                        fname_clean.endswith("/" + src_file_clean) or 
                        fname_clean.endswith("\\" + src_file_clean) or
                        os.path.basename(fname_clean) == os.path.basename(src_file_clean)):
                        code = content
                        break
            api_key = os.environ.get("GEMINI_API_KEY", "")
            conversions_cache[cache_key] = engine.perform_job_conversion(job_meta, code, target_tech, api_key, model=model)

    high_level = session.get("high_level_assessments", {})
    risk_mods = session.setdefault("risk_mods_cache", {})
    total_jobs = len(high_level)
    
    # Aggregate statistics
    high_risk_count = 0
    medium_risk_count = 0
    low_risk_count = 0
    for hl in high_level.values():
        risk = hl.get("risk_indicator", "LOW")
        if risk == "HIGH":
            high_risk_count += 1
        elif risk == "MEDIUM":
            medium_risk_count += 1
        else:
            low_risk_count += 1
            
    debts = []
    restartabilities = []
    for rm in risk_mods.values():
        debts.append(rm.get("technical_debt_score", 5))
        restartabilities.append(rm.get("restartability_score", 5))
        
    avg_tech_debt = sum(debts) / len(debts) if debts else 5.0
    avg_restartability = sum(restartabilities) / len(restartabilities) if restartabilities else 5.0
    
    # Pull Phase 1 aggregate signals
    phase1_analysis = session.get("phase1_analysis") or {}
    critical_path   = set(phase1_analysis.get("critical_path", []))
    bottlenecks     = {b.get("job_id") for b in phase1_analysis.get("bottlenecks", [])}
    criticality_map = phase1_analysis.get("criticality_map", {})
    exec_metrics_all = session.get("exec_metrics", {})

    crit_scores = [v.get("score", 0) for v in criticality_map.values() if isinstance(v, dict)]
    avg_criticality = sum(crit_scores) / len(crit_scores) if crit_scores else 0.0

    no_restart_count = sum(
        1 for rm in risk_mods.values()
        if str(rm.get("restartability_score", 5)) in ("0", "1", "2", 0, 1, 2)
    )
    sla_breach_count = sum(
        1 for em in exec_metrics_all.values()
        if isinstance(em, dict) and em.get("sla_breaches", 0) > 0
    )

    stats = {
        "total_jobs": total_jobs,
        "high_risk_count": high_risk_count,
        "medium_risk_count": medium_risk_count,
        "low_risk_count": low_risk_count,
        "avg_tech_debt": avg_tech_debt,
        "avg_restartability": avg_restartability,
        # Phase 1 enrichment
        "critical_path_count": len(critical_path),
        "bottleneck_count": len(bottlenecks),
        "avg_criticality_score": round(avg_criticality, 1),
        "no_restart_count": no_restart_count,
        "sla_breach_count": sla_breach_count,
    }
    
    api_key = os.environ.get("GEMINI_API_KEY", "")  # legacy — rotation handled by gemini_client internally
    model = session.get("selected_model", "")
    result = engine.perform_executive_summary(stats, api_key, model=model)
    session["executive_summary"] = result
    
    return {"success": True, "summary": result}


@router.get("/final-report/{session_id}")
def download_final_report(session_id: str, module: str = Query("everything"), format: str = Query("xlsx")):
    """
    Generate and download the report in xlsx, pdf, or csv format (either a single module or consolidated).
    """
    session = _get_session(session_id)
    session["session_id"] = session_id  # Save session_id in the session dict!
    
    # Run auto-high level assessment if not already started
    if "high_level_assessments" not in session:
        session["high_level_assessments"] = engine.run_high_level_assessment(session)
        
    # Pre-populate all caches (detailed analysis, risk mods, conversions) for all jobs in the session
    jobs = get_consolidated_jobs(session)
    model = session.get("selected_model", "gemini-3.1-flash")
    
    detailed_cache = session.setdefault("detailed_ai_cache", {})
    risk_cache = session.setdefault("risk_mods_cache", {})
    conversions_cache = session.setdefault("conversions_cache", {})
    
    for job in jobs:
        jid = job.get("JobId", "")
        if not jid:
            continue
        
        job_meta = _find_job(session, jid)
        
        # 1. Detailed AI Cache
        if jid not in detailed_cache:
            detailed_cache[jid] = engine.perform_detailed_analysis(job_meta, session_id=session_id, model=model)
            
        # 2. Risk Modernization Cache
        if jid not in risk_cache:
            hl = session.get("high_level_assessments", {}).get(jid, {})
            exec_metrics = session.get("exec_metrics", {}).get(jid, {})
            api_key = os.environ.get("GEMINI_API_KEY", "")
            risk_cache[jid] = engine.perform_risk_modernization(job_meta, hl, detailed_cache[jid], exec_metrics, api_key, model=model)
            
        # 3. Conversions Cache
        rm_val = risk_cache.get(jid, {})
        target_tech = rm_val.get("target_technology")
        if not target_tech:
            hl_val = session.get("high_level_assessments", {}).get(jid, {})
            rec = hl_val.get("modernization_recommendation", "Python")
            if "pyspark" in rec.lower():
                target_tech = "PySpark"
            elif "spring" in rec.lower():
                target_tech = "Spring Batch"
            elif "java" in rec.lower():
                target_tech = "Java"
            else:
                target_tech = "Python"
        cache_key = f"{jid}_{target_tech}"
        if cache_key not in conversions_cache:
            inventory = session.get("inventory", [])
            source_files = session.get("source_code_files", {})
            src_file = ""
            for j in inventory:
                if j.get("Job_ID") == jid:
                    src_file = j.get("Source_File", "")
                    break
            code = ""
            if src_file:
                src_file_clean = src_file.strip().lower()
                for fname, content in source_files.items():
                    fname_clean = fname.strip().lower()
                    if (fname_clean == src_file_clean or 
                        fname_clean.endswith("/" + src_file_clean) or 
                        fname_clean.endswith("\\" + src_file_clean) or
                        os.path.basename(fname_clean) == os.path.basename(src_file_clean)):
                        code = content
                        break
            api_key = os.environ.get("GEMINI_API_KEY", "")
            conversions_cache[cache_key] = engine.perform_job_conversion(job_meta, code, target_tech, api_key, model=model)

    if module == "highlevel":
        base_name = f"High_Level_Report_{session_id[:8]}"
    elif module == "detailed":
        base_name = f"Detailed_Report_{session_id[:8]}"
    elif module == "riskmods":
        base_name = f"Risk_Report_{session_id[:8]}"
    elif module == "convert":
        base_name = f"Conversion_Report_{session_id[:8]}"
    elif module == "summary":
        base_name = f"Executive_Summary_Report_{session_id[:8]}"
    else:
        base_name = f"Complete_Assessment_{session_id[:8]}"

    if format == "pdf":
        pdf_bytes = generate_redesigned_pdf_report(session, module=module)
        return StreamingResponse(
            io.BytesIO(pdf_bytes),
            media_type="application/pdf",
            headers={"Content-Disposition": f"attachment; filename={base_name}.pdf"},
        )
    elif format == "csv":
        csv_bytes = generate_redesigned_csv_report(session, module=module)
        return StreamingResponse(
            io.BytesIO(csv_bytes),
            media_type="text/csv",
            headers={"Content-Disposition": f"attachment; filename={base_name}.csv"},
        )
    else:
        excel_bytes = generate_redesigned_excel_report(session, module=module)
        return StreamingResponse(
            io.BytesIO(excel_bytes),
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f"attachment; filename={base_name}.xlsx"},
        )

# ── Private Helpers ───────────────────────────────────────────────
def _get_session(session_id: str) -> dict:
    session = sessions.get(session_id)
    if not session:
        raise HTTPException(404, f"Session {session_id} not found")
    return session


def _criticality_for(session: dict, job_id: str) -> dict:
    """Look up derived operational criticality for a job from Phase 1 analysis."""
    analysis = session.get("phase1_analysis")
    if not analysis:
        return {}
    return analysis.get("criticality_map", {}).get(job_id, {})


def _find_job(session: dict, job_id: str) -> dict:
    """
    Build a rich job_meta dict that includes ALL available Phase 1 signals:
    criticality, fan-in/out, critical path membership, dependency depth,
    schedule, platform, bottleneck flag, and execution history.
    These are passed into Gemini prompts to produce more accurate AI analysis.
    """
    analysis = session.get("phase1_analysis") or {}
    fan_metrics   = analysis.get("fan_metrics", {}).get(job_id, {})
    depth_map     = analysis.get("dependency_depth", {})
    critical_path = set(analysis.get("critical_path", []))
    bottlenecks   = {b.get("job_id") for b in analysis.get("bottlenecks", [])}

    def _enrich(job_meta: dict) -> dict:
        """Attach Phase 1 signals + matched Failure Log evidence onto any job_meta dict."""
        crit = _criticality_for(session, job_id)
        job_meta["Criticality"]        = crit.get("legacy_band", "LOW")
        job_meta["CriticalityBand"]    = crit.get("band", "Low")
        job_meta["CriticalityScore"]   = crit.get("score", 0)
        job_meta["CriticalityReason"]  = crit.get("reason", "")
        job_meta["CriticalityFactors"] = crit.get("factors", [])
        # Fan metrics
        job_meta["FanIn"]    = fan_metrics.get("fan_in", 0)
        job_meta["FanOut"]   = fan_metrics.get("fan_out", 0)
        # Graph position
        job_meta["OnCriticalPath"]   = job_id in critical_path
        job_meta["DependencyDepth"]  = depth_map.get(job_id, 0)
        job_meta["IsBottleneck"]     = job_id in bottlenecks
        # Failure log evidence (Submodule 3/4 enrichment) — present only if user uploaded one
        failure_log = session.get("failure_logs", {}).get(job_id)
        job_meta["FailureLog"] = failure_log
        job_meta["HasFailureLog"] = failure_log is not None
        return job_meta

    # 1. Search in Phase 2 inventory upload first
    inventory = session.get("inventory", [])
    for j in inventory:
        if j.get("Job_ID") == job_id:
            # Also try to pick up Phase 1 schedule/platform from jobs list
            phase1_job = next(
                (jj for jj in session.get("jobs", []) if jj.get("JobId") == job_id), {}
            )
            job_meta = {
                "JobId":       j.get("Job_ID", ""),
                "JobName":     j.get("Job_Name", ""),
                "AppName":     j.get("Application", "Unknown"),
                "Source_File": j.get("Source_File", ""),
                "Source_Type": j.get("Source_Type", "Unknown"),
                "Platform":    phase1_job.get("Platform", ""),
                "Schedule":    phase1_job.get("Schedule", ""),
                "Owner":       phase1_job.get("Owner", ""),
                "Runtime":     phase1_job.get("Runtime", ""),
            }
            return _enrich(job_meta)

    # 2. Fall back to Phase 1 jobs list
    jobs = session.get("jobs", [])
    for j in jobs:
        if j.get("JobId") == job_id:
            job_meta = {
                "JobId":       j.get("JobId", ""),
                "JobName":     j.get("JobName", ""),
                "AppName":     j.get("AppName", "Unknown"),
                "Source_File": "",
                "Source_Type": j.get("Platform", "Unknown"),
                "Platform":    j.get("Platform", ""),
                "Schedule":    j.get("Schedule", ""),
                "Owner":       j.get("Owner", ""),
                "Runtime":     j.get("Runtime", ""),
            }
            return _enrich(job_meta)

    return _enrich({
        "JobId": job_id, "JobName": job_id, "AppName": "Unknown",
        "Source_File": "", "Source_Type": "Unknown",
        "Platform": "", "Schedule": "", "Owner": "", "Runtime": "",
    })
