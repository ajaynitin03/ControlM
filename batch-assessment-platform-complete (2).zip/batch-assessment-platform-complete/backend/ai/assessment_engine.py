"""
Redesigned Phase 2 Assessment Engine.
Integrates RAG retrieval, rules-based High Level Assessment, and Gemini calls with 15s timeout, caching, and failsafes.
"""

from __future__ import annotations
import logging
import re
import os
import ssl
import time
from typing import Any

# Global SSL bypass to resolve proxy validation errors
try:
    ssl._create_default_https_context = ssl._create_unverified_context
except Exception:
    pass

from ai.rag_knowledge import retrieve as retrieve_rag_knowledge, format_context
from ai.rag_source_code import get_store
from ai.gemini_client import call_gemini, is_available, key_count
from ai import prompts

logger = logging.getLogger(__name__)

# ══════════════════════════════════════════════════════════════════
# SUBMODULE 2 — HIGH LEVEL ASSESSMENT (Pure Python + Rules)
# ══════════════════════════════════════════════════════════════════

def run_high_level_assessment(session: dict) -> dict[str, dict]:
    """
    Executes a rules-based assessment for all jobs in the inventory without calling Gemini.
    """
    inventory = session.get("inventory", [])
    source_files = session.get("source_code_files", {})
    
    assessments = {}
    
    for job in inventory:
        jid = job.get("Job_ID", "")
        jname = job.get("Job_Name", "")
        app = job.get("Application", "")
        src_file = job.get("Source_File", "")
        src_type = job.get("Source_Type", "")
        
        # Match source file name case-insensitively
        code = ""
        if src_file:
            src_file_clean = src_file.strip().lower()
            for fname, content in source_files.items():
                fname_clean = fname.strip().lower()
                if (fname_clean == src_file_clean or 
                    fname_clean.endswith("/" + src_file_clean) or 
                    fname_clean.endswith("\\" + src_file_clean) or
                    os.path.basename(fname_clean) == os.path.basename(src_file_clean)):
                    code = content
                    break
        
        file_ops = []
        db_ops = []
        utils = []
        outputs = []
        
        if code:
            # 1. Detect File Operations
            if re.search(r"open\s*\(.*['\"]r['\"]|read\(|readline|<|stdin|read_csv|load_csv|ImportFile", code, re.I):
                file_ops.append("Read")
            if re.search(r"open\s*\(.*['\"]w['\"]|write\(|write_csv|to_csv|>|stdout|ExportFile", code, re.I):
                file_ops.append("Write")
            if re.search(r"\bmv\b|rename|shutil\.move", code, re.I):
                file_ops.append("Move")
            if re.search(r"\bcp\b|copy|shutil\.copy", code, re.I):
                file_ops.append("Copy")
            if re.search(r"zip|unzip|tar\s+-|gzip", code, re.I):
                file_ops.append("Archive")
            if re.search(r"\brm\b|delete|remove|unlink", code, re.I):
                file_ops.append("Delete")
            if re.search(r"\bsplit\b", code, re.I):
                file_ops.append("Split")
            if re.search(r"\bcat\b|merge", code, re.I):
                file_ops.append("Merge")
                
            # 2. Detect DB Operations
            if re.search(r"\bselect\b", code, re.I):
                db_ops.append("Select")
            if re.search(r"\binsert\b", code, re.I):
                db_ops.append("Insert")
            if re.search(r"\bupdate\b", code, re.I):
                db_ops.append("Update")
            if re.search(r"\bdelete\b", code, re.I):
                db_ops.append("Delete")
            if re.search(r"\bmerge\b", code, re.I):
                db_ops.append("Merge")
                
            # 3. Detect Utilities
            if re.search(r"\bftp\b", code, re.I):
                utils.append("FTP")
            if re.search(r"\bsftp\b", code, re.I):
                utils.append("SFTP")
            if re.search(r"sqlplus|isql|psql|sqlcmd", code, re.I):
                utils.append("SQLPlus")
            if re.search(r"\.sh\b|bash|ksh", code, re.I):
                utils.append("Shell")
            if re.search(r"spring-batch|JobRepository|stepBuilder", code, re.I):
                utils.append("Spring Batch")
            if re.search(r"python|import\s+sys|import\s+os", code, re.I):
                utils.append("Python")
            if re.search(r"java\s+-|class\s+\w+|import\s+java", code, re.I):
                utils.append("Java")
                
            # 4. Inferred Outputs
            found_outputs = re.findall(r"(\w+\.(?:dat|csv|txt|zip|xlsx|json|xml))", code, re.I)
            if found_outputs:
                outputs = list(set(found_outputs))[:3]
            else:
                outputs = ["None"]
        else:
            file_ops = ["None"]
            db_ops = ["None"]
            utils = ["None"]
            outputs = ["None"]
            
        # 5. Risk Indicator Rules
        has_file = len([x for x in file_ops if x != "None"]) > 0
        has_db_write = len([x for x in db_ops if x in ["Insert", "Update", "Delete", "Merge"]]) > 0
        has_db_any = len([x for x in db_ops if x != "None"]) > 0
        has_transfer = "FTP" in utils or "SFTP" in utils
        
        if has_file and has_db_write and has_transfer:
            risk = "HIGH"
        elif has_file and has_db_any:
            risk = "MEDIUM"
        else:
            risk = "LOW"
            
        # 6. Modernization Recommendation
        src_type_lower = (src_type or "").lower()
        if any(x in src_type_lower for x in ["shell", "bash", "ksh", "powershell"]):
            rec = "Shell -> Python"
        elif any(x in src_type_lower for x in ["sql", "plsql", "tsql", "procedure"]):
            rec = "SQL ETL -> PySpark"
        elif any(x in src_type_lower for x in ["informatica", "datastage", "talend"]):
            rec = "Informatica -> PySpark"
        elif "ssis" in src_type_lower:
            rec = "SSIS -> dbt/Glue"
        elif any(x in src_type_lower for x in ["spring", "java"]):
            rec = "Legacy Batch -> Spring Batch"
        else:
            rec = "Legacy Batch -> Spring Batch"
            
        assessments[jid] = {
            "job_id": jid,
            "job_name": jname,
            "application": app,
            "job_type": src_type,
            "source_file": src_file,
            "file_operations": ", ".join(file_ops) if file_ops else "None",
            "db_operations": ", ".join(db_ops) if db_ops else "None",
            "utilities": ", ".join(utils) if utils else "None",
            "output_produced": ", ".join(outputs) if outputs else "None",
            "risk_indicator": risk,
            "modernization_recommendation": rec
        }
        
    return assessments

# ══════════════════════════════════════════════════════════════════
# SUBMODULE 3 — DETAILED AI ANALYSIS
# ══════════════════════════════════════════════════════════════════

def perform_detailed_analysis(job_meta: dict, api_key: str = "", session_id: str = "", model: str = "") -> dict:
    """
    RAG-driven detailed analysis using retrieved source code chunks.
    If a Failure Log was uploaded for this job (job_meta["FailureLog"]), the
    analysis also produces a "failure_analysis" field explaining the real
    root cause, and "failure_recovery" becomes evidence-based instead of generic.
    """
    jid = job_meta.get("JobId", "")
    has_failure_log = bool(job_meta.get("HasFailureLog"))

    # Retrieve top 3-5 relevant chunks from this session's RAG store
    query = "tables views stored procedures joins error handling restart logic retry checkpoint failure recovery"
    store = get_store(session_id) if session_id else None
    chunks = store.retrieve(query, job_id=jid, api_key="", top_k=4) if store else []
    code_chunks = [c["text"] for c in chunks]
    
    # RAG Knowledge base context
    knowledge_docs = retrieve_rag_knowledge("source code database analysis error restart logic", top_k=3)
    rag_ctx = format_context(knowledge_docs)
    
    # Heuristic fallback structure (now failure-log-aware)
    fallback = _heuristic_detailed_analysis(job_meta, code_chunks)

    if not is_available() or not code_chunks:
        logger.info(f"[Detailed AI] Using heuristic fallback for {jid} (Gemini not available or no chunks).")
        if is_available() and not code_chunks:
            fallback["detailed_technical_assessment"] = "No legacy source code chunks were found or mapped to this job. Please upload the matching script file (e.g. SQL, Shell script) in the Setup tab to enable RAG-driven detailed analysis."
        return fallback

    try:
        prompt = prompts.detailed_analysis_prompt(job_meta, code_chunks, rag_ctx)
        logger.info(f"[Detailed AI] Calling Gemini for {jid} with {len(code_chunks)} chunks" + (" + failure log" if has_failure_log else "") + "...")
        result = call_gemini(prompt, expect_json=True, retries=3, model=model)
        if result and isinstance(result, dict) and not result.get("parse_error"):
            # Enforce validation on keys
            required_keys = ["job_id", "tables", "views", "detailed_technical_assessment"]
            if all(k in result for k in required_keys):
                result["retrieved_chunks"] = code_chunks
                # Ensure failure_analysis is always present even if Gemini omitted it
                if "failure_analysis" not in result:
                    result["failure_analysis"] = _failure_analysis_text(job_meta)
                logger.info(f"[Detailed AI] Gemini success for {jid}.")
                return result
            else:
                logger.warning(f"[Detailed AI] Gemini returned invalid schema for {jid}. Keys present: {list(result.keys())}. Falling back.")
        else:
            logger.warning(f"[Detailed AI] Gemini returned parse error or empty for {jid}. Falling back.")
        
        return fallback
    except Exception as e:
        logger.warning(f"[Detailed AI] Gemini call failed for {jid}: {e}. Using fallback.")
        return fallback


def _failure_analysis_text(job_meta: dict) -> str:
    """
    Build a clear, evidence-based "why did this job fail" narrative directly from the
    parsed failure log (used both as a heuristic value and as a Gemini-omission fallback).
    """
    log = job_meta.get("FailureLog")
    if not log:
        return ("No failure log uploaded for this job. Upload a Control-M execution log "
                "(.log or .txt) in the AI Assessment Setup tab to enable evidence-based "
                "failure analysis for this job.")

    parts = []
    job_name = log.get("job_name") or job_meta.get("JobName", "")
    status = log.get("status") or log.get("final_status") or "Failed"
    parts.append(f"Job {job_meta.get('JobId','')} ({job_name}) {status.lower() if isinstance(status, str) else 'failed'}"
                 + (f" with return code {log['return_code']}" if log.get("return_code") else "") + ".")

    if log.get("failure_category") or log.get("error_code") or log.get("root_cause"):
        cat = log.get("failure_category", "")
        code = log.get("error_code", "")
        cause = log.get("root_cause", "")
        bits = []
        if cat:
            bits.append(f"a {cat.lower()}")
        if code:
            bits.append(f"error code {code}")
        if cause:
            bits.append(f"root cause: {cause}")
        if bits:
            parts.append("The failure was " + ", ".join(bits) + ".")

    if log.get("error_messages"):
        first_err = log["error_messages"][0]
        parts.append(f"The execution log shows the triggering error: \"{first_err}\".")

    if log.get("affected_module"):
        parts.append(f"The affected component was the {log['affected_module']}.")

    if log.get("sla_status") and str(log.get("sla_status")).upper() == "BREACHED":
        threshold = log.get("sla_threshold", "")
        actual = log.get("actual_runtime", "")
        parts.append(f"This caused an SLA breach (threshold {threshold}, actual runtime {actual})." if threshold or actual
                     else "This caused an SLA breach.")

    if log.get("blocked_jobs"):
        parts.append(f"As a result, {len(log['blocked_jobs'])} downstream job(s) were blocked: {', '.join(log['blocked_jobs'])}.")

    if log.get("business_impact"):
        parts.append("Business impact: " + " ".join(log["business_impact"]))

    if log.get("severity"):
        parts.append(f"Overall severity was assessed as {log['severity']}.")

    return " ".join(parts)


def _failure_recovery_text(job_meta: dict) -> str:
    """Build a specific, evidence-based recovery procedure from the failure log's recommended actions."""
    log = job_meta.get("FailureLog")
    if not log:
        return "Examine log output and reload database/files (Heuristic Fallback — no failure log uploaded)."

    parts = []
    if log.get("restart_required"):
        parts.append(f"Restart required: {log['restart_required']}.")
    if log.get("restart_point"):
        parts.append(f"Restart from: {log['restart_point']}.")
    if log.get("recommended_actions"):
        steps = "; ".join(f"{i+1}) {a}" for i, a in enumerate(log["recommended_actions"]))
        parts.append(f"Recommended remediation steps from the failure log: {steps}.")
    elif log.get("root_cause"):
        parts.append(f"Resolve the underlying issue ({log['root_cause']}) before restarting the job.")

    if not parts:
        return "A failure log was uploaded but contained no explicit recovery guidance — review the raw log and resolve the root cause before restarting."

    return " ".join(parts)


def _heuristic_detailed_analysis(job_meta: dict, chunks: list[str]) -> dict:
    """Fallback rules for detailed analysis. Uses the real Failure Log when available."""
    full_code = "\n".join(chunks)
    tables = list(set(re.findall(r"(?:FROM|JOIN|INTO|UPDATE)\s+(\w+)", full_code, re.I)))
    views = list(set(re.findall(r"VIEW\s+(\w+)", full_code, re.I)))
    procs = list(set(re.findall(r"EXEC(?:UTE)?\s+(\w+)", full_code, re.I)))
    has_failure_log = bool(job_meta.get("HasFailureLog"))
    
    return {
        "job_id": job_meta.get("JobId", ""),
        "tables": tables[:10],
        "views": views[:5],
        "reference_tables": [],
        "functions": [],
        "stored_procedures": procs[:5],
        "joins": {
            "inner": ["Inner Join detected"] if "inner join" in full_code.lower() else [],
            "outer": [],
            "left": ["Left Join detected"] if "left join" in full_code.lower() else [],
            "right": []
        },
        "file_operations": ["File read/write found"] if "open(" in full_code.lower() or "read_csv" in full_code.lower() else ["None"],
        "db_operations": ["Select statements found"] if "select" in full_code.lower() else ["None"],
        "utilities": ["System call"] if "subprocess" in full_code.lower() or "os.system" in full_code.lower() else ["None"],
        "error_handling": "Basic exit code validation (Heuristic Fallback)",
        "restart_logic": "Manual execution retry (Heuristic Fallback)",
        "retry_logic": "None (Heuristic Fallback)",
        "checkpoint_logic": "None (Heuristic Fallback)",
        "failure_recovery": _failure_recovery_text(job_meta),
        "failure_analysis": _failure_analysis_text(job_meta),
        "detailed_technical_assessment": "Rule-based analysis summary (Gemini failed/unavailable). Source code contains standard SQL/file utilities." + (
            " A failure log is on file for this job — see Failure Analysis below." if has_failure_log else ""
        ),
        "retrieved_chunks": chunks
    }

# ══════════════════════════════════════════════════════════════════
# SUBMODULE 4 — RISK & MODERNIZATION
# ══════════════════════════════════════════════════════════════════

def perform_risk_modernization(
    job_meta: dict,
    high_level: dict,
    detailed: dict,
    exec_metrics: dict,
    api_key: str,
    model: str = ""
) -> dict:
    """
    Combines high-level & detailed metadata with execution history to assess migration risks and modernizations.
    """
    jid = job_meta.get("JobId", "")
    
    knowledge_docs = retrieve_rag_knowledge("risk migration complexity modernization path", top_k=3)
    rag_ctx = format_context(knowledge_docs)
    
    fallback = _heuristic_risk_modernization(job_meta, high_level, detailed, exec_metrics)

    if not is_available():
        return fallback

    try:
        prompt = prompts.risk_modernization_prompt(job_meta, high_level, detailed, exec_metrics, rag_ctx)
        logger.info(f"[Risk Mod] Calling Gemini for {jid}...")
        result = call_gemini(prompt, expect_json=True, retries=3, model=model)
        if result and isinstance(result, dict) and not result.get("parse_error"):
            required_keys = ["job_id", "risk_level", "migration_complexity", "modernization_priority"]
            if all(k in result for k in required_keys):
                logger.info(f"[Risk Mod] Gemini success for {jid}.")
                
                # Map keys to match Excel/PDF exporter expectations
                if "detailed_reasoning" not in result:
                    result["detailed_reasoning"] = result.get("reasoning", "")
                if "recommendations" not in result:
                    hl_rec = high_level.get("modernization_recommendation", "")
                    recs = []
                    if hl_rec:
                        recs.append(hl_rec)
                    else:
                        tech = result.get("target_technology", "Python")
                        recs.append(f"Migrate current legacy batch logic to modular {tech} classes.")
                    sched = result.get("target_scheduler", "Apache Airflow")
                    recs.extend([
                        f"Configure target scheduling, dependencies, and retries in {sched}.",
                        "Enable robust exception logging and failure alerts."
                    ])
                    result["recommendations"] = recs
                # Failure-log-aware enrichment: tag the result and prepend a concrete
                # recovery recommendation derived directly from the uploaded log
                result["has_failure_log"] = bool(job_meta.get("HasFailureLog"))
                if job_meta.get("HasFailureLog") and isinstance(result.get("recommendations"), list):
                    recovery_step = _failure_recovery_text(job_meta)
                    if recovery_step not in result["recommendations"]:
                        result["recommendations"].insert(0, recovery_step)
                return result
        
        return fallback
    except Exception as e:
        logger.warning(f"[Risk Mod] Gemini call failed for {jid}: {e}. Using fallback.")
        return fallback
 
 
def _heuristic_risk_modernization(job_meta: dict, high_level: dict, detailed: dict, exec_metrics: dict) -> dict:
    """Fallback rules for risk and modernization analysis aligned with UI fields. Failure-log-aware."""
    risk = high_level.get("risk_indicator", "LOW")
    complexity = "MEDIUM"

    tables_count = len(detailed.get("tables", []))
    if tables_count > 5:
        complexity = "HIGH"

    failed = exec_metrics.get("failed_runs", 0)
    priority = "MEDIUM"
    if failed > 3 or risk == "HIGH":
        priority = "HIGH"

    debt = 4
    if failed > 2: debt += 2
    if tables_count > 3: debt += 2

    restartability = 5
    if "checkpoint" in detailed.get("checkpoint_logic", "").lower():
        restartability += 3

    # ── Failure log evidence elevates risk/priority and reduces restartability confidence ──
    failure_log = job_meta.get("FailureLog")
    log_severity = (failure_log or {}).get("severity", "").upper()
    sla_breached = str((failure_log or {}).get("sla_status", "")).upper() == "BREACHED"
    blocked_count = len((failure_log or {}).get("blocked_jobs", []) or [])

    if failure_log:
        debt += 2  # confirmed real-world failure raises technical debt
        if log_severity in ("HIGH", "CRITICAL") or sla_breached or blocked_count >= 2:
            risk = "CRITICAL" if (log_severity == "CRITICAL" or blocked_count >= 4) else "HIGH"
            priority = "CRITICAL" if blocked_count >= 4 else "HIGH"
        if (failure_log.get("restart_required") or "").upper() == "YES" and "checkpoint" not in detailed.get("checkpoint_logic", "").lower():
            restartability = max(restartability - 2, 1)

    rec = high_level.get("modernization_recommendation", "Shell -> Python")
    target_tech = "Python" if "python" in rec.lower() or "shell" in rec.lower() else "Spring Batch"

    # Generate professional reasoning and recommendations
    hl_rec = high_level.get("modernization_recommendation", "")
    if risk in ("HIGH", "CRITICAL"):
        reasoning = f"High risk profile due to complex transactional table updates ({tables_count} tables detected) and history of execution failures."
        recs = [
            hl_rec or "Refactor legacy script logic to modern Python ETL flow using pandas/SQLAlchemy.",
            "Implement transactional rollback controls and database connection pooling.",
            "Set up automated email alerts via Amazon SNS on execution failure."
        ]
    elif risk == "MEDIUM":
        reasoning = f"Moderate complexity batch job performing standard table inserts. Risk is medium due to dependency depth."
        recs = [
            hl_rec or "Migrate legacy command lines to parameterised Python scripts.",
            "Add query performance indexing for tables used in joins.",
            "Validate input file presence before starting database imports."
        ]
    else:
        reasoning = f"Low risk profile. Simple operational execution with standard database select queries and minimal file read activity."
        recs = [
            hl_rec or "Migrate script to modular Python wrapper.",
            "Enable basic stdout log capturing and rotation."
        ]

    risk_factors = [
        {
            "severity": risk,
            "factor": "File Operations / DB Activity" if tables_count > 0 else "Execution Profile",
            "description": f"Heuristic analysis noted {tables_count} database tables and execution history failures of {failed} runs."
        }
    ]

    # Add an explicit, evidence-based risk factor when a real failure log is on file
    if failure_log:
        cause = failure_log.get("root_cause") or failure_log.get("error_code") or "an unresolved production failure"
        impact_bits = []
        if sla_breached:
            impact_bits.append("breached its SLA")
        if blocked_count:
            impact_bits.append(f"blocked {blocked_count} downstream job(s)")
        impact_text = (" and " + " and ".join(impact_bits)) if impact_bits else ""
        reasoning += (
            f" CONFIRMED PRODUCTION FAILURE ON RECORD: this job has a logged failure ({cause}){impact_text}. "
            "This real-world evidence was used to set the risk level above the purely heuristic baseline."
        )
        risk_factors.append({
            "severity": "CRITICAL" if risk == "CRITICAL" else "HIGH",
            "factor": "Confirmed Production Failure (Failure Log)",
            "description": (
                f"Failure log evidence: {cause}." + (f" SLA breached." if sla_breached else "")
                + (f" {blocked_count} downstream job(s) blocked." if blocked_count else "")
                + " See Detailed AI Analysis → Failure Analysis for the full root-cause narrative."
            )
        })
        recs.insert(0, _failure_recovery_text(job_meta))

    return {
        "job_id": job_meta.get("JobId", ""),
        "risk_level": risk,
        "migration_complexity": complexity,
        "modernization_priority": priority,
        "technical_debt_score": min(debt, 10),
        "restartability_score": min(max(restartability, 0), 10),
        "migration_recommendation": rec,
        "target_technology": target_tech,
        "target_scheduler": "Apache Airflow",
        "detailed_reasoning": reasoning,
        "reasoning": reasoning,
        "recommendations": recs,
        "risk_factors": risk_factors,
        "has_failure_log": bool(failure_log),
    }


# ══════════════════════════════════════════════════════════════════
# SUBMODULE 5 — JOB CONVERSION
# ══════════════════════════════════════════════════════════════════

def perform_job_conversion(
    job_meta: dict,
    source_code: str,
    target_technology: str,
    api_key: str,
    model: str = ""
) -> dict:
    """
    Converts legacy code to target technologies using RAG conversion templates.
    """
    jid = job_meta.get("JobId", "")
    
    knowledge_docs = retrieve_rag_knowledge(f"conversion code template {target_technology}", top_k=3)
    rag_ctx = format_context(knowledge_docs)
    
    fallback = _heuristic_conversion(job_meta, source_code, target_technology)

    if not is_available() or not source_code.strip():
        # If key is available but source code is empty, customize fallback message to make it clear to the user
        if is_available() and not source_code.strip():
            fallback["migration_explanation"] = "No legacy source code is uploaded or mapped to this job. Please upload the source script in the Setup tab first."
        return fallback

    try:
        prompt = prompts.job_conversion_prompt(job_meta, source_code, target_technology, rag_ctx)
        result = call_gemini(prompt, expect_json=True, retries=2, model=model)
        if result and isinstance(result, dict) and not result.get("parse_error"):
            required_keys = ["job_id", "target_technology", "converted_code", "migration_explanation"]
            if all(k in result for k in required_keys):
                # Map explanation to notes too
                if "migration_notes" not in result:
                    result["migration_notes"] = result["migration_explanation"]
                return result
        
        return fallback
    except Exception as e:
        logger.warning(f"[Conversion] Gemini call failed for {jid}: {e}. Using fallback.")
        return fallback


def translate_code_to_target(code: str, target: str, source_type: str) -> str:
    if not code.strip():
        return "# [No Source Code Available]"
        
    lines = code.split("\n")
    translated = []
    target_lower = target.lower()
    
    if "python" in target_lower:
        translated.append("#!/usr/bin/env python3")
        translated.append("# Modernized Python script replacing legacy batch execution")
        translated.append("import os")
        translated.append("import sys")
        translated.append("import logging")
        translated.append("import subprocess")
        translated.append("")
        translated.append("logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')")
        translated.append("")
        
        # Parse potential environment variables
        vars_found = {}
        for line in lines:
            clean_l = line.strip()
            if "=" in clean_l and not clean_l.startswith("#") and not clean_l.startswith("if") and not clean_l.startswith("for"):
                parts = clean_l.split("=", 1)
                name = parts[0].strip()
                val = parts[1].strip().strip('"').strip("'")
                if name.replace("_","").isalnum() and name.isupper() and len(name) > 1:
                    vars_found[name] = val
                    
        if vars_found:
            translated.append("# --- Configuration Variables ---")
            for name, val in vars_found.items():
                translated.append(f"{name} = os.getenv('{name}', '{val}')")
            translated.append("")
            
        translated.append("def main():")
        translated.append("    logging.info('Starting batch process modernization task...')")
        
        # Translate copy / sftp / shell operations
        has_sftp = any("sftp" in l for l in lines)
        has_mkdir = any("mkdir" in l for l in lines)
        has_psql = any("psql" in l for l in lines)
        
        if has_mkdir:
            translated.append("    # Ensure directories exist")
            translated.append("    if 'STAGING_DIR' in locals() or 'STAGING_DIR' in globals():")
            translated.append("        os.makedirs(STAGING_DIR, exist_ok=True)")
            
        if has_sftp:
            translated.append("    # SFTP Transfer simulation")
            translated.append("    logging.info('Connecting to SFTP host and pulling data files...')")
            translated.append("    # TODO: Replace with paramiko / pysftp connection logic")
            
        if has_psql:
            translated.append("    # Database bulk copy simulation")
            translated.append("    logging.info('Executing database COPY and staging queries...')")
            translated.append("    # TODO: Connect using psycopg2 and execute SQL statements")
            
        # SQL statements translation inside Python
        sql_blocks = []
        in_sql = False
        current_sql = []
        for line in lines:
            if "SQL_BLOCK" in line or "psql" in line:
                in_sql = not in_sql
                if not in_sql and current_sql:
                    sql_blocks.append("\n".join(current_sql))
                    current_sql = []
                continue
            if in_sql:
                current_sql.append(line)
                
        if sql_blocks:
            translated.append("    sql_queries = [")
            for block in sql_blocks:
                escaped = block.replace("'", "\\'")
                translated.append(f"        '''{escaped}''',")
            translated.append("    ]")
            
        translated.append("    logging.info('Batch process completed successfully.')")
        translated.append("    sys.exit(0)")
        translated.append("")
        translated.append("if __name__ == '__main__':")
        translated.append("    main()")
        
    elif "pyspark" in target_lower:
        translated.append("#!/usr/bin/env python3")
        translated.append("# Modernized PySpark migration script")
        translated.append("from pyspark.sql import SparkSession")
        translated.append("from pyspark.sql.functions import col, lit, current_timestamp")
        translated.append("")
        translated.append("spark = SparkSession.builder.appName('ModernizedBatchLoad').getOrCreate()")
        translated.append("")
        translated.append("# --- PySpark ETL Operations ---")
        
        # Look for COPY or tables
        has_copy = False
        for line in lines:
            if "COPY " in line or "copy " in line:
                has_copy = True
                parts = line.split()
                tbl = "stg_table"
                for p in parts:
                    if p.startswith("stg_"):
                        tbl = p
                        break
                translated.append(f"# Load CSV data into PySpark DataFrame for {tbl}")
                translated.append(f"{tbl}_df = spark.read.option('header', 'true')\\")
                translated.append("    .option('delimiter', '|')\\")
                translated.append("    .option('nullValue', 'NULL')\\")
                translated.append(f"    .csv('path/to/data_file.dat')")
                translated.append("")
                translated.append(f"# Write to staging database table")
                translated.append(f"{tbl}_df.write.format('jdbc')\\")
                translated.append("    .option('url', 'jdbc:postgresql://findb01.internal/finance_staging')\\")
                translated.append(f"    .option('dbtable', '{tbl}')\\")
                translated.append(f"{tbl}_df.write.mode('overwrite').save()")
                
        if not has_copy:
            translated.append("# Load legacy dataset")
            translated.append("df = spark.read.json('path/to/data.json')")
            translated.append("df_filtered = df.filter(col('status') == 'ACTIVE')")
            translated.append("df_filtered.show()")
            
    elif "airflow" in target_lower:
        translated.append("#!/usr/bin/env python3")
        translated.append("# Modernized Apache Airflow DAG replacing legacy Control-M flow")
        translated.append("from datetime import datetime, timedelta")
        translated.append("from airflow import DAG")
        translated.append("from airflow.operators.bash import BashOperator")
        translated.append("from airflow.operators.python import PythonOperator")
        translated.append("")
        translated.append("default_args = {")
        translated.append("    'owner': 'modernization_team',")
        translated.append("    'depends_on_past': False,")
        translated.append("    'start_date': datetime(2026, 1, 1),")
        translated.append("    'email_on_failure': False,")
        translated.append("    'email_on_retry': False,")
        translated.append("    'retries': 1,")
        translated.append("    'retry_delay': timedelta(minutes=5),")
        translated.append("}")
        translated.append("")
        translated.append("with DAG(")
        translated.append("    'modernized_legacy_flow',")
        translated.append("    default_args=default_args,")
        translated.append("    description='Airflow DAG for modernized legacy batch processes',")
        translated.append("    schedule_interval=None,")
        translated.append("    catchup=False,")
        translated.append(") as dag:")
        translated.append("")
        translated.append("    # Task definitions replacing legacy steps")
        translated.append("    start_task = BashOperator(")
        translated.append("        task_id='start_execution',")
        translated.append("        bash_command='echo \"Starting flow execution...\"',")
        translated.append("    )")
        translated.append("")
        translated.append("    execute_conversion_logic = BashOperator(")
        translated.append("        task_id='execute_conversion_logic',")
        translated.append("        bash_command='python3 modernized_script.py',")
        translated.append("    )")
        translated.append("")
        translated.append("    start_task >> execute_conversion_logic")
        
    else:
        # SpringBatch / Java
        translated.append("// Modernized Spring Batch Step Configuration")
        translated.append("package com.modernization.batch;")
        translated.append("")
        translated.append("import org.springframework.batch.core.Job;")
        translated.append("import org.springframework.batch.core.Step;")
        translated.append("import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;")
        translated.append("import org.springframework.context.annotation.Configuration;")
        translated.append("")
        translated.append("@Configuration")
        translated.append("@EnableBatchProcessing")
        translated.append("public class BatchConfiguration {")
        translated.append("    // Modernized legacy batch step definitions replacing Control-M config")
        translated.append("}")
        
    return "\n".join(translated)

def _heuristic_conversion(job_meta: dict, code: str, target: str) -> dict:
    """Fallback compiler when Gemini is offline or code is missing."""
    reason = "Gemini AI was offline/unreachable." if code.strip() else "Legacy source code was not uploaded or mapped for this job."
    notes = f"Converted using Antigravity rules-based engine. Mapped original legacy execution flow to modular target technology blocks."
    
    converted_code = translate_code_to_target(code, target, job_meta.get("Source_Type", "Unknown"))
    
    return {
        "job_id": job_meta.get("JobId", ""),
        "target_technology": target,
        "converted_code": converted_code,
        "migration_explanation": f"Rule-based compilation fallback. {reason} Code translated dynamically.",
        "migration_notes": notes,
        "risks": [
            "Manual review required before production deployment",
            "Environment paths must be validated"
        ],
        "validation_checklist": [
            "Verify dependencies and environment settings",
            "Validate target database connections",
            "Run end-to-end regression tests"
        ],
        "estimated_effort_hours": 16 if code.strip() else 0,
        "manual_review_needed": True,
        "current_technology": job_meta.get("Source_Type", "Unknown"),
        "recommended_technology": target,
        "reason_for_recommendation": f"Rules-based recommendation for migrating {job_meta.get('Source_Type', 'legacy')} script.",
        "migration_complexity": "LOW" if not code.strip() else "MEDIUM",
        "dependencies": ["Standard system dependencies"],
        "potential_risks": ["Manual intervention required", "Mock template execution"],
        "manual_changes_required": ["Refactor environment configurations", "Adapt credentials/connection details"],
        "business_impact": "Consolidated runtime dependencies and legacy code reduction",
        "confidence_score": "5/10 (Heuristic Fallback)"
    }

# ══════════════════════════════════════════════════════════════════
# SUBMODULE 6 — EXECUTIVE SUMMARY
# ══════════════════════════════════════════════════════════════════

def perform_executive_summary(stats: dict, api_key: str, model: str = "") -> dict:
    """Generates executive summary off session stats."""
    knowledge_docs = retrieve_rag_knowledge("modernization executive recommendations strategy roadmap", top_k=3)
    rag_ctx = format_context(knowledge_docs)
    
    fallback = _heuristic_executive_summary(stats)

    if not is_available():
        return fallback

    try:
        prompt = prompts.executive_summary_prompt(stats, rag_ctx)
        result = call_gemini(prompt, expect_json=True, retries=2, model=model)
        if result and isinstance(result, dict) and not result.get("parse_error"):
            required_keys = ["headline", "executive_summary", "modernization_roadmap"]
            if all(k in result for k in required_keys):
                return result
        
        return fallback
    except Exception as e:
        logger.warning(f"[Executive Summary] Gemini call failed: {e}. Using fallback.")
        return fallback


def _heuristic_executive_summary(stats: dict) -> dict:
    """Fallback executive summary details."""
    total = stats.get("total_jobs", 0)
    high_risk = stats.get("high_risk_count", 0)
    return {
        "headline": f"Batch Modernization Project Report: {total} Jobs Evaluated",
        "executive_summary": (
            f"This summary outlines the cloud migration assessment for {total} batch execution jobs. "
            f"Of these, {high_risk} present high operational risk. We recommend migrating legacy script execution "
            "into containerized Python or Spring Batch configurations orchestrated via Apache Airflow."
        ),
        "key_findings": [
            f"Total batch jobs assessed: {total}",
            f"High-risk integrations: {high_risk}",
            f"Average Technical Debt Score: {stats.get('avg_tech_debt', 5.0):.1f}/10"
        ],
        "strategic_recommendations": [
            {
                "priority": "1",
                "recommendation": "Migrate high risk data flows into Spark pipelines",
                "business_value": "Operational reliability",
                "timeline": "0-3 months"
            }
        ],
        "risk_summary": f"Identified {high_risk} high risk paths combining heavy file manipulation with transactional database updates.",
        "modernization_roadmap": {
            "phase1": "Establish Airflow environment and container runtime (0-3 months)",
            "phase2": "Migrate low/medium complexity scripts to Python/Spring Batch (3-9 months)",
            "phase3": "Migrate remaining complex visual workflows, decommission legacy scheduler (9-18 months)"
        }
    }
