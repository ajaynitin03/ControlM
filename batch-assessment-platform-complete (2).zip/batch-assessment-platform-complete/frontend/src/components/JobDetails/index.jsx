import { useState, useRef, useEffect } from 'react'
import { X, Zap, Target, ArrowDownToLine, ArrowUpFromLine, Info } from 'lucide-react'
import { useApp } from '../../hooks/useAppState'
import { getImpactAnalysis, getJobCriticalityDetail } from '../../services/api'
import { highlightImpact, highlightCriticalPath, resetHighlight } from '../../utils/cytoscapeBuilder'
import toast from 'react-hot-toast'
import CriticalityBadge from '../CriticalityBadge'

const HEADER_THEME = {
  Critical: { grad: 'linear-gradient(135deg, #7f1d1d, #991b1b)', accent: '#fca5a5' },
  High:     { grad: 'linear-gradient(135deg, #991b1b, #b91c1c)', accent: '#fecaca' },
  Medium:   { grad: 'linear-gradient(135deg, #92400e, #b45309)', accent: '#fde68a' },
  Low:      { grad: 'linear-gradient(135deg, #065f46, #047857)', accent: '#a7f3d0' },
}

export default function JobDetails({ cyRef }) {
  const { state, dispatch } = useApp()
  const { selectedNode, sessionId, graphData } = state
  const [activeTab, setActiveTab] = useState('overview')
  const [loading, setLoading] = useState(false)
  const [apiData, setApiData] = useState(null)

  const wrapRef = useRef(null)

  useEffect(() => {
    if (!sessionId || !selectedNode?.id) {
      setApiData(null)
      return
    }
    setLoading(true)
    getJobCriticalityDetail(sessionId, selectedNode.id)
      .then(res => {
        setApiData(res.data)
      })
      .catch(err => {
        console.error(err)
      })
      .finally(() => setLoading(false))
  }, [sessionId, selectedNode?.id])

  if (!selectedNode) return null
  const nd = selectedNode

  const runImpact = async () => {
    try {
      const res = await getImpactAnalysis(sessionId, nd.id)
      const affected = res.data.affected_job_ids || []
      if (cyRef.current) {
        highlightImpact(cyRef.current, [nd.id, ...affected])
        toast.success(`Downstream impact analysis complete — ${affected.length} jobs affected`)
      }
    } catch (e) {
      toast.error('Impact analysis failed')
    }
  }

  const runCriticalPath = () => {
    if (!graphData?.critical_path?.length) {
      toast.error('No critical path available')
      return
    }
    if (cyRef.current) {
      highlightCriticalPath(cyRef.current, graphData.critical_path)
      toast.success(`Critical path highlighted — ${graphData.critical_path.length} jobs`)
    }
  }

  const band = nd.criticality_band || (nd.criticality === 'HIGH' ? 'High' : nd.criticality === 'MEDIUM' ? 'Medium' : 'Low')
  const theme = HEADER_THEME[band] || HEADER_THEME.Low

  const jd = apiData?.job_details || {}
  const critScore = apiData?.score ?? nd.criticality_score ?? 0
  const critFactors = apiData?.factors || nd.criticality_factors || []
  const critReason = apiData?.reason || nd.criticality_reason || ''

  const fields = [
    { label: 'Job ID',       value: jd.job_id || nd.id },
    { label: 'App Name',     value: jd.app_name || nd.app_name },
    { label: 'Platform',     value: jd.platform || nd.platform },
    { label: 'Schedule',     value: jd.schedule || nd.schedule },
    { label: 'Runtime',      value: jd.runtime || nd.runtime ? `${jd.runtime || nd.runtime} min` : null },
    { label: 'Priority',     value: jd.priority || nd.priority },
    { label: 'Owner',        value: jd.owner || nd.owner },
    { label: 'Status',       value: jd.status || nd.status },
    { label: 'Folder',       value: jd.folder || nd.folder },
    { label: 'Description',  value: jd.description || nd.description },
  ].filter((f) => f.value)

  const onCriticalPath = graphData?.critical_path?.includes(nd.id)

  return (
    <div
      ref={wrapRef}
      className="absolute right-4 top-4 w-80 rounded-2xl overflow-hidden z-20 animate-scaleIn card shadow-2xl"
      style={{
        border: '1px solid var(--border-color)',
      }}
    >
      {/* Header — gradient by criticality */}
      <div style={{ background: theme.grad, padding: '14px 16px' }} className="relative">
        {onCriticalPath && (
          <div className="absolute top-2 right-9 flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold"
               style={{ background: 'rgba(251,191,36,0.22)', color: '#fde68a', border: '1px solid rgba(251,191,36,0.4)' }}>
            <Target size={9} /> On Critical Path
          </div>
        )}
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0">
            <CriticalityBadge source={nd} />
          </div>
          <button
            onClick={() => dispatch({ type: 'SET_SELECTED_NODE', payload: null })}
            className="text-white/70 hover:text-white flex-shrink-0 transition-colors duration-150 hover:rotate-90 transform"
            style={{ transitionProperty: 'color, transform', background: 'none', border: 'none', cursor: 'pointer' }}
          >
            <X size={16} />
          </button>
        </div>
        <div className="mt-2">
          <p className="text-sm font-bold text-white truncate leading-tight">{nd.label}</p>
          <p className="text-[11px] mt-0.5 font-mono" style={{ color: theme.accent, opacity: 0.9 }}>{nd.id}</p>
        </div>
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', borderBottom: '1px solid var(--border-color)', background: 'var(--bg-table-hdr)' }}>
        <button
          onClick={() => setActiveTab('overview')}
          style={{
            flex: 1, padding: '10px 0', border: 'none', background: 'transparent',
            borderBottom: activeTab === 'overview' ? '2px solid #2563eb' : '2px solid transparent',
            color: activeTab === 'overview' ? '#2563eb' : 'var(--text-secondary)',
            fontWeight: activeTab === 'overview' ? 700 : 500, fontSize: 12, cursor: 'pointer'
          }}
        >
          Overview
        </button>
        <button
          onClick={() => setActiveTab('impact')}
          style={{
            flex: 1, padding: '10px 0', border: 'none', background: 'transparent',
            borderBottom: activeTab === 'impact' ? '2px solid #2563eb' : '2px solid transparent',
            color: activeTab === 'impact' ? '#2563eb' : 'var(--text-secondary)',
            fontWeight: activeTab === 'impact' ? 700 : 500, fontSize: 12, cursor: 'pointer'
          }}
        >
          Impact & Path
        </button>
      </div>

      {/* Content Panels */}
      {activeTab === 'overview' && (
        <div style={{ padding: '12px 14px', maxHeight: '340px', overflowY: 'auto' }}>
          {loading ? (
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: 80, fontSize: 12, color: 'var(--text-secondary)' }}>
              Loading job details...
            </div>
          ) : (
            <>
              {/* Job Details Section */}
              <div style={{ fontSize: 10, fontWeight: 700, color: 'var(--text-secondary)', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: 8 }}>
                Job Details
              </div>
              <div className="space-y-2 mb-4">
                {fields.map(({ label, value }) => (
                  <div key={label}>
                    <p className="text-[10px] text-gray-400 font-semibold uppercase tracking-wider">{label}</p>
                    <p className="text-xs text-gray-800 font-medium break-all mt-0.5" style={{ color: 'var(--text-primary)' }}>{value}</p>
                  </div>
                ))}
              </div>

              {/* Criticality Breakdown Section */}
              <div style={{ borderTop: '1px solid var(--border-color)', paddingTop: 10 }}>
                <div style={{ fontSize: 10, fontWeight: 700, color: 'var(--text-secondary)', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: 8 }}>
                  Criticality Breakdown (Score: {critScore})
                </div>
                
                <div className="space-y-1.5 mb-3">
                  {critFactors.map(f => (
                    <div key={f.factor} style={{ fontSize: 11, display: 'flex', alignItems: 'start', gap: 6 }}>
                      <span style={{ color: f.triggered ? '#10b981' : 'var(--text-tertiary)', fontWeight: 700 }}>
                        {f.triggered ? '✓' : '–'}
                      </span>
                      <span style={{ color: f.triggered ? 'var(--text-primary)' : 'var(--text-secondary)' }}>
                        {f.detail}
                        {f.triggered && f.points > 0 && (
                          <span style={{ color: '#d97706', fontFamily: 'monospace', marginLeft: 4 }}>(+{f.points})</span>
                        )}
                      </span>
                    </div>
                  ))}
                </div>

                {critReason && (
                  <div style={{ background: '#fffbeb', border: '1px solid #fde68a', borderRadius: 8, padding: '8px 10px', display: 'flex', gap: 6, alignItems: 'start' }}>
                    <Info size={12} className="text-amber-600 flex-shrink-0 mt-0.5" />
                    <p style={{ fontSize: 10.5, color: '#92400e', lineHeight: 1.5, margin: 0 }}>{critReason}</p>
                  </div>
                )}
              </div>
            </>
          )}
        </div>
      )}

      {activeTab === 'impact' && (
        <div style={{ padding: '12px 14px' }}>
          {/* Fan metrics */}
          <div className="grid grid-cols-2 gap-2 mb-3">
            <div className="rounded-xl p-3 text-center" style={{ background: '#eff4ff', border: '1px solid #dbeafe' }}>
              <div className="flex items-center justify-center gap-1 mb-1">
                <ArrowDownToLine size={11} className="text-brand-500" />
              </div>
              <p className="text-xl font-extrabold font-mono text-brand-700 leading-none">{nd.fan_in ?? 0}</p>
              <p className="text-[10px] text-brand-500 font-semibold uppercase tracking-wide mt-1">Fan-in</p>
            </div>
            <div className="rounded-xl p-3 text-center" style={{ background: '#f5f3ff', border: '1px solid #ede9fe' }}>
              <div className="flex items-center justify-center gap-1 mb-1">
                <ArrowUpFromLine size={11} className="text-violet-500" />
              </div>
              <p className="text-xl font-extrabold font-mono text-violet-700 leading-none">{nd.fan_out ?? 0}</p>
              <p className="text-[10px] text-violet-500 font-semibold uppercase tracking-wide mt-1">Fan-out</p>
            </div>
          </div>

          <div style={{ borderTop: '1px solid var(--border-color)', paddingTop: 10 }}>
            <div style={{ fontSize: 10, fontWeight: 700, color: 'var(--text-secondary)', letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: 8 }}>
              Dependency & Path Options
            </div>
            <div className="flex flex-col gap-2">
              <button
                onClick={runImpact}
                className="btn-primary flex items-center justify-center gap-1.5 text-xs py-2 w-full"
                style={{ border: 'none', cursor: 'pointer' }}
              >
                <Zap size={12} />
                Run Downstream Impact Analysis
              </button>
              <button
                onClick={runCriticalPath}
                className="flex items-center justify-center gap-1.5 text-xs py-2 rounded-lg font-semibold text-amber-700 bg-amber-50 border border-amber-200 hover:bg-amber-100 transition-all duration-150 w-full"
                style={{ cursor: 'pointer' }}
              >
                <Target size={12} />
                Highlight Critical Path
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
